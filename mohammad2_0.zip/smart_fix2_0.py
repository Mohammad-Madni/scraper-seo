import os, csv, re, json, time, base64
import asyncio
import aiohttp
import aiofiles
from concurrent.futures import ThreadPoolExecutor
from base import Helper
from itertools import cycle

# Import all API credentials from config
from config import USERNAME, PASSWORD, USERNAME1, PASSWORD1

# --- تنظیمات ---
MIN_SIZE_KB = 10 

DIRECTORY_DOMAINS = [
    'hipages.com.au', 'yelp.com', 'yelp.com.au', 'yellowpages.com.au', 
    'truelocal.com.au', 'facebook.com', 'instagram.com', 'starofservice.com.au',
    'checkatrade.com', 'buy.nsw.gov.au', 'localsearch.com.au', 'au.nextdoor.com', 'www.oneflare.com.au'
]

# Multiple API credentials - add more as needed
API_CREDENTIALS = [
    {'username': USERNAME, 'password': PASSWORD},
    {'username': USERNAME1, 'password': PASSWORD1},
    # Add more credentials here as needed
]

# ✅ NEW: Retry configuration
MAX_RETRIES = 5  # Maximum retry attempts
INITIAL_WAIT = 120  # Initial wait time in seconds (2 minutes)
MAX_WAIT = 600  # Maximum wait time (10 minutes)

class SmartFixer(Helper):
    def __init__(self):
        super().__init__(base_output_folder="parsed_content_markdowns")
        self.report_csv = os.path.join(self.base_output_folder, "_final_scan_report.csv")
        self.executor = ThreadPoolExecutor(max_workers=10)
        
        # Create headers for each API credential
        self.api_headers = self._setup_multiple_apis()
        
        # Create locks for each API to prevent rate limiting
        self.api_locks = [asyncio.Lock() for _ in self.api_headers]
        
        # Track API usage statistics
        self.api_stats = [{'posted': 0, 'fetched': 0, 'errors': 0, 'retries': 0} for _ in self.api_headers]

    def _setup_multiple_apis(self):
        """Setup authentication headers for all API credentials"""
        headers_list = []
        
        print(f"🔐 Setting up {len(API_CREDENTIALS)} API accounts...")
        
        for i, cred in enumerate(API_CREDENTIALS):
            auth_str = f"{cred['username']}:{cred['password']}"
            token = base64.b64encode(auth_str.encode()).decode()
            
            headers = {
                'Authorization': f'Basic {token}',
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            headers_list.append(headers)
            print(f"   ✓ API #{i+1} configured")
        
        return headers_list

    def clean_target_url(self, url):
        """اصلاح یو‌ار‌ال مخصوص سایت Empire Roofing و حذف .php"""
        if "empireroofing.com.au" in url.lower():
            clean_url = re.sub(r'\.php$', '', url.strip())
            return clean_url
        return url.strip()

    async def process_file_async(self, file_path):
        """Process a single file asynchronously"""
        try:
            file_size = os.path.getsize(file_path) / 1024
            
            if file_size >= MIN_SIZE_KB:
                return None
                
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                content = await f.read()
                data = json.loads(content)
                raw_url = data.get('data', {}).get('start_url')
            
            if "http" not in raw_url.lower():
                return None
                
            final_url = self.clean_target_url(raw_url)
            rg_match = re.search(r'_rg(\d+)', os.path.basename(file_path))
            r_grp = int(rg_match.group(1)) if rg_match else 0
            is_directory = any(domain in final_url.lower() for domain in DIRECTORY_DOMAINS)
            
            if is_directory:
                issue_type = "Error (Directory)"
                status = 'Skipped'
                is_target = False
            else:
                if r_grp <= 10:
                    issue_type = "CRITICAL (Top 10)"
                else:
                    issue_type = f"Error (Rank: {r_grp})"
                status = 'Pending'
                is_target = True

            return {
                'Issue': issue_type,
                'suburb': os.path.basename(os.path.dirname(os.path.dirname(file_path))),
                'rank_group': r_grp,
                'url': final_url,
                'actual_size': f"{file_size:.2f} KB",
                'status': status,
                'file_path': file_path,
                'is_target': is_target
            }
        except:
            return None

    async def scan_files_async(self):
        """Scan all files asynchronously"""
        print(f"🔍 Step 1: Scanning and Prioritizing (Async Mode)...")
        
        file_paths = []
        for root, dirs, files in os.walk(self.base_output_folder):
            if "organic" not in root.lower():
                continue
            for file in files:
                if file.endswith(".md") and not file.startswith("_"):
                    file_paths.append(os.path.join(root, file))
        
        tasks = [self.process_file_async(fp) for fp in file_paths]
        results = await asyncio.gather(*tasks)
        
        all_files_data = [r for r in results if r is not None]
        targets = [r for r in all_files_data if r.get('is_target')]
        
        csv_data = []
        for row in all_files_data:
            csv_row = {k: v for k, v in row.items() if k != 'is_target'}
            csv_data.append(csv_row)
        
        with open(self.report_csv, mode='w', newline='', encoding='utf-8') as csvfile:
            fields = ['Issue', 'suburb', 'rank_group', 'url', 'actual_size', 'status', 'file_path']
            writer = csv.DictWriter(csvfile, fieldnames=fields)
            writer.writeheader()
            writer.writerows(csv_data)
        
        print(f"✅ Step 1 Done. Found {len(targets)} targets from {len(file_paths)} files.")
        print(f"   💡 Using {len(self.api_headers)} API accounts for parallel processing")
        print(f"   - Top 10: {len([t for t in targets if t['rank_group'] <= 10])}")
        print(f"   - Others: {len([t for t in targets if t['rank_group'] > 10])}")
        return targets

    async def post_batch_async(self, session, batch, batch_num, smart_fix_dir, api_index):
        """Post a batch asynchronously using specific API credentials"""
        import post_page
        
        headers = self.api_headers[api_index]
        print(f"📡 Posting batch {batch_num} ({len(batch)} tasks) via API #{api_index + 1}...")
        
        try:
            loop = asyncio.get_event_loop()
            resp = await loop.run_in_executor(
                self.executor,
                lambda: post_page.post_onpage_task(
                    headers, batch, output_dir=smart_fix_dir, 
                    filename=f"smart_fix_batch_{batch_num}_api{api_index}.json"
                )
            )
            
            if not resp or resp.status_code != 200:
                print(f"❌ Batch post failed for batch {batch_num} (API #{api_index + 1})")
                self.api_stats[api_index]['errors'] += 1
                return None, None
            
            resp_data = resp.json()
            task_ids = []
            id_to_tag = {}
            
            for task in resp_data.get('tasks', []):
                tid = task.get('id')
                tag = task.get('data', {}).get('tag')
                if tid and tag:
                    task_ids.append(tid)
                    id_to_tag[tid] = tag
            
            self.api_stats[api_index]['posted'] += len(task_ids)
            return task_ids, id_to_tag
            
        except Exception as e:
            print(f"❌ Exception in post_batch (API #{api_index + 1}): {e}")
            self.api_stats[api_index]['errors'] += 1
            return None, None

    async def fetch_results_async(self, session, fetch_payload, batch_num, api_index):
        """Fetch results asynchronously using specific API credentials"""
        endpoint = "https://api.dataforseo.com/v3/on_page/content_parsing"
        headers = self.api_headers[api_index]
        
        try:
            async with session.post(
                endpoint, 
                headers=headers, 
                json=fetch_payload,
                timeout=aiohttp.ClientTimeout(total=120)
            ) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    print(f"❌ Fetch API Error for batch {batch_num} (API #{api_index + 1}): {response.status}")
                    self.api_stats[api_index]['errors'] += 1
                    return None
        except Exception as e:
            print(f"❌ Fetch Connection Error for batch {batch_num} (API #{api_index + 1}): {e}")
            self.api_stats[api_index]['errors'] += 1
            return None

    async def save_result_async(self, tag_path, result_data):
        """Save result to file asynchronously"""
        try:
            async with aiofiles.open(tag_path, 'w', encoding='utf-8') as f:
                await f.write(json.dumps(result_data, indent=4))
            size = os.path.getsize(tag_path) / 1024
            print(f"   ✨ Success! New size: {size:.2f} KB")
            return True
        except Exception as e:
            print(f"   💥 Save Error {tag_path}: {e}")
            return False

    async def fetch_with_retry(self, session, fetch_payload, id_to_tag, metadata_map, 
                               batch_num, api_index):
        """
        ✅ NEW: Fetch results with intelligent retry logic and exponential backoff
        """
        wait_time = INITIAL_WAIT
        retry_count = 0
        pending_tasks = fetch_payload.copy()
        successful_saves = 0
        
        while retry_count < MAX_RETRIES and pending_tasks:
            # Wait before fetching
            if retry_count == 0:
                print(f"⏳ Waiting {wait_time}s for batch {batch_num} results (API #{api_index + 1})...")
            else:
                print(f"🔄 Retry {retry_count}/{MAX_RETRIES} - Waiting {wait_time}s for {len(pending_tasks)} pending tasks...")
            
            await asyncio.sleep(wait_time)
            
            # Fetch results
            print(f"📥 Fetching {len(pending_tasks)} tasks (batch {batch_num}, API #{api_index + 1})...")
            
            async with self.api_locks[api_index]:
                res_json = await self.fetch_results_async(session, pending_tasks, batch_num, api_index)
                await asyncio.sleep(1)
            
            if not res_json:
                retry_count += 1
                wait_time = min(wait_time * 1.5, MAX_WAIT)  # Exponential backoff
                self.api_stats[api_index]['retries'] += 1
                continue
            
            # Process results and identify what's still pending
            still_pending = []
            save_tasks = []
            
            for task_res in res_json.get("tasks", []):
                tag_path = task_res.get("data", {}).get("tag")
                
                if not tag_path:
                    tid = task_res.get("id")
                    tag_path = id_to_tag.get(tid)
                
                if not tag_path:
                    continue
                
                status_msg = task_res.get('status_message')
                
                if status_msg == 'Ok.':
                    # Success - schedule save
                    save_tasks.append(self.save_result_async(tag_path, task_res))
                    
                elif 'Task In Queue' in status_msg or 'In Progress' in status_msg:
                    # Still processing - keep in pending list
                    tid = task_res.get("id")
                    url = metadata_map.get(tag_path, {}).get('url', 'unknown')
                    still_pending.append({"id": tid, "url": url})
                    
                else:
                    # Error - log and remove from pending
                    item = metadata_map.get(tag_path)
                    if item:
                        print(f"   ❌ API Error for {item['url']}: {status_msg}")
            
            # Save successful results
            if save_tasks:
                results = await asyncio.gather(*save_tasks)
                successful_saves += sum(results)
                self.api_stats[api_index]['fetched'] += sum(results)
            
            # Update pending tasks
            if still_pending:
                pending_tasks = still_pending
                retry_count += 1
                # Increase wait time for next retry
                wait_time = min(wait_time * 1.5, MAX_WAIT)
                self.api_stats[api_index]['retries'] += 1
                print(f"   ⚠️  {len(still_pending)} tasks still processing...")
            else:
                # All tasks completed
                break
        
        # Final status
        if pending_tasks:
            print(f"   ⏰ Timeout: {len(pending_tasks)} tasks still pending after {MAX_RETRIES} retries")
        
        return successful_saves

    async def process_batch_async(self, session, batch, metadata_map, batch_num, smart_fix_dir, api_index):
        """Process a complete batch: post, wait, fetch with retry, save"""
        # Use lock to prevent API rate limiting
        async with self.api_locks[api_index]:
            task_ids, id_to_tag = await self.post_batch_async(session, batch, batch_num, smart_fix_dir, api_index)
            await asyncio.sleep(1)
        
        if not task_ids:
            return 0
        
        # Prepare fetch payload
        fetch_payload = []
        for tid in task_ids:
            tag = id_to_tag.get(tid)
            meta = metadata_map.get(tag)
            if meta:
                fetch_url = meta.get('url')
                if fetch_url:
                    fetch_payload.append({"id": tid, "url": fetch_url})
        
        # ✅ NEW: Use retry logic
        successful_saves = await self.fetch_with_retry(
            session, fetch_payload, id_to_tag, metadata_map, batch_num, api_index
        )
        
        return successful_saves

    async def process_all_batches_async(self, targets):
        """Process all batches with TRUE parallel API usage"""
        import post_page
        
        smart_fix_dir = "smart_fix"
        if not os.path.exists(smart_fix_dir):
            os.makedirs(smart_fix_dir)
        
        # Prepare all batches
        tasks_bucket = []
        metadata_map = {}
        
        for item in targets:
            tag = item['file_path']
            url = item['url']
            
            # ✅ ADAPTIVE: Use full protection for Top 10, lighter for others
            is_top_10 = item.get('rank_group', 999) <= 10
            
            # Detect sites that typically need heavy protection
            heavy_protection_domains = [
                'hipages', 'yelp', 'yellowpages', 'truelocal',
                'oneflare', 'localsearch', 'checkatrade'
            ]
            needs_heavy = any(domain in url.lower() for domain in heavy_protection_domains)
            
            use_full_protection = is_top_10 or needs_heavy
            
            post_data = {
                "target": re.sub(r'(https?://|www\.)', '', url).split('/')[0],
                "start_url": url,
                "url": url,
                "enable_content_parsing": True,
                "max_crawl_pages": 1,
                "enable_javascript": True,
                "switch_pool": True,  # ✅ Always rotate IPs
                "load_resources": use_full_protection,  # Only for important/protected sites
                "enable_browser_rendering": use_full_protection,  # Only for important/protected sites
                "enable_xhr": use_full_protection,  # Only for important/protected sites
                "disable_cookie_popup": True,  # ✅ Always dismiss popups
                "browser_preset": "desktop",
                "proxy_country": "AU",
                "use_advanced_anti_robot_protection": use_full_protection,  # Only for important/protected sites
                "browser_wait_until": "networkidle0" if use_full_protection else "load",
                "wait_for_content_timeout": 90 if use_full_protection else 60,
                "custom_js": "window.scrollTo(0, document.body.scrollHeight);" if use_full_protection else "",
                "tag": tag
            }
            tasks_bucket.append(post_data)
            metadata_map[tag] = item
        
        # ✅ Optimal batch size
        batch_size = 100
        batches = [tasks_bucket[i:i + batch_size] for i in range(0, len(tasks_bucket), batch_size)]
        
        print(f"📦 Total batches to process: {len(batches)}")
        print(f"⚡ Parallel processing with {len(self.api_headers)} APIs + intelligent retry")
        
        # Distribute batches across APIs
        num_apis = len(self.api_headers)
        api_batch_assignments = [[] for _ in range(num_apis)]
        for batch_idx, batch in enumerate(batches):
            api_idx = batch_idx % num_apis
            api_batch_assignments[api_idx].append((batch_idx, batch))
        
        print(f"\n📋 Batch Distribution:")
        for api_idx, assignments in enumerate(api_batch_assignments):
            print(f"   API #{api_idx + 1}: {len(assignments)} batches")
        print()
        
        async with aiohttp.ClientSession() as session:
            async def api_worker(api_index, batch_list):
                """Process all assigned batches for one API"""
                processed = 0
                for batch_num, batch in batch_list:
                    result = await self.process_batch_async(
                        session, batch, metadata_map, 
                        batch_num, smart_fix_dir, api_index
                    )
                    processed += result
                    print(f"   API #{api_index + 1}: Completed batch {batch_num} ({processed} total)")
                return processed
            
            # Launch ALL workers in parallel
            worker_tasks = [
                api_worker(api_idx, batch_list)
                for api_idx, batch_list in enumerate(api_batch_assignments)
                if batch_list
            ]
            
            results = await asyncio.gather(*worker_tasks)
            total_processed = sum(results)
        
        return total_processed

    def _print_api_stats(self):
        """Print API usage statistics"""
        print("\n📈 API Usage Statistics:")
        for i, stats in enumerate(self.api_stats):
            print(f"   API #{i+1}: Posted={stats['posted']}, Fetched={stats['fetched']}, "
                  f"Retries={stats['retries']}, Errors={stats['errors']}")
        print()

    async def run_mega_fixer_async(self):
        """Main async orchestrator"""
        print("=" * 60)
        print("🚀 MULTI-API SMART FIXER WITH RETRY LOGIC")
        print("=" * 60)
        
        # Step 1: Scan files
        targets = await self.scan_files_async()
        
        if not targets:
            print("🏁 No targets to rescue.")
            return
        
        # Step 2: Process batches with multiple APIs
        total_processed = await self.process_all_batches_async(targets)
        
        print("\n" + "=" * 60)
        print(f"🏁 FINISHED: Rescued {total_processed}/{len(targets)} files")
        print("=" * 60)
        self._print_api_stats()

    def run_mega_fixer(self):
        """Sync wrapper for async execution"""
        asyncio.run(self.run_mega_fixer_async())

if __name__ == "__main__":
    SmartFixer().run_mega_fixer()