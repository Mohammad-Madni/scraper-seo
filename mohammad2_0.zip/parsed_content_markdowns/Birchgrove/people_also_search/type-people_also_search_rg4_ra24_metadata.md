# Type: people_also_search | Rank: 24 | RG: 4
### Raw Row Data:
{
    "rank_group": "4",
    "rank_absolute": "24",
    "service": "roofer",
    "suburb": "Birchgrove",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}