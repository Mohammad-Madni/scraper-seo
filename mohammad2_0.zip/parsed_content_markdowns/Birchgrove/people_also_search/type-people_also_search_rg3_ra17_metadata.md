# Type: people_also_search | Rank: 17 | RG: 3
### Raw Row Data:
{
    "rank_group": "3",
    "rank_absolute": "17",
    "service": "roofer",
    "suburb": "Birchgrove",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}