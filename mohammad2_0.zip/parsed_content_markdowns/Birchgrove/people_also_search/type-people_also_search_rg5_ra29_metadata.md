# Type: people_also_search | Rank: 29 | RG: 5
### Raw Row Data:
{
    "rank_group": "5",
    "rank_absolute": "29",
    "service": "roofer",
    "suburb": "Birchgrove",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}