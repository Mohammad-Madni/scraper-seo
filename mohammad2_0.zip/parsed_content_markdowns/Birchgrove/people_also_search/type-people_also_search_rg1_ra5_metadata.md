# Type: people_also_search | Rank: 5 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "5",
    "service": "roofer",
    "suburb": "Birchgrove",
    "title": "Find related products and services",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}