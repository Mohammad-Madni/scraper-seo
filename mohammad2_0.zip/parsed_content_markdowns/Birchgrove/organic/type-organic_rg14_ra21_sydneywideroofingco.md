{
    "id": "01190728-1132-0216-0000-7a0724cd44e8",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0164 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneywideroofingco.com.au/inner-west/",
        "target": "sydneywideroofingco.com.au",
        "start_url": "https://sydneywideroofingco.com.au/inner-west/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Birchgrove\\organic\\type-organic_rg14_ra21_sydneywideroofingco.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:19 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipes",
                                    "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                            "anchor_text": "Gutters and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tile Pointing and Bedding",
                                    "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                            "anchor_text": "Roof Tile Pointing and Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Roofing",
                                    "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                            "anchor_text": "Zinc Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs in Randwick NSW",
                                    "url": "https://sydneywideroofingco.com.au/randwick/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/randwick/",
                                            "anchor_text": "Roof Repairs in Randwick NSW"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Georges River",
                                    "url": "https://sydneywideroofingco.com.au/georges-river/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/georges-river/",
                                            "anchor_text": "Georges River"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Inner West Roof Repairs",
                                    "url": "https://sydneywideroofingco.com.au/inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/inner-west/",
                                            "anchor_text": "Sydney Inner West Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "City of Sydney",
                                    "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                            "anchor_text": "City of Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "GET QUOTE",
                                    "url": "https://sydneywideroofingco.com.au/get-quote/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/get-quote/",
                                            "anchor_text": "GET QUOTE"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "95 Bellingara Rd, Miranda NSW 2228.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "(02) 8294 4654",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Sydney Inner West Roof Repairs",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "That drip, drip, drip is one of the most stressful sounds you can hear in your home. We get it. A roof leak isn\u2019t just an annoyance; it\u2019s a threat to your property\u2019s structure, causing water damage, ceiling discoloration, and potential mould.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "This is where we come in. We are your local experts for all roof repairs in Inner West, Sydney.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We find leaks, fast. We offer a comprehensive Roof Leak Analysis for just $99. We guarantee to pinpoint the origin of your leak. If you hire us for the repair, we\u2019ll even subtract that $99 from the final quote. And if we can\u2019t fix the leak by the third try? You get your money back. That\u2019s our promise.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Call Us: (02) 8294 4654 Working Hours: Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us As Your Inner West Roof Repair Services?",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When your roof is compromised, you need a roofing specialist you can absolutely trust. But how do you choose between all the \u201cRoof repairs in Inner West\u201d options?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Here\u2019s the simple breakdown:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local Experts (That\u2019s Us!): We are a team of licensed and insured roofing specialists with over three decades of hands-on experience. We\u2019re not just contractors; we\u2019re your local partners. Our commitment is to stellar service, and you\u2019ll deal directly with an expert from your very first call.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Other Repair Teams (e.g., Roof Repairs in Inner West ): Many local teams are great, often family-run with solid experience (like our competitors). They provide a core set of repair services, which is fantastic for general issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Other Specialists (e.g., Ian\u2019s Roofing or RoofingCorp): Other pros in the Sydney roofing industry also have decades of experience and strong reviews. The key difference is our guaranteed leak detection. We don\u2019t just patch; we analyze, find the source, and offer a money-back guarantee on our fix.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why We\u2019re Different From Other Roofing Companies",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We know you have a choice in roofing companies. Our entire business is built on trust. We aren\u2019t just trying to make a quick sale\u2014we\u2019re here to be your long-term roofing partner. We show up on time, use only premium products, and back our work with a guarantee, which is why we have over 150 5-star reviews.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Complete Roofing Services",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We handle everything from a single slipped tile on a Leichhardt terrace to a full commercial re-roof in Marrickville. Our purpose is to find the cause of your problem and ensure its non-recurrence with the best roofing services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Expert Roof Leak Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "This is our specialty. We use our $99 guaranteed analysis to find the source of any leak. We are the experts in roof leak repair, from minor fixes to major storm damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement & Roof Installations",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sometimes a repair isn\u2019t enough. We offer full roof replacement in Inner West. Our expert team handles all roof installations, from start to finish, ensuring your new roof is secure, compliant, and looks fantastic.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roof & Tile Roofs",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We are experts in all common Sydney roof types. We handle all issues with tile roofs \u2014from classic terracotta tiles to modern concrete. We\u2019re also specialists in metal roof solutions, including installations and repairs for Colorbond and Kliplok systems.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Repairs",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The Inner West\u2019s beautiful heritage homes need special care. We provide expert slate roof repairs to protect your home\u2019s character, matching materials and ensuring a perfect, watertight seal. This is a specialist skill, and we are proud to offer slate roofing in Inner West, Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Preventative Roof Maintenance",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The best repair is one you never have to make. Ask about our preventative roof maintenance plans. We\u2019ll clear your gutters, check your flashings, and stop small issues (like leaf debris) from becoming major leaks. This is the core of our roof maintenance in Inner West.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Simple 3-Step Process",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We make fixing your roof easy and stress-free. Our process is designed to give you clarity and confidence.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Call & Analyze You call us. We come out and perform our guaranteed $99 leak analysis, using our advanced tools to find the exact source of the water entry.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quote & Repair We give you a clear, honest, and competitive quote for the fix. Once you approve, our skilled team gets to work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Protect & Guarantee We fix the problem at its source, clean the site, and back our repair with our money-back guarantee. Your home is protected.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Common Questions on Roof Repairs in Inner West",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "What causes most roof leaks?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Honestly, it\u2019s often not just one thing! In the We see a lot of leaks from blocked gutter systems, cracked or slipped tiles on older tile roofs, wind and storm damage, and rusted-out flashing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How long does a roof repair take?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A simple repair, like replacing a few tiles or sealing flashing, can often be done in just a few hours. A larger roof restoration or roof replacement can take several days, but we\u2019ll always give you a clear timeline.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you service my area?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes! We offer Inner West roofing solutions, along with the Rockdale, St George, and beyond.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Your Local Inner West Roofing Experts",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Don\u2019t let a minor leak escalate into a significant, costly issue. We\u2019re ready to help you with our roof repair services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Visit Us: 95 Bellingara Rd, Miranda NSW 2228",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Working Hours: Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Call Us: (02) 8294 4654",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email: [email\u00a0protected]",
                                        "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Your Local Roofing Contractors",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Stop Stressing. Let\u2019s Fix Roof Leaks. Protect Your Home.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Call our amicable team at (02) 8294 4654 today to book your $99 leak analysis or to get a free quote on any roofing project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sutherland Shire",
                                        "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                                "anchor_text": "Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                                "anchor_text": "Eastern Suburbs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georges River",
                                        "url": "https://sydneywideroofingco.com.au/georges-river/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/georges-river/",
                                                "anchor_text": "Georges River"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Inner West",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/",
                                                "anchor_text": "Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Northern Beaches",
                                        "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                                "anchor_text": "Northern Beaches"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "North Sydney",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                                "anchor_text": "North Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Our Roof Repairs in Inner West",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Locations We Serve",
                                "main_title": "Sydney Inner West Roof Repairs",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Russell Lea",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/russell-lea/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/russell-lea/",
                                                "anchor_text": "Russell Lea"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/five-dock/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/five-dock/",
                                                "anchor_text": "Five Dock"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rodd Point",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/rodd-point/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/rodd-point/",
                                                "anchor_text": "Rodd Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/summer-hill/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/summer-hill/",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/canada-bay/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/canada-bay/",
                                                "anchor_text": "Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 8294 4654"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}