{
    "id": "01190728-1132-0216-0000-2e7f07626902",
    "status_code": 40602,
    "status_message": "Task In Queue.",
    "time": "0.0013 sec.",
    "cost": 0,
    "result_count": 0,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://adkoroofing.com.au/locations/inner-west/",
        "target": "adkoroofing.com.au",
        "start_url": "https://adkoroofing.com.au/locations/inner-west/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Birchgrove\\organic\\type-organic_rg7_ra13_adkoroofing.md"
    },
    "result": null
}