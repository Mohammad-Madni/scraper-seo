{
    "id": "01190728-1132-0216-0000-a4b02dac9200",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0279 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://innerwestlocalroofing.com.au/",
        "target": "innerwestlocalroofing.com.au",
        "start_url": "https://innerwestlocalroofing.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Birchgrove\\organic\\type-organic_rg19_ra27_innerwestlocalroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:20 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Inner West Local Roofing",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Address: Inner West, Sydney, NSW",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Opening Hours:\u00a0Monday to Sunday \u2013 24 hours",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://innerwestlocalroofing.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms and Conditions",
                                    "url": "https://innerwestlocalroofing.com.au/terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repairs"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "The Roofer You Can Trust",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Local Roofing, we\u2019re proud to be the trusted roofing specialists serving homes and businesses across Sydney\u2019s Inner West. With extensive experience, our team provides expert roof repairs, replacements, and installations that combine quality workmanship with durable materials. From heritage terraces to modern family homes, we understand the unique character of the Inner West and deliver roofing solutions designed to protect and enhance every property.",
                                        "url": "https://en.wikipedia.org/wiki/Inner_West",
                                        "urls": [
                                            {
                                                "url": "https://en.wikipedia.org/wiki/Inner_West",
                                                "anchor_text": "Sydney\u2019s Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whether you need urgent roof repairs, routine maintenance, or a complete roof restoration, we\u2019re here to help. Backed by full licensing and insurance, our professional team works with honesty and care to give you peace of mind and long-lasting results. At Inner West Local Roofing, your roof is our priority and we\u2019re committed to keeping the Inner West covered.",
                                        "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                                "anchor_text": "roof repairs"
                                            },
                                            {
                                                "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                                "anchor_text": "routine maintenance"
                                            },
                                            {
                                                "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                                "anchor_text": "roof restoration"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Us",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Local Roofing, customer satisfaction is our top priority. Fully licensed and insured, we deliver roofing services you can trust \u2014 from repairs and maintenance to complete roof replacements and installations. No matter the size or complexity of your project, our team is here to guide you every step of the way, offering free, no-obligation quotes so you can plan with confidence.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professionalism in Roofing Services",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "What sets us apart from other roofing contractors in the Inner West is our commitment to precision, professionalism, and care. We understand the critical role your roof plays in protecting your property, so we handle every project with attention to detail and respect for your time. Our process is simple and stress-free: we begin with a thorough inspection, provide a clear estimate, carry out the work to the highest standard, and leave your property spotless when the job is done.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Commitment",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing is more than just a trade for us \u2014 it\u2019s our passion. At Inner West Local Roofing, we are committed to honesty, transparency, and integrity, never recommending unnecessary work and always completing projects on time and within budget. As your trusted Inner West roofing specialists, our promise is to keep your home or business safe, secure, and built to last. Get in touch with us today to discuss your roofing needs and discover how we can bring your vision to life.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to selecting a roofing contractor, you want to be sure you\u2019re making the right choice. Here are several compelling reasons why choosing us is the best decision for your roofing needs:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Professionalism: Our reputation for professionalism precedes us. From the moment you reach out to us for an initial consultation to the final walkthrough of your completed project, you can expect nothing but the highest level of professionalism from our team. We prioritize clear communication, timely responses, and courteous service at every step of the process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality: Quality is at the core of everything we do. We believe that using the best materials and employing skilled craftsmen is essential to delivering exceptional results. Whether it\u2019s a minor repair or a complete roof replacement, we approach each project with a commitment to excellence, ensuring that your roof not only looks great but also performs reliably for years to come.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Experience: With over two decades of experience in the roofing industry, we have seen and handled it all. Our extensive experience has equipped us with the knowledge and expertise needed to tackle even the most complex roofing challenges. You can trust that your project is in capable hands when you choose us as your roofing contractor.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Customer Satisfaction: Your satisfaction is our top priority. We understand that a happy customer is a loyal customer, which is why we go above and beyond to ensure that you\u2019re delighted with the final results. We listen to your needs, address any concerns promptly, and work tirelessly to exceed your expectations at every turn.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Reliability: As a family-owned and operated business, we take great pride in our reputation for reliability. When you choose us, you can count on us to be there when we say we will and to complete your project on time and within budget. We understand the importance of trust in a contractor-client relationship, and we strive to earn and maintain your trust with every job we undertake.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Craftsmanship Warranty: We stand behind the quality of our workmanship with confidence. That\u2019s why we offer a comprehensive five-year warranty on all craftsmanship. In the unlikely event that any issues arise as a result of our work, we will make it right at no additional cost to you. This warranty provides you with peace of mind and underscores our commitment to delivering excellence in every aspect of our work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Choosing us as your roofing contractor means choosing professionalism, quality, experience, customer satisfaction, reliability, and peace of mind. We value your trust and are dedicated to exceeding your expectations in every way. So why settle for anything less? Choose us for all your roofing needs and experience the difference firsthand.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "OUR SERVICES\u200b",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Trusted commercial roofing solutions to protect businesses with durable, long-lasting roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Fast emergency roof repairs when storms or sudden damage strike, keeping homes and businesses safe.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Repair",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From blockages to leaks, we handle all gutter repairs to prevent water damage and protect your property\u2019s structure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Expert residential roofing services for every home style, from classic cottages to modern apartments and townhouses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Professional roof cleaning restores your roof\u2019s appearance while extending its lifespan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspection",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Thorough roof inspections catch issues early, saving you time, money, and stress.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Expert roof installations using premium, long-lasting materials to ensure a strong and reliable roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Routine roof maintenance keeps your property safe and ensures your roof stays in top condition year-round.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Professional roof painting refreshes your roof\u2019s look while adding protection against the elements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From minor leaks to major damage, we provide durable, long-lasting roofing solutions for homes and businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Revitalise your roof with expert restoration services \u2014 a cost-effective alternative to full replacement.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Skylight Repair",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Professional skylight repairs fix leaks and restore natural light to your property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Service Areas",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Local Roofing, we are proud to provide expert roofing solutions across a wide range of suburbs. Whether you need residential, commercial, or emergency roofing services, our experienced team is ready to deliver high-quality, reliable results wherever you are. We are committed to keeping properties safe, durable, and looking their best, no matter the location.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Balmain East",
                                        "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                        "urls": [
                                            {
                                                "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                                "anchor_text": "Balmain East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St. Peters",
                                        "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                        "urls": [
                                            {
                                                "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                                "anchor_text": "St. Peters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                        "urls": [
                                            {
                                                "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Clients Have To Say",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "\"We couldn\u2019t be happier with the service from Inner West Local Roofing. From the first inspection to the final clean-up, the team was professional, reliable, and transparent about every step of the process. They fixed our leaking roof quickly, with top-quality workmanship that gave us peace of mind before the next big storm. It\u2019s rare to find tradespeople who are this punctual, friendly, and trustworthy. Highly recommend to anyone in the Inner West looking for honest and skilled roofers.\"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Inner West",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sarah M.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get a Free Quote Today!",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "When it comes to roofing needs, look no further than Inner West Local Roofing. We\u2019re the most reputable choice in the industry. Contact us today and discover the exceptional service we offer. You won\u2019t be let down.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "What Do We Do?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof cleaning and application of Sealer and Roofing Paint.",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Replacement of broken, cracked, shifted, or chipped tiles.",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Installation and replacement of gutters, downpipes, and or box gutters",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Detection and repair of any leaks.",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete or partial Re-Pointing and Re-Bedding.",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "De-mossing and/or pressure cleaning.",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "TESTIMONIALS",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "GET IN TOUCH",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Copyright \u00a9 2025 | Inner West Local Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 12,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0280743728"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}