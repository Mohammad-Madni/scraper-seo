{
    "id": "01190728-1132-0216-0000-0e08ec4d56d1",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0267 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://bluroofingco.com.au/",
        "target": "bluroofingco.com.au",
        "start_url": "https://bluroofingco.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Birchgrove\\organic\\type-organic_rg12_ra19_bluroofingco.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:17 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From small leak repairs to complete re-roofs, no job is too small!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read More",
                                        "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                                "anchor_text": "Read More"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "New Roofs",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Using only the finest materials, insulation and finishings, your new roof is built to survive decades of storms",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "New Roofs",
                                        "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                                "anchor_text": "New Roofs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read More",
                                        "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                                "anchor_text": "Read More"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Downpipes",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We only install long lasting quality COLORBOND gutters, fascia and downpipes",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read More",
                                        "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/roof-repairs.htm",
                                                "anchor_text": "Read More"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Strata Buildings",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We repair and service properties of any height and size",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Strata Buildings",
                                        "url": "https://bluroofingco.com.au/strata.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/strata.htm",
                                                "anchor_text": "Strata Buildings"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read More",
                                        "url": "https://bluroofingco.com.au/strata.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/strata.htm",
                                                "anchor_text": "Read More"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Safety Systems",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We are leaders in Anchor Point, Ladder bracket and Safety Installations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The Blu Roofing Co management have been the leaders in making roofs in Sydney safe for all trades. We are committed and fully compliant to all health and safety regulations (WHS) set out by the government standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We put safety first.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Because we maintain a wide variety of roofs and gutters from large commercial roofs to small residential homes our team's industry experience will save you time and money both now, and in the long term.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Safety Systems",
                                        "url": "https://bluroofingco.com.au/anchor-points.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/anchor-points.htm",
                                                "anchor_text": "Safety Systems"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read More",
                                        "url": "https://bluroofingco.com.au/anchor-points.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/anchor-points.htm",
                                                "anchor_text": "Read More"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Blu Roofing Co",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Instagram Feed",
                                        "url": "https://bluroofingco.com.au/portfolio/instagram-feed.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/portfolio/instagram-feed.htm",
                                                "anchor_text": "Instagram Feed"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Examples Gallery",
                                        "url": "https://bluroofingco.com.au/portfolio/gallery.htm",
                                        "urls": [
                                            {
                                                "url": "https://bluroofingco.com.au/portfolio/gallery.htm",
                                                "anchor_text": "Examples Gallery"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Strata Commercial Residential",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our specialist team have provided practical roofing solutions for years to Strata Properties, Commercial and Industrial sites and to the Residential market.",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We are the leading Leak Detection and roof repair specialists because we stay humble - we don't just rely on our years of experience.",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "With fresh eyes, we look, inspect, and find practical solutions for each problem.",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Gallery",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Services",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Blu Roofing Co",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leak Detection and Repairs",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Safety Systems",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Us",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Clients are Saying",
                                "main_title": "Blu Roofing Co",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "02 8234 8871",
                                "0433773774"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}