{
    "id": "01191221-1132-0216-0000-78bf0ba5d2ac",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0184 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.allroofingservices.com.au/birchgrove",
        "target": "allroofingservices.com.au",
        "start_url": "https://www.allroofingservices.com.au/birchgrove",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": true,
        "load_resources": true,
        "enable_browser_rendering": true,
        "enable_xhr": true,
        "disable_cookie_popup": true,
        "browser_preset": "desktop",
        "custom_js": "window.scrollTo(0, document.body.scrollHeight);",
        "tag": "parsed_content_markdowns\\Birchgrove\\organic\\type-organic_rg4_ra8_allroofingservices.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 0,
            "items": null
        }
    ]
}