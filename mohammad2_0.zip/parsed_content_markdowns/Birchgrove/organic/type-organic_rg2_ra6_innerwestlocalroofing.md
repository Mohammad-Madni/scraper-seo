{
    "id": "01190728-1132-0216-0000-f645b739bf44",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0241 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://innerwestlocalroofing.com.au/roofing-birchgrove/",
        "target": "innerwestlocalroofing.com.au",
        "start_url": "https://innerwestlocalroofing.com.au/roofing-birchgrove/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Birchgrove\\organic\\type-organic_rg2_ra6_innerwestlocalroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:32:27 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Inner West Local Roofing",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Address: Inner West, Sydney, NSW",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Opening Hours:\u00a0Monday to Sunday \u2013 24 hours",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://innerwestlocalroofing.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms and Conditions",
                                    "url": "https://innerwestlocalroofing.com.au/terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repairs"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "The Roofer You Can Trust",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Local Roofing, we\u2019re proud to serve Birchgrove with reliable roofing solutions. From Rowntree Street to Louisa Road and beyond, our team understands the suburb\u2019s mix of heritage cottages, waterfront homes, and modern builds, delivering expert repairs, maintenance, and replacements tailored to every property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As your local Birchgrove specialists, we\u2019re committed to keeping roofs strong, weather-resistant, and built to last.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Birchgrove Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Local Roofing, customer satisfaction is our top priority. We\u2019re proud to serve homeowners and businesses in Birchgrove with high-quality workmanship, backed by full licensing and insurance for complete peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter the size or complexity of your roofing project, our experienced team is here to help. We specialise in roof repairs, replacements, and new installations in Birchgrove, and we offer free, no-obligation quotes so you can plan your project with confidence.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professionalism in Roofing Services",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "What sets us apart from other roofing companies in Birchgrove is our attention to detail and commitment to professionalism. We know how important your roof is, which is why we treat every project with the care it deserves \u2014 from the first on-site inspection to the final clean-up.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our process is straightforward and stress-free: we assess your roof, provide a clear and honest estimate, and deliver quality work on time and within budget. Respecting your schedule, we work efficiently to minimise any disruption to your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Commitment",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing in Birchgrove isn\u2019t just our job \u2014 it\u2019s our passion. We pride ourselves on honesty, transparency, and integrity, and we\u2019ll never recommend services you don\u2019t need. As your trusted Birchgrove roofing specialists, our goal is to protect your property, enhance its value, and give you lasting peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Contact us today to discuss your Birchgrove roofing needs \u2014 whether it\u2019s a minor repair, a full roof replacement, or expert advice. We\u2019re here to help you every step of the way.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Looking for roofing services in Birchgrove?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to protecting your home, you deserve a roofing team that combines skill, reliability, and genuine local care. At Inner West Local Roofing, we\u2019re more than just contractors \u2014 we\u2019re your neighbours. With years of experience working across Birchgrove, from heritage sandstone cottages and weatherboard homes to modern harbourfront builds, we understand the unique challenges local properties face and provide tailored roofing solutions built to last. Our commitment to quality workmanship, honest advice, and dependable service sets us apart, ensuring Birchgrove homeowners enjoy peace of mind under every roof we build or repair.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide reliable commercial roofing solutions across Birchgrove, ensuring local shops, offices, and waterfront businesses are protected with durable, long-lasting roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "When wild weather or sudden damage strikes, our Birchgrove team offers fast emergency roof repairs to keep your home or business safe.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Repair",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From leaks caused by salt air to blockages from leafy streets, we handle all gutter repairs in Birchgrove, helping protect your property from water damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our residential roofing services in Birchgrove are tailored to all home styles, from heritage sandstone cottages and terraces to modern harbourside builds.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide professional roof cleaning across Birchgrove, removing moss, salt residue, and debris to restore the look of your roof and extend its lifespan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspection",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our thorough roof inspections in Birchgrove help identify issues early, saving you time, money, and stress before they become major problems.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Regular roof maintenance keeps your Birchgrove property protected. Our team ensures your roof stays strong against salt, storms, and everyday wear.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We offer professional roof painting in Birchgrove to shield your roof from the elements while refreshing and modernising your home\u2019s appearance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FREQUENTLY ASKED QUESTIONS",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "What types of roofing services do you offer in Birchgrove?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We provide a full range of roofing services in Birchgrove, including roof repairs, restorations, new roof installations, roof cleaning, roof painting, and skylight repairs for both residential and commercial properties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How quickly can you respond to roof damage in Birchgrove?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our local team provides fast response times across Birchgrove, handling urgent roof repairs caused by storms, leaks, salt corrosion, or sudden emergencies to keep your property safe.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you work on older or heritage-style homes in Birchgrove?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes \u2014 we specialise in Birchgrove\u2019s sandstone cottages, Federation terraces, and heritage homes, delivering careful roof restorations that preserve original features while improving durability.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What roofing materials do you recommend for homes in Birchgrove?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We recommend durable, weather-resistant materials suited to Birchgrove\u2019s harbourside climate and diverse housing styles, including Colorbond, slate, terracotta, and metal roofing for long-lasting protection.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Is roof maintenance really necessary for homes in Birchgrove?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Regular roof maintenance is essential in Birchgrove, especially for heritage properties and homes near the harbour, as it helps prevent salt corrosion, leaks, and structural damage while extending your roof\u2019s lifespan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Clients Say",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Roofing, we\u2019re proud to serve the Birchgrove community with trusted, high-quality roofing services. From restoring weathered slate and iron roofs on heritage cottages near Louisa Road to installing modern roofing on contemporary homes overlooking Snails Bay, we\u2019ve helped homeowners across Birchgrove protect and enhance their properties with tailored solutions and expert workmanship. With Birchgrove\u2019s blend of historic homes and stylish waterfront residences, we understand the unique roofing challenges locals face \u2014 here\u2019s what some of our happy Birchgrove clients have shared about working with us.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cWe couldn\u2019t be happier with the work from Inner West Local Roofing. Our old slate roof on our Birchgrove cottage near Louisa Road was leaking badly after a storm, and their team handled everything quickly and professionally. They not only repaired the damage but also gave us practical advice on how to maintain the roof in the future. The workmanship is excellent, and it\u2019s clear they really understand the needs of Birchgrove homes. Highly recommend them to anyone local.\u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sarah M.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get a Free Quote Today!",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "When it comes to roofing needs, look no further than Inner West Local Roofing. We\u2019re the most reputable choice in the industry. Contact us today and discover the exceptional service we offer. You won\u2019t be let down.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Why Choose Us?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "SAFETY & RELIABILITY",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "LONG-TERM PLANS",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FULLY EXPERIENCED",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "QUALITY MATERIALS",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "OUR SERVICES\u200b",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Looking for a new roof? We specialise in expert roof installations throughout Birchgrove, using only high-quality, weather-resistant materials.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From minor leaks to major damage, our Birchgrove roof repair services deliver lasting solutions for local homes and businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Bring your roof back to life with our expert roof restoration services in Birchgrove \u2014 a cost-effective alternative to full replacement.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Skylight Repair",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide professional skylight repairs across Birchgrove, fixing leaks and restoring natural light to your property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Do We Do?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Built for Birchgrove\u2019s Harbourside Climate",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Designed to handle Birchgrove\u2019s salty sea air, sudden Sydney storms, and warm summer heat",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Helps prevent common roofing issues in Birchgrove, including corrosion from salt spray and leaks in ageing cottages",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Uses durable, weather-resistant materials suited to heritage terraces and modern waterfront homes",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Delivers long-lasting roofing solutions tailored to Birchgrove\u2019s coastal environment and local housing styles",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage & Modern Home Expertise",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Experienced in restoring Birchgrove\u2019s sandstone cottages, Federation terraces, and heritage-listed properties",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Careful roof restorations that protect original charm while strengthening structure and durability",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Custom solutions for Birchgrove\u2019s mix of character homes, apartments, and contemporary harbourfront builds",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tailored advice for renovations, extensions, and upgrading older Birchgrove roofs to meet today\u2019s standards",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fast, Local & Trusted Service",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quick response times for urgent roof repairs in Birchgrove, from storm damage to salt-weathered roofs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fully familiar with Inner West council guidelines and Birchgrove\u2019s unique building requirements",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted by homeowners and small businesses around Darling Street, Louisa Road, and the Birchgrove Peninsula",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Committed to delivering skilled workmanship, transparent advice, and dependable service every time",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "GET IN TOUCH",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Copyright \u00a9 2025 | Inner West Local Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 12,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0280743728"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}