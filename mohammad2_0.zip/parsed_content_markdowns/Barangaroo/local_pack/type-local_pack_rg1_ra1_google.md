# Type: local_pack | Rank: 1 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "1",
    "service": "roofer",
    "suburb": "Barangaroo",
    "title": "Nuroofing services pty ltd",
    "domain": "www.google.com",
    "url": "https://www.google.com/viewer/place?sca_esv=ed956a20e7b48028&hl=en&gl=AU&output=search&mid=/g/1tlz_b9g&pip=CgZyb29mZXIQAg%3D%3D",
    "description": "Open \u00b7 Haymarket NSW",
    "type": "local_pack"
}