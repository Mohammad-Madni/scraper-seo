{
    "id": "01190728-1132-0216-0000-ff37f8967a4a",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0175 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://spspropertyservices.com.au/property-services-barangaroo/",
        "target": "spspropertyservices.com.au",
        "start_url": "https://spspropertyservices.com.au/property-services-barangaroo/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Barangaroo\\organic\\type-organic_rg12_ra16_spspropertyservices.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:16 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://spspropertyservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://spspropertyservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Shower Repairs",
                                    "url": "https://spspropertyservices.com.au/services/shower-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/services/shower-repairs/",
                                            "anchor_text": "Shower Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata Maintenance",
                                    "url": "https://spspropertyservices.com.au/services/strata-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/services/strata-maintenance/",
                                            "anchor_text": "Strata Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become a member",
                                    "url": "https://spspropertyservices.com.au/sign-up/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/sign-up/",
                                            "anchor_text": "Become a member"
                                        }
                                    ]
                                },
                                {
                                    "text": "SPS Guarantee",
                                    "url": "https://spspropertyservices.com.au/finance/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/finance/",
                                            "anchor_text": "SPS Guarantee"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Professional, Affordable & Considerate Property Maintenance",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Professional, Affordable & Considerate Property Maintenance",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Shower Repairs",
                                    "url": "https://spspropertyservices.com.au/services/shower-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/services/shower-repairs/",
                                            "anchor_text": "Shower Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata Maintenance",
                                    "url": "https://spspropertyservices.com.au/services/strata-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/services/strata-maintenance/",
                                            "anchor_text": "Strata Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney NSW 2000",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "(02) 9067 9500",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Operating Hours",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "24 hours / 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Book An Urgent Repair",
                                    "url": "https://spspropertyservices.com.au/booking/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/booking/",
                                            "anchor_text": "Book An Urgent Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Speak To A Strata Specialist",
                                    "url": "https://spspropertyservices.com.au/strata/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/strata/",
                                            "anchor_text": "Speak To A Strata Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become A Lifetime Member Now",
                                    "url": "https://spspropertyservices.com.au/sign-up/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/sign-up/",
                                            "anchor_text": "Become A Lifetime Member Now"
                                        }
                                    ]
                                },
                                {
                                    "text": "Work With Us",
                                    "url": "https://spspropertyservices.com.au/join-our-team/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/join-our-team/",
                                            "anchor_text": "Work With Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://spspropertyservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Partners",
                                    "url": "https://spspropertyservices.com.au/partners/",
                                    "urls": [
                                        {
                                            "url": "https://spspropertyservices.com.au/partners/",
                                            "anchor_text": "Our Partners"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Property Maintenance Services in Barangaroo",
                                "main_title": "Property Services Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "All properties need regular and emergency services to maintain their systems, services, and integrity. The plumbing, roofing, water filters, and showers are going to need maintenance and servicing and repairs from time to time. At SPS Property Services, we provide you with comprehensive property maintenance, repair, strata maintenance, and handyman services in Barangaroo and the surrounding regions. With over two decades of industry presence and 250 years of combined team experience, there is no maintenance and repair service that we haven\u2019t handled.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professional & Affordable Services in Barangaroo",
                                "main_title": "Property Services Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "All the technicians at Sydney Property Specialists are accredited and experienced professionals. We are the 2019 Local Business Award winner and 2020 finalists. Besides, we were the 2021 Australian Small Business Champion Awards finalists. All our services are driven by the goal to provide our clients with a professional, honest, and reliable service every time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You will find our services to be professional and affordable and our team courteous and considerate at all times. We listen carefully to our clients\u2019 issues before our experts develop a maintenance or repair plan and provide a quote. When you choose our services, you can expect:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We can handle any property situation that you may have in Barangaroo.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Same-day service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24/7 emergency services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lifetime workmanship guarantee",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Range of Services",
                                "main_title": "Property Services Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We have experienced and licensed professionals for each division, with everyone committed to achieving excellence and customer satisfaction. We are so certain about the quality of our work that we are able to provide a lifetime guarantee on our workmanship. We provide property maintenance services in the following areas:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Visit our Services Page for more details about the range of property maintenance services in Barangaroo.",
                                        "url": "https://spspropertyservices.com.au/our-services/",
                                        "urls": [
                                            {
                                                "url": "https://spspropertyservices.com.au/our-services/",
                                                "anchor_text": "Services Page"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We always put ourselves in our client\u2019s shoes to understand their issues and challenges in the best possible way. Our team has the expertise, resources, and focus required to get the job done. With us, you can have peace of mind in the knowledge that our experts have the certifications, experience, knowledge, and skills required to address your repair, maintenance, and renovation needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Shower Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Water Filters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Handyman Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Strata Maintenance",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us?",
                                "main_title": "Property Services Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Affordable : We charge by the job and not by the hour. Whether the task takes an hour or four to complete, you will not have to worry about additional fees.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Upfront Pricing : The costs will be presented to you in the form of a clear upfront quote. There are no hidden fees or surprises.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lifetime Guarantee : If you are not fully satisfied with our job the first time, our team will fix it again for free.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Payment Option : We make our Barangaroo property maintenance services more affordable by providing an interest-free pay-later option. You can have your , roofing, plumbing, water filters, doors/windows, or showers repaired or serviced and pay later with 0% interest.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have a proven track record of quality work, reliability, and customer satisfaction. At SPS Property Services, we handle all sizes of property maintenance jobs. No repair or maintenance job is too big or too small for us. All our work is compliant with the Australian Standards. All our technicians and builders undergo regular training and keep up-to-date with the latest techniques and technologies.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You can have all your residential or commercial repair, maintenance, and renovation needs addressed by a professional and skilled Barangaroo team. For more information about our property maintenance services, feel free to call us at (02) 9067 9500 or write to us. You may also book our services from this Booking Page.",
                                        "url": "https://spspropertyservices.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://spspropertyservices.com.au/contact-us/",
                                                "anchor_text": "write to us"
                                            },
                                            {
                                                "url": "https://spspropertyservices.com.au/booking/",
                                                "anchor_text": "Booking Page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Interest-Free Payment Plans",
                                "main_title": "Property Services Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We understand our customers and the struggles during these difficult times. Have peace of mind knowing you can get serviced now & pay later with 0% interest!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Property Services Barangaroo",
                                "main_title": "Property Services Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 9067 9500"
                            ],
                            "emails": [
                                "contact@spsplumbers.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}