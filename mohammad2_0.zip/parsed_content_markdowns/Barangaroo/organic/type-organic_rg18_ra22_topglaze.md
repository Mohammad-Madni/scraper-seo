{
    "id": "01190728-1132-0216-0000-d0ada52282e1",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0203 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.topglaze.com.au/attraction-areas/barangaroo-reserve/",
        "target": "www.topglaze.com.au",
        "start_url": "https://www.topglaze.com.au/attraction-areas/barangaroo-reserve/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Barangaroo\\organic\\type-organic_rg18_ra22_topglaze.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:18 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Contact us for your Free Roof Assessment and Report and receive upto 25% off any quoted work",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Get 1/2 Price Gutters with Every Roof Restoration! \ud83c\udfe0 Limited Time!",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Tile Roof Repair",
                                    "url": "https://topglaze.com.au/service/tile-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/tile-roof-repair/",
                                            "anchor_text": "Tile Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repair",
                                    "url": "https://topglaze.com.au/service/metal-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/metal-roof-repair/",
                                            "anchor_text": "Metal Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repair",
                                    "url": "https://topglaze.com.au/service/emergency-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/emergency-roof-repair/",
                                            "anchor_text": "Emergency Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://topglaze.com.au/service/roof-leak-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/roof-leak-repair-melbourne/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://topglaze.com.au/service/roof-repointing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/roof-repointing-melbourne/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://topglaze.com.au/service/tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/tile-roof-restoration/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://topglaze.com.au/service/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Replacement",
                                    "url": "https://topglaze.com.au/service/metal-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/metal-roof-replacement/",
                                            "anchor_text": "Metal Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Replacement",
                                    "url": "https://topglaze.com.au/service/tile-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/tile-roof-replacement/",
                                            "anchor_text": "Tile Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cladding Installers",
                                    "url": "https://topglaze.com.au/service/cladding-installers-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/cladding-installers-melbourne/",
                                            "anchor_text": "Cladding Installers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Batteries",
                                    "url": "https://topglaze.com.au/service/solar-batteries-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/solar-batteries-melbourne/",
                                            "anchor_text": "Solar Batteries"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panel Installations",
                                    "url": "https://topglaze.com.au/service/solar-panel-installations/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/solar-panel-installations/",
                                            "anchor_text": "Solar Panel Installations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repair",
                                    "url": "https://topglaze.com.au/service/tile-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/tile-roof-repair/",
                                            "anchor_text": "Tile Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repair",
                                    "url": "https://topglaze.com.au/service/metal-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/metal-roof-repair/",
                                            "anchor_text": "Metal Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repair",
                                    "url": "https://topglaze.com.au/service/emergency-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/emergency-roof-repair/",
                                            "anchor_text": "Emergency Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panel Installations",
                                    "url": "https://topglaze.com.au/service/solar-panel-installations/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/solar-panel-installations/",
                                            "anchor_text": "Solar Panel Installations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://topglaze.com.au/service/tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/tile-roof-restoration/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://topglaze.com.au/service/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Replacement",
                                    "url": "https://topglaze.com.au/service/metal-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/metal-roof-replacement/",
                                            "anchor_text": "Metal Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Replacement",
                                    "url": "https://topglaze.com.au/service/tile-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/tile-roof-replacement/",
                                            "anchor_text": "Tile Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Rye",
                                    "url": "https://topglaze.com.au/service/roof-restoration-rye/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/roof-restoration-rye/",
                                            "anchor_text": "Roof Restoration Rye"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Cranbourne",
                                    "url": "https://topglaze.com.au/service/roof-restoration-cranbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/roof-restoration-cranbourne/",
                                            "anchor_text": "Roof Restoration Cranbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacements",
                                    "url": "https://topglaze.com.au/service/gutter-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/gutter-replacements/",
                                            "anchor_text": "Gutter Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guards",
                                    "url": "https://topglaze.com.au/service/gutter-guard-installation/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/gutter-guard-installation/",
                                            "anchor_text": "Gutter Guards"
                                        }
                                    ]
                                },
                                {
                                    "text": "Reno Now/Pay Later",
                                    "url": "https://topglaze.com.au/reno-now-pay-later/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/reno-now-pay-later/",
                                            "anchor_text": "Reno Now/Pay Later"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call Us:",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\ud83c\udf1e Spring Special: Get 1/2 Price Gutters with Every Roof Restoration! \ud83c\udfe0 Limited Time!",
                                    "url": "https://topglaze.com.au/contact/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/contact/",
                                            "anchor_text": "\ud83c\udf1e Spring Special: Get 1/2 Price Gutters with Every Roof Restoration! \ud83c\udfe0 Limited Time!"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call Us:",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\ud83c\udf27\ufe0f July Special:",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\ud83c\udf1e Spring Special",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Have a question or are you ready to get started? Contact Top Glaze Roofing Systems for expert advice and professional roofing services across Melbourne. Call us, email us, or simply fill out the form and our team will be in touch promptly to arrange your free quote.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Factory 7/1441 S Gippsland Hwy, Cranbourne VIC 3977, Australia",
                                    "url": "https://www.google.com/maps?cid=16764365024144095281",
                                    "urls": [
                                        {
                                            "url": "https://www.google.com/maps?cid=16764365024144095281",
                                            "anchor_text": "Factory 7/1441 S Gippsland Hwy, Cranbourne VIC 3977, Australia"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fill In The Form Below Or Call Us Now On 1800 88 77 98",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Top Glaze Roofing Systems has delivered trusted roofing solutions across Melbourne since 1987. Fully licensed, insured, and backed by a 10-year workmanship guarantee.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://topglaze.com.au/about/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/about/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://topglaze.com.au/service/roof-replacement-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/roof-replacement-melbourne/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://topglaze.com.au/service/roof-restoration-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/roof-restoration-melbourne/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repair",
                                    "url": "https://topglaze.com.au/roof-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/roof-repair-melbourne/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://topglaze.com.au/service/roof-leak-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/roof-leak-repair-melbourne/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://topglaze.com.au/service/roof-repointing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/roof-repointing-melbourne/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cladding Installers",
                                    "url": "https://topglaze.com.au/service/cladding-installers-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/cladding-installers-melbourne/",
                                            "anchor_text": "Cladding Installers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Batteries",
                                    "url": "https://topglaze.com.au/service/solar-batteries-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/solar-batteries-melbourne/",
                                            "anchor_text": "Solar Batteries"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panel Installation",
                                    "url": "https://topglaze.com.au/service/solar-panel-installations/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/solar-panel-installations/",
                                            "anchor_text": "Solar Panel Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://topglaze.com.au/service/gutter-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/gutter-replacements/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard Installer",
                                    "url": "https://topglaze.com.au/service/gutter-guard-installation/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/gutter-guard-installation/",
                                            "anchor_text": "Gutter Guard Installer"
                                        }
                                    ]
                                },
                                {
                                    "text": "Factory 7/1441 S Gippsland Hwy, Cranbourne VIC 3977, Australia",
                                    "url": "https://www.google.com/maps?cid=16764365024144095281",
                                    "urls": [
                                        {
                                            "url": "https://www.google.com/maps?cid=16764365024144095281",
                                            "anchor_text": "Factory 7/1441 S Gippsland Hwy, Cranbourne VIC 3977, Australia"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://topglaze.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repair",
                                    "url": "https://topglaze.com.au/service/tile-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/tile-roof-repair/",
                                            "anchor_text": "Tile Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repair",
                                    "url": "https://topglaze.com.au/service/metal-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/metal-roof-repair/",
                                            "anchor_text": "Metal Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repair",
                                    "url": "https://topglaze.com.au/service/emergency-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/emergency-roof-repair/",
                                            "anchor_text": "Emergency Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://topglaze.com.au/service/roof-leak-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/roof-leak-repair-melbourne/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://topglaze.com.au/service/roof-repointing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/roof-repointing-melbourne/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://topglaze.com.au/service/tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/tile-roof-restoration/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://topglaze.com.au/service/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Replacement",
                                    "url": "https://topglaze.com.au/service/tile-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/tile-roof-replacement/",
                                            "anchor_text": "Tile Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Replacement",
                                    "url": "https://topglaze.com.au/service/metal-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/metal-roof-replacement/",
                                            "anchor_text": "Metal Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cladding Installers",
                                    "url": "https://topglaze.com.au/service/cladding-installers-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/cladding-installers-melbourne/",
                                            "anchor_text": "Cladding Installers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Batteries",
                                    "url": "https://topglaze.com.au/service/solar-batteries-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/solar-batteries-melbourne/",
                                            "anchor_text": "Solar Batteries"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panel Installations",
                                    "url": "https://topglaze.com.au/service/solar-panel-installations/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/solar-panel-installations/",
                                            "anchor_text": "Solar Panel Installations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacements",
                                    "url": "https://topglaze.com.au/service/gutter-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/gutter-replacements/",
                                            "anchor_text": "Gutter Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guards",
                                    "url": "https://topglaze.com.au/service/gutter-guard-installation/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/service/gutter-guard-installation/",
                                            "anchor_text": "Gutter Guards"
                                        }
                                    ]
                                },
                                {
                                    "text": "Reno Now/Pay Later",
                                    "url": "https://topglaze.com.au/reno-now-pay-later/",
                                    "urls": [
                                        {
                                            "url": "https://topglaze.com.au/reno-now-pay-later/",
                                            "anchor_text": "Reno Now/Pay Later"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Over 100 Reviews",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": null,
                        "secondary_topic": [
                            {
                                "h_title": "Barangaroo Reserve",
                                "main_title": "Barangaroo Reserve",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61399177986",
                                "1800887798"
                            ],
                            "emails": [
                                "info@topglaze.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}