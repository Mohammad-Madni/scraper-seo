{
    "id": "01190728-1132-0216-0000-5f12ff9df965",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0144 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneyroofrestorers.com.au/services/barangaroo-nsw-2000/",
        "target": "sydneyroofrestorers.com.au",
        "start_url": "https://sydneyroofrestorers.com.au/services/barangaroo-nsw-2000/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Barangaroo\\organic\\type-organic_rg8_ra12_sydneyroofrestorers.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:14 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://sydneyroofrestorers.com.au/roofing-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/roofing-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting and Sealing",
                                    "url": "https://sydneyroofrestorers.com.au/painting-sealing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/painting-sealing/",
                                            "anchor_text": "Roof Painting and Sealing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement & Reroofing",
                                    "url": "https://sydneyroofrestorers.com.au/replacement-installation-reroofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/replacement-installation-reroofing/",
                                            "anchor_text": "Roof Replacement & Reroofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://sydneyroofrestorers.com.au/repointing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair & Replacement",
                                    "url": "https://sydneyroofrestorers.com.au/gutter-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/gutter-repair-replacement/",
                                            "anchor_text": "Gutter Repair & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation Systems",
                                    "url": "https://sydneyroofrestorers.com.au/roofing-ventilation-systems/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/roofing-ventilation-systems/",
                                            "anchor_text": "Roof Ventilation Systems"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://sydneyroofrestorers.com.au/roofing-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/roofing-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting and Sealing",
                                    "url": "https://sydneyroofrestorers.com.au/painting-sealing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/painting-sealing/",
                                            "anchor_text": "Roof Painting and Sealing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://sydneyroofrestorers.com.au/repointing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://sydneyroofrestorers.com.au/roofing-ventilation-systems/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/roofing-ventilation-systems/",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair & Replacement",
                                    "url": "https://sydneyroofrestorers.com.au/gutter-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/gutter-repair-replacement/",
                                            "anchor_text": "Gutter Repair & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bondi Junction",
                                    "url": "https://sydneyroofrestorers.com.au/services/bondi-junction-nsw-2022/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/services/bondi-junction-nsw-2022/",
                                            "anchor_text": "Bondi Junction"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lane Cove",
                                    "url": "https://sydneyroofrestorers.com.au/services/lane-cove-nsw-2066/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/services/lane-cove-nsw-2066/",
                                            "anchor_text": "Lane Cove"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surry Hills",
                                    "url": "https://sydneyroofrestorers.com.au/services/surry-hills-nsw-2010/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/services/surry-hills-nsw-2010/",
                                            "anchor_text": "Surry Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Watsons Bay",
                                    "url": "https://sydneyroofrestorers.com.au/services/watsons-bay-nsw-2030/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/services/watsons-bay-nsw-2030/",
                                            "anchor_text": "Watsons Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "\u00a9 2026 Sydney Roof Restorers, all rights reserved.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Privacy Policy | Terms and Conditions",
                                    "url": "https://sydneyroofrestorers.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        },
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://sydneyroofrestorers.com.au/roofing-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/roofing-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting and Sealing",
                                    "url": "https://sydneyroofrestorers.com.au/painting-sealing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/painting-sealing/",
                                            "anchor_text": "Roof Painting and Sealing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement & Reroofing",
                                    "url": "https://sydneyroofrestorers.com.au/replacement-installation-reroofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/replacement-installation-reroofing/",
                                            "anchor_text": "Roof Replacement & Reroofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://sydneyroofrestorers.com.au/repointing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair & Replacement",
                                    "url": "https://sydneyroofrestorers.com.au/gutter-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/gutter-repair-replacement/",
                                            "anchor_text": "Gutter Repair & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation Systems",
                                    "url": "https://sydneyroofrestorers.com.au/roofing-ventilation-systems/",
                                    "urls": [
                                        {
                                            "url": "https://sydneyroofrestorers.com.au/roofing-ventilation-systems/",
                                            "anchor_text": "Roof Ventilation Systems"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "We restore roofs of all types in Barangaroo. Call Sydney Roof Restorers today!",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Get a FREE Quote Today!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Please enable JavaScript in your browser to submit the form",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "The Best Roof Restoration Contractor In Barangaroo 2000",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We guarantee that you\u2019ll love the results of Sydney Roof Restorers!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We are expert Barangaroo roof restorers",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "[We are a leading roof restoration company servicing customers all over Barangaroo. We are a one-stop shop for all things roof restoration. From broken roof tiles to rusty metal sheets, or severely damaged roofs, we can tackle it all. We work with all types of roofs \u2013 metal, tiled, colorbond, terracotta and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Repair and Replacement",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If your roof is damaged or is looking unappealing, give us a call! We can discuss a customised solution for your property that may not involve a brand-new roof. You\u2019d be amazed at how a restored roof looks very much like a brand new one\u00a0\u2013 at a much cheaper price!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney Roof Restorers can provide a comprehensive assessment of the current status of your roof and suggest the most cost-effective solution for you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter Repair and Replacement",
                                        "url": "https://sydneyroofrestorers.com.au/gutter-repair-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/gutter-repair-replacement/",
                                                "anchor_text": "Gutter Repair and Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "About Our Roof Restoration Company",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With over 10 years of experience in the roofing sector, Sydney Roof Restorers prides itself for outstanding results and many satisfied customers.\u00a0Our knowledge of roofs is vast and includes all sorts of roofing materials: tiled, metal, colorbond, terracotta and more.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a local Barangaroo family-owned small business. We have the latest equipment and strictly follow industry best practice and safety standards. We are fully certified and have comprehensive insurance. Our staff is fully trained and have qualifications in different types of roofing trades, including:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof plumbers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof carpenters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof tilers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof painters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof installers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have the finest roof restoration professionals in Barangaroo!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Barangaroo Roof Repair & Restoration \u2013 Our Process",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We undertake a comprehensive roof assessment",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Report explaining the most cost-efficient and appropriate solution for your case",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019ll discuss a quote and the required timeframes for restoring your roof",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "After accepting our quote, we\u2019ll schedule a day/time to come over to do the restoration job.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clean up \u2013 we won\u2019t leave a mess behind!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What type of roof do you restore?",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We can restore it all! The most usual types of roof found in Barangaroo are tiled roofs, metal, colorbond and terracotta, however, we have repaired more unusual roof materials such as rubber or super traditional material such as shingles. It\u2019s very rare that we\u2019ll find a roof that we can\u2019t tackle. In case we do, there are good chances we can recommend other roofing professionals.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Is roof restoration just for traditional roofs?",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "No! Although the term restoration is normally linked to historical buildings, antiques and ancient objects; roof restoration applies to modern and sometimes fairly new roofs. Simply put, roof restoration is about fixing, re-coating, re-pointing and, more generally, performing jobs that will bring a broken roof to a point where it\u2019s like a brand new one.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Is it better to restore a roof than re-roof?",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "A brand new roof is more expensive. In that sense, roof restoration delivers a more affordable outcome compared to re-roofing. However, when a roof is too damaged and/or is deemed structurally unsound, re-roofing is often the only and safest solution. Sydney Roof Restorers usually recommends re-roofing as a \u2018last-resort\u2019 option.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you do storm damage roof inspection and repairs?",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes, we sure do! Storms are easily one of your roof\u2019s most feared enemies! Sydney Roof Restorers can assess your roof and look for any possible damage that may not be visible. We can also restore, repair and wash your roof post-storm.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you replace roofs that contain asbestos?",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes, we sure do! Under these circumstances, the first step is to get all asbestos materials safely removed before we get started on the new roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Barangaroo Roof Restoration Specialists",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We are a one-stop-shop roofing company and our expertise includes all aspects of roof restorations in Barangaroo:",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://sydneyroofrestorers.com.au/roofing-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/roofing-repairs/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting and Sealing",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Painting and Sealing",
                                        "url": "https://sydneyroofrestorers.com.au/painting-sealing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/painting-sealing/",
                                                "anchor_text": "Roof Painting and Sealing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Roofing (brand new roof)",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Re-Roofing (brand new roof)",
                                        "url": "https://sydneyroofrestorers.com.au/replacement-installation-reroofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/replacement-installation-reroofing/",
                                                "anchor_text": "Re-Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Ventilation Systems",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Ventilation Systems",
                                        "url": "https://sydneyroofrestorers.com.au/roofing-ventilation-systems/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/roofing-ventilation-systems/",
                                                "anchor_text": "Roof Ventilation Systems"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Re-pointing",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Re-pointing",
                                        "url": "https://sydneyroofrestorers.com.au/repointing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/repointing/",
                                                "anchor_text": "Roof Re-pointing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "We Restore Roofs in Barangaroo 2000",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u2026 and surrounding areas, including:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Millers Point",
                                        "url": "https://sydneyroofrestorers.com.au/services/millers-point-nsw-2000/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/services/millers-point-nsw-2000/",
                                                "anchor_text": "Millers Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Rocks",
                                        "url": "https://sydneyroofrestorers.com.au/services/the-rocks-nsw-2000/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/services/the-rocks-nsw-2000/",
                                                "anchor_text": "The Rocks"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dawes Point",
                                        "url": "https://sydneyroofrestorers.com.au/services/dawes-point-nsw-2000/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/services/dawes-point-nsw-2000/",
                                                "anchor_text": "Dawes Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Balmain East",
                                        "url": "https://sydneyroofrestorers.com.au/services/balmain-east-nsw-2041/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/services/balmain-east-nsw-2041/",
                                                "anchor_text": "Balmain East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Milsons Point",
                                        "url": "https://sydneyroofrestorers.com.au/services/milsons-point-nsw-2061/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/services/milsons-point-nsw-2061/",
                                                "anchor_text": "Milsons Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "McMahons Point",
                                        "url": "https://sydneyroofrestorers.com.au/services/mcmahons-point-nsw-2060/",
                                        "urls": [
                                            {
                                                "url": "https://sydneyroofrestorers.com.au/services/mcmahons-point-nsw-2060/",
                                                "anchor_text": "McMahons Point"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Other Barangaroo Roofing Services:",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof repairs",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof painting & sealing",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Roofing",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof ventilation systems",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof repointing",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter repairs",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions About Roof Restorations",
                                "main_title": "Barangaroo Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61251217216"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}