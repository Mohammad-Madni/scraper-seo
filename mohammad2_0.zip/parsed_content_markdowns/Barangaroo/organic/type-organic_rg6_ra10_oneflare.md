{
    "id": "01190728-1132-0216-0000-557091122b4b",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0221 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.oneflare.com.au/roofing/nsw/barangaroo",
        "target": "www.oneflare.com.au",
        "start_url": "https://www.oneflare.com.au/roofing/nsw/barangaroo",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Barangaroo\\organic\\type-organic_rg6_ra10_oneflare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:14 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Best roofing experts in Barangaroo",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Post a job now to get quotes from local roofing experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average rating of roofing experts in Barangaroo based on 234 reviews of 26 businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oneflare /",
                                        "url": "https://www.oneflare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/",
                                                "anchor_text": "Oneflare"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Categories /",
                                        "url": "https://www.oneflare.com.au/directory",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/directory",
                                                "anchor_text": "Categories"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.oneflare.com.au/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NSW /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw",
                                                "anchor_text": "NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                                "anchor_text": "Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Storey Roofing",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (1.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Storey Roofing are experts with years of experience in roofing repairs, roof restorations, maintenance and installations, metal roofing, colorbond roofing and more. We\u2019ll transform your roof to withstand the harsh Aussie climate and give it that new look and a new lease on life. Providing roofing services to residential and commercial buildings in Sydney and all throughout the coast and greater Sydney area. Check out our services and give us a call to see what we can do to help you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Storey Roofing",
                                        "url": "https://www.oneflare.com.au/b/james-storey-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/james-storey-roofing",
                                                "anchor_text": "Storey Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Oce Roofing Verified Business",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "North Parramatta, NSW (18.5km from North Parramatta)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OCEANIA ROOFING delivers roofing services all across Sydney. OCE specialises in :\n\u2022 Roof Leaks\n\u2022 Gutter leaks \u2022 Tile replacement \u2022 Colorbond replacement\n\u2022 Gutter cleaning\n\u2022 Roof maintenance \u2022 Roof Inspections\n\u2022 Roof washing\nAll job provided comes with 7 years warranty. Feel free to reach out to us!!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oce Roofing Verified Business",
                                        "url": "https://www.oneflare.com.au/b/oce-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/oce-roofing",
                                                "anchor_text": "Oce Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pipe Perfection Plumbers Drainage & Gas Fitting",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Marrickville, NSW (7.1km from Marrickville)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney\u2019s expert solution to your plumbing, drainage, gas problems. We\u2019ll fix it right or it\u2019s free! Inner West or Eastern Suburbs. Our customers describe us as reliable, thorough, punctual and knowledgeable and that\u2019s just the beginning! If you have a water, gas or roof leak, a blocked drain or need your plumbing repaired, you need Pipe Perfection Plumbers. Our work has a 6-year labour warranty plus 100% happiness guarantee. If you follow our advice but aren\u2019t 100% satisfied we will refund your money. Head to our website for your FREE copy of the Smart Consumer\u2019s Guide To Choosing the Right Plumber (and avoiding cowboys)",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pipe Perfection Plumbers Drainage & Gas Fitting",
                                        "url": "https://www.oneflare.com.au/b/pipe-perfection-plumbing-drainage-gas-fitting",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/pipe-perfection-plumbing-drainage-gas-fitting",
                                                "anchor_text": "Pipe Perfection Plumbers Drainage & Gas Fitting"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pure Metal Roofing",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (1.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The Pure Metal Proofing partnership has over 40 years experience between them in both metal and tile work. Pure Metal Roofing provide a high quality, reliable service to suit your business or residential needs. Pure Metal Roofing is one of the highest rated roofers on hi-pages. If you need a trustworthy, experienced and reliable roofer, give us a call.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pure Metal Roofing",
                                        "url": "https://www.oneflare.com.au/b/pure-metal-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/pure-metal-roofing",
                                                "anchor_text": "Pure Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Au Roofing",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Forest Lodge, NSW (3.1km from Forest Lodge)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Written Warranty\nWe have built a reputation on doing exceptional quality work and giving our clients amazing customer service. We provide a full 10 year written guarantee on all Roof Restorations and roof replacements.\nFully Insured & Licensed\nWe are a team of fully qualified and experienced roofers. We are fully insured and licensed for your peace of mind. We are also members of Master Builders Association as well as the Housing Industry Australia.\nRoofing Services\n\u2713 Concrete & Terra Cotta Roof Restoration\n\u2713 Concrete & Terra Cotta Roof Painting\n\u2713 Concrete & Terra Cotta Roof Cleaning\n\u2713 Concrete & Terra Cotta Roof Repairs\n\u2713 Valley Repairs and Replacements\nAll Roofing Services\nRoof Restorations\nRoof Replacements & New Roof\nRoof",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Au Roofing",
                                        "url": "https://www.oneflare.com.au/b/au-roofing-122",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/au-roofing-122",
                                                "anchor_text": "Au Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Metal Roofing Projects Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Surry Hills, NSW (2.3km from Surry Hills)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Trade Lic # 381129C\nFor all your metal roofing requirements, domestic & commercial New roofs, extensions, repairs, guttering & downpipes, box gutters. Zincalume & Colorbond\nFully qualified Roof Plumber with over 30years experience. Servicing eastern suburbs, inner west, southern suburbs & lower north shore Obligation free quote\nCompetitive pricing\nFully insured for your protection",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney Metal Roofing Projects Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/sydney-metal-roofing-projects",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/sydney-metal-roofing-projects",
                                                "anchor_text": "Sydney Metal Roofing Projects Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Suburbs Roofing & Repairs Pty Ltd",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (0.9km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a 3rd generation family company serving all of Sydney with high quality roofing repairs and all aspects of roofing we do Roofing leak repairs Valley repairs Roof washing and painting Sarkimg & battens Chimney repairs Flexi pointing Possum removal Rebedding Gutter repairs We give free estimates true out Sydney same day estimate We are fully registered & insured",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Suburbs Roofing & Repairs Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/all-suburbs-roofing-repairs-pty-ltd-568",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-suburbs-roofing-repairs-pty-ltd-568",
                                                "anchor_text": "All Suburbs Roofing & Repairs Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Dr leak plumbing",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (0.3km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Dr leak plumbing services is Fully Licensed and Insured with over 14 years experience In the plumbing field with the competitive pricing along with lifetime warranty on workmanship. We beat all quotes by 5% to 10% and also applying a 15% Pensioners discount and seniors.\nGive Dr Leak Plumbing a call on\n\ud83d\udee0 0409199799 to get your FREE QUOTE Based in Melbourne and Sydney. Family owned and operated",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Dr leak plumbing",
                                        "url": "https://www.oneflare.com.au/b/dr-leak-plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/dr-leak-plumbing",
                                                "anchor_text": "Dr leak plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Just Fascia & Gutter",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (1.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As a premier business specialising in residential and commercial roofing services, we are dedicated to providing customer service that is second to none. Whether you have a new construction project or need to replace an old or damaged fascia & gutter, roofing repair or replacement ,you\u2019ll be satisfied with us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Just Fascia & Gutter",
                                        "url": "https://www.oneflare.com.au/b/just-fascia-gutter",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/just-fascia-gutter",
                                                "anchor_text": "Just Fascia & Gutter"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Cain Sayers Roofing",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (1.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Straight to the point no short cuts quality trades work metal roofer that womt cost and arm and a leg",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Cain Sayers Roofing",
                                        "url": "https://www.oneflare.com.au/b/cain-sayers-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/cain-sayers-roofing",
                                                "anchor_text": "Cain Sayers Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Roof Gutter Repairs",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (1.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney Roof-Gutter Repairs over 20years of combined experience with peace of mind with trained contractors with many satisfied customers! We service all Sydney and nearby suburbs. We specialise in metal roofs and tile to metal reroofs and all aspects of metal roofing. Please visit our web site for more info or call 0422625879 to help with all inquiries!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney Roof Gutter Repairs",
                                        "url": "https://www.oneflare.com.au/b/sydney-roof-gutter-repairs",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/sydney-roof-gutter-repairs",
                                                "anchor_text": "Sydney Roof Gutter Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "MLR Slate Roofing Pty Ltd",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (1.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "MLR Slate roofing, specialises in traditional slate roofing, whether it's a small repair or a complete re-roof.\nAs a small business owner my aim is to provide and deliver top quality workmanship with a professional service.\nFor a no obligation quote please contact Matt",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "MLR Slate Roofing Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/mlr-slate-roofing-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/mlr-slate-roofing-pty-ltd",
                                                "anchor_text": "MLR Slate Roofing Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "OZWIDE Roofing",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (1.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OZWIDE ROOFING IS A WELL ESTABLISHED COMPANY WITH THE BEST TRADESMEN AND %100 workmanship attitude..the best rates on roof restorations call us now..",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "OZWIDE Roofing",
                                        "url": "https://www.oneflare.com.au/b/ausco-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/ausco-roofing",
                                                "anchor_text": "OZWIDE Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Blue Sky, Roofing And Property Maintenance",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (0.9km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are family owned and operated\nFully licensed and Insured\n20 years experience in Roofing We offer a warranty with all our work Free quote at a time suitable to you\nQuality service and peace of mind All our employees are respectful and we always keep a nice and tidy job site",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Blue Sky, Roofing And Property Maintenance",
                                        "url": "https://www.oneflare.com.au/b/blue-sky-roofing-and-property-maintenance",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/blue-sky-roofing-and-property-maintenance",
                                                "anchor_text": "Blue Sky, Roofing And Property Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Grand Platinum Developments",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (1.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At grand platinum we strive for boutique and luxury design and build,\nThe company withholds a stance of extravagant design and luxury to suit all types of clients, from bathroom renovations and kitchen to landscaping and building from scratch here at grand platinum we ensure a high level of customer satisfaction.\nWe offer a free final inspection report to make sure our clients are happy with the work delivered.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Grand Platinum Developments",
                                        "url": "https://www.oneflare.com.au/b/grand-platinum-developments",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/grand-platinum-developments",
                                                "anchor_text": "Grand Platinum Developments"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stormforce roofing & waterproofing",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (0.8km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Licensed & truly competent Tradesmen that ensure a quality job every time. Our team are Fully insured, height & safety certified, confined spaced certified & most importantly never settle for anything less than the best. We\u2019re Not Cowboys We don't compete with cowboys who decorate lamp posts with 'Dirt Cheap Offers'. We are real roofing and waterproofing tradesman; we add value to your home at competitive rates with Aussie products that last the test of time. Only a 10% deposit to secure schedule! No Progress Payments! We provide all machinery & materials! We're so confident that you will be delighted with the roofing and waterproofing work we provide that payment is only required after you've approved our finished work!\nUnbeatable",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Stormforce roofing & waterproofing",
                                        "url": "https://www.oneflare.com.au/b/roof-restoration-specialist",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roof-restoration-specialist",
                                                "anchor_text": "Stormforce roofing & waterproofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "RSG roofing",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (1.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality work is my preference for all the roofing jobs. Get your job done at good price.\nExperienced with jobs in city, suburban and regional where its hard to find tradies. good with\nRoof leaks Restoration Gutter clean\nRoof cleaning New Colorbond roof\nFascia\nGutter\nDownpipe\nSkylight Flashing Capping Roof exhaust fan, etc.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "RSG roofing",
                                        "url": "https://www.oneflare.com.au/b/rsg-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/rsg-roofing",
                                                "anchor_text": "RSG roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get the right price for your job",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Oneflare Cost Guide Centre is your one-stop shop to help you set your budget; from smaller tasks to larger projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Top Barangaroo roofing experts near you",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Browse top Roofing Expert experts with top ratings and reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quick Roof Service",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (1.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repairs, roof installation, gutter cleaning, gutter installation, downpipes, skylights",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Quick Roof Service",
                                        "url": "https://www.oneflare.com.au/b/quick-roof-service",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/quick-roof-service",
                                                "anchor_text": "Quick Roof Service"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Best roofing experts in Barangaroo",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "View more roofing experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Truss costs",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Truss costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Roof Truss costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $9,000 - $15,000",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Average price $9,000 - $15,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof costs",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roof costs",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Colorbond Roof costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $15,000 - $25,000",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Average price $15,000 - $25,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling costs",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Roof Tiling costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $35 - $140 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Average price $35 - $140 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing costs",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing costs",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Roofing costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $45 - $90 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Average price $45 - $90 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse roofing experts by suburb",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular searches on Oneflare",
                                "main_title": "Best roofing experts in Barangaroo",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.8,
                                "max_rating_value": 5,
                                "rating_count": 234,
                                "relative_rating": 0.96
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}