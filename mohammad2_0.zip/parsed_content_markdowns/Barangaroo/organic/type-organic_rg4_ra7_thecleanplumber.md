{
    "id": "01190728-1132-0216-0000-fc705ad32a35",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0261 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.thecleanplumber.com.au/roof-repairs/barangaroo/",
        "target": "www.thecleanplumber.com.au",
        "start_url": "https://www.thecleanplumber.com.au/roof-repairs/barangaroo/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Barangaroo\\organic\\type-organic_rg4_ra7_thecleanplumber.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:21 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Call for Same Day Service",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Emergency 24/7 Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/emergency-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/emergency-plumbing/",
                                            "anchor_text": "Emergency 24/7 Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Domestic Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/general-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/general-plumbing/",
                                            "anchor_text": "Domestic Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "TMV Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/tmv-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/tmv-plumbing/",
                                            "anchor_text": "TMV Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bathroom Renovations",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/bathroom-renovations/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/bathroom-renovations/",
                                            "anchor_text": "Bathroom Renovations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Real Estate Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/real-estate-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/real-estate-plumber/",
                                            "anchor_text": "Real Estate Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/kitchen-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/kitchen-plumber/",
                                            "anchor_text": "Kitchen Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/commercial-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/commercial-plumber/",
                                            "anchor_text": "Commercial Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/strata-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/strata-plumbing/",
                                            "anchor_text": "Strata Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/blocked-drains/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/blocked-drains/",
                                            "anchor_text": "Blocked Drains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leak Detection",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/leak-detection/",
                                            "anchor_text": "Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-plumbing/",
                                            "anchor_text": "Gas Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Stormwater Drains",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/stormwater-drains/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/stormwater-drains/",
                                            "anchor_text": "Stormwater Drains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Backflow Prevention",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/backflow/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/backflow/",
                                            "anchor_text": "Backflow Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/pipe-relinings/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/pipe-relinings/",
                                            "anchor_text": "Pipe Relining"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sub Soil Drainage",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/sub-soil-drainage/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/sub-soil-drainage/",
                                            "anchor_text": "Sub Soil Drainage"
                                        }
                                    ]
                                },
                                {
                                    "text": "Drain Camera Inspections",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/drain-camera-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/drain-camera-inspections/",
                                            "anchor_text": "Drain Camera Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pool Resurfacing & Tiling",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-resurfacing-tiling/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-resurfacing-tiling/",
                                            "anchor_text": "Pool Resurfacing & Tiling"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pool Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-plumbing/",
                                            "anchor_text": "Pool Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water Systems",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/hot-water-systems/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/hot-water-systems/",
                                            "anchor_text": "Hot Water Systems"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water Filtration Systems",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/water-filtration-systems/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/water-filtration-systems/",
                                            "anchor_text": "Water Filtration Systems"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Appliance Installation",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-appliance-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-appliance-installation/",
                                            "anchor_text": "Gas Appliance Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitting Repair Services",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-fitting-repair-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-fitting-repair-services/",
                                            "anchor_text": "Gas Fitting Repair Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Line Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-line-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-line-plumber/",
                                            "anchor_text": "Gas Line Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fridge Installation",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/fridge-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/fridge-installation/",
                                            "anchor_text": "Fridge Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Taps Sydney",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/leaking-taps-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/leaking-taps-sydney/",
                                            "anchor_text": "Leaking Taps Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gutter-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gutter-repairs/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Upper North Shore Plumber",
                                    "url": "https://www.thecleanplumber.com.au/upper-north-shore-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/upper-north-shore-plumber/",
                                            "anchor_text": "Upper North Shore Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lower North Shore Plumber",
                                    "url": "https://www.thecleanplumber.com.au/lower-north-shore-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/lower-north-shore-plumber/",
                                            "anchor_text": "Lower North Shore Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "South East Sydney Plumber",
                                    "url": "https://www.thecleanplumber.com.au/south-east-sydney-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/south-east-sydney-plumber/",
                                            "anchor_text": "South East Sydney Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs Plumber",
                                    "url": "https://www.thecleanplumber.com.au/eastern-suburbs-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/eastern-suburbs-plumber/",
                                            "anchor_text": "Eastern Suburbs Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wollongong Plumber",
                                    "url": "https://www.thecleanplumber.com.au/service-areas/wollongong-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/service-areas/wollongong-plumber/",
                                            "anchor_text": "Wollongong Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hills District Sydney",
                                    "url": "https://www.thecleanplumber.com.au/service-areas/hills-district-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/service-areas/hills-district-plumber/",
                                            "anchor_text": "Hills District Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Service Areas",
                                    "url": "https://www.thecleanplumber.com.au/roof-repairs-service-areas/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/roof-repairs-service-areas/",
                                            "anchor_text": "Roof Repairs Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining Service Areas",
                                    "url": "https://www.thecleanplumber.com.au/pipe-relining-service-areas/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/pipe-relining-service-areas/",
                                            "anchor_text": "Pipe Relining Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Service Areas",
                                    "url": "https://www.thecleanplumber.com.au/blocked-drains-service-areas/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/blocked-drains-service-areas/",
                                            "anchor_text": "Blocked Drains Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Other Areas",
                                    "url": "https://www.thecleanplumber.com.au/service-areas/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/service-areas/",
                                            "anchor_text": "Other Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Pricing",
                                    "url": "https://www.thecleanplumber.com.au/pricing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/pricing/",
                                            "anchor_text": "Our Pricing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Customer Testimonials",
                                    "url": "https://www.thecleanplumber.com.au/testimonials/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/testimonials/",
                                            "anchor_text": "Customer Testimonials"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lifetime Labour Warranty",
                                    "url": "https://www.thecleanplumber.com.au/lifetime-labour-warranty/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/lifetime-labour-warranty/",
                                            "anchor_text": "Lifetime Labour Warranty"
                                        }
                                    ]
                                },
                                {
                                    "text": "VIP Plumbing Program",
                                    "url": "https://www.thecleanplumber.com.au/vip-plumbing-program/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/vip-plumbing-program/",
                                            "anchor_text": "VIP Plumbing Program"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Standards",
                                    "url": "https://www.thecleanplumber.com.au/our-standards/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/our-standards/",
                                            "anchor_text": "Our Standards"
                                        }
                                    ]
                                },
                                {
                                    "text": "In the media",
                                    "url": "https://www.thecleanplumber.com.au/in-the-media/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/in-the-media/",
                                            "anchor_text": "In the media"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumbing Tips & Advice",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-tips-advice/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-tips-advice/",
                                            "anchor_text": "Plumbing Tips & Advice"
                                        }
                                    ]
                                },
                                {
                                    "text": "0488 854 186",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "$50 off Online Bookings",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Book Online",
                                    "url": "https://www.thecleanplumber.com.au/contact/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/contact/",
                                            "anchor_text": "Book Online"
                                        }
                                    ]
                                },
                                {
                                    "text": "$50 off Online Bookings",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Emergency 24/7 Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/emergency-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/emergency-plumbing/",
                                            "anchor_text": "Emergency 24/7 Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Domestic Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/general-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/general-plumbing/",
                                            "anchor_text": "Domestic Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "TMV Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/tmv-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/tmv-plumbing/",
                                            "anchor_text": "TMV Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bathroom Renovations",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/bathroom-renovations/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/bathroom-renovations/",
                                            "anchor_text": "Bathroom Renovations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Real Estate Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/real-estate-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/real-estate-plumber/",
                                            "anchor_text": "Real Estate Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/kitchen-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/kitchen-plumber/",
                                            "anchor_text": "Kitchen Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/commercial-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/commercial-plumber/",
                                            "anchor_text": "Commercial Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/strata-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/strata-plumbing/",
                                            "anchor_text": "Strata Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/blocked-drains/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/blocked-drains/",
                                            "anchor_text": "Blocked Drains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leak Detection",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/leak-detection/",
                                            "anchor_text": "Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-plumbing/",
                                            "anchor_text": "Gas Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Stormwater Drains",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/stormwater-drains/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/stormwater-drains/",
                                            "anchor_text": "Stormwater Drains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Backflow Prevention",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/backflow/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/backflow/",
                                            "anchor_text": "Backflow Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/pipe-relinings/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/pipe-relinings/",
                                            "anchor_text": "Pipe Relining"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sub Soil Drainage",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/sub-soil-drainage/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/sub-soil-drainage/",
                                            "anchor_text": "Sub Soil Drainage"
                                        }
                                    ]
                                },
                                {
                                    "text": "Drain Camera Inspections",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/drain-camera-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/drain-camera-inspections/",
                                            "anchor_text": "Drain Camera Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pool Resurfacing & Tiling",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-resurfacing-tiling/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-resurfacing-tiling/",
                                            "anchor_text": "Pool Resurfacing & Tiling"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pool Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-plumbing/",
                                            "anchor_text": "Pool Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water Systems",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/hot-water-systems/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/hot-water-systems/",
                                            "anchor_text": "Hot Water Systems"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water Filtration Systems",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/water-filtration-systems/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/water-filtration-systems/",
                                            "anchor_text": "Water Filtration Systems"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Appliance Installation",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-appliance-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-appliance-installation/",
                                            "anchor_text": "Gas Appliance Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitting Repair Services",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-fitting-repair-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-fitting-repair-services/",
                                            "anchor_text": "Gas Fitting Repair Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Line Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-line-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-line-plumber/",
                                            "anchor_text": "Gas Line Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fridge Installation",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/fridge-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/fridge-installation/",
                                            "anchor_text": "Fridge Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Taps Sydney",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/leaking-taps-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/leaking-taps-sydney/",
                                            "anchor_text": "Leaking Taps Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gutter-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gutter-repairs/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Upper North Shore Plumber",
                                    "url": "https://www.thecleanplumber.com.au/upper-north-shore-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/upper-north-shore-plumber/",
                                            "anchor_text": "Upper North Shore Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lower North Shore Plumber",
                                    "url": "https://www.thecleanplumber.com.au/lower-north-shore-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/lower-north-shore-plumber/",
                                            "anchor_text": "Lower North Shore Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "South East Sydney Plumber",
                                    "url": "https://www.thecleanplumber.com.au/south-east-sydney-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/south-east-sydney-plumber/",
                                            "anchor_text": "South East Sydney Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs Plumber",
                                    "url": "https://www.thecleanplumber.com.au/eastern-suburbs-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/eastern-suburbs-plumber/",
                                            "anchor_text": "Eastern Suburbs Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wollongong Plumber",
                                    "url": "https://www.thecleanplumber.com.au/service-areas/wollongong-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/service-areas/wollongong-plumber/",
                                            "anchor_text": "Wollongong Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hills District Sydney",
                                    "url": "https://www.thecleanplumber.com.au/service-areas/hills-district-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/service-areas/hills-district-plumber/",
                                            "anchor_text": "Hills District Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Service Areas",
                                    "url": "https://www.thecleanplumber.com.au/roof-repairs-service-areas/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/roof-repairs-service-areas/",
                                            "anchor_text": "Roof Repairs Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining Service Areas",
                                    "url": "https://www.thecleanplumber.com.au/pipe-relining-service-areas/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/pipe-relining-service-areas/",
                                            "anchor_text": "Pipe Relining Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Service Areas",
                                    "url": "https://www.thecleanplumber.com.au/blocked-drains-service-areas/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/blocked-drains-service-areas/",
                                            "anchor_text": "Blocked Drains Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Other Areas",
                                    "url": "https://www.thecleanplumber.com.au/service-areas/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/service-areas/",
                                            "anchor_text": "Other Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Pricing",
                                    "url": "https://www.thecleanplumber.com.au/pricing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/pricing/",
                                            "anchor_text": "Our Pricing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Customer Testimonials",
                                    "url": "https://www.thecleanplumber.com.au/testimonials/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/testimonials/",
                                            "anchor_text": "Customer Testimonials"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lifetime Labour Warranty",
                                    "url": "https://www.thecleanplumber.com.au/lifetime-labour-warranty/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/lifetime-labour-warranty/",
                                            "anchor_text": "Lifetime Labour Warranty"
                                        }
                                    ]
                                },
                                {
                                    "text": "VIP Plumbing Program",
                                    "url": "https://www.thecleanplumber.com.au/vip-plumbing-program/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/vip-plumbing-program/",
                                            "anchor_text": "VIP Plumbing Program"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Standards",
                                    "url": "https://www.thecleanplumber.com.au/our-standards/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/our-standards/",
                                            "anchor_text": "Our Standards"
                                        }
                                    ]
                                },
                                {
                                    "text": "In the media",
                                    "url": "https://www.thecleanplumber.com.au/in-the-media/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/in-the-media/",
                                            "anchor_text": "In the media"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumbing Tips & Advice",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-tips-advice/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-tips-advice/",
                                            "anchor_text": "Plumbing Tips & Advice"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Pipe relining, roof & emergency plumbing by Sydney\u2019s trusted plumbers. $0 call-out fee. 5.0\u2605 rating from 566 reviews. 41,000+ jobs since 1985.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof and Pool Plumbing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Drainage and Leak Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 The Clean Plumber \u2013 2026. All rights reserved.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "2 Millcroft Way, Kellyville NSW 2155, Australia",
                                    "url": "https://maps.google.com/maps?ll=-33.705209,150.93428&z=12&t=m&hl=en&gl=US&mapclient=embed&q=2%20Millcroft%20Way%20Beaumont%20Hills%20NSW%202155%20Australia",
                                    "urls": [
                                        {
                                            "url": "https://maps.google.com/maps?ll=-33.705209,150.93428&z=12&t=m&hl=en&gl=US&mapclient=embed&q=2%20Millcroft%20Way%20Beaumont%20Hills%20NSW%202155%20Australia",
                                            "anchor_text": "2 Millcroft Way, Kellyville NSW 2155, Australia"
                                        }
                                    ]
                                },
                                {
                                    "text": "49 Kenny St, Wollongong NSW 2500, Australia",
                                    "url": "https://www.google.com/maps/place/The+Clean+Plumber+Wollongong+-+40%2B+Years+in+Business/@-34.430223,150.8917334,17z/data=!3m1!4b1!4m6!3m5!1s0x6b13197f908fee35:0x30cb0391fdb6d12f!8m2!3d-34.430223!4d150.8917334!16s%2Fg%2F11xvy425b9?hl=en&entry=ttu&g_ep=EgoyMDI1MDkyMi4wIKXMDSoASAFQAw%3D%3D",
                                    "urls": [
                                        {
                                            "url": "https://www.google.com/maps/place/The+Clean+Plumber+Wollongong+-+40%2B+Years+in+Business/@-34.430223,150.8917334,17z/data=!3m1!4b1!4m6!3m5!1s0x6b13197f908fee35:0x30cb0391fdb6d12f!8m2!3d-34.430223!4d150.8917334!16s%2Fg%2F11xvy425b9?hl=en&entry=ttu&g_ep=EgoyMDI1MDkyMi4wIKXMDSoASAFQAw%3D%3D",
                                            "anchor_text": "49 Kenny St, Wollongong NSW 2500, Australia"
                                        }
                                    ]
                                },
                                {
                                    "text": "16 Billyard Ave, Wahroonga NSW 2076, Australia",
                                    "url": "https://www.google.com/maps?ll=-33.717267,151.121819&z=16&t=m&hl=en&gl=EG&mapclient=embed&cid=8416292324231872482",
                                    "urls": [
                                        {
                                            "url": "https://www.google.com/maps?ll=-33.717267,151.121819&z=16&t=m&hl=en&gl=EG&mapclient=embed&cid=8416292324231872482",
                                            "anchor_text": "16 Billyard Ave, Wahroonga NSW 2076, Australia"
                                        }
                                    ]
                                },
                                {
                                    "text": "0488 854 186",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Emergency 24/7 Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/emergency-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/emergency-plumbing/",
                                            "anchor_text": "Emergency 24/7 Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Domestic Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/general-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/general-plumbing/",
                                            "anchor_text": "Domestic Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "TMV Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/tmv-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/tmv-plumbing/",
                                            "anchor_text": "TMV Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bathroom Renovations",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/bathroom-renovations/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/bathroom-renovations/",
                                            "anchor_text": "Bathroom Renovations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Real Estate Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/real-estate-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/real-estate-plumber/",
                                            "anchor_text": "Real Estate Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/kitchen-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/kitchen-plumber/",
                                            "anchor_text": "Kitchen Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/commercial-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/commercial-plumber/",
                                            "anchor_text": "Commercial Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/strata-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/strata-plumbing/",
                                            "anchor_text": "Strata Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pool Resurfacing & Tiling",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-resurfacing-tiling/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-resurfacing-tiling/",
                                            "anchor_text": "Pool Resurfacing & Tiling"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pool Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-plumbing/",
                                            "anchor_text": "Pool Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Installations & Repairs",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Fridge Installation",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/fridge-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/fridge-installation/",
                                            "anchor_text": "Fridge Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Taps Sydney",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/leaking-taps-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/leaking-taps-sydney/",
                                            "anchor_text": "Leaking Taps Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gutter-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gutter-repairs/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/blocked-drains/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/blocked-drains/",
                                            "anchor_text": "Blocked Drains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leak Detection",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/leak-detection/",
                                            "anchor_text": "Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-plumbing/",
                                            "anchor_text": "Gas Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Stormwater Drains",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/stormwater-drains/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/stormwater-drains/",
                                            "anchor_text": "Stormwater Drains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Backflow Prevention",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/backflow/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/backflow/",
                                            "anchor_text": "Backflow Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/pipe-relinings/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/pipe-relinings/",
                                            "anchor_text": "Pipe Relining"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sub Soil Drainage",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/sub-soil-drainage/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/sub-soil-drainage/",
                                            "anchor_text": "Sub Soil Drainage"
                                        }
                                    ]
                                },
                                {
                                    "text": "Drain Camera Inspections",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/drain-camera-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/drain-camera-inspections/",
                                            "anchor_text": "Drain Camera Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water System Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Hot Water Systems",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/hot-water-systems/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/hot-water-systems/",
                                            "anchor_text": "Hot Water Systems"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water Filtration Systems",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/water-filtration-systems/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/water-filtration-systems/",
                                            "anchor_text": "Water Filtration Systems"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Gas Appliance Installation",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-appliance-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-appliance-installation/",
                                            "anchor_text": "Gas Appliance Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitting Repair Services",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-fitting-repair-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-fitting-repair-services/",
                                            "anchor_text": "Gas Fitting Repair Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Line Plumbing",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-line-plumber/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-line-plumber/",
                                            "anchor_text": "Gas Line Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Quick Links",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://www.thecleanplumber.com.au/service-areas/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/service-areas/",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lifetime Labour Warranty",
                                    "url": "https://www.thecleanplumber.com.au/lifetime-labour-warranty/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/lifetime-labour-warranty/",
                                            "anchor_text": "Lifetime Labour Warranty"
                                        }
                                    ]
                                },
                                {
                                    "text": "VIP Plumbing Program",
                                    "url": "https://www.thecleanplumber.com.au/vip-plumbing-program/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/vip-plumbing-program/",
                                            "anchor_text": "VIP Plumbing Program"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumbing Tips & Advice",
                                    "url": "https://www.thecleanplumber.com.au/plumbing-tips-advice/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/plumbing-tips-advice/",
                                            "anchor_text": "Plumbing Tips & Advice"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Standards",
                                    "url": "https://www.thecleanplumber.com.au/our-standards/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/our-standards/",
                                            "anchor_text": "Our Standards"
                                        }
                                    ]
                                },
                                {
                                    "text": "Customer Testimonials",
                                    "url": "https://www.thecleanplumber.com.au/testimonials/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/testimonials/",
                                            "anchor_text": "Customer Testimonials"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.thecleanplumber.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Scholarship Program",
                                    "url": "https://www.thecleanplumber.com.au/scholarship-program/",
                                    "urls": [
                                        {
                                            "url": "https://www.thecleanplumber.com.au/scholarship-program/",
                                            "anchor_text": "Scholarship Program"
                                        }
                                    ]
                                },
                                {
                                    "text": "License: A3149",
                                    "url": "https://verify.licence.nsw.gov.au/details/Contractor%20Licence/1-LEN-2654",
                                    "urls": [
                                        {
                                            "url": "https://verify.licence.nsw.gov.au/details/Contractor%20Licence/1-LEN-2654",
                                            "anchor_text": "License: A3149"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Barangaroo",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Serving Barangaroo for over 30 years with trustworthy roof plumbing services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24/7 emergency plumbing available \u2013 here when you need us most",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Specialised Roof Plumbing for High-End Properties in Barangaroo",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Call Now \u2013 Fast Help",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Limited-Time Roof Plumbing Specials in Barangaroo",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Looking for the\u00a0best plumbing deals? Don\u2019t miss out on the amazing specials we\u2019re offering at\u00a0The Clean Plumber. Head to our\u00a0specials page\u00a0today to discover exclusive discounts and find the perfect offer for your plumbing needs.",
                                        "url": "https://www.thecleanplumber.com.au/specials/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/specials/",
                                                "anchor_text": "specials page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "View Specials",
                                        "url": "https://www.thecleanplumber.com.au/specials/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/specials/",
                                                "anchor_text": "View Specials"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Roof Repair in Barangaroo",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With its modern buildings and exposed waterfront position, Barangaroo properties can face weather damage or roofing wear more frequently than expected. Clean Plumber offers practical roof repair services that help protect your property from long-term damage. We also work on hot water systems, unblock drains, complete gas plumbing tasks, and offer emergency plumbing support 24/7. Each service visit starts with a focus on safety and efficiency, and we never charge a call-out fee. Our team has worked across Sydney since 1990, and we bring over three decades of company experience to every task. Each plumber is fully licensed and trained according to Australian Standards. You\u2019ll always receive a clear, upfront quote with no unexpected fees. Every job is covered by our lifetime labour warranty, so you can feel confident in the quality of our work. With 500+ Google reviews and a perfect 5-star rating, Barangaroo locals continue to choose Clean Plumber for reliable plumbing and roof services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "0488 854 186",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Roof Plumbing Services You Can Rely On",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We provide a comprehensive range of roof plumbing services, including:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Safety is our top priority. Our team follows a strict safety process when working on roofs, ensuring all plumbers are equipped with harnesses and protective gear. For steep slopes, guardrails may be used to enhance safety and stability.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "In some cases,\u00a0pipe relining may be a no-dig alternative for repairing blocked or damaged drains, depending on the severity of the issue.",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/pipe-relinings/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/pipe-relinings/",
                                                "anchor_text": "pipe relining"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "For a more in-depth look at roof plumbing essentials,\u00a0check out our Ultimate Roof Plumbing Guide.",
                                        "url": "https://www.thecleanplumber.com.au/blog/roof-plumbing-guide/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/blog/roof-plumbing-guide/",
                                                "anchor_text": "check out our Ultimate Roof Plumbing Guide"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Flashing: Protect Your Home from Leaks",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof flashing prevents water leaks by directing rain away from vulnerable areas like chimneys, skylights, vents, and roof valleys. Our expert installation, repair, and maintenance services ensure your home stays watertight and secure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Downpipes: Essential for Preventing Water Damage",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A downpipe directs rainwater from the roof to the ground or drainage system, preventing ceiling leaks and structural damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Made from PVC, metal, or aluminium, it connects to gutters to keep water away from the foundation. Proper installation and maintenance prevent blockages, overflows, and costly repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you\u2019re dealing with a leak, check out our blog,\u00a0\u201cFixing a Ceiling Leak\u201d, for more information on identifying and resolving the issue.",
                                        "url": "https://www.thecleanplumber.com.au/blog/fixing-a-ceiling-leak/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/blog/fixing-a-ceiling-leak/",
                                                "anchor_text": "\u201cFixing a Ceiling Leak\u201d"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restorations for Lasting Protection",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Over time, roofs weaken due to weather, aging materials, and general wear. Our expert roof restoration services strengthen your roof, improve its appearance, and prevent leaks and structural damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We repair leaks, waterproof surfaces, and restore both tile and metal roofs. Our team also inspects and fixes gutters and downpipes to improve drainage and stop water-related issues before they worsen.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "By sealing and applying protective coatings, we extend your roof\u2019s lifespan and boost its resistance to harsh weather. Restore and protect your roof\u2014 contact us today for expert roof restoration services!",
                                        "url": "https://www.thecleanplumber.com.au/contact/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/contact/",
                                                "anchor_text": "contact us today"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Book a Plumber",
                                        "url": "https://www.thecleanplumber.com.au/contact/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/contact/",
                                                "anchor_text": "Book a Plumber"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Book a Plumber",
                                        "url": "https://www.thecleanplumber.com.au/contact/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/contact/",
                                                "anchor_text": "Book a Plumber"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How we can help you",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At The Clean Plumber, we specialise in a range of plumbing services designed to keep your home or business running smoothly, including:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Domestic Plumbing",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If it\u2019s a plumbing issue in your home, we guarantee we\u2019ll be able to fix it!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Explore Domestic Plumbing Solutions",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/general-plumbing/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/general-plumbing/",
                                                "anchor_text": "Explore Domestic Plumbing Solutions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Blocked Drains",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Smells coming from the drain? Toilets not flushing properly? We can help.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Clear Blocked Drains Now",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/blocked-drains/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/blocked-drains/",
                                                "anchor_text": "Clear Blocked Drains Now"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Plumbing",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We have certified roof plumbers who can fix leaks, gutters and downpipes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Get Roof Plumbing Help",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/roof-plumbing/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/roof-plumbing/",
                                                "anchor_text": "Get Roof Plumbing Help"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Plumbing",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We offer a genuine after-hours plumbing service to our clients so you can be assured that we\u2019re only one call away, no matter what time it is!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "24/7 Emergency Plumber",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/emergency-plumbing/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/emergency-plumbing/",
                                                "anchor_text": "24/7 Emergency Plumber"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Hot Water Plumbing",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If your system is leaking or needs any type of repair, we\u2019re here to help. We also expertly install new hot water systems of all sizes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Expert Hot Water Plumbing",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/hot-water-systems/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/hot-water-systems/",
                                                "anchor_text": "Expert Hot Water Plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stormwater Plumbing",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney weather can be unpredictable and cause all sorts of problems with your stormwater drains. Our plumbers are here to help!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Stormwater Drainage Solutions",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/stormwater-drains/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/stormwater-drains/",
                                                "anchor_text": "Stormwater Drainage Solutions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gas Plumbing",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Gas stopped working or perhaps you need a conversion? Our qualified gas fitters are here to save the day.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Hire a Certified Gas Plumber",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-plumbing/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/gas-plumbing/",
                                                "anchor_text": "Hire a Certified Gas Plumber"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leak Detection",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We offer a specialised leak detection service to all our domestic and commercial customers.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Professional Leak Detection",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/leak-detection/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/leak-detection/",
                                                "anchor_text": "Professional Leak Detection"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Backflow Prevention",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our accredited plumbers here at The Clean Plumber are authorised to install and test backflow prevention devices.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Licensed Backflow Prevention Experts",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/backflow/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/backflow/",
                                                "anchor_text": "Licensed Backflow Prevention Experts"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Thermostatic Mixing Valve",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Get perfect water temperature with quality thermostatic valve installation at affordable pricing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Thermostatic Mixing Valve Services",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/tmv-plumbing/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/tmv-plumbing/",
                                                "anchor_text": "Thermostatic Mixing Valve Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sub Soil Drainage",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Expert sub soil drainage solutions, from installations to repairs, protect your property today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Yard Drainage Solutions",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/sub-soil-drainage/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/sub-soil-drainage/",
                                                "anchor_text": "Yard Drainage Solutions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pool Resurfacing\n& Tiling Services",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our expert pool resurfacing and tiling services restore and upgrade your pool\u2019s look, ensuring a durable and visually stunning finish.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Expert Pool Restoration Solutions",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-resurfacing-tiling/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/pool-resurfacing-tiling/",
                                                "anchor_text": "Expert Pool Restoration Solutions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What do our customers have to say about The Clean Plumber?",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our 5-Star Google Reviews Speak For Themselves!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thank you to Stephen and Kevin for their excellent work during the Christmas break. Stephen realigned my father\u2019s toilet seat and did a great job, thankfully, because it\u2019s been a huge problem for my dad after several attempts from several plumbers. We also had a leak that was promptly detected and fixed in no time. We were happy with the very decent price and the seniors discount that my father was given. Stephen and Kevin were awesome guys that were lovely to speak to and they were also very tidy and respectful.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We had a leaking tap right at the start of the new year, and keen to get it fixed but couldn\u2019t get hold of the plumber we knew. It was pleasing to see The Clean Plumber has a user-friendly online booking system, and we are booked in for the next day in no time. Blake attended the job on-time on a searing hot day. He did a fantastic job, deserve a 5 out of 5 \u2013 he identified the issue quickly; explained the solution and price to us clearly before proceeding; he is skilful and cleaned up everything afterwards. Highly recommend!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our hot water system had recently given up on us. Blake came out on time and was fantastic to work with. Gave us an honest and reasonable upfront price to replace the system, and now we won\u2019t have to worry about the system while we\u2019re away.5 stars isn\u2019t enough!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "5/5 my husband and I have had the most fantastic experience with multiple individuals from individuals from the Clean Plumber. This past Friday, Harry and Blake were very helpful and today Isacc and David were particularly helpful. A big shout out to Isacc who was so thorough in understanding the complexities occuring in a few units. He was also generous with his time in explaining and helping us understand everything. Highly recommend The Clean Plumbers and will definitely use them in the future",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Great experience with The Clean Plumber. David and Blake were awesome to deal with and got our hot water system replaced quickly, even over the Christmas/New Year break. Super easy process, no hassles at all, and they cleaned everything up before they left. Really impressed with the service &##x1f44d;",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I had a very large job with this business and I must say I\u2019m very happy with the work they did. The plumber who came out for the quote was very professional answer my never ending questions without any fuss and with helpful explanations.When the job was being work on the team was very proactive in keeping me informed as to what going to happen what to expect and how it impacted any happening.I\u2019m very happy with the service they provided.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The Clean Plumbers came on Christmas Eve to patch my Sewer near the Sydney Water main sewer. David and Con worked to late afternoon including finding the Main was full of root and debris to nearly blocked; and will help to report to Sydney Water for proper treatment. We much appreciate David and Con\u2019s dedication and willing to take the extra step to help us &##x1f44d;",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thank you for letting me encounter such a great company and such responsible staff.They finally resolved the water leak issue in our home, which had been troubling us for a long time.We had two or three plumbers come before, but none of them were able to fix the problem.David, Beny, Jayden, and Constantinos dug up the concrete driveway at our place, located the copper pipe, and repaired it successfully.It\u2019s hard to imagine how they managed to do such an outstanding job in such hot weather.Thank you, The Clean Plumber.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Had our first dishwasher installed today. A benchtop one. The whole experience was faultless; from the assessment by James and Kevin, the timing schedule and then the installation. Blake arrived on time. Completed the job efficiently and expertly. Blake was also very pleasant to deal with and extremely tidy. Thank you Blake and thank you The Clean Plumbet.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Review from Dennis Lee West Pennant HillsDavid attended our house and fixed our complicated tap leak but also identified that leaky bathroom and old shower taps also needed replacing and input metal hoses under our vanity sink needed replacing as they were severely worn thereby saving us from a burst pipe incident in the future. Great work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I recently had a major drain issue at my property, and The Clean Plumber delivered an exceptional experience from start to finish. It was a huge undertaking, but the team handled it with total professionalism and care.A massive thank you to Isaac, David, and Jayden, who were on-site throughout the job. Their communication was clear, their workmanship was outstanding, and their attention to detail gave me complete confidence that the problem was being fixed properly. They explained every step, offered solutions, and made what could have been a stressful situation incredibly smooth.The Clean Plumber truly lives up to their name reliable, efficient, and genuinely committed to high-quality service. I couldn\u2019t be happier with the result and highly recommend them to anyone needing drainage or plumbing work done right",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I highly recommend The Clean Plumber.I called them regarding a leaking tap and they were incredibly prompt, arriving at my house within the hour. David, was efficient, knowledgeable, and got the job done quickly.What really impressed me was how clean their service was. They took great care to protect the area they were working in and left absolutely no mess behind\u2014it was like they were never there!For prompt, reliable, and exceptionally clean plumbing work, look no further. Five stars!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I couldn\u2019t be happier with the work. The plumber was professional, punctual, and very knowledgeable. They quickly identified the issue, explained everything clearly, and fixed it efficiently. The quality of work was top-notch, and they left everything clean and tidy. Highly recommend to anyone looking for a reliable and skilled plumber!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I am very impressed with the level of service I received from Bree at the sales desk.She listened to my needs and provided me with options and assistance for my bathroom renovation. No question was too much for herShe went beyond my buyers expectations.My experience went for overwhelmed to enjoyment.Thank you so much Bree.Lorena",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019ve been using the Clean Plumber for years. What I love about the team is they always do what they say. They communicate well and are super customer focused. Recently had Jordan visit us for a couple of jobs and couldn\u2019t be more happy with the service!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Kevin was absolutely outstanding! He stood by me every step of the way when things went wrong and didn\u2019t stop until everything was fully resolved. What impressed me most was how he took full ownership of the situation instead of passing it around. His support, patience, and professionalism made a stressful experience so much easier. I really appreciate his dedication and can\u2019t thank him enough!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tanaka is the man! The team at The Clean Plumber came at a time where I just wasn\u2019t happy with our recent renovation. Tanaka solved our problems and he did it with style and competence (as well as living up to their namesake with his indoor booties to keep things clean). Highly recommended!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Very disappointed with the service related to Job Number 4154. Communication was poor from the start, and the issue was not handled professionally. Despite following up multiple times, there was little accountability, and the experience left me feeling frustrated and let down. For the price they charge, I expected reliability and proper customer support, but unfortunately, that was not the case. I would not recommend The Clean Plumber based on this experience.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Nick from The Clean Plumber came on Thursday afternoon to diagram and quote to fix a leaking upstairs hand basin which leaked onto the downstairs ceiling. Another plumber (not sure of his name as my wife was dealt with him) whom I met when I got home from work and he was finishing up the work. Both were very nice, helpful and very professional and they live up to company\u2019s name. Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The Clean plumber\u2019s service is fast efficient and on time. Today David has done a great job for me, fixed the complicated blocked main drains in my property. He is polite and explained things very clearly. I highly recommend him to anyone.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "David from the Clean Plumber arrived on time.Extremely polite and helpful.Immediately located the problems and resolved both the leak and blocked Water Board main issue quickly and efficiently.Followed up with the Water Board and arranged for them to inspect their main line the same day.Could not be more satisfied.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Outstanding Service from Nick!Nick assisted with a plumbing issue involving my hot water system, and I couldn\u2019t be more impressed. He was efficient, clearly communicated the problem, and promptly resolved it. His professionalism stood out throughout from diagnosing the issue to completing the job with care and attention. He even took the time to tidy up afterwards, which was greatly appreciated. Highly recommend Nick for anyone needing reliable and professional plumbing work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Great service!A friendly Chinese gentleman (possibly named David) came to clean our plumbing. He carefully listened to all our concerns and did a fantastic job. He went the extra mile to make sure everything was clean and there were no blockages left. Super helpful and professional \u2014 really happy with the service! Super hero:)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I dont normally do reviews but Tony was a champion, super accomodating and took the time to explain my blockage issue thoroughly. Great service and will use again! \u2013 Thanks Clean Plumber",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I recently experienced a blocked toilet at home and contacted The Clean Plumber for assistance. David, the plumber who attended, delivered exceptional service. He was professional, efficient, and handled everything with great care. He thoroughly cleared the blockage, explained the cause to me, and ensured the area was left spotless\u2014there was no mess at all.What I appreciated most was the honesty and transparency\u2014there were no hidden fees, just straightforward, high-quality service. I\u2019m extremely impressed with David\u2019s work and would highly recommend The Clean Plumber to anyone in need of reliable and trustworthy plumbing services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I used the Clean Plumber and they were honest in their assessment. A previous plumber installed our freestanding bathtub incorrectly and used the incorrect drain connection (for a sink instead of a tub) leading to unbearably slow drainage. I hired two other plumbers who couldn\u2019t diagnose the problem correctly but the Clean Plumber came and identified the issue and re-installed the tub with correct parts. All along the process they were upfront as to how much it would cost to do the work based on issues found. They were pleasant to deal with and thoroughly explained how they were going to fix it. I would definitely use them again.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guys got us out of a tough spot with a leaking valve on the hot water system on Christmas eve. Saved the family from cold showers for a week.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I\u2019m writing this review as a very happy first time customer. Service was excellent, David was very knowledgeable and friendly. Pricing is reasonable and transparent. I would highly recommend The Clean Plumber",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I had an emergency plumbing situation and a work colleague recommended Cerena and The Clean Plumber. Cerena was an absolute legend from start to finish! Responded quickly, was professional and solved the problem in no time. Would highly recommend to anyone i know.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tanaka was great. He communicated well on what he was doing and any disruption to water supply.Turned up on time and no mess when he left.Thanks clean plumber",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "My mother had The Clean Plumbers to fix her bathroom shower taps. Jayden was very professional and friendly. Highly recommend Jayden.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Many thanks to David and Harry. Resolved my plumbing problems quickly and efficiently. Would be happy to recommend.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I had a blocked gutter and the two men who came to fix it were efficient and found the problem and fixed it. As it wasn\u2019t fixed properly the first time. I like their professionalism too.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Great service from The Clean Plumber and Jayden. Very professional and transparent. Had a leak and the response and assistance was very prompt. The job was completed efficiently, thoroughly and economically. I definitely recommend and will use them again for all plumbing needs. Well done team. Awesome customer service. Many thanks.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Excellent Service and Professionalism!I recently called The Clean Plumber for a repair job, and I couldn\u2019t be happier with their service. The team was punctual, polite, and very efficient. The pricing was transparent, and they left the workspace clean and tidy.If you\u2019re looking for reliable plumbers in Sydney, I highly recommend The Clean Plumber!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "David was helpful in fixing and clear in explaining the reasons behind the water flow issues. Thanks for your expertise and service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I recently had the pleasure of having Tanaka from The Clean Plumber handle a plumbing issue at my home, and I couldn\u2019t be happier with the service. From start to finish, Tanaka was the epitome of professionalism. He arrived on time, which I greatly appreciated, and even wore shoe covers to ensure my home stayed spotless\u2014such a thoughtful touch!Tanaka was incredibly polite and took the time to clearly explain the work that needed to be done, outlining all the options available with transparent and very reasonable pricing. This made it easy for me to make an informed decision without feeling pressured. His work was efficient, thorough, and left everything cleaner than when he arrived.Not only did he solve the plumbing issue flawlessly, but he was also genuinely pleasant to have around, making the whole experience stress-free. I will absolutely be using The Clean Plumber again, and I highly recommend Tanaka to anyone in need of a reliable, skilled, and courteous plumber.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Recently called the clean plumber for an urgent plumbing issue. I have never called them before but after jayden arrived to my house and completed the work I\u2019ll never call anyone else. Jayden was on time, had great communication, explained everything he was doing to me and how things work, his work was precise and to a high standard and left the work area spotless. I will definitely be asking for Jayden again next time I need a plumber.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jayden is an exceptional plumber who exemplifies professionalism and expertise. His communication skills are outstanding, keeping us informed every step of the way. He completed the job with precision and care, ensuring everything was spotless. A true professional and a pleasure to work with!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "My in-laws were after a reliable plumber but didn\u2019t know anyone reputable. I did a google search for them and took a few quotes. Although The Clean Plumber wasn\u2019t the cheapest, their quote was still very reasonable and they were by far the most professional to deal with. Happy with the job and glad we took the plunge. Workmanship 5 stars, Service 5 stars and reliability 5 stars. Job well done!!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I contacted the Clean Plumber yesterday for a blockage in my shower. They arrived within 3 hours, cleared it and gave us some excellence advice on how to maintain it going forward. It was a smooth service from start to finish. High\u00a0recommend!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I had a great experience replacing our toilet with Clean Plumbing. While the cost was higher than some other quotes I received, the quality of the work and the final result made it worthwhile. The service was very professional. Thank you to the entire team, especially Jayden, for a great job",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What a fantastic and reliable company! Made my booking a week prior and the team showed on at the expected time. Work was completed with very little mess !Would highly recommend Kevin and his team for your plumbing repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Based on 615 reviews",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "03:33 09 Jan 26",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "03:22 09 Jan 26",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "00:29 09 Jan 26",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "01:37 07 Jan 26",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "04:47 30 Dec 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "23:55 29 Dec 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "04:36 26 Dec 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "03:20 25 Dec 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "08:45 22 Dec 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "01:34 10 Dec 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "00:38 29 Nov 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "09:32 28 Nov 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "03:32 04 Nov 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "00:50 29 Oct 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "02:03 03 Oct 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "23:55 16 Sep 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "08:20 16 Sep 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "09:08 05 Sep 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "08:29 02 Sep 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "07:20 22 Aug 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "12:00 26 Jul 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "00:04 23 Jul 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "00:56 21 Jul 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10:39 27 May 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10:11 06 May 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "06:45 15 Apr 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "21:50 25 Feb 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "02:30 24 Feb 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "03:05 07 Feb 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "00:22 05 Feb 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "03:37 02 Feb 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "19:52 29 Jan 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "23:28 28 Jan 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "00:14 24 Jan 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "01:26 22 Jan 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "04:44 11 Jan 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "23:36 09 Jan 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "05:17 08 Jan 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "02:26 07 Jan 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "23:09 05 Jan 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "21:02 05 Jan 25",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "05:46 26 Dec 24",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "00:57 03 Dec 24",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "23:51 25 Nov 24",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "04:23 19 Nov 24",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "04:22 19 Nov 24",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "03:10 19 Nov 24",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "11:15 25 Oct 24",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "23:24 06 Oct 24",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "12:02 02 Oct 24",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "06:00 23 Sep 24",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "We also offer a LIFETIME warranty on all labour!",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u201cClean Plumber is now our plumber of choice! Five stars to Matthew. He was prompt, polite and helpful. Answered all our questions thoroughly before proceeding to replace the tap and when he got to work nothing was a problem. He even left the worksite much cleaner than when he started.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cContacted Clean P from their fridge magnet and took up their seniors offer. They tidied up some taps and washers in some problem areas and were able to identify a few pressing issues. Price was reasonable and we went ahead to get them fixed. We are confident in their service and warranty and felt very secure due to their sound knowledge of matters\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cShane and his team are awesome. They regularly look after our plumbing and general maintenance needs for our hotel. Great guys. Nothing is ever trouble. And Everything is always done efficiently and at a reasonable price.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cThe Clean plumber came to my home to investigate a roof leak. They diagnosed the issue and put in a plan of action to rectify it. I am convinced that had it not been for Damien\u2019s foresight, the situation could have been a lot worse down the track.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "They are excellent plumbers and their knowledge and wisdom is unparalleled compared to other plumbers I have engaged in the past.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cWe contacted Clean Plumber after hours for a urgent matter, as we had a large pipe that burst on our acreage property. They turned up within the hour and immediately stopped the leaking.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We were very impressed with the quick service as we live in a semi rural area. They came back a few days later and replaced the faulty section of the pipe. All in all a very happy customer!\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cAs a manager of several childcare centres we need reliable plumbers. The clean plumber is our go to plumbers, always quick, efficient and on time. The Clean Plumbers are professional, reliable and can be trusted to get the job done to a high standard.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cGreat job on the shower leak guys. Diego removed all tiles to base and re-waterproofed and tiled our 2 showers. He provided excellent service and we are very happy with his work. We recommend to anyone worth a shower base leak to reach out to them!\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cClean Plumber came to my house and fixed a blocked toilet and leaking kitchen sink. The experience was very professional from booking in the job to the service. Happy to give them five stars. Thanks\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cClean plumber attended my property in Strathfield and installed a new vanity and two toilets. The service was quick and efficient and better yet the site was left squeaky clean. Big shout out to Damien!\u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tim Y",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Call 0488 854 186",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "24/7 Emergency Plumber in Barangaroo",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Clean Plumber team operates 24 hours a day, 7 days a week, and is always on call for emergencies. No matter the time, if you are dealing with a plumbing emergency, we\u2019ll resolve it as efficiently as possible, leaving you satisfied with our work. So if you are currently experiencing a plumbing emergency,\u00a0call us on\u00a002 8859 0801.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you suspect a gas leak, don\u2019t take any risks\u2014call a professional immediately. Learn more about detecting and preventing gas leaks in our\u00a0Gas Leaks blog.",
                                        "url": "https://www.thecleanplumber.com.au/blog/top-tips-for-gas-leak-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/blog/top-tips-for-gas-leak-repairs/",
                                                "anchor_text": "Gas Leaks blog"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "With years of experience and the skills to back it up, our expert plumbers provide a hassle-free, affordable, and reliable plumbing experience.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have helped repair and resolve all types of plumbing issues for our Annandale customers, thanks to our innovative approach and use of the latest plumbing technology. This ensures that every service is of the highest quality, giving you value for money.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Going the extra mile to see you smile!",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A legacy of reliability and expertise.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Delivering quality plumbing services on every job, big or small.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ready to help, day or night, for emergencies like burst pipes, blocked toilets, and gas leaks.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We guarantee same day service and excellent customer service. Our reviews speak for themselves!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lifetime Labour Warranty & Guarantees",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We provide warranties on all work conducted and a manufacturer\u2019s warranty on parts and equipment.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No gimmicks, upfront\u00a0fixed pricing guaranteed by our expert plumbing team.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All our plumbers are fully licensed & have been trained in accordance with Australian Standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Respect for Your Home with CleanBoot\u00ae\ufe0f Protection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Keeping your home spotless by preventing dirt and debris with every visit.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "40+ Years of Service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "41,000+ Jobs Completed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24/7 Plumbing Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "5 Star Reviews",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Affordable Plumbing Guaranteed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Qualified Team",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is Roof Plumbing?",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof plumbing is a critical yet often overlooked aspect of maintaining a home or building, so hiring an experienced roof plumber can be beneficial . It refers to the installation,\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "What is Roof Plumbing?",
                                        "url": "https://www.thecleanplumber.com.au/blog/what-is-roof-plumbing/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/blog/what-is-roof-plumbing/",
                                                "anchor_text": "What is Roof Plumbing?"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Your Ultimate Roof Plumbing Guide",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof plumbing\u00a0is a highly crucial part to keep either your home or workplace safe. It helps to prevent damage occurring, as well as redirecting potential leaks that could cause major\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Your Ultimate Roof Plumbing Guide",
                                        "url": "https://www.thecleanplumber.com.au/blog/roof-plumbing-guide/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/blog/roof-plumbing-guide/",
                                                "anchor_text": "Your Ultimate Roof Plumbing Guide"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "The Benefits of Pipe Relining",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Repairing pipes can be challenging, especially when they are located beneath structures like buildings, pools, or gardens.\u00a0Pipe relining\u00a0offers an effective, modern solution for homeowners, businesses, and strata seeking to avoid\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "The Benefits of Pipe Relining",
                                        "url": "https://www.thecleanplumber.com.au/blog/the-benefits-of-pipe-relining/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/blog/the-benefits-of-pipe-relining/",
                                                "anchor_text": "The Benefits of Pipe Relining"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Do you offer emergency roof plumbing services in Barangaroo?",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Yes\u2014we provide\u00a024/7 emergency roof plumbing in Barangaroo. Whether it\u2019s storm damage, blocked gutters, or leaks, we aim to be onsite within an hour, fully equipped to sort it promptly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much should I expect to pay for roof repairs in Barangaroo?",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Costs depend on the issue\u2019s severity. We\u2019ll inspect your home (call\u2011out is free), explain your options clearly, and quote with flat-rate pricing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What services do you offer for roof plumbing in Barangaroo?",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our Barangaroo roof plumbing services include gutter repair and replacement, downpipe installation, flashing repairs, stormwater solutions, roof leak investigations, and complete roofing inspections",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How often should I get my roof plumbing checked in Barangaroo?",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We recommend inspections\u00a0every 6\u201312 months, often after winter and before storm season, to spot and fix minor issues early.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Are you licensed and insured in Barangaroo?",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Absolutely. We\u2019re fully licensed and insured, with proof available upon request\u2014giving you peace of mind with every job.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "$0 Callout",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Express Booking Guaranteed 24 Hours",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "$50 off Online Bookings",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Preferred Time (Sydney Time)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Are you the owner of the property?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Your Information Is 100% Safe & Secure",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Based on 615 reviews",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a quick quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Preferred Date",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us?",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Roof Flashing Matters",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Flashing Services",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hear from one of our amazing customers",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roof Plumbing Jobs",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Strata Plumbing",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Voted Sydney\u2019s top strata plumber: 24/7 service, trusted by over 1,200 strata managers.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Reliable Strata Plumbing Solutions",
                                        "url": "https://www.thecleanplumber.com.au/plumbing-services/strata-plumbing/",
                                        "urls": [
                                            {
                                                "url": "https://www.thecleanplumber.com.au/plumbing-services/strata-plumbing/",
                                                "anchor_text": "Reliable Strata Plumbing Solutions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Over 41,000 Jobs Completed",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Rated 5 Stars on Google!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Meet Our Team",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Plumbing Supervisor",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Nearby Service Areas",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Blogs",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions \u2013 Roof Plumbing Barangaroo",
                                "main_title": "Barangaroo",
                                "author": "The Clean Plumber",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 557,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 557,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 557,
                                "relative_rating": 1
                            }
                        ],
                        "offers": [
                            {
                                "name": null,
                                "price": 199,
                                "price_currency": "AUD",
                                "price_valid_until": "2025-08-31 00:00:00 +00:00"
                            },
                            {
                                "name": null,
                                "price": 149,
                                "price_currency": "AUD",
                                "price_valid_until": null
                            }
                        ],
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61488854186",
                                "0288590801"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}