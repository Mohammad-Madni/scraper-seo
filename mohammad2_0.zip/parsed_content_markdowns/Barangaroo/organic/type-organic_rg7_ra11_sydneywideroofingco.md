{
    "id": "01190728-1132-0216-0000-3e655518fe57",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0211 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneywideroofingco.com.au/city-of-sydney/barangaroo/",
        "target": "sydneywideroofingco.com.au",
        "start_url": "https://sydneywideroofingco.com.au/city-of-sydney/barangaroo/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Barangaroo\\organic\\type-organic_rg7_ra11_sydneywideroofingco.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:15 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipes",
                                    "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                            "anchor_text": "Gutters and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tile Pointing and Bedding",
                                    "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                            "anchor_text": "Roof Tile Pointing and Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Roofing",
                                    "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                            "anchor_text": "Zinc Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs in Randwick NSW",
                                    "url": "https://sydneywideroofingco.com.au/randwick/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/randwick/",
                                            "anchor_text": "Roof Repairs in Randwick NSW"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Georges River",
                                    "url": "https://sydneywideroofingco.com.au/georges-river/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/georges-river/",
                                            "anchor_text": "Georges River"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Inner West Roof Repairs",
                                    "url": "https://sydneywideroofingco.com.au/inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/inner-west/",
                                            "anchor_text": "Sydney Inner West Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "City of Sydney",
                                    "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                            "anchor_text": "City of Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "GET QUOTE",
                                    "url": "https://sydneywideroofingco.com.au/get-quote/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/get-quote/",
                                            "anchor_text": "GET QUOTE"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "95 Bellingara Rd, Miranda NSW 2228.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "(02) 8294 4654",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "The Barangaroo Roofing Difference.",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to fortifying your Barangaroo residence or business against Sydney\u2019s unpredictable elements, top-tier roofing services are indispensable. Sydney Wide Roofing Co stands as the premier choice in Barangaroo, representing unwavering dedication to excellence. Our seasoned team recognises that a robust roof is more than just protection; it\u2019s a lasting investment in your property\u2019s safety and value. With vast experience under our belt, we masterfully handle roofing projects, guaranteeing that every job showcases our expertise and dependability. From prompt roof repairs to impeccable installations, we\u2019re here to bolster your Barangaroo estate with exceptional roofing solutions, offering both resilience and tranquillity.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Exceptional Roofing Services",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Wide Roofing Co is your go-to ally for all roofing endeavours, irrespective of scale or intricacy. Our roofers in Barangaroo emphasize superior craftsmanship, enduring solutions, and client contentment. Here\u2019s a snapshot of our offerings:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Barangaroo",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "When refurbishing becomes a futile effort or when your roof is past its prime, our proficient crew ensures a flawless roof replacement. We focus on both your property\u2019s aesthetic elevation and its comprehensive defence against varying weather.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation Barangaroo",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Be it a contemporary home build or an annex, our adept Barangaroo roofing maestros proficiently manage installations across all scales and designs. Trust in our premium materials and rigorous industry compliance for a lasting roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Barangaroo",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Proactive roof repairs in Barangaroo are essential to curb escalating issues and retain the roof\u2019s foundational strength. We\u2019re adept at spotting and remedying a spectrum of roofing concerns, from minor leakages to significant structural defects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Barangaroo",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Breathe new vigour into an aging roof without a complete overhaul through our restoration services. We meticulously clean, repair, and reseal to prolong your roof\u2019s life and bolster its aesthetics.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters and Downpipes Barangaroo",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ensure rainwater efficiently diverts from your premises with our services for gutters and downpipes. We install, maintain, and repair these vital systems to ward off potential water damage and uphold your roof\u2019s integrity.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Pointing Barangaroo",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "With prolonged exposure, roof tiles may wane, risking seepages and thermal inefficiencies. Rely on our specialists for precise tile pointing, solidifying loose tiles, and enhancing your roof\u2019s weather resistance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Why Barangaroo Chooses Us When it comes to premier services in Barangaroo, our unparalleled expertise sets us apart. Here\u2019s why Barangaroo residents consistently favour us:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rich Industry Experience : Our tenure in the roofing world speaks volumes. Decades of unwavering dedication have enriched our insights, sharpening our craft.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Unparalleled Barangaroo Acumen : We don\u2019t merely serve Barangaroo; we\u2019re woven into its fabric. This deep-rooted connection imparts a nuanced grasp of the locale, facilitating services tailored to Barangaroo\u2019s unique essence.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Staunch Dedication to Client Delight : Our ethos revolves around client contentment. Our enduring client relationships reflect our commitment to transparency, adaptability, and genuine care.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Masterful Craftsmanship and Precision : Every project is a testament to our relentless pursuit of perfection. Be it an expansive assignment or a minor tweak, our attention to detail is unwavering.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Reach Out To Us",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney Wide Roofing Co is at your service:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Barangaroo: A Snapshot and Local Roofing Insights Nestled in Sydney\u2019s heart, Barangaroo is a dynamic urban locale, teeming with modern edifices, cultural spots, and a vibrant waterfront. Roofing in Barangaroo demands a blend of aesthetics and functionality, factoring in the bustling urban milieu.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local Roofing Norms : Barangaroo roofing adheres to the regulations stipulated by the City of Sydney. It\u2019s essential to familiarize oneself with these specifics:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Material and Design : Unique architectural zones might dictate specific roofing aesthetics.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bushfire and Safety Protocols : Given Barangaroo\u2019s urban setting, fire safety remains paramount.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Stormwater Management : Barangaroo\u2019s dense urbanization necessitates efficient drainage systems.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Permit Essentials : Secure the necessary permits for compliance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Green Initiatives : Embrace sustainable materials and practices, aligning with Barangaroo\u2019s forward-thinking ethos.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney Wide Roofing Co is Barangaroo\u2019s trusted roofing confidant. With us, expect impeccable service and unwavering commitment. We\u2019re here for you, Barangaroo!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Phone \u2013 (02) 8294 4654",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email \u2013 [email\u00a0protected]",
                                        "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Website \u2013 https://sydneywideroofingco.com.au/",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                                "anchor_text": "https://sydneywideroofingco.com.au/"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Experts in Roof Repair",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roof repair service includes general repairs, repairs of broken or damaged tiles, repair of roof hips and skellions and repair of water leaks",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installs",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A re-roofing or brand new roof install project can be stressful project, which is why you need the best contractors to help ease you through the process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Bedding",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Pointing has the function of binding the ridge capping onto the tiles so that the tiles do not get blown off in strong winds.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "December 21st, 2025 |",
                                        "url": "https://sydneywideroofingco.com.au/author/admin/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/author/admin/",
                                                "anchor_text": "admin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Picture water slowly tracking under your roof tiles during Sydney's next downpour. Not through obvious damage you can see, but through tiny gaps where metal meets tile. That's the reality when flashing fails. And it",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                        "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                                "anchor_text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Steps to Fix Broken, Cracked, or Dislodged Roof Tiles",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "November 14th, 2025 |",
                                        "url": "https://sydneywideroofingco.com.au/author/admin/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/author/admin/",
                                                "anchor_text": "admin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Broken, cracked, or dislodged roof tiles can lead to major issues if not repaired quickly. These tiles shield your home from the weather, and any damage could allow leaks or water to cause further harm.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Steps to Fix Broken, Cracked, or Dislodged Roof Tiles",
                                        "url": "https://sydneywideroofingco.com.au/steps-to-fix-broken-cracked-or-dislodged-roof-tiles/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/steps-to-fix-broken-cracked-or-dislodged-roof-tiles/",
                                                "anchor_text": "Steps to Fix Broken, Cracked, or Dislodged Roof Tiles"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "October 10th, 2025 |",
                                        "url": "https://sydneywideroofingco.com.au/author/admin/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/author/admin/",
                                                "anchor_text": "admin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Clogged gutters cause issues for your roof, especially for tiles and ridge capping. Blocked gutters lead to water overflow, which can damage the roof structure. This damages the tiles and ridge capping, resulting in leaks",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                        "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                                "anchor_text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Highly Rated Roofing Company located in Newtown, City of Sydney",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Wide Roofing Co \u2013 Newtown is located on 305/88 King St, Newtown NSW 2042. From Sydney Airport (SYD) take Airport Dr and O\u2019Riordan st to Wyndham st in Alexandria. Turn left onto Wyndham st. Take Cleveland st to Princess Hwy/A36 in Newtown.",
                                        "url": "https://goo.gl/maps/YW9VD72zu1R5jkmB7",
                                        "urls": [
                                            {
                                                "url": "https://goo.gl/maps/YW9VD72zu1R5jkmB7",
                                                "anchor_text": "Sydney Wide Roofing Co \u2013 Newtown"
                                            },
                                            {
                                                "url": "https://goo.gl/maps/VQmcvuzbPFsmxNGk9",
                                                "anchor_text": "Newtown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We\u2019re open Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For additional questions you can call us at 61282944654 or you can find us on Hotfrog.",
                                        "url": "https://www.hotfrog.com.au/company/1072156708818944",
                                        "urls": [
                                            {
                                                "url": "https://www.hotfrog.com.au/company/1072156708818944",
                                                "anchor_text": "Hotfrog"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Barangaroo Roofing Service",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Freshen up your Roof",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We specialise in the restoration of all types of roofs including; Colorbond, slate, metal, tin, terracotta and tiled.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Roofing",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leak Repair",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof leaks may be insignificant to begin with. However, they can soon turn into an expensive problem with water damage and mould",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters Downpipes",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Freshen up your Roof",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If not properly maintained your gutter and down-pipe system can soon cause an immense amount of damage to your home",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Pointing",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Portfolio",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burraneer Bay Residential",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Burraneer Bay Residential",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                                "anchor_text": "Burraneer Bay Residential"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing Project Sydney",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing Project Sydney",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                                "anchor_text": "Slate Roofing Project Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Project Eastern Suburbs",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Project Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                                "anchor_text": "Metal Roofing Project Eastern Suburbs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Handy Tips About Roofing",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leaks",
                                        "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                                "anchor_text": "Roof Leaks"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-roofing",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Re-roofing",
                                        "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                                "anchor_text": "Re-roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Downpipes",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                                "anchor_text": "Roof Tiling"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Latest News",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                        "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                                "anchor_text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                        "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                                "anchor_text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Read all of our reviews on Google +",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Read all of our reviews on Google +",
                                        "url": "https://plus.google.com/u/0/117630578737877513335/about/",
                                        "urls": [
                                            {
                                                "url": "https://plus.google.com/u/0/117630578737877513335/about/",
                                                "anchor_text": "Read all of our reviews on Google +"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations We Service",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sutherland Shire",
                                        "url": "https://sydneywideroofingco.com.au/home/sutherland-shire/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/home/sutherland-shire/",
                                                "anchor_text": "Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/home/eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/home/eastern-suburbs/",
                                                "anchor_text": "Eastern Suburbs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "City of Sydney",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney",
                                                "anchor_text": "City of Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georges River",
                                        "url": "https://sydneywideroofingco.com.au/sydney/georges-river/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sydney/georges-river/",
                                                "anchor_text": "Georges River"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Inner West",
                                        "url": "https://sydneywideroofingco.com.au/inner-west",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west",
                                                "anchor_text": "Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Northern Beaches",
                                        "url": "https://sydneywideroofingco.com.au/sydney/northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sydney/northern-beaches/",
                                                "anchor_text": "Northern Beaches"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Central Coast",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Building Inspiring Roofs",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Only takes a few seconds!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Roofing",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heritage Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/heritage-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/heritage-roofing/",
                                                "anchor_text": "Heritage Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Copper Roofing",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Copper Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/copper-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/copper-roofing/",
                                                "anchor_text": "Copper Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/slate-roofing/",
                                                "anchor_text": "Slate Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Zinc Roofing",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Zinc Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/zinc-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/zinc-roofing/",
                                                "anchor_text": "Zinc Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations in the City of Sydney Council We Service",
                                "main_title": "Barangaroo Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Centennial Park",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/centennial-park",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/centennial-park",
                                                "anchor_text": "Centennial Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dawes Point",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/dawes-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/dawes-point",
                                                "anchor_text": "Dawes Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Elizabeth bay",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/elizabeth-bay",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/elizabeth-bay",
                                                "anchor_text": "Elizabeth bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Forest Lodge",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/forest-lodge",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/forest-lodge",
                                                "anchor_text": "Forest Lodge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Millers Point",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/millers-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/millers-point",
                                                "anchor_text": "Millers Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Moore Park",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/moore-park",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/moore-park",
                                                "anchor_text": "Moore Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Potts Point",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/potts-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/potts-point",
                                                "anchor_text": "Potts Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rushcutters Bay",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/rushcutters-bay",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/rushcutters-bay",
                                                "anchor_text": "Rushcutters Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Peters",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/st-peters",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/st-peters",
                                                "anchor_text": "St Peters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Surry Hills",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/surry-hills",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/surry-hills",
                                                "anchor_text": "Surry Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Rocks",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/the-rocks",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/the-rocks",
                                                "anchor_text": "The Rocks"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "61282944654",
                                "+61282944654"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}