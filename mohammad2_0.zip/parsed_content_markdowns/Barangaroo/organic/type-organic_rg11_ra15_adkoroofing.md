{
    "id": "01190728-1132-0216-0000-b65fe3e3957a",
    "status_code": 40602,
    "status_message": "Task In Queue.",
    "time": "0.0057 sec.",
    "cost": 0,
    "result_count": 0,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://adkoroofing.com.au/roofing-services/roof-repairs-sydney/",
        "target": "adkoroofing.com.au",
        "start_url": "https://adkoroofing.com.au/roofing-services/roof-repairs-sydney/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Barangaroo\\organic\\type-organic_rg11_ra15_adkoroofing.md"
    },
    "result": null
}