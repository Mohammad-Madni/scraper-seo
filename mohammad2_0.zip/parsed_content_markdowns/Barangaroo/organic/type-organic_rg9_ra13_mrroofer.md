{
    "id": "01190728-1132-0216-0000-6e47e12ea598",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0222 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.mrroofer.com.au/Barangaroo-roof-painting/",
        "target": "www.mrroofer.com.au",
        "start_url": "https://www.mrroofer.com.au/Barangaroo-roof-painting/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Barangaroo\\organic\\type-organic_rg9_ra13_mrroofer.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:15 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Sydney Roof Restoration company that caters to residential customers across Sydney.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.mrroofer.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "CONTACT PHONE",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mon - Sat 8:00 - 18:00",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "OPEN HOURS",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.mrroofer.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Mr. Roofer is a premier, Sydney Roof Restoration company that caters to residential customers across Sydney. We have been in this business for over 20 years and provide excellent roofing services.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright 2021 Mr Roofer, All Right Reserved",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Site Map",
                                    "url": "https://www.mrroofer.com.au/site-map/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/site-map/",
                                            "anchor_text": "Site Map"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney NSW. 2200",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Barangaroo Roof Painting",
                                "main_title": "Barangaroo Roof Painting",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Mr Roofer is one of the most renowned Barangaroo roof painting companies in the region. We know from experience that sometimes even very well-maintained roofs need something more than cleaning to improve their appearance. It\u2019s why we offer professional residential and commercial roof painting in Barangaroo services.",
                                        "url": "https://www.mrroofer.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/",
                                                "anchor_text": "Mr Roofer"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The fact is that the roof is one of the first things people notice about your home or commercial building. If it looks dated and dull, that can leave a very poor impression on your guests, visitors, customers or clients. Getting your roof painted by an affordable Barangaroo roof painting company like ours is a great way to create the impact you want.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Not only will a newly painted roof add to the appeal of your property, but will also make it more weather-resistant and impervious to dirt, debris, and stains. A great roof adds to the value of your home as well and it\u2019s something you should consider if you are planning to put your property up for sale in the near future.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Barangaroo Roof Painting",
                                "main_title": "Barangaroo Roof Painting",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Many people wonder whether they should really get their roof painted at all. There are a number of benefits to doing so. Here are some of the main reasons why you should consider hiring us for the best Barangaroo roof painting service:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Aesthetics \u2013 We use top quality paints in our Barangaroo roof painting services. These help the surface withstand the elements in a better way and the roof stays looking great for a number of years. In fact, a well-painted roof is easier to maintain too.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Improve energy-efficiency \u2013 The heat-reflective paint products we use in our work significantly improve the energy-efficiency of your home and reduces your electricity bills every month.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Higher property value \u2013 As mentioned earlier, roof painting and regular maintenance will keep your roof looking great at all times and increase its value too.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Affordable Roof Painting Barangaroo",
                                "main_title": "Barangaroo Roof Painting",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Moss, lichen, algae, the weather and the UV rays of the sun all take their toll and impact the integrity and look of your roof. We can provide excellent commercial and residential roof painting in Barangaroo services at very attractive price points. It\u2019s true that sometimes a weathered roof lends a very classic appearance to the structure, but in most cases people want their roofs to look clean, sharp and stunning.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our high-quality Barangaroo roof painting contractors have the technical knowledge, training, and skills to handle projects of every scale. They can paint metal, tiled, terracotta and concrete roofs. Since all of these materials are different, we adopt a different approach to the paint job.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Terracotta Barangaroo Roof Painting Services",
                                "main_title": "Barangaroo Roof Painting",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Terracotta is primarily a porous material and glazing the surfaces protects these tiles from becoming eroded or impacted by the wind. Most people that have terracotta roofing tiles prefer the natural vibrant colour. But some prefer colours that will blend in well with the overall appearance of their homes. We can clean the tiles and remove all the debris, moss and mildew, apply primer and then meticulously paint the surface. We use a specialise dairless paint application method rather than brushes and rollers. This helps ensure a very seamless and beautiful finish when we are painting roof tiles.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Concrete Barangaroo Roof Painting Solutions",
                                "main_title": "Barangaroo Roof Painting",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If you have noticed a build-up of lichen, moss, and mildew on your concrete roof tiles or if you feel the tiles are looking old and dated, we recommend you consider getting your roof painted. We provide cheap roof painting Barangaroo service for all types of roofs including concrete ones. Our technicians will clear all the debris, stains, lichens and moss from the tiles using a water-blasting machine. They will then apply a specialised sealant over which the basecoat will be applied. The final coat is a colour glaze that provides maximum protection and increases the longevity of your concrete roof tiles.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Barangaroo Roof Painting",
                                "main_title": "Barangaroo Roof Painting",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Today, many homes and commercial establishments sport Colorbond metal roofs. These high-quality roofs can provide years of trouble-free services as long as they are maintained well. Poor maintenance or some damage can affect the paint coat of your Colorbond roof. We have the expertise to handle painting Colorbond roof projects and give the features a new lease of life. While we provide the best solutions, you will find that our roof painting Barangaroo price is very easy on your pocket.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Cost of Barangaroo Roof Painting",
                                "main_title": "Barangaroo Roof Painting",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If you are looking for \u201c cheap roof painting Barangaroo companies \u201d online, you will find many that advertise their services are \u201caffordable\u201d or \u201ccost-effective\u201d. But it\u2019s important not to get carried away by these terms. Very few companies are able to strike the right balance between quality and cost, but this is something we do very expertly. We use only premium paints in our projects such as Nutech Paints, Shieldcoat, Dulux and ACE Cutters, but always maintain very competitive costs. Regardless of the size and scope of the job, you are assured value for money, every time you hire us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Other Barangaroo Roofing Services",
                                "main_title": "Barangaroo Roof Painting",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We also offer other roofing services to suit any roof you may have. These services include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Cleaning Barangaroo",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Cleaning Barangaroo",
                                        "url": "https://www.mrroofer.com.au/Barangaroo-roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/Barangaroo-roof-cleaning/",
                                                "anchor_text": "Roof Cleaning Barangaroo"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Barangaroo",
                                        "url": "https://www.mrroofer.com.au/Barangaroo-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/Barangaroo-roof-restoration/",
                                                "anchor_text": "Roof Restoration Barangaroo"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repair Barangaroo",
                                        "url": "https://www.mrroofer.com.au/Barangaroo-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/Barangaroo-roof-repair/",
                                                "anchor_text": "Roof Repair Barangaroo"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ask our Barangaroo Roof Painting Team",
                                "main_title": "Barangaroo Roof Painting",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "For any more information about our cheap Barangaroo roof painting services or for a free inspection and quote, call Mr Roofer at 0405 804 804. You can also send us your queries and quote requests via our online form.",
                                        "url": "https://www.mrroofer.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/",
                                                "anchor_text": "Mr Roofer"
                                            },
                                            {
                                                "url": "https://www.mrroofer.com.au/contact-us/",
                                                "anchor_text": "online form"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Years Experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restorations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofs Painted",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": null,
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0405804804"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}