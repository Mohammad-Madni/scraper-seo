{
    "id": "01190728-1132-0216-0000-f0e3f9c2d3b6",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0164 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.facebook.com/rooferssydney/",
        "target": "www.facebook.com",
        "start_url": "https://www.facebook.com/rooferssydney/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Barangaroo\\organic\\type-organic_rg14_ra18_facebook.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 0
            },
            "items_count": 0,
            "items": null
        }
    ]
}