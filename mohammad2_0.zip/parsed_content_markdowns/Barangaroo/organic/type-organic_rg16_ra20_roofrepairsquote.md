{
    "id": "01191205-1132-0216-0000-37e72beede41",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0163 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.roofrepairsquote.com/contact-us",
        "target": "roofrepairsquote.com",
        "start_url": "https://www.roofrepairsquote.com/contact-us",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": false,
        "load_resources": false,
        "enable_browser_rendering": false,
        "enable_xhr": false,
        "disable_cookie_popup": false,
        "browser_preset": "desktop",
        "tag": "parsed_content_markdowns\\Barangaroo\\organic\\type-organic_rg16_ra20_roofrepairsquote.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 08:05:54 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Call 02 92156360",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.roofrepairsquote.com/contact-us",
                                    "urls": [
                                        {
                                            "url": "https://www.roofrepairsquote.com/contact-us",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Advice",
                                    "url": "https://www.roofrepairsquote.com/roof-restoration-advice",
                                    "urls": [
                                        {
                                            "url": "https://www.roofrepairsquote.com/roof-restoration-advice",
                                            "anchor_text": "Roof Restoration Advice"
                                        }
                                    ]
                                },
                                {
                                    "text": "How to Repair a Leaking Roof",
                                    "url": "https://www.roofrepairsquote.com/how-to-repair-leaking-roof",
                                    "urls": [
                                        {
                                            "url": "https://www.roofrepairsquote.com/how-to-repair-leaking-roof",
                                            "anchor_text": "How to Repair a Leaking Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Melbourne Roof Repair",
                                    "url": "https://www.roofrepairsquote.com/eastern-suburbs",
                                    "urls": [
                                        {
                                            "url": "https://www.roofrepairsquote.com/eastern-suburbs",
                                            "anchor_text": "Melbourne Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.roofrepairsquote.com/contact-us",
                                    "urls": [
                                        {
                                            "url": "https://www.roofrepairsquote.com/contact-us",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing contractor \u2013 Sydney, NSW, Australia",
                                    "url": "https://www.roofrepairsquote.com/roofing-contractor-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.roofrepairsquote.com/roofing-contractor-sydney",
                                            "anchor_text": "Roofing contractor \u2013 Sydney, NSW,  Australia"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Cleaning Tips",
                                    "url": "https://www.roofrepairsquote.com/roof-cleaning-tips",
                                    "urls": [
                                        {
                                            "url": "https://www.roofrepairsquote.com/roof-cleaning-tips",
                                            "anchor_text": "Roof Cleaning Tips"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Advice",
                                    "url": "https://www.roofrepairsquote.com/roof-restoration-advice",
                                    "urls": [
                                        {
                                            "url": "https://www.roofrepairsquote.com/roof-restoration-advice",
                                            "anchor_text": "Roof Restoration Advice"
                                        }
                                    ]
                                },
                                {
                                    "text": "How to Repair a Leaking Roof",
                                    "url": "https://www.roofrepairsquote.com/how-to-repair-leaking-roof",
                                    "urls": [
                                        {
                                            "url": "https://www.roofrepairsquote.com/how-to-repair-leaking-roof",
                                            "anchor_text": "How to Repair a Leaking Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.roofrepairsquote.com/privacy",
                                    "urls": [
                                        {
                                            "url": "https://www.roofrepairsquote.com/privacy",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Contact Us",
                                "main_title": "Contact Us",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Head Office : Unit 602 25 Barangaroo Ave, Barangaroo, Sydney, NSW Australia 2000",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile: 02 92156360",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": null,
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}