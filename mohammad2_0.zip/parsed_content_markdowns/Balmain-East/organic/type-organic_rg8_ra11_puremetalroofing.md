{
    "id": "01190727-1132-0216-0000-25abc6bd268d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0299 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://puremetalroofing.com.au/roof-repairs-balmain-east/",
        "target": "puremetalroofing.com.au",
        "start_url": "https://puremetalroofing.com.au/roof-repairs-balmain-east/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain-East\\organic\\type-organic_rg8_ra11_puremetalroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:16 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Pure Metal Roofing Pty Ltd",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Quick Links",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Newtown NSW 2042",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Berala NSW 2141",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN: 18 664 818 357",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Lic No. 388625C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "100% Satisfaction Guaranteed",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Testimonials",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Balmain East is a tightly held harbourside suburb, known for its historic terraces, charming cottages, and waterfront residences. With properties exposed to coastal breezes, salt air, and Sydney\u2019s unpredictable weather, roofs in Balmain East often require professional attention to maintain their strength, performance, and appearance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Pure Metal Roofing, we specialise in metal roof repairs for Balmain East homes and businesses. Metal roofing is a popular choice in the area thanks to its resilience and sleek design, but the combination of salt air and coastal weather can lead to corrosion, lifted sheets, or damaged fasteners over time. Our team uses high-quality products like Colorbond steel to carry out repairs that restore both durability and style.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Older homes in Balmain East often feature tiled roofs, which can develop cracks, loose ridge capping, or missing tiles. Our roofers provide careful repairs that blend seamlessly with the existing roof to maintain its character while ensuring long-term protection against water ingress.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For commercial and strata properties, low-pitched or flat metal roofs are common. These roofs are prone to leaks around joints, vents, and skylights.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our detailed inspections uncover the cause of these problems, and we provide tailored repairs that prevent further issues, minimising future maintenance costs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Every job is carried out by our fully licensed, in-house team \u2014 never subcontractors. With more than 30 years of experience across Sydney, Pure Metal Roofing delivers trusted solutions designed to protect Balmain East properties against coastal exposure and storm conditions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Binbin Liang",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Request an Inspection",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Get in touch to book a convenient inspection for your Balmain East property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Assessment",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roofers conduct a detailed inspection. For metal roofs, we look for rust, loose sheets, and failing flashings. For tiled roofs, we identify broken tiles, leaks, and damaged ridge capping.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quote & Approval",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide a written, upfront quote outlining the necessary work. Once approved, we book in the repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Repair Work",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Repairs are completed by our in-house licensed team using premium materials like Colorbond for metal roofing and carefully sourced tiles for tiled roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Final Check",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We carry out a final inspection to ensure the roof is secure, watertight, and ready to withstand Sydney\u2019s climate.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Pure Metal Roofing in Balmain East",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Specialists in Metal Roof Repairs: Skilled in Colorbond and other sheet metal systems.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Experience with Coastal Homes: Knowledge of issues caused by salt air and waterfront exposure.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "In-House Licensed Team: No subcontractors \u2014 all work completed by our own professionals.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium Materials: Long-lasting, weather-resistant products suited to Sydney\u2019s climate.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive Services: Repairs for residential, strata, and commercial properties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Decades of Experience: More than 30 years of roofing expertise in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Clients We Work With",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Homeowners: Repairs for leaks, storm damage, and routine maintenance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Strata Managers: Consistent service for unit blocks and multi-residential buildings.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Commercial Property Owners: Efficient roof repairs that minimise disruption to business operations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Real Estate Agents: Quick and professional fixes to prepare properties for sale or lease.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Builders and Renovators: Roofing support integrated into larger building projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "What roof issues are common in Balmain East?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rusting on metal roofs, cracked tiles, leaks caused by damaged flashings, and deterioration from salt air exposure.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you service waterfront and heritage properties?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes. We regularly repair roofs on waterfront homes and heritage terraces, sourcing materials that respect the property\u2019s character.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Are metal roof repairs different from tiled roof repairs?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes. Metal roof repairs involve addressing rust, loose fasteners, and damaged flashings, while tiled roof repairs focus on cracked or displaced tiles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you handle flat or commercial roofs?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we repair flat and low-pitched roofs often found on strata and commercial buildings in Balmain East.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you provide quotes upfront?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. All quotes are transparent, detailed, and provided in writing before work begins.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs in Balmain East",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How It Works",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gallery",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Areas We Serve",
                                "main_title": "Roof Repairs in Balmain East",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park",
                                        "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                                "anchor_text": "Croydon Park"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0422088256"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}