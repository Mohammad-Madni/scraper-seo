{
    "id": "01190727-1132-0216-0000-b17a4f476c56",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0138 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/",
        "target": "www.sydneyeasternsuburbsroofing.com.au",
        "start_url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain-East\\organic\\type-organic_rg14_ra18_sydneyeasternsuburbsroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:05 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Call (02) 9029 6727 or 0434 705 699 | Email info@iansroofing.com.au",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Sydney Eastern Suburbs Roofing",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing",
                                            "anchor_text": "Sydney Eastern Suburbs Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-repairs-sydney-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-repairs-sydney-eastern-suburbs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roofs",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/new-roofs-gutters-pipes/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/new-roofs-gutters-pipes/",
                                            "anchor_text": "New Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing Products and Services Sydney",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roofing-products-and-services-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roofing-products-and-services-sydney/",
                                            "anchor_text": "Roofing Products and Services Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing Sydney",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/colorbond-roofing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/colorbond-roofing-sydney/",
                                            "anchor_text": "Colorbond Roofing Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restorations",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-restorations-sydney-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-restorations-sydney-eastern-suburbs/",
                                            "anchor_text": "Roof Restorations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://sydneycommercialroofing.com.au/roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneycommercialroofing.com.au/roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Financing Available",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/financing-available/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/financing-available/",
                                            "anchor_text": "Financing Available"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roofing-enquiry-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roofing-enquiry-sydney/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call (02) 9029 6727 or 0434 705 699",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email info@iansroofing.com.au",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "New and Recycled Slate Roofing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "AFT Silva Family Trust",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright \u00a9 2026 Sydney Eastern Suburbs Roofing",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Phone: (02) 9029 6727",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email: info@iansroofing.com.au",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mobile 0434 705 699",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Repairs & Leaks",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Complete Re-Roofs",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://sydneycommercialroofing.com.au/roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneycommercialroofing.com.au/roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restorations",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-restorations-sydney-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-restorations-sydney-eastern-suburbs/",
                                            "anchor_text": "Roof Restorations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-repairs-sydney-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-repairs-sydney-eastern-suburbs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Financing Available",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/financing-available/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/financing-available/",
                                            "anchor_text": "Financing Available"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roofing-enquiry-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roofing-enquiry-sydney/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Google Page",
                                    "url": "https://g.page/r/CXKF8nUY9hGlEAE",
                                    "urls": [
                                        {
                                            "url": "https://g.page/r/CXKF8nUY9hGlEAE",
                                            "anchor_text": "Google Page"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://sydneycommercialroofing.com.au/roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneycommercialroofing.com.au/roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restorations",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-restorations-sydney-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-restorations-sydney-eastern-suburbs/",
                                            "anchor_text": "Roof Restorations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-repairs-sydney-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-repairs-sydney-eastern-suburbs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Financing Available",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/financing-available/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/financing-available/",
                                            "anchor_text": "Financing Available"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roofing-enquiry-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roofing-enquiry-sydney/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Google Page",
                                    "url": "https://g.page/r/CXKF8nUY9hGlEAE",
                                    "urls": [
                                        {
                                            "url": "https://g.page/r/CXKF8nUY9hGlEAE",
                                            "anchor_text": "Google Page"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Commercial Roofing",
                                    "url": "https://sydneycommercialroofing.com.au/roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneycommercialroofing.com.au/roofing/",
                                            "anchor_text": "Sydney Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Property Conveyancing",
                                    "url": "https://innerwestconveyancers.com.au/conveyancing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestconveyancers.com.au/conveyancing/",
                                            "anchor_text": "Property Conveyancing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West Air Conditioning",
                                    "url": "https://innerwestairconditioning.com.au/aircon/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestairconditioning.com.au/aircon/",
                                            "anchor_text": "Inner West Air Conditioning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs Roofing",
                                    "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/",
                                            "anchor_text": "Eastern Suburbs Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Domains",
                                    "url": "https://www.sydneydomains.com.au/domains/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneydomains.com.au/domains/",
                                            "anchor_text": "Sydney Domains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Soundproofing",
                                    "url": "https://sydneysoundproofing.com.au/soundproof/",
                                    "urls": [
                                        {
                                            "url": "https://sydneysoundproofing.com.au/soundproof/",
                                            "anchor_text": "Sydney Soundproofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West Electrical",
                                    "url": "https://innerwestelectrical.com.au/electric/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestelectrical.com.au/electric/",
                                            "anchor_text": "Inner West Electrical"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dial a Painter",
                                    "url": "https://www.dialapainter.com.au/house-painter-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.dialapainter.com.au/house-painter-sydney/",
                                            "anchor_text": "Dial a Painter"
                                        }
                                    ]
                                },
                                {
                                    "text": "License 351337c",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN 44 200 133 003",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Balmain Web Design",
                                    "url": "http://balmainwebdesign.com.au/",
                                    "urls": [
                                        {
                                            "url": "http://balmainwebdesign.com.au/",
                                            "anchor_text": "Balmain Web Design"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "From small repairs to major heritage re-roofing work. Backed by a team of experienced tradesmen our estimator can provide free quotes for tile, metal and slate roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why We Are\nThe Best",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Ian\u2019s Eastern Suburbs Roofing differs from other roofing companies as our attention to detail and customer service are what comes first. No job is too big or small, our tradesmen have over 30 years of experience and there has yet to be a roofing issue they can\u2019t solve. From small repairs to major heritage re-roofing work, Ian\u2019s Eastern Suburbs Roofing has you covered. Our estimator can provide a free quote for tile, metal and slate roofs which you can book online.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Fantastic experience! I had a tricky repair done on my roof and honestly, I could not be happier with Ian\u2019s Roofing. Ian was very thorough and Jolie and the office team kept me in the loop the whole time. Highly recommend!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I would highly recommend Ian's Roofing. I was very impressed with Maddi and her team. They have raised the bar and raised the reputation of all tradies with their approach and professionalism. I am so pleased to have had the experience of dealing with them. 5/5 stars",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I had a smallish job to close some possum holes in the roof of 2 adjoining houses (possum catcher price was too high) plus some work on a skylight - so I went looking for a roofer. Getting anyone to come and quote was a struggle. I was recommended Ian by a friend. After a little back and forth Ian visited and provided a clear quote which I proceeded with. Roof work is not cheap! Ian's team arrived at the promised time and completed the work promptly. They provided photos of all the work and I was happy it was done as requested. A week later my tenant had a question around the skylight work. Ian visited and checked it out and again provided photos to my satisfaction. Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We were very happy with the work and service provided by Ian and the team, Maddi, Jolie and Maria.\nTheir communication was great throughout the whole process.\nHighly recommend Ian\u2019s roofing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "This is the third time I have had The pleasure of using Ian\u2019s Inner west Roofing on different properties.\nBesides the wonderful service you get from the office girls right through to the Roofing guys and from Ian himself , It is always a job very well done. I have recommended him to other members of our family and they too have had excellent results and pricing..\nI would not hesitate to recommend them as they always do the job properly, no cutting corners always on time, And they always tidy up after themselves.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I found Ian's Roofing to be very responsive to my request for repairs as well as being honest and reliable. I have been happy with their work unlike others I have used .",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I am joining a plethora of 5 star reviews for this impressive business...I doubt there would ever have been anything less than 5 stars and I'd like to give 10. It was a pleasure to deal with this business... a smart, capable, reliable team who really know their work and focus on a perfect job. ....at a very reasonable, competitive price. I would never use anyone else.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ian\u2019s roofing provided an excellent service.\nThey went above and beyond to get my roof done before I travelled, were efficient and Maddi has great communication skills. Roof doesn\u2019t leak for the first time in five years!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Elyse Mitchell",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mary C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "g a",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Marcus Elsum",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Maria Nikolakopoulos",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Georgia Lambropoulos",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Julie S",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Annie Campbell",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Diane Losche",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Common Sydney Roofs",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Tile roofing advantages:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Durability: Tile roofing is known for its durability and can last for decades with proper maintenance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Weather resistance: Tile roofing is resistant to extreme weather conditions such as high winds, hail, and heavy rain.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Energy efficiency: Tile roofing can help to keep your home or business cooler in the summer and warmer in the winter, reducing energy costs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Low maintenance: Tile roofing requires minimal maintenance, as it does not rot, warp, or corrode.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Aesthetic appeal: Tile roofing can add to the overall aesthetic appeal of your home or business and is available in a variety of colours and styles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Environmental benefits: Tile roofing is made from natural materials such as clay or concrete, making it an environmentally friendly choice.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Long lifespan: With proper maintenance, a tile roof can last for 50 years or more, making it a long-term investment.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Advantages of steel roofing:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Durability: Steel roofing is known for its strength and durability and can withstand extreme weather conditions such as high winds, hail, and heavy rain.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Low maintenance: Steel roofing requires minimal maintenance, as it does not rot, warp, or corrode.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Energy efficiency: Steel roofing can reflect solar heat, helping to keep your home or business cooler in the summer and reducing energy costs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lightweight: Steel roofing is much lighter than other materials such as tile or asphalt, making it easier to install and less likely to put stress on the structure of your home or business.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Aesthetic appeal: Steel roofing is available in a variety of colours and styles to match the look of your home or business.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Environmentally friendly: Steel roofing is made from recycled materials and is fully recyclable at the end of its lifespan, making it an environmentally friendly choice.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Long lifespan: With proper maintenance, a steel roof can last for 50 years or more, making it a long-term investment.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Slate roofs have several advantages:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Durability: Slate roofs are extremely durable and can last for more than 100 years with proper maintenance. They are resistant to rot, insects, and extreme weather conditions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Low maintenance: Slate roofs require very little maintenance and can last for decades without any major repairs. They do not need to be painted or treated, and their natural colour never fades.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Aesthetically pleasing: Slate roofs have a natural, elegant look that adds to the overall beauty of a home or building. They come in a variety of colours, including shades of grey, black, green, purple, and red.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Energy efficient: Slate roofs have a high insulation value, which helps to keep a building cool in the summer and warm in the winter. This can help to reduce energy costs and increase the overall efficiency of a building.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Environmentally friendly: Slate is a natural material that is abundant and renewable. It is also recyclable, making it a more environmentally friendly option compared to other roofing materials.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Ian\u2019s Eastern Suburbs Roofing is a Sydney based roofing company who has expertise in all types of roofing requirements. Some of the services we offer are repairs of leaks, re-roofing, tile roofing, slate roofing, metal roofing, copper and zinc roofing. We offer a complete package from information and advice on products and finishes through to installation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Client Testimonials",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\"We wouldn\u2019t hesitate in recommending Inner West Roofing to anyone needing roof/gutter work.Ian has been to our home himself on many occasions, often out of hours and on weekends. We have been very happy with the work he and his team have done.They are punctual, friendly and very professional, and their communication has been great! Due to the very wet weather this year, they have all had a difficult time scheduling work, and we have had a few delays, but it was obvious why that happened!\nWe wish them better weather for the next year.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ian's Roofing workmanship is to the highest standard, they have repaired a large amount of water ingress issues for the buildings I manage and approved the condition of the roof. The service from Maria and Lee is next to none and one of the best in the industry. I highly recommend Ian's Roofing for any roof repair.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney CBD Roofing",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney CBD Roofing 50 Kings St Sydney King St, Sydney NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney CBD Roofing",
                                        "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/sydney-cbd-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/sydney-cbd-roofing/",
                                                "anchor_text": "Sydney CBD Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "One Step Ahead",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Google reviews",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ian\u2019s Eastern Suburbs Roofing",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What We Are Doing Better",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Tile Roofing, Slate Roofing, Metal Roofing, Copper and Zinc Roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Complete New Roofs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restorations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Colorbond Roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Request a free quote",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Eastern Suburbs Roofing | Roofing Contractors Eastern Suburbs",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Common Sydney Roofs",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "tiles",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Terracotta & Concrete",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Steel",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Corrugated - Colorbond",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "New & Recycled",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What People Say About Us",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "You can relax with Ian\u2019s Eastern Suburbs Roofing",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "35 years of roofing experience",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We have lots of experience",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recently Completed",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "New Roof in Woolloomooloo",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "New Roof in Woolloomooloo Woolloomooloo NSW 2011",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "New Roof in Woolloomooloo",
                                        "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/new-roof-woolloomooloo/",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/new-roof-woolloomooloo/",
                                                "anchor_text": "New Roof in Woolloomooloo"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Mercedes-Benz Alexandria Roof Replacement",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Mercedes-Benz Alexandria Roof Replacement Alexandria NSW",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Mercedes-Benz Alexandria Roof Replacement",
                                        "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/mercedes-benz-alexandria-roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/mercedes-benz-alexandria-roof-replacement/",
                                                "anchor_text": "Mercedes-Benz Alexandria Roof Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "New Roof Bondi",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "New Roof Bondi",
                                        "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/new-roof-bondi/",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/new-roof-bondi/",
                                                "anchor_text": "New Roof Bondi"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Renovation Maroubra",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Renovation Maroubra",
                                        "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-renovation-maroubra/",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/roof-renovation-maroubra/",
                                                "anchor_text": "Roof Renovation Maroubra"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "New Tile Roof Maroubra",
                                "main_title": "Complete Roofing Services\nSydney Eastern Suburbs",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "New Tile Roof Maroubra",
                                        "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/new-tile-roof-maroubra/",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyeasternsuburbsroofing.com.au/roofing/new-tile-roof-maroubra/",
                                                "anchor_text": "New Tile Roof Maroubra"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.6,
                                "max_rating_value": 5,
                                "rating_count": 59,
                                "relative_rating": 0.9199999999999999
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0290296727",
                                "0434705699"
                            ],
                            "emails": [
                                "info@iansroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}