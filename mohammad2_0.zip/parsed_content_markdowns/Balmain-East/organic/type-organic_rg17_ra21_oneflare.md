{
    "id": "01190727-1132-0216-0000-31ffbcdc8e28",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0181 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.oneflare.com.au/roofing/nsw/balmain",
        "target": "www.oneflare.com.au",
        "start_url": "https://www.oneflare.com.au/roofing/nsw/balmain",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain-East\\organic\\type-organic_rg17_ra21_oneflare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:01 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Best roofing experts in Balmain",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Post a job now to get quotes from local roofing experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average rating of roofing experts in Balmain based on 362 reviews of 39 businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oneflare /",
                                        "url": "https://www.oneflare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/",
                                                "anchor_text": "Oneflare"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Categories /",
                                        "url": "https://www.oneflare.com.au/directory",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/directory",
                                                "anchor_text": "Categories"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.oneflare.com.au/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NSW /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw",
                                                "anchor_text": "NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                                "anchor_text": "Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Render My Home Pty Ltd",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Waterloo, NSW (5.3km from Waterloo)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Render My Home is your one-stop design and building service that Renovates, Rejuvenates and Restores your home facade. We only deal with quality products and systems from trusted suppliers. Render My Home are accredited and use products by Dulux and CSR.\nRender My Home \u2013 Exterior Fa\u00e7ade Home Improvement Specialists, can dramatically boost your home\u2019s value by transforming your home into a vibrant and intriguing reflection of your own personal style and individualism. For all small and large jobs, Render My Home specialises in restoring and rejuvenating your homes facade, by using renders, coatings, wall panels, paints, landscaping, tiling, balustrade upgrades, roof restorations, awnings and shutters to breathe new life into your home.\nThe Render My Home design team are",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Render My Home Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/render-my-home-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/render-my-home-pty-ltd",
                                                "anchor_text": "Render My Home Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "NGP Projects",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Randwick, NSW (8.5km from Randwick)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "New Generation Plus (NGP) is an established, multi-skilled Sydney based Building company in operation for over 17 years, with a focus on customer service, quality tradesmanship and the highest standard of excellence. We have extensive experience within the commercial, residential, retail, hospitality & healthcare sectors. With excellent management and coordination, we give every project 100% commitment and our project teams have a reputation for quality and efficiency. We have the capacity to integrate services from make good to complete product so we can have a greater control on the outcome of the project. We provide a free quotation service and offer extremely competitive rates whether on an hourly rate or square metre rate. Our trades are painter, plasterer including commercial",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "NGP Projects",
                                        "url": "https://www.oneflare.com.au/b/new-generation-plus",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/new-generation-plus",
                                                "anchor_text": "NGP Projects"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Dunne, Cian Sean Verified Business",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Maroubra, NSW (11.5km from Maroubra)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At C.D. Roofing and Restoration, we\u2019re more than just another roofing company \u2014 we\u2019re your local, reliable partner in protecting what matters most: your home. With a commitment to quality craftsmanship, honest service, and attention to detail, we deliver roofing and repair solutions that are built to last.\nWhat sets us apart? We don\u2019t cut corners. Every project, big or small, is handled with the same care and precision we\u2019d want for our own homes. Whether you\u2019re dealing with storm damage, a leaky roof, or need a full replacement, we provide clear communication, fair pricing, and dependable results \u2014 without the runaround.\nWe specialize in:\n\u2022. Slate and Tile roofs \u2022. Leadwork \u2022 Roof inspections, repairs, and full replacements\n\u2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Dunne, Cian Sean Verified Business",
                                        "url": "https://www.oneflare.com.au/b/dunne-s-roofing-solutions",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/dunne-s-roofing-solutions",
                                                "anchor_text": "Dunne, Cian Sean"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Kesov Roofing",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Westmead, NSW (18.8km from Westmead)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We specialise in metal roof replacement, gutter installation and all types of roof repair.\nKesov roofing is a local business we servicing Sydney Eastern Suburb and Western suburb. We are highly professional - fully qualified and fully insured service will help put your mind at ease with your roofing job. All quotes are free.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Kesov Roofing",
                                        "url": "https://www.oneflare.com.au/b/kesov-roof-fix",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/kesov-roof-fix",
                                                "anchor_text": "Kesov Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ozroof Roof Repairs & Restorations",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.0km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OZROOF specialise in Roof Restoration, Roof Repairs, Roof Painting, Metal Roofing and Guttering Replacement - Sydney Wide\nOZROOF Repairs & Restoration provide homeowners with high quality roofing services including roof restoration, roof repairs, roof painting, metal roofing and guttering replacement throughout Sydney and surrounding suburbs. Family owned and operated, we are dedicated to delivering exceptional quality to every task undertaken, regardless of the size of the project. All work is carried out by our own tradesmen and we certainly don't appoint flashy, commission based salesmen. This allows us to maintain lower overheads, in-turn keeping our prices affordable and competitive!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ozroof Roof Repairs & Restorations",
                                        "url": "https://www.oneflare.com.au/b/21st-roofing-guttering-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/21st-roofing-guttering-pty-ltd",
                                                "anchor_text": "Ozroof Roof Repairs & Restorations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Oracle Carpentry Sydney Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Chullora, NSW (12.8km from Chullora)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Established in 1995, Oracle roofing are well established, highly experienced, skilled, professional and extremely reliable providing the very best roofing services in the Sydney Metropolitan area.\nRoof repairs and maintenance is the top quality of our work. We specialise in roof leak detection and all roof maintenance services - including gutter and down pipe installation, gutter installation and cleaning, roof restoration, roof carpentry, roof painting and skylight installation. Our emphasis has been and always will be to provide top quality work and service at all times.\nWe are a team of 11 experienced professionals and able to service your needs at all times and provide quick and efficient service. We provide free site inspections, and at times, within hours of",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oracle Carpentry Sydney Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/sydney-home-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/sydney-home-services",
                                                "anchor_text": "Oracle Carpentry Sydney Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slide 1 of 27",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Duravex Roofing Group Verified Business",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Minto, NSW (37.1km from Minto)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "NSW Fair Trading License 466515C I Public Liability Insurance NSW\nWe are a team of skilled and professional roofers who have been serving our clients for over two decades. Our reputation is based on the number of delighted and happy clients we have across NSW. Our aim is to provide the greatest quality workmanship, products, and customer service experience for our clients. From your first contact with us until the completion of the job, our attention is on you, the client, and ensuring that you are satisfied with your decision to hire Duravex Roofing! Our team of highly trained professionals is up to date on the latest technologies and advancements in the roofing business. Our main goal is to keep",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Duravex Roofing Group Verified Business",
                                        "url": "https://www.oneflare.com.au/b/duravex-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/duravex-roofing",
                                                "anchor_text": "Duravex Roofing Group"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Dr leak plumbing",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (2.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Dr leak plumbing services is Fully Licensed and Insured with over 14 years experience In the plumbing field with the competitive pricing along with lifetime warranty on workmanship. We beat all quotes by 5% to 10% and also applying a 15% Pensioners discount and seniors.\nGive Dr Leak Plumbing a call on\n\ud83d\udee0 0409199799 to get your FREE QUOTE Based in Melbourne and Sydney. Family owned and operated",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Dr leak plumbing",
                                        "url": "https://www.oneflare.com.au/b/dr-leak-plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/dr-leak-plumbing",
                                                "anchor_text": "Dr leak plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pro Cut Sydney",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Zetland, NSW (6.4km from Zetland)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a family run roofing and property maintenance company. With over 20 years of experience as carpenters and roofers, we pride ourselves on honesty, hard work and reliability. With a wide range of services from carpentry and roofing to cleaning and garden maintenance, we guarantee you\u2019ll love our work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pro Cut Sydney",
                                        "url": "https://www.oneflare.com.au/b/pro-cut-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/pro-cut-sydney",
                                                "anchor_text": "Pro Cut Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "D2plumbing",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Hunters Hill, NSW (4.4km from Hunters Hill)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "D2plumbing are a friendly fair priced company and are fully licenced and insured.\nwe are trained in all types of plumbing.\nTo see more about us check out our website on www.d2plumbing.com.au",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "D2plumbing",
                                        "url": "https://www.oneflare.com.au/b/d2plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/d2plumbing",
                                                "anchor_text": "D2plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Star Roof Masters",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (2.9km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Star Roof Masters specialises in all metal roofing, exterior wall cladding, carports, and awnings for Sydney and the surrounding Sydney suburbs. Our services include: New Colorbond Metal Roofs, Gutters, Fascia Cover, Replacing Tiles and Colorbond with New Colorbond, Colorbond Roofing, Down Pipes, Roof Skylights, Roof Repairs, Wall Cladding, Carports, Awnings, Flashing, and Insulation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Star Roof Masters",
                                        "url": "https://www.oneflare.com.au/b/star-roof-masters",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/star-roof-masters",
                                                "anchor_text": "Star Roof Masters"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "M&T Roofing",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.0km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "35 Years Roofing Experience. Call Now For Free Quote! If you are looking for reliable leaking roof repairs maintenance service Sydney.here at M&t roofing we provide all types of roofing and home maintenance services free call out charge we have a team of high Quality roofers and carpenters our team provide 7 professional roofers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "M&T Roofing",
                                        "url": "https://www.oneflare.com.au/b/m-t-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/m-t-roofing",
                                                "anchor_text": "M&T Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stormforce roofing & waterproofing",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (2.7km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Licensed & truly competent Tradesmen that ensure a quality job every time. Our team are Fully insured, height & safety certified, confined spaced certified & most importantly never settle for anything less than the best. We\u2019re Not Cowboys We don't compete with cowboys who decorate lamp posts with 'Dirt Cheap Offers'. We are real roofing and waterproofing tradesman; we add value to your home at competitive rates with Aussie products that last the test of time. Only a 10% deposit to secure schedule! No Progress Payments! We provide all machinery & materials! We're so confident that you will be delighted with the roofing and waterproofing work we provide that payment is only required after you've approved our finished work!\nUnbeatable",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Stormforce roofing & waterproofing",
                                        "url": "https://www.oneflare.com.au/b/roof-restoration-specialist",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roof-restoration-specialist",
                                                "anchor_text": "Stormforce roofing & waterproofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Flash Plumbing Services",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Concord, NSW (7.0km from Concord)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flash plumbing services specialise in New residential plumbing (free quote)\ndrain cleaning and drain maintenance and utilise our custom built vehicles fitted with the latest equipment available High Pressure water jet cleaner for all blocked drains and sewer problems\nPlumbing for kitchens and bathrooms Roof and guttering repairs and installation Gas Installation, maintenance and repairs Complete Bathroom renovations\nNew Residential Plumbing / Gas / Drainage\nC.C T.V diagnostic pipe camera Electronic underground pipe and cable locator Hot Water Systems New - Repairs\nBackflow Prevention inspections and testing\nThermostatic Mixing Valves Electronic Pipe Location and Leak Detection .",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Flash Plumbing Services",
                                        "url": "https://www.oneflare.com.au/b/flash-plumbing-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/flash-plumbing-services",
                                                "anchor_text": "Flash Plumbing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Interstate Prestige Roofing",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Olympic Park, NSW (9.9km from Sydney Olympic Park)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All types of Roof maintenance we do! \u2022 Gutter Cleaning\n\u2022 Roof Repairs\n\u2022 Drive way Sealing\n\u2022 Roof Restorations\n\u2022 Roof Replacement\n\u2022 We specialise in, terracotta, concrete and Slate roof tiles.\n\u2022 7 Years Warranty\nEvery job is provided with warranty. Rain, hail or shine we are at your doorstep!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Interstate Prestige Roofing",
                                        "url": "https://www.oneflare.com.au/b/interstate-prestige-roofing-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/interstate-prestige-roofing-roofing",
                                                "anchor_text": "Interstate Prestige Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Suburbs Roofing & Repairs Pty Ltd",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (2.8km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a 3rd generation family company serving all of Sydney with high quality roofing repairs and all aspects of roofing we do Roofing leak repairs Valley repairs Roof washing and painting Sarkimg & battens Chimney repairs Flexi pointing Possum removal Rebedding Gutter repairs We give free estimates true out Sydney same day estimate We are fully registered & insured",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Suburbs Roofing & Repairs Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/all-suburbs-roofing-repairs-pty-ltd-568",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-suburbs-roofing-repairs-pty-ltd-568",
                                                "anchor_text": "All Suburbs Roofing & Repairs Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "MLR Slate Roofing Pty Ltd",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.0km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "MLR Slate roofing, specialises in traditional slate roofing, whether it's a small repair or a complete re-roof.\nAs a small business owner my aim is to provide and deliver top quality workmanship with a professional service.\nFor a no obligation quote please contact Matt",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "MLR Slate Roofing Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/mlr-slate-roofing-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/mlr-slate-roofing-pty-ltd",
                                                "anchor_text": "MLR Slate Roofing Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "OZWIDE Roofing",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.0km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OZWIDE ROOFING IS A WELL ESTABLISHED COMPANY WITH THE BEST TRADESMEN AND %100 workmanship attitude..the best rates on roof restorations call us now..",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "OZWIDE Roofing",
                                        "url": "https://www.oneflare.com.au/b/ausco-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/ausco-roofing",
                                                "anchor_text": "OZWIDE Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Popular roofing jobs in Balmain",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Mobile Verified Verified Information Email and phone number have been verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified Mobile Phone number has been verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email Verified Email Email has been verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Job Description: To replace gable roof and fix",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified Verified Information Phone number has been verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Job Description: replace gal iron roof with colorbond on garden shed\ntotal area 12.5 m x 2.2m\nAlso ridge cap 7.3m",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing service required: New roof installation/replacement | Type of roof: Steel / metal / colourbond | Type of building: Single-level home",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing job",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Posted by Yvonne",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing job",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Posted by Hans",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Hans' review for a a roofing job in Balmain",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Recommended. On time with quote and the job.\nFair price. Job well done",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Job Description: Semi detached 2 bedroom home",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing service required: New roof installation/replacement | Type of roof: Steel / metal / colourbond | Type of building: Single-level home",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "20 Mar 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "20 Mar 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing job",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Posted by Jill",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get the right price for your job",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Oneflare Cost Guide Centre is your one-stop shop to help you set your budget; from smaller tasks to larger projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Top Balmain roofing experts near you",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Browse top Roofing Expert experts with top ratings and reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best roofing experts in Balmain",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "View more roofing experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Truss costs",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Truss costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Roof Truss costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $9,000 - $15,000",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Average price $9,000 - $15,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof costs",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roof costs",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Colorbond Roof costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $15,000 - $25,000",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Average price $15,000 - $25,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling costs",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Roof Tiling costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $35 - $140 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Average price $35 - $140 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing costs",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing costs",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Roofing costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $45 - $90 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Average price $45 - $90 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse roofing experts by suburb",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular searches on Oneflare",
                                "main_title": "Best roofing experts in Balmain",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.8,
                                "max_rating_value": 5,
                                "rating_count": 362,
                                "relative_rating": 0.96
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}