{
    "id": "01190727-1132-0216-0000-8ce084590d15",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0251 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://spsroofing.com.au/roof-repairs-balmain-east/",
        "target": "spsroofing.com.au",
        "start_url": "https://spsroofing.com.au/roof-repairs-balmain-east/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Balmain-East\\organic\\type-organic_rg1_ra4_spsroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:03 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Property Check Channel",
                                    "url": "https://www.youtube.com/channel/UCRsC8oPEHOARWLpWoqQ8ItQ",
                                    "urls": [
                                        {
                                            "url": "https://www.youtube.com/channel/UCRsC8oPEHOARWLpWoqQ8ItQ",
                                            "anchor_text": "Property Check  Channel"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become A Member",
                                    "url": "https://spsroofing.com.au/sign-up/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/sign-up/",
                                            "anchor_text": "Become A Member"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacements",
                                    "url": "https://spsroofing.com.au/services/roof-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-replacements/",
                                            "anchor_text": "Roof Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://spsroofing.com.au/services/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restorations",
                                    "url": "https://spsroofing.com.au/services/roof-restorations/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-restorations/",
                                            "anchor_text": "Roof Restorations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://spsroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Services",
                                    "url": "https://spsroofing.com.au/services/gutter-services/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-services/",
                                            "anchor_text": "Gutter Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become a member",
                                    "url": "https://spsroofing.com.au/sign-up/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/sign-up/",
                                            "anchor_text": "Become a member"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://spsroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booking Now",
                                    "url": "https://spsroofing.com.au/booking/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/booking/",
                                            "anchor_text": "Booking Now"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "We're a Multi Award Winning Business",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Address Sydney NSW 2000 Tel 02 9067 9574 Operating Hours 24 hours / 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright 2026 | SPS Roofing | All Rights Reserved | SPS Roofing License No. 394055C",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Replacements",
                                    "url": "https://spsroofing.com.au/services/roof-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-replacements/",
                                            "anchor_text": "Roof Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://spsroofing.com.au/services/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restorations",
                                    "url": "https://spsroofing.com.au/services/roof-restorations/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-restorations/",
                                            "anchor_text": "Roof Restorations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://spsroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Services",
                                    "url": "https://spsroofing.com.au/services/gutter-services/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-services/",
                                            "anchor_text": "Gutter Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Inner West",
                                    "url": "https://spsroofing.com.au/services/roof-repairs-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-repairs-inner-west/",
                                            "anchor_text": "Roof Repairs Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Gutter Replacement",
                                    "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                            "anchor_text": "Box Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaf Gutter Guard",
                                    "url": "https://spsroofing.com.au/services/leaf-guard/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/leaf-guard/",
                                            "anchor_text": "Leaf Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repairs and Replacements",
                                    "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                            "anchor_text": "Downpipe Repairs and Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booking an Urgent Repair",
                                    "url": "https://spsroofing.com.au/booking/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/booking/",
                                            "anchor_text": "Booking an Urgent Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Speak to a Strata Specialist",
                                    "url": "https://spsroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/contact-us/",
                                            "anchor_text": "Speak to a Strata Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become a lifetime Member Now",
                                    "url": "https://spsroofing.com.au/membership/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/membership/",
                                            "anchor_text": "Become a lifetime Member Now"
                                        }
                                    ]
                                },
                                {
                                    "text": "Work With Us",
                                    "url": "https://spsroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/contact-us/",
                                            "anchor_text": "Work With Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs Balmain East",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "At SPS Roofing, we deliver roof repairs in Balmain East that stand the test of time, weather, and wear. With over 15 years of experience in roofing services Balmain East, we\u2019ve built a brand on quality, trust, and fast turnarounds - doing it the right way, every time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Your Local Experts in Roofing Balmain East",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If your roof\u2019s leaking, sagging, or showing signs of age, it\u2019s time to call in local roofers Balmain East who know what they\u2019re doing. From minor cracks to major storm damage, our roofing services Balmain East cover everything from emergency repairs to full roof restorations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019re the roofing contractors Balmain East homeowners and businesses rely on\u2014backed by a Lifetime Workmanship Guarantee and upfront pricing. No surprises. Just solutions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Book an emergency callout today",
                                        "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Book an emergency callout today"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs Balmain East",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We offer same day service for urgent jobs if you call before 10:30am. Our emergency roof repairs Balmain East team handles sudden leaks, storm damage, and dangerous structural shifts. We act fast to protect your property and prevent further damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose SPS Roofing ?",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Multi-Award Winning (Australian Small Business Champion Awards)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "15+ Years Experience Across Sydney & NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We Charge Per Job, Not Per Hour",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Make-A-Wish & Cancer Council Supporters",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Lifetime Workmanship Guarantee",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Seniors Card Accepted",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Affordable Roofing Balmain East, Backed by Experience",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "You shouldn\u2019t have to choose between quality and cost. As one of the top roofing companies Balmain East, we offer affordable roofing Balmain East with interest-free payment plans and upfront job-based pricing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We also run seasonal deals:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free Roof Clean with any roof restoration",
                                        "url": "https://spsroofing.com.au/services/roof-restorations/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-restorations/",
                                                "anchor_text": "roof restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "15% Off Leaf Guards with any roofing service",
                                        "url": "https://spsroofing.com.au/services/gutter-services/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/gutter-services/",
                                                "anchor_text": "roofing service"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Free Downpipe Install with any gutter replacement",
                                        "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                                "anchor_text": "gutter replacement"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections & Roof Maintenance Balmain East",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Prevention is always cheaper than repair. Our roof inspections Balmain East check for early signs of wear, damage, and poor ventilation. Ongoing roof maintenance Balmain East ensures your roof performs year-round and extends its lifespan.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ask about our inspection-to-maintenance plans for residential roofing Balmain East and commercial roofing Balmain East.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Roofing Solutions Balmain East",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Need more than a patch-up job? We\u2019re specialists in roof replacements Balmain East and large-scale roof restoration Balmain East projects. We handle metal roofing Balmain East, tile roofing Balmain East, flat roof repairs Balmain East, and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacements",
                                        "url": "https://spsroofing.com.au/services/roof-replacements/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-replacements/",
                                                "anchor_text": "Roof Replacements"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Cleaning",
                                        "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                                "anchor_text": "Roof Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://spsroofing.com.au/services/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-painting/",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing Installations",
                                        "url": "https://spsroofing.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing Installations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Need Gutter and Roofing Care?",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The roof and gutters work together. That\u2019s why we also offer:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Protect your roofline with SPS\u2019s full range of gutter services.",
                                        "url": "https://spsroofing.com.au/services/gutter-services/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/gutter-services/",
                                                "anchor_text": "gutter services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Box Gutter Replacement",
                                        "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                                "anchor_text": "Box Gutter Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaf Guard Installation",
                                        "url": "https://spsroofing.com.au/services/leaf-guard/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/leaf-guard/",
                                                "anchor_text": "Leaf Guard Installation"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak Repairs Balmain East You Can Trust",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A small leak today becomes a big problem tomorrow. Our specialists use thermal imaging and detailed assessments to find the roof damage Balmain East at its source. Our roof leak detection service helps prevent mould, timber rot, and insulation damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Learn more about leak detection \u00bb",
                                        "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                                "anchor_text": "Learn more about leak detection \u00bb"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Book a Quote for Roof Repairs Balmain East",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Whether it\u2019s roof repair cost Balmain East, roofing quotes Balmain East, or full-scale roof installation Balmain East, we\u2019ve got your needs covered. No pushy sales. Just honest service from Sydney\u2019s best roofers Balmain East.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Protect what\u2019s over your head\u2014choose SPS Roofing for expert care and peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Call Now or Contact Us Online",
                                        "url": "https://spsroofing.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/contact-us/",
                                                "anchor_text": "Contact Us Online"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Book a Roof Inspection",
                                        "url": "https://spsroofing.com.au/booking/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/booking/",
                                                "anchor_text": "Book a Roof Inspection"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "FAQs",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "How do I know if I need roof repairs Balmain East?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Common signs include leaks, cracked tiles, sagging areas, water stains on ceilings, or visible storm damage. If your roof's over 10 years old, we recommend a roof inspection Balmain East to catch problems early.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How much do roof repairs cost in Balmain East?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repair cost Balmain East depends on the issue, material type, and job size. Minor repairs may cost a few hundred dollars, while larger roofing solutions Balmain East can run into the thousands. We offer fixed-price quotes with no hidden fees.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Are emergency roof repairs Balmain East available after hours?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes. Our emergency roof repairs Balmain East team is available 24/7, with same-day service when you call before 10:30am. We respond quickly to storm damage roof repairs Balmain East and urgent leak issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What roofing materials do you work with?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We handle all major materials:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tile roofing Balmain East",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal roofing Balmain East",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flat roof repairs Balmain East",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We also specialise in heritage work and new roof installation Balmain East for both homes and commercial sites.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you offer roofing maintenance or just repairs?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. Ongoing roof maintenance Balmain East helps you avoid costly repairs down the track. This includes roof cleaning Balmain East, gutter repairs Balmain East, and roof ventilation Balmain East upgrades.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Why should I choose SPS Roofing over other roofing companies Balmain East?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We're not just another crew of roof repair specialists Balmain East \u2014we're award-winning roofers with a Lifetime Workmanship Guarantee, payment flexibility, and transparent pricing. We charge per job, not by the hour, so you know what to expect.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you offer any specials or discounts?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes! Current offers include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2714 Free roof clean with any restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2714 15% off leaf guards with any roofing service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2714 Free downpipe installation with any gutter replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Still have questions? Give us a call or send us a message \u2014we're here to help with all your roofing Balmain East needs.",
                                        "url": "https://spsroofing.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/contact-us/",
                                                "anchor_text": "send us a message"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Book your inspection here \u00bb",
                                        "url": "https://spsroofing.com.au/booking/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/booking/",
                                                "anchor_text": "Book your inspection here \u00bb"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Request your roofing estimate \u00bb",
                                        "url": "https://spsroofing.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/contact-us/",
                                                "anchor_text": "Request your roofing estimate \u00bb"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Call Now",
                                        "url": "https://spsroofing.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/contact-us/",
                                                "anchor_text": "Call Now"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "See our maintenance services \u00bb",
                                        "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                                "anchor_text": "See our maintenance services \u00bb"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Meet the team \u00bb",
                                        "url": "https://spsroofing.com.au/services/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-repairs/",
                                                "anchor_text": "Meet the team \u00bb"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Claim your offer \u00bb",
                                        "url": "https://spsroofing.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/contact-us/",
                                                "anchor_text": "Claim your offer \u00bb"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Balmain East",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Same Day Service Guaranteed!",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Lifetime Workmanship Guarantee",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roofing Repairs",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Range of Roofing Services",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Box Gutter Replacement",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Box Gutter Replacement",
                                        "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                                "anchor_text": "Box Gutter Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Cleaning",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter & Downpipe Replacement",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter & Downpipe Replacement",
                                        "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                                "anchor_text": "Gutter & Downpipe Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaf Guard",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Leaf Guard",
                                        "url": "https://spsroofing.com.au/services/leaf-guard/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/leaf-guard/",
                                                "anchor_text": "Leaf Guard"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nCleaning",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof\nCleaning",
                                        "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                                "anchor_text": "RoofCleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nRepairs",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof\nRepairs",
                                        "url": "https://spsroofing.com.au/services/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-repairs/",
                                                "anchor_text": "RoofRepairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency\nRoof Repairs",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Emergency\nRoof Repairs",
                                        "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak\nDetection",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leak\nDetection",
                                        "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                                "anchor_text": "Roof Leak Detection"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nReplacements",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof\nReplacements",
                                        "url": "https://spsroofing.com.au/services/roof-replacements/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-replacements/",
                                                "anchor_text": "RoofReplacements"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nPainting",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof\nPainting",
                                        "url": "https://spsroofing.com.au/services/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-painting/",
                                                "anchor_text": "RoofPainting"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nRestorations",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof\nRestorations",
                                        "url": "https://spsroofing.com.au/services/roof-restorations/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-restorations/",
                                                "anchor_text": "RoofRestorations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal\nRoofing",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal\nRoofing",
                                        "url": "https://spsroofing.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/metal-roofing/",
                                                "anchor_text": "MetalRoofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter\nServices",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter\nServices",
                                        "url": "https://spsroofing.com.au/services/gutter-services/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/gutter-services/",
                                                "anchor_text": "GutterServices"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Process",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "1. Inspection",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "2. Meet Project Manager",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "3. Job Commences",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Enquire with the team for an Inspection or Quotes",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Same Day Service Guaranteed!",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Lifetime Workmanship Guarantee",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "24/7 EMERGENCY Available",
                                "main_title": "Roof Repairs Balmain East",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+02 9067 9574",
                                "02 9067 9574",
                                "+61290679574"
                            ],
                            "emails": [
                                "info@spsroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}