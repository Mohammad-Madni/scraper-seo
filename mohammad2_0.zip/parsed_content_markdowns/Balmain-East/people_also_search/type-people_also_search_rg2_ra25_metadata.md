# Type: people_also_search | Rank: 25 | RG: 2
### Raw Row Data:
{
    "rank_group": "2",
    "rank_absolute": "25",
    "service": "roofer",
    "suburb": "Balmain East",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}