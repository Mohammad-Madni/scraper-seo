# Type: local_pack | Rank: 3 | RG: 3
### Raw Row Data:
{
    "rank_group": "3",
    "rank_absolute": "3",
    "service": "roofer",
    "suburb": "Castle Cove",
    "title": "Roofing Today of Roseville",
    "domain": "www.google.com",
    "url": "https://www.google.com/viewer/place?sca_esv=ed956a20e7b48028&hl=en&gl=AU&output=search&mid=/g/11rxtv9x0f&pip=CgZyb29mZXIQAg%3D%3D",
    "description": "Open \u00b7 Roseville Chase NSW",
    "type": "local_pack"
}