{
    "id": "01190728-1132-0216-0000-056919a229ad",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0344 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sespestcontrolfremantle.com.au/roof-plumber-castle-cove/",
        "target": "sespestcontrolfremantle.com.au",
        "start_url": "https://sespestcontrolfremantle.com.au/roof-plumber-castle-cove/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castle-Cove\\organic\\type-organic_rg20_ra24_sespestcontrolfremantle.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:45 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Plumber North Sydney",
                                    "url": "https://sespestcontrolfremantle.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/",
                                            "anchor_text": "Plumber North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Repairs & Installation North Sydney",
                                    "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-sydney-north/",
                                            "anchor_text": "Toilet Repairs & Installation North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs North Sydney",
                                    "url": "https://sespestcontrolfremantle.com.au/roof-plumber-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/roof-plumber-sydney-north/",
                                            "anchor_text": "Roof Repairs North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining Solutions Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/pipe-relining-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/pipe-relining-sydney-north/",
                                            "anchor_text": "Pipe Relining Solutions Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Pipe Repairs Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-sydney-north/",
                                            "anchor_text": "Leaking Pipe Repairs Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitter Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/gas-fitter-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/gas-fitter-sydney-north/",
                                            "anchor_text": "Gas Fitter Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water Heater Repairs Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-sydney-north/",
                                            "anchor_text": "Hot Water Heater Repairs Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-sydney-north/",
                                            "anchor_text": "Commercial Plumbing Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing North Sydney",
                                    "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-north-sydney/",
                                            "anchor_text": "Commercial Plumbing North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspection Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-sydney-north/",
                                            "anchor_text": "CCTV Drain Inspection Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Sydney North Plumbing",
                                    "url": "https://sespestcontrolfremantle.com.au/about-sydney-north-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/about-sydney-north-plumbing/",
                                            "anchor_text": "About Sydney North Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pest Control Instructions",
                                    "url": "https://sespestcontrolfremantle.com.au/pest-control-instructions/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/pest-control-instructions/",
                                            "anchor_text": "Pest Control Instructions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://sespestcontrolfremantle.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Sydney North Plumbing",
                                    "url": "https://sespestcontrolfremantle.com.au/about-sydney-north-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/about-sydney-north-plumbing/",
                                            "anchor_text": "About Sydney North Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Beacon Hill",
                                    "url": "https://sespestcontrolfremantle.com.au/blocked-drains-beacon-hill/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/blocked-drains-beacon-hill/",
                                            "anchor_text": "Blocked Drains Beacon Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Dee Why",
                                    "url": "https://sespestcontrolfremantle.com.au/blocked-drains-dee-why/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/blocked-drains-dee-why/",
                                            "anchor_text": "Blocked Drains Dee Why"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Marsfield",
                                    "url": "https://sespestcontrolfremantle.com.au/blocked-drains-marsfield/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/blocked-drains-marsfield/",
                                            "anchor_text": "Blocked Drains Marsfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains North Sydney",
                                    "url": "https://sespestcontrolfremantle.com.au/blocked-drains-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/blocked-drains-sydney-north/",
                                            "anchor_text": "Blocked Drains North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Terrey Hills",
                                    "url": "https://sespestcontrolfremantle.com.au/blocked-drains-terrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/blocked-drains-terrey-hills/",
                                            "anchor_text": "Blocked Drains Terrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspection Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-sydney-north/",
                                            "anchor_text": "CCTV Drain Inspection Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspections Beecroft",
                                    "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-beecroft/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-beecroft/",
                                            "anchor_text": "CCTV Drain Inspections Beecroft"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspections Dundas Valley",
                                    "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-dundas-valley/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-dundas-valley/",
                                            "anchor_text": "CCTV Drain Inspections Dundas Valley"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspections Mosman",
                                    "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-mosman/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-mosman/",
                                            "anchor_text": "CCTV Drain Inspections Mosman"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspections Turramurra",
                                    "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-turramurra/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-turramurra/",
                                            "anchor_text": "CCTV Drain Inspections Turramurra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing Balgowlah",
                                    "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-balgowlah/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-balgowlah/",
                                            "anchor_text": "Commercial Plumbing Balgowlah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing Clareville",
                                    "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-clareville/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-clareville/",
                                            "anchor_text": "Commercial Plumbing Clareville"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing Lavender Bay",
                                    "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-lavender-bay/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-lavender-bay/",
                                            "anchor_text": "Commercial Plumbing Lavender Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing North Sydney",
                                    "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-north-sydney/",
                                            "anchor_text": "Commercial Plumbing North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-sydney-north/",
                                            "anchor_text": "Commercial Plumbing Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://sespestcontrolfremantle.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitter Balgowlah Heights",
                                    "url": "https://sespestcontrolfremantle.com.au/gas-fitter-balgowlah-heights/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/gas-fitter-balgowlah-heights/",
                                            "anchor_text": "Gas Fitter Balgowlah Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitter Denistone East",
                                    "url": "https://sespestcontrolfremantle.com.au/gas-fitter-denistone-east/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/gas-fitter-denistone-east/",
                                            "anchor_text": "Gas Fitter Denistone East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitter Mona Vale",
                                    "url": "https://sespestcontrolfremantle.com.au/gas-fitter-mona-vale/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/gas-fitter-mona-vale/",
                                            "anchor_text": "Gas Fitter Mona Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitter Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/gas-fitter-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/gas-fitter-sydney-north/",
                                            "anchor_text": "Gas Fitter Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitter The Oaks",
                                    "url": "https://sespestcontrolfremantle.com.au/gas-fitter-the-oaks/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/gas-fitter-the-oaks/",
                                            "anchor_text": "Gas Fitter The Oaks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water Heater Frenchs Forest",
                                    "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-frenchs-forest/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-frenchs-forest/",
                                            "anchor_text": "Hot Water Heater Frenchs Forest"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water Heater Narrabeen",
                                    "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-narrabeen/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-narrabeen/",
                                            "anchor_text": "Hot Water Heater Narrabeen"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water Heater Repairs Berowra Heights",
                                    "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-berowra-heights/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-berowra-heights/",
                                            "anchor_text": "Hot Water Heater Repairs Berowra Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water Heater Repairs Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-sydney-north/",
                                            "anchor_text": "Hot Water Heater Repairs Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water Heater Willoughby East",
                                    "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-willoughby-east/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-willoughby-east/",
                                            "anchor_text": "Hot Water Heater Willoughby East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Pipe Repair Cremorne",
                                    "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-cremorne/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-cremorne/",
                                            "anchor_text": "Leaking Pipe Repair Cremorne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Pipe Repair Manly",
                                    "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-manly/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-manly/",
                                            "anchor_text": "Leaking Pipe Repair Manly"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Pipe Repair Pennant Hills",
                                    "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-pennant-hills/",
                                            "anchor_text": "Leaking Pipe Repair Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Pipe Repairs Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-sydney-north/",
                                            "anchor_text": "Leaking Pipe Repairs Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Local Plumber St Ives",
                                    "url": "https://sespestcontrolfremantle.com.au/plumber-saint-ives/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/plumber-saint-ives/",
                                            "anchor_text": "Local Plumber St Ives"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pest Control Instructions",
                                    "url": "https://sespestcontrolfremantle.com.au/pest-control-instructions/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/pest-control-instructions/",
                                            "anchor_text": "Pest Control Instructions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining Chatswood",
                                    "url": "https://sespestcontrolfremantle.com.au/pipe-relining-chatswood/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/pipe-relining-chatswood/",
                                            "anchor_text": "Pipe Relining Chatswood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining Curl Curl",
                                    "url": "https://sespestcontrolfremantle.com.au/pipe-relining-curl-curl/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/pipe-relining-curl-curl/",
                                            "anchor_text": "Pipe Relining Curl Curl"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining Killara",
                                    "url": "https://sespestcontrolfremantle.com.au/pipe-relining-killara/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/pipe-relining-killara/",
                                            "anchor_text": "Pipe Relining Killara"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining North Manly",
                                    "url": "https://sespestcontrolfremantle.com.au/pipe-relining-north-manly/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/pipe-relining-north-manly/",
                                            "anchor_text": "Pipe Relining North Manly"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining Solutions Sydney North",
                                    "url": "https://sespestcontrolfremantle.com.au/pipe-relining-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/pipe-relining-sydney-north/",
                                            "anchor_text": "Pipe Relining Solutions Sydney North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumber In Artarmon",
                                    "url": "https://sespestcontrolfremantle.com.au/plumber-artarmon/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/plumber-artarmon/",
                                            "anchor_text": "Plumber In Artarmon"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumber In Cromer",
                                    "url": "https://sespestcontrolfremantle.com.au/plumber-cromer/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/plumber-cromer/",
                                            "anchor_text": "Plumber In Cromer"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumber Manly Vale",
                                    "url": "https://sespestcontrolfremantle.com.au/plumber-manly-vale/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/plumber-manly-vale/",
                                            "anchor_text": "Plumber Manly Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumber North Sydney",
                                    "url": "https://sespestcontrolfremantle.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/",
                                            "anchor_text": "Plumber North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumber Avalon Beach",
                                    "url": "https://sespestcontrolfremantle.com.au/roof-plumber-avalon-beach/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/roof-plumber-avalon-beach/",
                                            "anchor_text": "Roof Plumber Avalon Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumber Castle Cove",
                                    "url": "https://sespestcontrolfremantle.com.au/roof-plumber-castle-cove/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/roof-plumber-castle-cove/",
                                            "anchor_text": "Roof Plumber Castle Cove"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumber North Curl Curl",
                                    "url": "https://sespestcontrolfremantle.com.au/roof-plumber-north-curl-curl/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/roof-plumber-north-curl-curl/",
                                            "anchor_text": "Roof Plumber North Curl Curl"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Freshwater",
                                    "url": "https://sespestcontrolfremantle.com.au/roof-plumber-freshwater/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/roof-plumber-freshwater/",
                                            "anchor_text": "Roof Repairs Freshwater"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs North Sydney",
                                    "url": "https://sespestcontrolfremantle.com.au/roof-plumber-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/roof-plumber-sydney-north/",
                                            "anchor_text": "Roof Repairs North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Thank You",
                                    "url": "https://sespestcontrolfremantle.com.au/thank-you/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/thank-you/",
                                            "anchor_text": "Thank You"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Repairs & Installation Berowra",
                                    "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-berowra/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-berowra/",
                                            "anchor_text": "Toilet Repairs & Installation Berowra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Repairs & Installation Elanora Heights",
                                    "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-elanora-heights/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-elanora-heights/",
                                            "anchor_text": "Toilet Repairs & Installation Elanora Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Repairs & Installation Naremburn",
                                    "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-naremburn/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-naremburn/",
                                            "anchor_text": "Toilet Repairs & Installation Naremburn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Repairs & Installation North Sydney",
                                    "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-sydney-north/",
                                            "anchor_text": "Toilet Repairs & Installation North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Repairs & Installation Willoughby",
                                    "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-willoughby/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-willoughby/",
                                            "anchor_text": "Toilet Repairs & Installation Willoughby"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "All information provided by us and our associated trading names through website content, marketing materials, emails, or verbal communication is for general reference only. Services are arranged and coordinated by us, and delivery may vary based on availability and scope. No guarantees, warranties, or representations apply unless expressly stated and agreed with the customer invoice and confirmed in writing on site with contractor before starting the job.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Our professional Sydney North Plumbing team is one of the best and leading plumbing service provider in this region of North Sydney. Our plumbing experts are certified and licensed to troubleshoot your plumbing system with the best result\u2026 Know More About Us",
                                    "url": "https://sydneynorthplumbing.com.au/about-sydney-north-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneynorthplumbing.com.au/about-sydney-north-plumbing/",
                                            "anchor_text": "Know More About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains",
                                    "url": "https://sespestcontrolfremantle.com.au/blocked-drains-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/blocked-drains-sydney-north/",
                                            "anchor_text": "Blocked Drains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing",
                                    "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/commercial-plumbing-north-sydney/",
                                            "anchor_text": "Commercial Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitter",
                                    "url": "https://sespestcontrolfremantle.com.au/gas-fitter-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/gas-fitter-sydney-north/",
                                            "anchor_text": "Gas Fitter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining",
                                    "url": "https://sespestcontrolfremantle.com.au/pipe-relining-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/pipe-relining-sydney-north/",
                                            "anchor_text": "Pipe Relining"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Repairs & Installation",
                                    "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/toilet-repairs-installation-sydney-north/",
                                            "anchor_text": "Toilet Repairs & Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspections",
                                    "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/cctv-drain-inspections-sydney-north/",
                                            "anchor_text": "CCTV Drain Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water Heater",
                                    "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/hot-water-heater-sydney-north/",
                                            "anchor_text": "Hot Water Heater"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Pipe Repair",
                                    "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/leaking-pipe-repair-sydney-north/",
                                            "anchor_text": "Leaking Pipe Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumber",
                                    "url": "https://sespestcontrolfremantle.com.au/roof-plumber-sydney-north/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/roof-plumber-sydney-north/",
                                            "anchor_text": "Roof Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney, Australia",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright \u00a9 2026 Plumber Sydney | All Rights Reserved.",
                                    "url": "https://sespestcontrolfremantle.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://sespestcontrolfremantle.com.au/",
                                            "anchor_text": "Plumber Sydney"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Having A Tough Time Searching For A Roof Plumber In Castle Cove??",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "You need to keep an eye on the roof of your house to keep it clean and maintained. As you do not clean your roof very often, so it can get dirty and damaged very easily. It is important for you to clean the roof of your house on time. Sydney North Plumbing team offers the best roof plumbing service in Castle Cove. Our team of professional plumbers is well-experienced in plumbing services. We also have well-trained plumbing experts who will try to solve your roof problem immediately. You can hire our Roof Repair Plumber Castle Cove to get the best roof repair service in your area.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With the rough weather in Castle Cove, not even a single day of stress will blow in your life when you have booked us. Standing with you in your emergencies, we here at Sydney North Plumbing, are 24*7 available for you, to talk to you over 02 8503 4109 and deliver you with the same day services or as per your preferences for Roof Plumbing. When you are struggling with roof damage, you are bound to immediately hunt for a roof plumber in Castle Cove. The reason is, holding up the roof unattended for a longer time, will conclude you to expend more. Therefore, it is feasible to hire a professional to attend to your roof in the initial stage to reclaim it from getting more damaged.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Places Where We\nServe Exceptional Plumbing Services",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Sydney North Plumbing never limits the places to provide plumbing services. We provide services for commercial areas as well as residential areas. Our plumbers\u2019 team committed to providing fully satisfied services without compromising on quality level. The places where we provide services are listed below:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "So, if you need plumbing services in any of the above-mentioned places and more then make us call anytime. One more thing we need to add that every plumber which we send to do the work is licensed and accredited so, feel free to have our team at your place.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Main Reason For Roof Leaks",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof leaks can irritate you very easily, as it is one of the most frustrating situations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "for everyone. One of the main reasons for a roof leak is the damage to the vents of the roof. If your gutters are blocked then you will also face a roof leak problem. You can book your appointment with Roof Repair Plumber Castle Cove for the repairing of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Services That We Have For You",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Repair Plumber Castle Cove provides various roof repairing services. You can hire us for rooftop maintenance, Gutter Replacement, Roofing Restoration, Metal Roof Repairs, and so on. We always try to provide the best quality service to our customers. Our team also communicates with the customers to solve their problems immediately. Below, you can find the list of our main services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Repair Plumber Castle Cove also offers gutter repair and replacement services. It is important for you to take good care of your gutters to maintain their longevity. With us, you can also replace your gutter if needed. The repair and replacement completely depend upon the condition of your gutter. If the damage is in the small portion then it will be easy to repair. You need the gutter replacement service when the complete section of the gutter is damaged or has various problems. We are using the latest tools to provide you the most effective gutter repair and replacement service.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "A Quick Peek At A Few Of The Roof Plumbing Services",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "It is most of the time advised to pull up your socks and get ready before the storm crashes you and your house. We cannot wait until the damages cost you more, or your unclean gutters start flooding and rusting. Your needs can be:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaking Roof Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof/Gutter Cleaning & Maintenance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Downpipe Repair and installation",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation And Repairs in Castle Cove",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From residential to commercial areas, color bond roof installation in Castle Cove being the choice of maximum clients is a perfect one with a stunning look. Further adding up with the easy maintenance in the future, our team for roof plumbing Castle Cove renders you with the installation, re-roofing, and repairs services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters And Downpipes",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Gutters and downpipes act as the protectors of your house in storms and floods. They accurately eliminate the rainwater to enter your place. Be it your commercial place or your residence area, the continuous length gutters offered by us will surely eliminate leaks.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Can You Expect From Sydney North Plumbing ??",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Always showing up on time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Provide you with the 24 hours and 365 days of the service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our professional roof plumbers at Castle Cove are well-equipped and experienced enough to deliver you the ultimate outcome.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are upfront about the fees that we charge you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Safety is also considered while working.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Take initiative for the accurate solution for your roof damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Find Our Services Location In Castle Cove",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\ud83c\udfea Roof Plumber Castle Cove | \ud83d\udccd Location: Castle Cove, 2069, NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Plumber Castle Cove",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Repairs And Replacement Castle Cove",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Request Call Back",
                                "main_title": "Roof Plumber Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I acknowledge that I have read the Pest Control Instructions",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We Are Here For You 24 x 7",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Call Now For A Quote",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "0488 859 950",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0488 859 950"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}