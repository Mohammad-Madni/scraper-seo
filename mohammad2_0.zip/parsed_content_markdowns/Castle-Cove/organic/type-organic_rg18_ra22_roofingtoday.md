{
    "id": "01190728-1132-0216-0000-407b5b34929c",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0236 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofingtoday.com.au/roseville-chase-nsw/",
        "target": "roofingtoday.com.au",
        "start_url": "https://roofingtoday.com.au/roseville-chase-nsw/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castle-Cove\\organic\\type-organic_rg18_ra22_roofingtoday.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:47 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://roofingtoday.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofingtoday.com.au/roof-repairs/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/roof-repairs/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Maintenance",
                                    "url": "https://roofingtoday.com.au/gutter-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/gutter-maintenance/",
                                            "anchor_text": "Gutter Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://roofingtoday.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://roofingtoday.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://roofingtoday.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofingtoday.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofingtoday.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofingtoday.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofingtoday.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofingtoday.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofingtoday.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Roofing Services in Roseville Chase, NSW",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roofing today Roseville Chase, NSW",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Frequently Asked Questions",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Local Roofing Experts in Roseville Chase",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to roofing in Roseville Chase, NSW, locals turn to\u00a0Roofing Today for expert service, honest pricing, and lasting results. We provide a complete range of roofing services for both residential and commercial properties, including installations, inspections, guttering, and repairs. Whether you\u2019re upgrading an older roof or dealing with sudden damage, we\u2019re ready to help.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We also work across nearby suburbs such as Roseville, Castle Cove, and across the North Shore offering fast turnaround and high-quality workmanship in every job. With tree-lined streets and steep roof designs common in this area, our experienced team is equipped to handle everything from tile replacement to emergency roof repair with confidence and care.",
                                        "url": "https://roofingtoday.com.au/roseville-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roseville-nsw/",
                                                "anchor_text": "Roseville"
                                            },
                                            {
                                                "url": "https://roofingtoday.com.au/castle-cove-nsw/",
                                                "anchor_text": "Castle Cove"
                                            },
                                            {
                                                "url": "https://roofingtoday.com.au/north-shore-nsw/",
                                                "anchor_text": "North Shore"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing today services in the suburbs of Roseville and Castle Cove",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Home Roofing",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We offer full-service home roofing solutions across Roseville Chase, including installations, upgrades, and re-roofing projects. Our team works with Colorbond, tile, and slate roofing materials to suit your style and budget. Whether you\u2019re restoring a classic home or building new, we deliver tailored results designed to last. Our work enhances property value while improving weather resistance and insulation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From small businesses to multi-unit buildings, we provide reliable commercial roofing services in Roseville Chase, NSW. We handle installations, maintenance, and repairs using durable materials that stand up to sun, rain, and wear. We know how to minimise disruptions, stick to schedules, and ensure your property remains protected. Every project meets compliance standards and is built to perform long-term.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Prompt and professional roof repair is one of our most requested services in Roseville Chase. Whether you\u2019re dealing with cracked tiles, rusted flashing, or roof sagging, we\u2019ll identify the problem and restore your roof to full function. Our team uses matching materials to maintain your roof\u2019s appearance and performance. We also handle emergency roof repair when leaks or damage can\u2019t wait.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Services",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We clean, repair, and replace gutters to prevent blockages and protect your home\u2019s structure. With overhanging trees common in Roseville Chase, gutters often need more attention. We install rust-resistant systems and offer gutter guard installations to reduce long-term maintenance. A functioning drainage system keeps water flowing safely away from your home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our detailed roof inspections identify hidden issues and prevent costly repairs down the track. We assess materials, flashing, drainage, and structure, then provide a report with photos and recommendations. If you\u2019re preparing to sell, recently purchased a home, or just want peace of mind, our inspections provide the clarity you need. We\u2019re here to help you make informed decisions about your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Prices in Roseville Chase, NSW",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roofing prices in Roseville Chase vary depending on roof type, size, and the work required. Small repairs are generally affordable, while full replacements or complex installations involve higher costs. We always begin with a free inspection and follow up with a fixed, written quote\u2014no hidden extras or surprise charges. Our pricing reflects quality, reliability, and long-term value.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Roofing Today in Roseville Chase?",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Local Knowledge : We understand the unique roofing challenges in Roseville Chase and nearby suburbs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast Response : Especially for urgent leaks or storm damage, we act quickly and effectively.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Licensed Professionals : All our roofers are insured, qualified, and experienced.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Top-Tier Materials : We use trusted products from brands like Colorbond and Monier.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guaranteed Results : Every job comes with a workmanship guarantee and full product warranties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q1: Do you provide roofing services in Roseville Chase?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes. Roofing Today of Roseville Chase services all local homes, offering roof repairs, restorations, and replacements.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q2: Do you handle emergency roof repairs?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. We provide 24/7 emergency leak and storm damage repair for Roseville Chase homeowners.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q3: What types of roofs do you work with?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tile, metal, and Colorbond roofs \u2014 we handle all major roof types across the North Shore.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q4: Do you offer gutter maintenance and cleaning?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes. We provide gutter cleaning, repair, and installation as part of our complete roofing service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q5: Is the work guaranteed?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Every project is backed by our 7-year workmanship guarantee and quality assurance program.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Customers Say",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u201cExcellent roof repair after a tree branch cracked some tiles. Great communication and clean-up too.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cCalled them for an emergency roof repair during a storm. They were here in under two hours and fixed the issue fast.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cVery happy with their service from start to finish. Friendly team and quality work.\u201d \u2b50\u2b50\u2b50\u2b50\u2b50",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What\u2019s involved in a typical roof inspection?",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We examine all key areas\u2014tiles or sheeting, flashing, drainage, ridges, and valleys. Our team identifies both visible and hidden damage and provides a clear report with recommendations. It\u2019s a great way to catch problems before they become costly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Can you repair roofs on older homes?",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Yes. We work with many older properties in Roseville Chase and nearby areas. Our team is skilled at sourcing compatible materials and ensuring repairs blend with the original design. We prioritise both functionality and aesthetic consistency.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What should I do if I notice a leak during heavy rain?",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Call us for an emergency roof repair. We can provide temporary protection if needed and then carry out full repairs as soon as weather permits. Acting quickly helps prevent water damage inside your home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Are metal roofs better than tile in this area?",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Both materials are used in Roseville Chase. Colorbond offers long-term durability and requires less maintenance, while tile provides a traditional look with excellent thermal insulation. We\u2019ll guide you on the best option based on your needs and roof structure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Book Roofing Services in Roseville Chase, NSW Today",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If you need a roofer you can count on in Roseville Chase, NSW, look no further than\u00a0Roofing Today. From fast roof repairs to full replacements, we bring expertise and care to every job. Our goal is to make roofing simple, stress-free, and built to last. Call now to schedule a free quote, or visit our\u00a0main website to explore our full range of services.",
                                        "url": "https://roofingtoday.com.au/roseville-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roseville-nsw/",
                                                "anchor_text": "main website"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Driving Directions",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Driving Directions to Our Roseville Chase Location",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Head north on Malga Ave toward Rowe St (250 m)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Turn left onto Babbage Rd \u2014 destination will be on the left",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Services in Roseville Chase, NSW",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roofing Today is a business owned by Local Searches Pty Ltd. It connects customers with roofing businesses that it has commercial arrangements with",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Contact Info",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ROOFING TODAY",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 8261 0051",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney, NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quick Links",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "About Us",
                                        "url": "https://roofingtoday.com.au/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/about-us/",
                                                "anchor_text": "About Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our Services",
                                        "url": "https://roofingtoday.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/services/",
                                                "anchor_text": "Our Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Commercial Roofing",
                                        "url": "https://roofingtoday.com.au/commercial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/commercial-roofing/",
                                                "anchor_text": "Commercial Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": "https://roofingtoday.com.au/roof-repairs/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roof-repairs/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Repair",
                                        "url": "https://roofingtoday.com.au/gutter-maintenance/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/gutter-maintenance/",
                                                "anchor_text": "Gutter Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Residential Roofing",
                                        "url": "https://roofingtoday.com.au/residential-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/residential-roofing/",
                                                "anchor_text": "Residential Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Maintenance",
                                        "url": "https://roofingtoday.com.au/roof-maintenance/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roof-maintenance/",
                                                "anchor_text": "Roof Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://roofingtoday.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roof-repairs/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://roofingtoday.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://roofingtoday.com.au/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://roofingtoday.com.au/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "GET IN TOUCH",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Talk to us today about roofing services for your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Serving Roseville, Castle Cove, and surrounding North Shore suburbs",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Roofing Today",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Fill out our quick form to receive a personalised quote:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Today of Roseville",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Location",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Phone",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hours of Operation",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof repair Roseville Chase, NSW",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roofing Services",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "All Services We Offer",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Affordable and flexible Roofing pricing options",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing",
                                        "url": "https://roofingtoday.com.au/commercial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/commercial-roofing/",
                                                "anchor_text": "Commercial Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": "https://roofingtoday.com.au/roof-repairs/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roof-repairs/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Maintenance",
                                        "url": "https://roofingtoday.com.au/gutter-maintenance/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/gutter-maintenance/",
                                                "anchor_text": "Gutter Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Residential Roofing",
                                        "url": "https://roofingtoday.com.au/residential-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/residential-roofing/",
                                                "anchor_text": "Residential Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Maintenance",
                                        "url": "https://roofingtoday.com.au/roof-maintenance/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roof-maintenance/",
                                                "anchor_text": "Roof Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://roofingtoday.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roof-repairs/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://roofingtoday.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://roofingtoday.com.au/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://roofingtoday.com.au/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofingtoday.com.au/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Today of Roseville",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Reach Out",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Location",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "2/9B Babbage Rd, Roseville Chase NSW 2069",
                                        "url": "https://goo.gl/maps/Q5HwSxjAV56zk9V89",
                                        "urls": [
                                            {
                                                "url": "https://goo.gl/maps/Q5HwSxjAV56zk9V89",
                                                "anchor_text": "2/9B Babbage Rd, Roseville Chase NSW 2069"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Phone",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "(02) 8403 0126",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Hours of Operation",
                                "main_title": "Roofing Services in Roseville Chase, NSW",
                                "author": "Roofing Today",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Monday \u2013 Sunday: Open 24 hours",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 8403 0126",
                                "(02) 8261 0051"
                            ],
                            "emails": [
                                "info@roofingtoday.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}