{
    "id": "01190728-1132-0216-0000-a87379319ac8",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0320 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofernearme.com.au/",
        "target": "roofernearme.com.au",
        "start_url": "https://roofernearme.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castle-Cove\\organic\\type-organic_rg17_ra21_roofernearme.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:31:51 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://roofernearme.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://roofernearme.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Book Online",
                                    "url": "https://book.servicem8.com/request_booking?uuid=d30fc6f3-58df-4a76-9656-3850e7d994ab",
                                    "urls": [
                                        {
                                            "url": "https://book.servicem8.com/request_booking?uuid=d30fc6f3-58df-4a76-9656-3850e7d994ab",
                                            "anchor_text": "Book Online"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofernearme.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofernearme.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Talk to one of our expert roofers- fill in the inquiry form or call us on 0432 822 128",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Areas We Service : We are Sydney based and service the Lower North Shore and Inner West Sydney. Including Artarmon, Chatswood, Inner West Sydney, Newtown, Marrickville, Mosman, Killara, Lindfield, Lower North Shore, Roseville, Willoughby, Lane Cove, Castle Cove, St Ives, Gordon, Middle Cove, Turramurra, Naremburn, Crows Nest, Castlecrag, Cremorne, Lane Cove North, Killara East, East Lindfield, Roseville Chase, Willoughby North, St Peters, Northbridge, Cammeray, Annandale, Balwgowlah, Brookvale, Chatswood East, Chatswood West, Clontarf, Cremorne Point, Curl Curl, Dee Why, Drummoyne, Dulwich Hill, East Killara, Forestville, Frenchs Forest, Freshwater, Greenwich, Killarney Heights, Kurraba Point, Lane Cove East, Lane Cove West, Lewisham, Liechardt, Longueville, Macquarie Park, Manly, Neutral Bay, North Balgowlah, North Curl Curl, North Ryde, North Sydney, Northwood, Riverview, Ryde, Seaforth, South Turramurra, St Leonards, Stanmore, Wahroonga, Waverton, Willoughby East, Wollstonecraft and more.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2026 Roofer Near Me Privacy Policy. RNM Terms and Conditions",
                                    "url": "https://roofernearme.com.au/privacy/",
                                    "urls": [
                                        {
                                            "url": "https://roofernearme.com.au/privacy/",
                                            "anchor_text": "Privacy Policy"
                                        },
                                        {
                                            "url": "https://roofernearme.com.au/terms-and-coditions/",
                                            "anchor_text": "RNM Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Couldn't Find What You Were Looking For ?",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Talk to one of our expert roofers before you go..",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email Us",
                                    "url": "https://roofernearme.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofernearme.com.au/contact-us/",
                                            "anchor_text": "Email Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call 0432822128",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Ask a Roofer",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Call Now",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email Us",
                                    "url": "https://roofernearme.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofernearme.com.au/contact-us/",
                                            "anchor_text": "Email Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Your 10% OFF code is ready.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "You're in!",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://roofernearme.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://roofernearme.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Book Online",
                                    "url": "https://book.servicem8.com/request_booking?uuid=d30fc6f3-58df-4a76-9656-3850e7d994ab",
                                    "urls": [
                                        {
                                            "url": "https://book.servicem8.com/request_booking?uuid=d30fc6f3-58df-4a76-9656-3850e7d994ab",
                                            "anchor_text": "Book Online"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofernearme.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofernearme.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Sydney\u2019s Roofing Experts",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roofer Near Me- We Do it Right the first time!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lic 335427c",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leak Detection Specialist",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Why replace when you can repair your roof. We have trained leak detection specialists who can find the cause of a leak!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile roof repairs",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We specialise in most types of tile repairs to help maintain and extend the life of your roof. No job is too big or small.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Strata and Real Estate",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our customer service and response time is fast and reliable which makes us a joy for stratas and real estate managers to work with!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "RESIDENTIAL, COMMERCIAL, STRATA AND MORE\u2026",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From the roof inspection process all the way through to works completed, our team will guide you through the process efficiently and professionally.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Simon and Michael",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "AKA the 2 Boss Men",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon is the Production and technical boss man and Michael is the Estimator boss man making sure everything is being done to the highest standard.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Keiko",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Ultimate Assistant",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The friendly voice on the other end of the phone when you call for your free inspection and to book in your works. She runs a tight ship and we can\u2019t imagine Roofer Near Me without her!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Jorge",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Lead Roofer",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jorge is fully licensed and knows his stuff! Expert at tile roofing, metal roofing and slate roofing. There\u2019s not much he can\u2019t do!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Andrew",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roofing Master!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Andrew knows his stuff! He takes that extra bit of care which shows through on all the 5 star reviews he gets from clients.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Bernado",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Tile Roofing Expert",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bernardo is hard working, thorough and is one of the friendliest roofers around. His work ethic is second to none and we constantly get feedback regarding how caring and all round awesome he is.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Eduardo",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal and Tile Roofing Expert",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Eduardo is the humble one on the team. He is humble yet very meticulous with his craft and takes care with each part of the job to make sure it is done right!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Matt",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "All round roofing legend!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Matt joins us from Coffs Harbour, he is just an all round great roofer and about the nicest person you will meet!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tony",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Gutter, Repairs and Estimating Expert",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "About the nicest person you will meet, Tony is friendly, down to earth and works faster on gutter cleaning than anyone we have seen!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tina",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Accounts Manager",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tina makes sure all the staff are paid and gets invoices sent and collected. She is very professional and friendly and doesn\u2019t miss a beat!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "With so many options out there, why us\u2026?",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We are licensed and insured",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We won\u00b4t leave you waiting for days",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We care about doing a good job",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What do our customers say\u2026",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Melissa Halliday",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Alessandro Leonardi",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Georgina Andrews",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Dennis Wan",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Kai Lam",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Margaret Cooke",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Frances MacDonagh",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Kathryn anne Dally",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bonnie Reid",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Robert Gullotta",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Local\nBusiness Awards Winners",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Full roof replacements",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Replacing your roof to Colorbond is our speciality! Using all different types of roof sheets and colours to suit your needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential and Commercial\nRoofing experts",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Servicing Sydney\u2019s Lower North Shore and Inner West",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Professional, Reliable and Competent",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "MEET THE TEAM",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney\u2019s Roofing Experts",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "WHY CHOOSE US??",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Works\nCompleted",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Protect your roof",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "3 simple steps to safeguard\nyour roof",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact us to book a free inspection at a time that suits you, you can phone, text, email or fill in an enquiry form",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our roofing experts will come and assess your roofing needs, find a suitable solution and provide you with a straightforward, easy to understand analysis and quote",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "You book in your works with our team and we come and get the job\u2026\nDONE!",
                                "main_title": "Sydney\u2019s Roofing Experts",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+612 38211614",
                                "0432 822 128",
                                "0432822128",
                                "0272057788"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}