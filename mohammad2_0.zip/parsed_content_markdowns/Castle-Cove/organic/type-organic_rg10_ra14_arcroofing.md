{
    "id": "01190728-1132-0216-0000-27ff19ea7fd5",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0225 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://arcroofing.com.au/project/castle-cove-residence-nsw/",
        "target": "arcroofing.com.au",
        "start_url": "https://arcroofing.com.au/project/castle-cove-residence-nsw/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castle-Cove\\organic\\type-organic_rg10_ra14_arcroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:47 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Why choose us",
                                    "url": "https://arcroofing.com.au/about/why-choose-us/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/about/why-choose-us/",
                                            "anchor_text": "Why choose us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Awards & Recognition",
                                    "url": "https://www.arcroofing.com.au/about/why-choose-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/about/why-choose-us/",
                                            "anchor_text": "Awards & Recognition"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our History",
                                    "url": "https://www.arcroofing.com.au/about/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/about/",
                                            "anchor_text": "Our History"
                                        }
                                    ]
                                },
                                {
                                    "text": "What we do",
                                    "url": "https://arcroofing.com.au/capabilities/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/capabilities/",
                                            "anchor_text": "What we do"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Services",
                                    "url": "https://www.arcroofing.com.au/capabilities/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/capabilities/",
                                            "anchor_text": "Our Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Sectors",
                                    "url": "https://www.arcroofing.com.au/capabilities/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/capabilities/",
                                            "anchor_text": "Our Sectors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call us Now! 02-9482-4461",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Talk to us info@arcroofing.com.au",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Why choose us",
                                    "url": "https://arcroofing.com.au/about/why-choose-us/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/about/why-choose-us/",
                                            "anchor_text": "Why choose us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Awards & Recognition",
                                    "url": "https://www.arcroofing.com.au/about/why-choose-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/about/why-choose-us/",
                                            "anchor_text": "Awards & Recognition"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our History",
                                    "url": "https://www.arcroofing.com.au/about/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/about/",
                                            "anchor_text": "Our History"
                                        }
                                    ]
                                },
                                {
                                    "text": "What we do",
                                    "url": "https://arcroofing.com.au/capabilities/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/capabilities/",
                                            "anchor_text": "What we do"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Services",
                                    "url": "https://www.arcroofing.com.au/capabilities/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/capabilities/",
                                            "anchor_text": "Our Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Sectors",
                                    "url": "https://www.arcroofing.com.au/capabilities/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/capabilities/",
                                            "anchor_text": "Our Sectors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call us Now! 02-9482-4461",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Talk to us info@arcroofing.com.au",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "The Sirius Building, a landmark of Sydney\u2019s architectural her",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "After being approached by H&E Architects, ARC Roofing was task",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Previous Post Lauriston House",
                                    "url": "https://arcroofing.com.au/project/lauriston-house/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/project/lauriston-house/",
                                            "anchor_text": "Previous Post\n\t\t\t\t\t\tLauriston House"
                                        }
                                    ]
                                },
                                {
                                    "text": "Next Post Goddard Building QLD",
                                    "url": "https://arcroofing.com.au/project/goddard-building-qld/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/project/goddard-building-qld/",
                                            "anchor_text": "Next Post\n\t\t\t\t\t\tGoddard Building QLD"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney, CBD",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Sydney CBD",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "H&E Architects",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://arcroofing.com.au/about/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/about/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Why Choose Us",
                                    "url": "https://arcroofing.com.au/about/why-choose-us/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/about/why-choose-us/",
                                            "anchor_text": "Why Choose Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://arcroofing.com.au/contact/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/contact/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Services",
                                    "url": "https://www.arcroofing.com.au/capabilities/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/capabilities/",
                                            "anchor_text": "Our Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Projects",
                                    "url": "https://arcroofing.com.au/project/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/project/",
                                            "anchor_text": "Our Projects"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our News",
                                    "url": "https://arcroofing.com.au/news/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/news/",
                                            "anchor_text": "Our News"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cladding Specialist",
                                    "url": "https://www.arcroofing.com.au/about/careers/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/about/careers/",
                                            "anchor_text": "Cladding Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Working Visa\u2019s",
                                    "url": "https://www.arcroofing.com.au/about/careers/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/about/careers/",
                                            "anchor_text": "Working Visa\u2019s"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copyright \u00a9 2021 ARC Roofing. Designed and Developed by Hanna Media",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Why choose us",
                                    "url": "https://arcroofing.com.au/about/why-choose-us/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/about/why-choose-us/",
                                            "anchor_text": "Why choose us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Awards & Recognition",
                                    "url": "https://www.arcroofing.com.au/about/why-choose-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/about/why-choose-us/",
                                            "anchor_text": "Awards & Recognition"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our History",
                                    "url": "https://www.arcroofing.com.au/about/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/about/",
                                            "anchor_text": "Our History"
                                        }
                                    ]
                                },
                                {
                                    "text": "What we do",
                                    "url": "https://arcroofing.com.au/capabilities/",
                                    "urls": [
                                        {
                                            "url": "https://arcroofing.com.au/capabilities/",
                                            "anchor_text": "What we do"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Services",
                                    "url": "https://www.arcroofing.com.au/capabilities/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/capabilities/",
                                            "anchor_text": "Our Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Sectors",
                                    "url": "https://www.arcroofing.com.au/capabilities/",
                                    "urls": [
                                        {
                                            "url": "https://www.arcroofing.com.au/capabilities/",
                                            "anchor_text": "Our Sectors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call us Now! 02-9482-4461",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Talk to us info@arcroofing.com.au",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": null,
                        "secondary_topic": [
                            {
                                "h_title": "Location",
                                "main_title": "Location",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Neerim Road, Castle Cove NSW",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Architect",
                                "main_title": "Location",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Builder",
                                "main_title": "Location",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Callic construction",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Material",
                                "main_title": "Location",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "elZinc Slate / Ebano",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Material supplier",
                                "main_title": "Location",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fabricator",
                                "main_title": "Location",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "CASA Group",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fabrication details",
                                "main_title": "Location",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Double standing seam and interlocking panel system",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+0294824461"
                            ],
                            "emails": [
                                "info@arcroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}