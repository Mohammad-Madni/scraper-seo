{
    "id": "01191136-1132-0216-0000-089298f7ecec",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0166 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://yourlocalroofers.com.au/locations/willoughby/",
        "target": "yourlocalroofers.com.au",
        "start_url": "https://yourlocalroofers.com.au/locations/willoughby/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": false,
        "load_resources": false,
        "enable_browser_rendering": false,
        "enable_xhr": false,
        "disable_cookie_popup": false,
        "browser_preset": "desktop",
        "tag": "parsed_content_markdowns\\Castle-Cove\\organic\\type-organic_rg8_ra12_yourlocalroofers.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 07:37:00 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Professional Roofing Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Australia's trusted roofing specialists. We provide comprehensive roofing solutions with professional excellence.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Rain warranty coverage is provided on eligible leak repairs following acceptance of our quote and commencement of works.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2026 YourLocalRoofers.com.au. All rights reserved.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Licensed \u2022 Insured \u2022 Bonded | NSW Builder Licence No. 393687C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Get a Quote Get a Quote",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email Us Email Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Call Us Now Call Us Now",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://yourlocalroofers.com.au/services/roof-replacement",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/roof-replacement",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://yourlocalroofers.com.au/services/roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/roof-restoration",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Repairs",
                                    "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                            "anchor_text": "Emergency Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://yourlocalroofers.com.au/about-us",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/about-us",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://yourlocalroofers.com.au/terms-and-conditions",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/terms-and-conditions",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://yourlocalroofers.com.au/privacy-policy",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/privacy-policy",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Emergency Service",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email inquiries",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "NSW & ACT",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Licence No. 393687C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday to Sunday",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "24 hour service",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roofing Services Willoughby",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Professional, reliable and local roofers serving Willoughby and North Shore. Specialising in Federation home restoration, established family property maintenance, traditional character roofing and heritage-appropriate solutions across Willoughby's leafy, established streets.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "+16 years of experience",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Your Local Roofers in Willoughby?",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We are a local, experienced roofing team delivering reliable workmanship across Willoughby and North Shore. From Federation home restoration to established family property maintenance, we complete projects with respect for architectural character and community stability.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Federation & Heritage Specialists",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We excel in Willoughby's heritage housing - Federation homes, Victorian terraces, California Bungalows and established properties requiring sympathetic restoration and character-appropriate roofing solutions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Established Suburb Understanding",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Experienced in Willoughby's established environment - leafy streets, mature trees, community stability, good schools proximity and respectful approach to long-term residents and family neighbourhoods.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Traditional Quality Craftsmanship",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Delivering heritage-appropriate materials and traditional workmanship meeting the quality expectations of Willoughby's family-oriented community and property-proud established residents.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted Willoughby North Shore Roofers",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From Federation home restoration and preventative maintenance to detailed heritage inspections and sympathetic replacements, our Willoughby roofing team delivers dependable solutions across North Shore's most established family suburb including Castle Cove, Castlecrag, Middle Cove and surrounding areas. We understand heritage considerations, established character, good schools proximity and the quality standards expected in Willoughby 2068.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our Willoughby roofing services cover heritage terracotta tile restoration, slate work, traditional metal roofing, Federation-appropriate flashing, valley maintenance, ridge repointing, period guttering systems and council-compliant heritage re-roofing. Every project includes respectful site management, photo reporting, character-appropriate materials and warranty-backed workmanship meeting North Shore established family home standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Choose Willoughby's trusted roofers for respectful heritage service, transparent pricing and craftsmanship that protects your Federation home or established family property and preserves the traditional character of this cherished community for years to come.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professional Willoughby North Shore Roofing Experts",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our Willoughby roofing specialists combine decades of local experience with heritage restoration expertise and traditional materials. From Federation homes requiring careful character preservation to established family residences needing quality installations, we deliver tailored roofing services respecting the traditional architectural character of North Shore's most stable family suburb.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether you need emergency repairs, heritage-appropriate maintenance, or complete sympathetic roof replacement for your Federation home or established family property, our certified team provides comprehensive solutions with community-respectful service, transparent pricing and industry-leading warranties that protect your Willoughby investment.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Trust our local Willoughby knowledge and proven North Shore heritage expertise to deliver roofing solutions that preserve Federation character, withstand weather exposure and exceed Australian building standards for family-oriented established homeowners.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "+500 projects completed",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roofing Services",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Expert roofing craftsmanship meets superior construction quality. Every roofing project is custom-designed to protect your property and enhance its value and functionality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Not Sure Which Option is Right for You?",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roofing specialists will assess your property and recommend the perfect roofing solution that matches your style preferences, budget, and functional requirements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Services Across Upper North Shore",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Professional roofing services throughout the Upper North Shore. From emergency leak response to planned maintenance and restorations, we keep roofs watertight in this leafy, established region.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Chatswood & Willoughby",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing services for residential and commercial properties in established North Shore suburbs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Chatswood, Willoughby, St Ives",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Key Suburbs:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pymble & Gordon",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Professional roofing solutions for leafy residential areas and heritage properties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Pymble, Gordon, Killara, Turramurra",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Key Suburbs:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Lindfield & Roseville",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Experienced team handling roof repairs and restorations in prestigious Upper North Shore suburbs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lindfield, Roseville, East Killara",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Key Suburbs:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Wahroonga & Hornsby",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Reliable roofing services for family homes and established communities across the Upper North Shore.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Wahroonga, Warrawee, Hornsby, Asquith, Normanhurst",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Key Suburbs:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get a Free Quote in Your Area",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "No matter where you are in the Upper North Shore, our team is ready to repair and protect your roof. Contact us today for a free consultation and local quote.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Loved by +1000 home and business owners",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Discover why our clients trust us for their roofing projects.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fantastic job and really professional experience from the first enquiry. Rapan the leader on site was amazing. Wouldn't hesitate to recommend this company! Awesome.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I found your local roofers to be fantastic. They demolished the old roof and put the new roof up 2 days before Xmas. I now have a roof that does not leak onto my deck. We are so happy with their service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are very glad we chose Your Local Roofers for the reroofing of our home. It was a huge thing for us and they kept us in the loop all the way. A great experience from start to finish. Would recommend them to anyone.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thankyou to Your Local Roofers for your excellence of service in repairing our roof & solving our water problem. Shout out to your professional staff skilled & experienced roofer Lachlan & Admin Alex who were helpful & courteous.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If we could give Luke Durazza more than a five star rating we would!!! Such a professional, courteous and thoughtful person. Luke's knowledge and workmanship are top notch and so greatly appreciated.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We had water cascading from the gutter onto our deck when it rained. We would like to thank the team at Your Local Roofers for doing a very good job in replacing the roof and fixing the guttering.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Adam and his roofing team absolutely astounded me with the quality of service, speed and professional finish of our complete roof replacement. The quoted price was competitive and they were packed up, cleaned up with some long days to complete 2 days prior to their scheduled finish.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We had a great experience with this roofing company. Their team was friendly, efficient and professional. We love the results of the newly painted roof and feel secure with all of the repair work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What a great a team, they have completed my workshop roof in 1 week and the difference is mind blowing. The team are on point from start to finish. A job well done \ud83d\udc4d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Julian Barton",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "12 May 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bruce Dunlop",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 February 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "John Hardaker",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24 May 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Julian Barton",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "12 May 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bruce Dunlop",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 February 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "John Hardaker",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24 May 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ange L",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "9 August 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Susie Molloy",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "12 July 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mark Read",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "11 May 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ange L",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "9 August 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Susie Molloy",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "12 July 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mark Read",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "11 May 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Richard Aurisch",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 November 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lesley Paredes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "15 January 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mark Dyball",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "15 April 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Richard Aurisch",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 November 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lesley Paredes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "15 January 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mark Dyball",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "15 April 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Need Reliable Roofers? Get a Free Quote Today",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From urgent make-safes to scheduled remedial works, we deliver clear scopes, photo documentation and workmanship warranties, keeping your operations safe and minimising downtime.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Our Focus:",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Federation home expertise",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Victorian terrace specialists",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "California Bungalow knowledge",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Heritage restoration focus",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Character-appropriate solutions",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Focus:",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Leafy street access expertise",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Mature tree protection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Community-stable approach",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "School zone awareness",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Long-term resident respect",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Focus:",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Long-term property care",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Heritage-appropriate materials",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Traditional workmanship standards",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Family-focused approach",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Established community respect",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "24/7 Emergency Repairs & Make Safes",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "24/7 Emergency Repairs & Make Safes",
                                        "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                                "anchor_text": "24/7 Emergency Repairs & Make Safes"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "24/7 emergency roofing services when you need them most. Our rapid response team provides immediate repairs and make-safe solutions to protect your property from further damage.",
                                        "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                                "anchor_text": "24/7 emergency roofing services when you need them most. Our rapid response team provides immediate repairs and make-safe solutions to protect your property from further damage."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Professional roof repair services for all types of roofing materials. From minor fixes to major structural repairs, we ensure your roof is restored to optimal condition.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                                "anchor_text": "Professional roof repair services for all types of roofing materials. From minor fixes to major structural repairs, we ensure your roof is restored to optimal condition."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://yourlocalroofers.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Complete roof restoration services to extend your roof's lifespan. Our comprehensive approach includes cleaning, repairs, and protective treatments for lasting results.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-restoration/",
                                                "anchor_text": "Complete roof restoration services to extend your roof's lifespan. Our comprehensive approach includes cleaning, repairs, and protective treatments for lasting results."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://yourlocalroofers.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Complete roof replacement services for when repairs aren't enough. We install brand new roofing systems with premium materials and expert craftsmanship for long-term protection.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-replacement/",
                                                "anchor_text": "Complete roof replacement services for when repairs aren't enough. We install brand new roofing systems with premium materials and expert craftsmanship for long-term protection."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing & Flashings",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing & Flashings",
                                        "url": "https://yourlocalroofers.com.au/services/metal-roofing-flashings/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/metal-roofing-flashings/",
                                                "anchor_text": "Metal Roofing & Flashings"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Expert installation and repair of metal roofing systems and flashings. Durable, weather-resistant solutions that provide long-lasting protection for your property.",
                                        "url": "https://yourlocalroofers.com.au/services/metal-roofing-flashings/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/metal-roofing-flashings/",
                                                "anchor_text": "Expert installation and repair of metal roofing systems and flashings. Durable, weather-resistant solutions that provide long-lasting protection for your property."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://yourlocalroofers.com.au/services/roof-painting",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-painting",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Professional roof painting services to transform and protect your roof. High-quality paints and expert application techniques ensure lasting beauty and weather protection.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-painting",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-painting",
                                                "anchor_text": "Professional roof painting services to transform and protect your roof. High-quality paints and expert application techniques ensure lasting beauty and weather protection."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Cleaning",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Scheduled gutter cleaning to prevent blockages, water ingress and foundation damage. Includes debris removal and flow testing.",
                                        "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                                "anchor_text": "Scheduled gutter cleaning to prevent blockages, water ingress and foundation damage. Includes debris removal and flow testing."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Pergolas & Patios",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Pergolas & Patios",
                                        "url": "https://yourlocalroofers.com.au/services/metal-pergolas-patios",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/metal-pergolas-patios",
                                                "anchor_text": "Metal Pergolas & Patios"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Custom-designed metal pergolas and patios that integrate with your roofing system for shade, durability and style.",
                                        "url": "https://yourlocalroofers.com.au/services/metal-pergolas-patios",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/metal-pergolas-patios",
                                                "anchor_text": "Custom-designed metal pergolas and patios that integrate with your roofing system for shade, durability and style."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Restoration & Remediation",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Restoration & Remediation",
                                        "url": "https://yourlocalroofers.com.au/services/restoration-remediation",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/restoration-remediation",
                                                "anchor_text": "Restoration & Remediation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Holistic restoration and remediation to address underlying roof issues, structural defects and water ingress long-term.",
                                        "url": "https://yourlocalroofers.com.au/services/restoration-remediation",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/restoration-remediation",
                                                "anchor_text": "Holistic restoration and remediation to address underlying roof issues, structural defects and water ingress long-term."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ridge Capping Restoration",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Ridge Capping Restoration",
                                        "url": "https://yourlocalroofers.com.au/services/ridge-capping-restoration",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/ridge-capping-restoration",
                                                "anchor_text": "Ridge Capping Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Re-bedding and re-pointing ridge caps with flexible compounds to seal joints, prevent leaks and improve appearance.",
                                        "url": "https://yourlocalroofers.com.au/services/ridge-capping-restoration",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/ridge-capping-restoration",
                                                "anchor_text": "Re-bedding and re-pointing ridge caps with flexible compounds to seal joints, prevent leaks and improve appearance."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak Detection & Repair",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leak Detection & Repair",
                                        "url": "https://yourlocalroofers.com.au/services/roof-leak",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-leak",
                                                "anchor_text": "Roof Leak Detection & Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rapid roof leak detection and permanent repairs using diagnostics, moisture tracing and targeted remediation.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-leak",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-leak",
                                                "anchor_text": "Rapid roof leak detection and permanent repairs using diagnostics, moisture tracing and targeted remediation."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Maintenance",
                                        "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                                "anchor_text": "Roof Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Proactive maintenance programs with scheduled inspections, cleaning and minor repairs to extend roof life and reduce costs.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                                "anchor_text": "Proactive maintenance programs with scheduled inspections, cleaning and minor repairs to extend roof life and reduce costs."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Safety Roof Anchors",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Safety Roof Anchors",
                                        "url": "https://yourlocalroofers.com.au/services/safety-roof-anchors",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/safety-roof-anchors",
                                                "anchor_text": "Safety Roof Anchors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Design and installation of compliant roof anchor systems and fall-arrest points for safe rooftop access.",
                                        "url": "https://yourlocalroofers.com.au/services/safety-roof-anchors",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/safety-roof-anchors",
                                                "anchor_text": "Design and installation of compliant roof anchor systems and fall-arrest points for safe rooftop access."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Repointing",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Repointing",
                                        "url": "https://yourlocalroofers.com.au/services/what-is-the-point-of-repointing",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/what-is-the-point-of-repointing",
                                                "anchor_text": "Repointing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Flexible repointing compounds applied to ridge and hip cappings to reseal joints and prevent water ingress.",
                                        "url": "https://yourlocalroofers.com.au/services/what-is-the-point-of-repointing",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/what-is-the-point-of-repointing",
                                                "anchor_text": "Flexible repointing compounds applied to ridge and hip cappings to reseal joints and prevent water ingress."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted by over +1000 happy clients",
                                "main_title": "Roofing Services Willoughby",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61-2-5300-4047",
                                "0253004047",
                                "(02) 5300 4047"
                            ],
                            "emails": [
                                "customersupport@yourlocalroofers.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}