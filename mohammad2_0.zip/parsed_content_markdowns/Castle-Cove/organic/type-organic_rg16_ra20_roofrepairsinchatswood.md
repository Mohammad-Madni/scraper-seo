{
    "id": "01190728-1132-0216-0000-a37dea547e48",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0268 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrepairsinchatswood.com.au/in/castle-cove/",
        "target": "roofrepairsinchatswood.com.au",
        "start_url": "https://roofrepairsinchatswood.com.au/in/castle-cove/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castle-Cove\\organic\\type-organic_rg16_ra20_roofrepairsinchatswood.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:44 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsinchatswood.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsinchatswood.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsinchatswood.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsinchatswood.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsinchatswood.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsinchatswood.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsinchatswood.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsinchatswood.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsinchatswood.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsinchatswood.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsinchatswood.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsinchatswood.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsinchatswood.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsinchatswood.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsinchatswood.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsinchatswood.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsinchatswood.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinchatswood.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "We Take Care Of Your Roof",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Castle Cove is a gorgeous city, and you are worthy of the very best roof for your house or business. However, severe weather can be harsh on your roof and trigger it to deteriorate with time. Whether you require a brand-new roof or repairs for an existing one, Roofing Today Castle Cove is here to help you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With years of experience in repair and installation, our team of certified specialists are professionals in getting the job done right the very first time. We offer a wide range of services to guarantee your roof is safe and protected. From minor repairs, such as changing tiles or fixing leakages, to more involved projects, like total replacements or re-roofing, our professionals will work with you to help determine the very best remedy for your home.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We understand the value of having a reliable and secure roof over your head, which is why we aim to provide quality workmanship and remarkable client service. Our team of knowledgeable specialists takes pride in their work and utilizes only the first-rate products for all our projects. We are also happy to talk about any unique demands or concerns you may have and provide practical recommendations throughout the process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter what type of roofing needs you have, Roofing Today Castle Cove is here to help. Contact our team today, and let us be the ones to fix your roof!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Colorbond roofing is a popular option for both domestic and industrial properties. Our group of knowledgeable specialists is trained in the installation of colorbond roofing and uses the first-rate products to guarantee your roof looks its finest.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing Contractors Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Whether you require a total replacement or repairs for an existing roof, our team of certified specialists can help. We understand that a small disturbance in company can be costly. We work around your schedule to reduce downtime, that includes weekends and/or nights if required.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing Contractors Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We understand that emergency situations can happen anytime and need quick action to reduce damage. Our team of knowledgeable specialists is readily available 24/7 to provide fast and reliable emergency roof repair services. From minor repairs to more substantial work, we can be relied on to finish the job right.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Emergency Roof Repairs Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Castle Cove Roof and Gutter",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Routine maintenance of your roof and gutter is essential in ensuring that it remains in good condition. Our team of experienced specialists offers numerous services, such as cleaning and repairs, to keep your gutters working appropriately and help lengthen the life of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Castle Cove Roof and Gutter",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Castle Cove Roof and Gutter"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Let our team of certified specialists help you examine the condition of your roof. We\u2019ll provide an extensive inspection to diagnose roof problems and precisely recommend economical remedies. We provide a comprehensive report of our findings, which can then be used to prepare any essential repairs or replacements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Inspections Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Roof Repairs Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Don\u2019t let a little leak become a larger problem. We use the most recent leak detection methods to diagnose and repair any problems properly. They include water tests, thermal imaging, and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Leaking Roof Repairs Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of qualified specialists is can install all roofing materials, including metal roofs, slate roofs, solar roofs, tile roofs, and more. we believe in quality workmanship and use only the first-rate products to guarantee your roof is strong and secure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Installation Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal roofs are becoming significantly popular due to their resilience, low maintenance, and energy efficiency. We deal with different type of metal roofing, from corrugated to standing seam, and several color alternatives. Furthermore, we can install soaker panels and other add-ons for a more customized look.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of knowledgeable specialists can provide a complete roof replacement service if your roof is beyond repair. We\u2019ll help you choose the ideal product, size, and shape to match your property and spending plan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Castle Cove Roof Restoration",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roofing Today Castle Cove, we believe in preserving existing structures wherever possible rather than changing them. We use the most recent products and methods to extend the life of your roof while being mindful of its historic worth and character.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Castle Cove Roof Restoration",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-restoration/",
                                                "anchor_text": "Castle Cove Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We offer numerous services for residential and industrial properties in Castle Cove, ranging from minor repairs to full-scale installations. Whether it\u2019s metal or tile roofs, skylights, or solar panels\u2013 our knowledgeable team will provide quality solutions that satisfy your needs and spending plan. We manage every little thing from start to finish and provide remarkable client service throughout the entire process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roofing/",
                                                "anchor_text": "Roofing Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Skylights Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Skylights are among the most popular attributes of a house, offering natural light and ventilation. Our team of certified specialists can install residential and office skylights, from standard systems to customized designs. We also provide repair options, including changing damaged seals and frames.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Skylights Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/skylights/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/skylights/",
                                                "anchor_text": "Skylights Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tilers Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Tiling is a specialized job that needs knowledge, skill, and experience\u2013 all of which our team has in abundance. We provide installation and repairs for slate, terracotta, metal, concrete tiles, and all types of roof devices.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Tilers Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Repairs Castle Cove",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Slate roofs are a popular option for heritage houses due to their long-lasting resilience and timeless look. We comprehend the value of preserving a structure\u2019s original character and can help you with all your slate roof repair needs. Our knowledgeable specialists use only the first-rate products to restore your roof to its previous splendor.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Slate Roof Repairs Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Castle Cove\u200b",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We understand that some Castle Cove homeowners may not have the ability to afford a roof repair or installation. Considering that our desire is to help everybody, we provide a unique discount program for qualified Castle Cove homeowners. With our Castle Cove Discount Roof Repair program, you can get the repairs or installations you require at a lower expense.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019re proud to be part of the Castle Cove community and do all we can to help our neighbors. It doesn\u2019t matter if you require a basic repair or a complete roof replacement; our knowledgeable specialists are here to help.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our 100% satisfaction guarantee backs every job we do. We stand behind all of our work and will not rest till you\u2019re totally happy with the results. From when you first call us to when we finish the job, you can rely on our team for remarkable service and workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A reliable and secure roof is one of the most essential financial investments in your life. That\u2019s why when it concerns repair or installation, you can rely on the specialists at Roofing Today Castle Cove for quality service and workmanship.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We proudly serve: Roseville Chase, North Willoughby, Middle Cove, Willoughby East, Chatswood, Killarney Heights, Willoughby, Roseville, Castlecrag, East Lindfield and Castle Cove",
                                        "url": "https://roofrepairsinchatswood.com.au/in/roseville-chase/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/in/roseville-chase/",
                                                "anchor_text": "Roseville Chase"
                                            },
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/in/north-willoughby/",
                                                "anchor_text": "North Willoughby"
                                            },
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/in/middle-cove/",
                                                "anchor_text": "Middle Cove"
                                            },
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/in/willoughby-east/",
                                                "anchor_text": "Willoughby East"
                                            },
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/in/chatswood/",
                                                "anchor_text": "Chatswood"
                                            },
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/in/killarney-heights/",
                                                "anchor_text": "Killarney Heights"
                                            },
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/in/willoughby/",
                                                "anchor_text": "Willoughby"
                                            },
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/in/roseville/",
                                                "anchor_text": "Roseville"
                                            },
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/in/castlecrag/",
                                                "anchor_text": "Castlecrag"
                                            },
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/in/east-lindfield/",
                                                "anchor_text": "East Lindfield"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Castle Cove\u200b",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We at Roofing Today Castle Cove are the roof experts! We can fix any type of roof from flat roofs to gabled roofs and everything in between. Contact us today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Are You Waiting For?",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A reliable and secure roof is one of the most important investments in your life. That\u2019s why when it comes to repair or installation, you can count on the professionals at Roofing Today Castle Cove for quality service and workmanship. Call us now!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Castle Cove\u200b",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Talk to us today about roofing services for your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "GET IN TOUCH",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repairs Castle Cove Services",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What we offer",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We provide a wide range of services, consisting of:",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Castle Cove Discount Roof Repair",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Castle Cove, New South Wales",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "For more information about Castle Cove, New South Wales",
                                        "url": "https://en.wikipedia.org/wiki/Castle%20Cove,_New%20South%20Wales",
                                        "urls": [
                                            {
                                                "url": "https://en.wikipedia.org/wiki/Castle%20Cove,_New%20South%20Wales",
                                                "anchor_text": "For more information about Castle Cove, New South Wales"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Google News:",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Latest Castle Cove News",
                                        "url": "https://news.google.com/search?q=Castle%20Cove,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                        "urls": [
                                            {
                                                "url": "https://news.google.com/search?q=Castle%20Cove,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                                "anchor_text": "Latest Castle Cove News"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Links",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Us",
                                        "url": "https://roofrepairsinchatswood.com.au/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/about-us/",
                                                "anchor_text": "About Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our Services",
                                        "url": "https://roofrepairsinchatswood.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/",
                                                "anchor_text": "Our Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing",
                                        "url": "https://roofrepairsinchatswood.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roofing Contractors",
                                        "url": "https://roofrepairsinchatswood.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": "https://roofrepairsinchatswood.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof and Gutter",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Roof and Gutter"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof Repairs",
                                        "url": "https://roofrepairsinchatswood.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://roofrepairsinchatswood.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tilers",
                                        "url": "https://roofrepairsinchatswood.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slate Roof Repairs",
                                        "url": "https://roofrepairsinchatswood.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Info",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Email Us",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "[email\u00a0protected]",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "[email\u00a0protected]",
                                        "url": "https://roofrepairsinchatswood.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "\u00a9 2022 Roofing Today Chatswood",
                                "main_title": "Roof Repairs Castle Cove\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "\u00a9 2022 Roofing Today Chatswood",
                                        "url": "https://roofrepairsinchatswood.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/",
                                                "anchor_text": "Roofing Today Chatswood"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://roofrepairsinchatswood.com.au/privacy-policy/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/privacy-policy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms & Conditions",
                                        "url": "https://roofrepairsinchatswood.com.au/terms-and-conditions/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinchatswood.com.au/terms-and-conditions/",
                                                "anchor_text": "Terms & Conditions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 8403 0126",
                                "(02)%208403%200126"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}