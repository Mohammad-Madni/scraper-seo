{
    "id": "01190728-1132-0216-0000-018d860ca8ed",
    "status_code": 40602,
    "status_message": "Task In Queue.",
    "time": "0.0032 sec.",
    "cost": 0,
    "result_count": 0,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://kangaroof.com.au/roof-repair-services-in-castle-cove/",
        "target": "kangaroof.com.au",
        "start_url": "https://kangaroof.com.au/roof-repair-services-in-castle-cove/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castle-Cove\\organic\\type-organic_rg11_ra15_kangaroof.md"
    },
    "result": null
}