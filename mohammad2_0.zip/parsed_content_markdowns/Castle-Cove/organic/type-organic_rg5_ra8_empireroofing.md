{
    "id": "01190728-1132-0216-0000-4af772f7367c",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0173 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://empireroofing.com.au/locations/castle-cove-roofing-services",
        "target": "empireroofing.com.au",
        "start_url": "https://empireroofing.com.au/locations/castle-cove-roofing-services",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castle-Cove\\organic\\type-organic_rg5_ra8_empireroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:43 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Sydney's trusted roofing specialists with over 30 years of excellence. Quality craftsmanship and customer satisfaction guaranteed.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "$20M Public Liability Coverage",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Call Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "0414 854 307",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://empireroofing.com.au/services/roof-restoration-sydney",
                                    "urls": [
                                        {
                                            "url": "https://empireroofing.com.au/services/roof-restoration-sydney",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://empireroofing.com.au/services/roof-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://empireroofing.com.au/services/roof-repairs-sydney",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://empireroofing.com.au/services/roof-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://empireroofing.com.au/services/roof-cleaning-sydney",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://empireroofing.com.au/services/roof-painting-sydney",
                                    "urls": [
                                        {
                                            "url": "https://empireroofing.com.au/services/roof-painting-sydney",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://empireroofing.com.au/services/colorbond-roofing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://empireroofing.com.au/services/colorbond-roofing-sydney",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://empireroofing.com.au/about",
                                    "urls": [
                                        {
                                            "url": "https://empireroofing.com.au/about",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://empireroofing.com.au/locations",
                                    "urls": [
                                        {
                                            "url": "https://empireroofing.com.au/locations",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://empireroofing.com.au/contact",
                                    "urls": [
                                        {
                                            "url": "https://empireroofing.com.au/contact",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "ABN: 30 169 797 004",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Professional Roofing Services Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Comprehensive roofing solutions for Castle Cove residents. From restoration to repairs, we're your local roofing specialists with over 30 years of experience.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our Services in Castle Cove :",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Your Trusted Roofing Specialists in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Serving the Castle Cove community for over 30 years, Empire Roofing is your trusted local expert for all roofing needs. We understand the unique challenges faced by properties in Castle Cove and provide tailored solutions for every home.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our comprehensive roofing services are specifically designed for Castle Cove 's climate and the diverse architectural styles found throughout the area. Whether you need emergency repairs, routine maintenance, or a complete roof transformation, our experienced team delivers exceptional results with lasting quality.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Years serving Castle Cove",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Same Day",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Emergency Response",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Area Experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Roofing Services for Your Home",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From heritage homes to modern properties, we provide comprehensive roofing solutions for all Castle Cove residents",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our comprehensive roof restoration services in Castle Cove bring your roof back to life, extending its lifespan by 10-15 years and dramatically improving your property's value and kerb appeal.",
                                        "url": "https://empireroofing.com.au/services/roof-restoration-sydney",
                                        "urls": [
                                            {
                                                "url": "https://empireroofing.com.au/services/roof-restoration-sydney",
                                                "anchor_text": "roof restoration services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Why Choose Us in Castle Cove ?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We've completed hundreds of successful roof restorations throughout Castle Cove, with deep knowledge of local architectural styles and weather conditions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Fast, reliable roof repair services for Castle Cove homes. From emergency leak repairs to storm damage, we provide same-day service with lasting solutions.",
                                        "url": "https://empireroofing.com.au/services/roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://empireroofing.com.au/services/roof-repairs-sydney",
                                                "anchor_text": "roof repair services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Need urgent repairs in Castle Cove ? Call us at 0414 854 307 for same-day emergency assistance during business hours.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Emergency Service Available",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Professional high-pressure roof cleaning services that remove years of moss, algae, and debris, restoring your roof's appearance and preventing long-term damage.",
                                        "url": "https://empireroofing.com.au/services/roof-cleaning-sydney",
                                        "urls": [
                                            {
                                                "url": "https://empireroofing.com.au/services/roof-cleaning-sydney",
                                                "anchor_text": "high-pressure roof cleaning services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For Castle Cove properties, we recommend roof cleaning every 12-18 months to maintain optimal condition.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Recommended Frequency",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Transform your Castle Cove home with our premium roof painting services. Using Australian-made paints with heat-reflective technology for lasting protection and stunning results.",
                                        "url": "https://empireroofing.com.au/services/roof-painting-sydney",
                                        "urls": [
                                            {
                                                "url": "https://empireroofing.com.au/services/roof-painting-sydney",
                                                "anchor_text": "roof painting services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Choose from a wide range of colours to complement your Castle Cove property's style and architecture.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Free Colour Consultation",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Modern Colorbond steel roofing installations for Castle Cove homes. Superior durability, energy efficiency, and style with Australia's most trusted roofing material.",
                                        "url": "https://empireroofing.com.au/services/colorbond-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://empireroofing.com.au/services/colorbond-roofing-sydney",
                                                "anchor_text": "Colorbond steel roofing installations"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our team specialises in Colorbond installations throughout Castle Cove with full warranty coverage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Expert Installation",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Local Area Knowledge",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Deep understanding of local weather impacts, building codes, and architectural styles found throughout the area",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Rapid Response Times",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Based locally, we provide fast response times for emergency repairs across the entire region",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Established Reputation",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Over 30 years serving local families with hundreds of successful projects and satisfied customers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Insurance Coverage",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Fully licensed and insured with comprehensive public liability and workers compensation coverage",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quality Guarantee",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "All work backed by comprehensive warranties and our commitment to exceptional craftsmanship",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Proudly Serving Castle Cove & Surrounding Areas",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our local expertise extends throughout the entire region and surrounding suburbs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Your Local Roofing Partner",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Based in Rydalmere, we're perfectly positioned to serve the local area with fast, reliable roofing services throughout the region.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions About Roofing in Castle Cove",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Get answers to common questions about our roofing services in your area",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof restoration cost in Castle Cove?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Roof restoration costs in Castle Cove typically range from $3,500 to $8,000 for an average-sized home, depending on the roof size, condition, and materials. This comprehensive service includes high-pressure cleaning, repairs, re-bedding, pointing, and premium coating. We provide free, detailed quotes with no obligation. The investment often adds significant value to your property and extends your roof's life by 10-15 years, making it more cost-effective than a full replacement.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long does a roof restoration take in Castle Cove?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Most roof restorations in Castle Cove take 3-5 days to complete, weather permitting. The timeline depends on your roof size and complexity. Day 1 involves thorough cleaning and assessment, Days 2-3 cover repairs and re-bedding, and Days 4-5 are for coating application and final touches. We work efficiently whilst maintaining our high-quality standards, and we'll provide an exact timeline during your free consultation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What does roof restoration include?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Our comprehensive roof restoration includes: complete high-pressure cleaning, tile/ridge cap re-bedding and pointing, valley and flashing repairs, crack and leak repairs, two coats of premium roof membrane, and final inspection. We use Australian-made materials with long warranties and ensure all work meets council requirements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long will a restored roof last?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "A professionally restored roof typically lasts 10-15 years before requiring another restoration, significantly extending the total lifespan of your roof. With proper maintenance (regular cleaning every 12-18 months), you can maximise this duration. Our premium coatings come with manufacturer warranties for your peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you offer emergency roof repairs in Castle Cove?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes! We provide same-day emergency roof repair services throughout Castle Cove and surrounding areas during business hours (Mon-Fri 7am-5pm, Sat 9am-5pm). Our typical response time is 2-4 hours for genuine emergencies like active leaks or storm damage. We'll arrive quickly to assess the situation, provide temporary protection to prevent further damage, and arrange permanent repairs. Call us immediately at 0414 854 307 if you need urgent assistance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much do roof repairs cost?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Roof repair costs vary depending on the extent of damage. Minor repairs (1-5 broken tiles) typically start from $300-$600, whilst more extensive repairs can range from $800-$2,500. Emergency call-outs may include an additional fee. We always provide upfront pricing before starting work, and we can work directly with your insurance company for storm damage claims.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you handle insurance claims for roof repairs?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Absolutely! We regularly work with all major insurance companies for storm damage and leak claims. We'll provide detailed documentation, photographs, and comprehensive quotes to support your claim. We can also work directly with your insurer to streamline the process and ensure you get fair coverage for necessary repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long do roof repairs take?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Most standard roof repairs are completed within 1-2 days. Minor repairs (replacing a few broken tiles) can often be done in a few hours. More extensive repairs involving structural work, valleys, or flashing may take 2-3 days. For emergency repairs, we provide immediate temporary protection and schedule permanent repairs as quickly as possible.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How often should I have my roof cleaned in Castle Cove?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "For properties in Castle Cove, we recommend professional roof cleaning every 12-18 months to maintain optimal condition. However, homes with heavy tree coverage or those in particularly humid areas may benefit from annual cleaning. Regular cleaning prevents moss and algae buildup, extends your roof's life, and maintains your property's kerb appeal. We can assess your specific situation and recommend the ideal cleaning schedule during our free inspection.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof cleaning cost?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Roof cleaning costs typically range from $800 to $2,000 depending on your roof size, pitch, and condition. This includes high-pressure cleaning, moss and algae treatment, gutter cleaning, and debris removal. We provide free quotes with transparent pricing and no hidden costs. Regular cleaning is a cost-effective way to prevent expensive repairs and extend your roof's life.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Is roof cleaning safe for my tiles?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes, when done by professionals! We use specialised equipment and techniques designed specifically for roof tiles. Our high-pressure settings are carefully calibrated to remove dirt, moss, and algae without damaging tiles or dislodging them. We also inspect for any loose or damaged tiles during the process and can repair them as needed. Our experienced team has cleaned thousands of roofs safely.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you use chemicals for roof cleaning?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We use eco-friendly, biodegradable cleaning solutions that are safe for your family, pets, and garden. Our moss and algae treatments are specifically formulated for roofs and are applied at the correct concentrations. They effectively kill organic growth without harming your tiles or the environment. We also offer chemical-free cleaning options using only high-pressure water if preferred.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof painting cost?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Roof painting costs typically range from $3,500 to $7,000 for an average home, depending on roof size, pitch, and the number of coats required. This includes surface preparation, primer, two coats of premium paint, and protective sealant. We use only Australian-made paints with 10+ year warranties. Our pricing is competitive and includes all labour, materials, and cleanup. We provide detailed written quotes with no hidden costs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long does roof paint last?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Quality roof paint applied by professionals typically lasts 10-15 years. We use premium Australian-made paints with advanced UV protection and weather resistance. The longevity depends on factors like paint quality, surface preparation, number of coats, and local weather conditions. Our paints come with manufacturer warranties, and we stand behind our workmanship with comprehensive guarantees.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Can I choose any colour for my roof?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes! We offer a wide range of colours to complement your home's style and architecture. Our colour consultation service helps you choose the perfect shade. We provide colour charts and can show you examples from recent projects. Popular choices include Terracotta, Slate Grey, Monument, and Surfmist. We also offer heat-reflective colours that can help reduce cooling costs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you need to clean the roof before painting?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Absolutely! Thorough cleaning and preparation is crucial for paint adhesion and longevity. Our roof painting service includes: high-pressure cleaning to remove all dirt, moss, and algae; repairs to any damaged tiles or cracks; primer application for better adhesion; and multiple coats of premium paint. Proper preparation ensures your painted roof looks great and lasts for years.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much does a Colorbond roof cost?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Colorbond roof installations typically range from $15,000 to $35,000+ depending on your roof size, pitch, and complexity. This includes removing the old roof, installing new Colorbond sheeting, flashings, ridge capping, and gutters. Whilst the initial investment is higher than tile repairs, Colorbond roofs last 50+ years with minimal maintenance, making them excellent long-term value. We provide detailed quotes breaking down all costs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long do Colorbond roofs last?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Colorbond roofs typically last 50+ years with minimal maintenance, significantly longer than traditional tile roofs (20-30 years). The steel material is incredibly durable, resistant to cracking, and handles extreme weather well. Colorbond comes with a manufacturer's warranty and requires very little upkeep - just occasional cleaning. Many Australian homes have had Colorbond roofs for decades with no issues.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Is Colorbond better than tiles?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Colorbond and tiles each have advantages. Colorbond offers: 50+ year lifespan, minimal maintenance, lighter weight, faster installation, and better bushfire resistance. Tiles offer: traditional aesthetic, good insulation, and established track record. For most modern homes, Colorbond is the superior choice due to its longevity and low maintenance. We can assess your specific needs and recommend the best option during a free consultation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What colours does Colorbond come in?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Colorbond is available in 22+ contemporary colours ranging from classic neutrals (Monument, Surfmist, Shale Grey) to bold statements (Wilderness, Terrain, Mangrove). We provide colour charts and can show examples from recent projects. Our team helps you select the perfect colour to complement your home's style whilst considering heat reflection properties for energy efficiency.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Still Have Questions?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our friendly team is here to help with any questions about roofing services in Castle Cove",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Customers Say",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\" From the quote to the completion of the job, the experience was fast and professional. I'm very happy with the job and will definitely use Empire Roofing again. \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" We had an excellent experience with Empire Roofing. They are very professional and thorough and very competitive on pricing. They went the extra mile. We are very happy with their work. \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Very impressed with the whole process. Couldn't be happier with the finish. Empire Roofing was helpful from start to finish and the quality of the work was just as we hoped it would be. April 2024 \"",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Erik Van Heinekeler",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Peter Bull",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ken Collins",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Repair",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ready to Improve Your Castle Cove Roof?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Get expert roofing services from your local specialists. Serving the community with pride.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "What's Included:",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Complete roof inspection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "High-pressure cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tile re-bedding & pointing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Valley & flashing repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium coating & sealing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Local Benefits:",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Perfect for older homes",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "30+ years local experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Weather-resistant coatings",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Council-approved work",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10-15 year extended life",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Common Repairs:",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof leak repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Broken tile replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Storm damage fixes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Valley & gutter repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flashing & capping work",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Promise:",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Same-day emergency response",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast response available",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rapid arrival times",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Insurance work accepted",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality workmanship",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Cleaning Process:",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "High-pressure wash",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Moss & algae treatment",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Debris removal",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Final inspection",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Benefits:",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Eco-friendly solutions",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Extends roof life",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Improves appearance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Prevents water damage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cost-effective maintenance",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Process:",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Surface preparation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Primer application",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Two premium coats",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Protective sealant",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10+ year warranty",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Premium Features:",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heat-reflective coating",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "UV protection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Colour consultation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Australian-made paints",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Key Advantages:",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "50+ year lifespan",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bushfire resistant",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Low maintenance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Energy efficient",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lightweight & strong",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Perfect For:",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "New constructions",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof replacements",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Extensions & pergolas",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Commercial buildings",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All property types",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Empire Roofing for Your Property?",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Questions",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Questions",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning Questions",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting Questions",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing Questions",
                                "main_title": "Professional Roofing Services Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0414854307",
                                "0414 854 307"
                            ],
                            "emails": [
                                "info@empireroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}