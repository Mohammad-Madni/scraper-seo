{
    "id": "01190728-1132-0216-0000-f538177cc1c9",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0401 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.oneflare.com.au/roofing/nsw/castle-cove",
        "target": "www.oneflare.com.au",
        "start_url": "https://www.oneflare.com.au/roofing/nsw/castle-cove",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castle-Cove\\organic\\type-organic_rg15_ra19_oneflare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:44 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Best roofing experts in Castle Cove",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Post a job now to get quotes from local roofing experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Castle Cove",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average rating of roofing experts in Castle Cove based on 221 reviews of 22 businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oneflare /",
                                        "url": "https://www.oneflare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/",
                                                "anchor_text": "Oneflare"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Categories /",
                                        "url": "https://www.oneflare.com.au/directory",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/directory",
                                                "anchor_text": "Categories"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.oneflare.com.au/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NSW /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw",
                                                "anchor_text": "NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                                "anchor_text": "Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Northside Master Plumbing",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Narrabeen, NSW (11.1km from Narrabeen)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Northside Master Plumbing can provide you with all aspects of plumbing services ranging from domestic maintenance through to industrial and commercial fit-outs. We also offer remedial building works and complete electrical services.\nWe are a family owned and operated company with over 35 years experience in the plumbing industry. We employ Licensed NSW Plumbers and Electricians, and our employees also hold current White Cards (formerly Green Cards) and Confined Spaces Accreditation.\nWe comply with Australian Occupational Health & Safety regulations and will provide Safe Work Method Statements / JSA on all contracts as required.\nNorthside Master Plumbing holds all relevant insurances including:\nPublic Liability\nProduct Liability\nWorkers Compensation\nAt Northside Master Plumbing we take pride in the knowledge that our",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Northside Master Plumbing",
                                        "url": "https://www.oneflare.com.au/b/collaroy-plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/collaroy-plumbing",
                                                "anchor_text": "Northside Master Plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "My List Pty Ltd",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Manly, NSW (7.4km from Manly)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mylist is a Home Improvement and Property Maintenance company,\nMylist specializes in a vast range of services. We cover from Building and Carpentry projects, Renovations, Maintenance, Rubbish Removal, Garden Maintenance, Cleaning, Painting, Plastering and more.\nWe also offer monthly maintenance and cleaning upkeep services.\nPlease feel free to get in touch.\nWEB: www.mylist.net.au\nABN : 86630313343\nLIC : 299935C\nFB: Mylist",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "My List Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/marvel-modifications",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/marvel-modifications",
                                                "anchor_text": "My List Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofix Group Sydney",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Chatswood, NSW (3.3km from Chatswood)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Haus Property Maintenance Sydney, we provide a broad range of efficient and affordable property maintenance solutions. The dedicated and trained staff at our business have years of experience in the industry so you can be rest assured of the highest level of service. At Haus Property Maintenance, the requests of the clients are the most important thing as we can gauge your issues whether they are interior or exterior property maintenance concerns. Quality over quantity is our fundamental purpose in our line of handyman services\nHere at Haus, all property maintenance projects are carried out with utmost care and with minimum disruption. Our aim is to make it easy for businesses to spend their time and effort working on",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofix Group Sydney",
                                        "url": "https://www.oneflare.com.au/b/roofix-group-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roofix-group-sydney",
                                                "anchor_text": "Roofix Group Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Contracting Engineers pty ltd Verified Business",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Artarmon, NSW (4.7km from Artarmon)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney Contracting Engineers Pty Ltd (SCE Corp) holds extensive certifications, credentials, and verifications that confirm its standing as a trusted, ISO certified construction company in New South Wales and the Australian Capital Territory. As a DBP certified organisation, SCE Corp maintains compliance with state and federal standards across both building and civil divisions.\nSCE Corp certifications and verifications include ISO 9001:2015 for Quality Management, ISO 14001:2015 for Environmental Management, and ISO 45001:2018 for Occupational Health and Safety. These credentials are issued by Global Compliance Certification Pty Ltd, accredited by JAS-ANZ, ensuring independent oversight of all construction operations.\nSydney Contracting Engineers credentials and compliance systems are reinforced by its active registrations with NSW Fair Trading and Service NSW, Master Builders Association",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney Contracting Engineers pty ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/sydney-contracting-engineers",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/sydney-contracting-engineers",
                                                "anchor_text": "Sydney Contracting Engineers pty ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "McBride Roofing",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "North Ryde, NSW (8.3km from North Ryde)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "McBride Roofing, your local roofing specialists.\nServicing the North Shore and surrounding areas\nWe often get asked about the best long-term solution for a new roof, especially with our tough Australian weather. Our answer is almost always metal roofing, and specifically, Colorbond!\n\u2022 \ud83d\udee1\ufe0f Superior Durability: Metal roofs, like the Colorbond we use, are built to withstand heavy rain, strong winds, and even hail better than traditional materials. They are a 50+ year investment.\n\u2022 \ud83d\udca1 Energy Efficiency: Colorbond\u00ae features Thermatech\u00ae solar reflective technology, which can help keep your home cooler in summer, potentially reducing your energy bills.\n\u2022 \ud83d\udca7 Watertight & Low Maintenance: Say goodbye to brittle tiles and constant repairs. Metal provides a sleek, seamless barrier.\nYes, the",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "McBride Roofing",
                                        "url": "https://www.oneflare.com.au/b/mcbride-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/mcbride-roofing",
                                                "anchor_text": "McBride Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "D2plumbing",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Hunters Hill, NSW (8.1km from Hunters Hill)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "D2plumbing are a friendly fair priced company and are fully licenced and insured.\nwe are trained in all types of plumbing.\nTo see more about us check out our website on www.d2plumbing.com.au",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "D2plumbing",
                                        "url": "https://www.oneflare.com.au/b/d2plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/d2plumbing",
                                                "anchor_text": "D2plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "J.P. Roofing Solutions Pty Ltd",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Mosman, NSW (5.5km from Mosman)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We specialise in all types of roofing services, including new roof installations, roof replacements, restoration, painting, roof repairs, and maintenance etc. We use only the highest quality materials and equipment to ensure that every job is completed to the highest standards. If you're looking for a reliable and professional roofing company, look no further. Contact us today to schedule a consultation and let us help you with all your roofing needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "J.P. Roofing Solutions Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/j-p-roofing-solutions-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/j-p-roofing-solutions-pty-ltd",
                                                "anchor_text": "J.P. Roofing Solutions Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ozroof Roof Repairs & Restorations",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (9.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OZROOF specialise in Roof Restoration, Roof Repairs, Roof Painting, Metal Roofing and Guttering Replacement - Sydney Wide\nOZROOF Repairs & Restoration provide homeowners with high quality roofing services including roof restoration, roof repairs, roof painting, metal roofing and guttering replacement throughout Sydney and surrounding suburbs. Family owned and operated, we are dedicated to delivering exceptional quality to every task undertaken, regardless of the size of the project. All work is carried out by our own tradesmen and we certainly don't appoint flashy, commission based salesmen. This allows us to maintain lower overheads, in-turn keeping our prices affordable and competitive!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ozroof Roof Repairs & Restorations",
                                        "url": "https://www.oneflare.com.au/b/21st-roofing-guttering-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/21st-roofing-guttering-pty-ltd",
                                                "anchor_text": "Ozroof Roof Repairs & Restorations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Harbour City Remedial Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Balmain East, NSW (8.2km from Balmain East)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Harbour City Remedial / Baker Roofing we care about our customers and our workmanship. Like no other, we offer a quality guarantee with all our work. We have in house quality managers that inspect each project once complete to ensure the job is done right. We do all types of roofing works to the highest standard including but not limited to: - Tile Re-Roofs. - Metal Re-Roofs.\n- Tile & Metal Maintenance Works.\n- Guttering & Downpipe works.\n- New Metal & Tile works. - Tile Re-Bedding & Pointing. - Asbestos Removal. - Leaf Mesh. & Much much more. Please get in contact with us today if there's anything you require.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Harbour City Remedial Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/harbour-city-remedial-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/harbour-city-remedial-pty-ltd",
                                                "anchor_text": "Harbour City Remedial Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Dr leak plumbing",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (8.1km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Dr leak plumbing services is Fully Licensed and Insured with over 14 years experience In the plumbing field with the competitive pricing along with lifetime warranty on workmanship. We beat all quotes by 5% to 10% and also applying a 15% Pensioners discount and seniors.\nGive Dr Leak Plumbing a call on\n\ud83d\udee0 0409199799 to get your FREE QUOTE Based in Melbourne and Sydney. Family owned and operated",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Dr leak plumbing",
                                        "url": "https://www.oneflare.com.au/b/dr-leak-plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/dr-leak-plumbing",
                                                "anchor_text": "Dr leak plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Red House Roofing",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Rozelle, NSW (9.6km from Rozelle)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Red House Roofing are skilled, professional and extremely reliable providing the very best roofing services. Protect and Enhance your home and investment with Red House Roofing AWARD WINNING WORK - Rob Everett is a former winner of the Sydney Morning Herald tradesman of the year competition. At Red House Roofing we offer a complete roofing service from small repairs to major heritage re-roofing work. Backed by a team of experienced tradesmen our director is an award winning second generation roofer with over 25 years roofing experience. Red House Roofing is a Sydney based roofing company who has expertise in all types of roofing requirements. Some of the services we offer are repairs and leaks, re-roofing, slate roofing, metal roofing, copper",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Red House Roofing",
                                        "url": "https://www.oneflare.com.au/b/red-house-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/red-house-roofing",
                                                "anchor_text": "Red House Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fazwear Australia",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Wareemba, NSW (11.0km from Wareemba)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All aspects of roofing. Tile. Metal. Slate. Over 20 years experience. Family owned and operated. Servicing all of Sydney. Please call us for quote today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Fazwear Australia",
                                        "url": "https://www.oneflare.com.au/b/aus-roof-restorations-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/aus-roof-restorations-pty-ltd",
                                                "anchor_text": "Fazwear Australia"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Suburbs Roofing & Repairs Pty Ltd",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (8.9km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a 3rd generation family company serving all of Sydney with high quality roofing repairs and all aspects of roofing we do Roofing leak repairs Valley repairs Roof washing and painting Sarkimg & battens Chimney repairs Flexi pointing Possum removal Rebedding Gutter repairs We give free estimates true out Sydney same day estimate We are fully registered & insured",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Suburbs Roofing & Repairs Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/all-suburbs-roofing-repairs-pty-ltd-568",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-suburbs-roofing-repairs-pty-ltd-568",
                                                "anchor_text": "All Suburbs Roofing & Repairs Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Corp Gutter & Roof Restoration",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (9.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you need to extend the life of your roof? At Roofingcorpsydney.com.au, we offer the professional suggestions on all the roofing repairs and cleaning services. We offer the best roofing restorations & painting services in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Corp Gutter & Roof Restoration",
                                        "url": "https://www.oneflare.com.au/b/roofing-corp-gutter-roof-restoration",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roofing-corp-gutter-roof-restoration",
                                                "anchor_text": "Roofing Corp Gutter & Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Just Fascia & Gutter",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (9.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As a premier business specialising in residential and commercial roofing services, we are dedicated to providing customer service that is second to none. Whether you have a new construction project or need to replace an old or damaged fascia & gutter, roofing repair or replacement ,you\u2019ll be satisfied with us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Just Fascia & Gutter",
                                        "url": "https://www.oneflare.com.au/b/just-fascia-gutter",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/just-fascia-gutter",
                                                "anchor_text": "Just Fascia & Gutter"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Cain Sayers Roofing",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (9.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Straight to the point no short cuts quality trades work metal roofer that womt cost and arm and a leg",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Cain Sayers Roofing",
                                        "url": "https://www.oneflare.com.au/b/cain-sayers-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/cain-sayers-roofing",
                                                "anchor_text": "Cain Sayers Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Roof Gutter Repairs",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (9.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney Roof-Gutter Repairs over 20years of combined experience with peace of mind with trained contractors with many satisfied customers! We service all Sydney and nearby suburbs. We specialise in metal roofs and tile to metal reroofs and all aspects of metal roofing. Please visit our web site for more info or call 0422625879 to help with all inquiries!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney Roof Gutter Repairs",
                                        "url": "https://www.oneflare.com.au/b/sydney-roof-gutter-repairs",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/sydney-roof-gutter-repairs",
                                                "anchor_text": "Sydney Roof Gutter Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "MLR Slate Roofing Pty Ltd",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (9.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "MLR Slate roofing, specialises in traditional slate roofing, whether it's a small repair or a complete re-roof.\nAs a small business owner my aim is to provide and deliver top quality workmanship with a professional service.\nFor a no obligation quote please contact Matt",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "MLR Slate Roofing Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/mlr-slate-roofing-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/mlr-slate-roofing-pty-ltd",
                                                "anchor_text": "MLR Slate Roofing Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get the right price for your job",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Oneflare Cost Guide Centre is your one-stop shop to help you set your budget; from smaller tasks to larger projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Top Castle Cove roofing experts near you",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Browse top Roofing Expert experts with top ratings and reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best roofing experts in Castle Cove",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "View more roofing experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Truss costs",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Truss costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Roof Truss costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $9,000 - $15,000",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Average price $9,000 - $15,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof costs",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roof costs",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Colorbond Roof costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $15,000 - $25,000",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Average price $15,000 - $25,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling costs",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Roof Tiling costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $35 - $140 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Average price $35 - $140 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing costs",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing costs",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Roofing costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $45 - $90 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Average price $45 - $90 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse roofing experts by suburb",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular searches on Oneflare",
                                "main_title": "Best roofing experts in Castle Cove",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.8,
                                "max_rating_value": 5,
                                "rating_count": 221,
                                "relative_rating": 0.96
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}