{
    "id": "01190728-1132-0216-0000-c16f5fa301a7",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0250 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://kangarooroofrestorationthehills.com.au/",
        "target": "kangarooroofrestorationthehills.com.au",
        "start_url": "https://kangarooroofrestorationthehills.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castle-Cove\\organic\\type-organic_rg3_ra6_kangarooroofrestorationthehills.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:46 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://kangarooroofrestorationthehills.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Why Us",
                                    "url": "https://kangarooroofrestorationthehills.com.au/projects/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/projects/",
                                            "anchor_text": "Why Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://kangarooroofrestorationthehills.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://kangarooroofrestorationthehills.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://kangarooroofrestorationthehills.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Why Us",
                                    "url": "https://kangarooroofrestorationthehills.com.au/projects/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/projects/",
                                            "anchor_text": "Why Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://kangarooroofrestorationthehills.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Copyright \u00a9 2026 Kangaroo Roof Restoration The Hills",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Powered by Kangaroo Roof Restoration The Hills",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Kangaroo\u00a0Roof Restoration The Hills",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "P.O. Box 123 Castle Hill NSW 2154",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "0435 145 256",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://kangarooroofrestorationthehills.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Why Us",
                                    "url": "https://kangarooroofrestorationthehills.com.au/projects/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/projects/",
                                            "anchor_text": "Why Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://kangarooroofrestorationthehills.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Roofing Services",
                                    "url": "https://kangarooroofrestorationthehills.com.au/services/",
                                    "urls": [
                                        {
                                            "url": "https://kangarooroofrestorationthehills.com.au/services/",
                                            "anchor_text": "Our Roofing Services"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Kangaroo Roof Restoration The Hills",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "At Kangaroo Roof Restoration The Hills, we take pride in safeguarding your home with our top-notch roofing services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A strong and well-maintained roof is crucial to the integrity and longevity of your property, and we are here to ensure just that.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With years of experience in the industry, we offer a comprehensive range of roofing services to cater to all your needs. All household repairs and maintenance up to your satisfaction is guaranteed.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "P.O Box 123, Castle Hill NSW 2154",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Advice",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Thorough inspection of complete roof to assess the extent of damage and recommend the most suitable solution. This may include cleaning, repairs, re-pointing, and applying protective coatings to extend the lifespan of your roof and enhance its appearance to last for years!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Flexible Schedule",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Understanding that scheduling roof repairs can be disruptive to daily life, we offer flexible scheduling options to accommodate our customers' busy lives. We work with you to find appointment times that suit your schedule, whether it's early mornings, evenings, or weekends.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Workmanship Quality",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Meticulous attention to detail, using top-grade materials of Dulux premium brand for quality workmanship, proper preparation to ensure a durable, long-lasting, and aesthetically pleasing result that protects your property for years to come.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Affordable Cost",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Roof restoration can be a significant investment, but we strive to make it accessible to homeowners by offering competitive transparent pricing. We explore cost-effective solutions that meet your budget while ensuring the highest quality workmanship and long-lasting results.\nWe believe in providing upfront and honest pricing with no hidden costs, allowing you to make informed decisions about your roof restoration project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quality Professionals",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Team of Quality professionals, highly skilled and experienced individuals who possess a strong work ethics, a commitment to excellence, and a deep understanding of industry best practices. They prioritise customer satisfaction and consistently deliver exceptional results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Customer Satisfaction",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Customer satisfaction is our top priority. We are committed to providing exceptional service throughout the entire roof restoration and repairs process, from the initial consultation to the final inspection. We strive to exceed your expectations with meticulous attention to detail, clear communication, and a focus on building long-term relationships.\nWe value your feedback and are always looking for ways to improve our services. We believe that satisfied customers are our greatest advocates, and we work hard to earn your trust and loyalty.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Need A Free Quote?",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Welcome to call or message, Kangaroo Roof Restoration The Hills",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Your Roof Repairs and Restoration Services Provider",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Kangaroo Roof Restoration The Hills is a leading Hills Shire Council area\u2019s local roof repairs and maintenance company specialised in all types of roof, tiles and/or metal roof repairs, maintenance, high pressure cleaning, painting, roof leakage repairs/ damage, re-pointing and broken tiles replacements.",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our highly skilled team is customer focussed and customer satisfaction with quality workmanship and using quality materials is our top most priority.",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "0435 145 256",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Request a Free Quote",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Google Reviews",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Referred by friend",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Social Media",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Required Fields",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "01",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Residential Tile Roof Restoration",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "02",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Residential Tile Roof Restoration",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "03",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Residential Tile Roof Restoration",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us ?",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Kangaroo Roof Restoration The Hills \u2013 Peace of Mind with your Roof Restoration and Repairs Work!",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Council Areas Serviced",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hills Shire Council Areas",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hornsby Council Areas",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Council Areas Serviced",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": [
                                    {
                                        "header": null,
                                        "body": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Hills Shire Council Areas",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Hornsby Council Areas",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Willoughby City Council Areas",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Annangrove: 2156",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Asquith: 2077",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Artarmon: 2064",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Baulkham Hills: 2153",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Berowra: 2077",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Castle Cove: 2069",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Beaumont Hills: 2155",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Berowra Heights: 2077",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Castlecrag: 2068",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Bella Vista: 2153",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Brooklyn: 2083",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Chatswood: 2067",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Castle Hill: 2154",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Calabash: 2077",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Chatswood West: 2067",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Dural: 2158",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Cowan: 2064",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Lane Cove North (part): 2065",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Glenhaven: 2156",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Dural: 2158",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Middle Cove: 2069",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Glenorie: 2157",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Forest Glen: 2157",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Naremburn: 2065",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Kellyville: 2155",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Galston: 2111",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Northbridge: 2063",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Kenthurst: 2156",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Glenorie: 2157",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "North Willoughby: 2068",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "North Kellyville: 2155",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Hornsby: 2077",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Roseville (part): 2069",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "North Rocks: 2151",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Hornsby Heights: 2077",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "St Leonards (part): 2065",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Norwest: 2153",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Laughtondale: 2077",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Willoughby: 2068",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Rouse Hill: 2155",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Mount Colah: 2079",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Willoughby East: 2068",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "West Pennant Hills: 2125",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Mount Kuring-gai: 2080",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Winston Hills: 2153",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Normanhurst: 2076",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Pennant Hills: 2120",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Thornleigh: 2120",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Wahroonga: 2076",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Waitara: 2077",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Westleigh: 2120",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            }
                                        ],
                                        "footer": null
                                    }
                                ]
                            },
                            {
                                "h_title": "Willoughby City Council Areas",
                                "main_title": "Kangaroo Roof Restoration The Hills",
                                "author": "Kangaroo Roof Restoration The Hills",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}