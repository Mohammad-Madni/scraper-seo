{
    "id": "01190728-1132-0216-0000-57326f0796e8",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0274 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://budgetroofpainting.com.au/roof-repairs-cammeray/",
        "target": "budgetroofpainting.com.au",
        "start_url": "https://budgetroofpainting.com.au/roof-repairs-cammeray/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cammeray\\organic\\type-organic_rg13_ra16_budgetroofpainting.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:37 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Painting",
                                    "url": "https://budgetroofpainting.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://budgetroofpainting.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://budgetroofpainting.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://budgetroofpainting.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Pigeon Proofing",
                                    "url": "https://budgetroofpainting.com.au/solar-pigeon-proofing/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/solar-pigeon-proofing/",
                                            "anchor_text": "Solar Pigeon Proofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://budgetroofpainting.com.au/roof-leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/roof-leak-repair/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "AREAS WE SERVICE",
                                    "url": "https://budgetroofpainting.com.au/areas-we-service/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/areas-we-service/",
                                            "anchor_text": "AREAS WE SERVICE"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Budget roof painting is the name you can trust for restoring & beautifying your roof.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Areas We Service",
                                    "url": "https://budgetroofpainting.com.au/areas-we-service/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/areas-we-service/",
                                            "anchor_text": "Areas We Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://budgetroofpainting.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://budgetroofpainting.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://budgetroofpainting.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://budgetroofpainting.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Pigeon Proofing",
                                    "url": "https://budgetroofpainting.com.au/solar-pigeon-proofing/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/solar-pigeon-proofing/",
                                            "anchor_text": "Solar Pigeon Proofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://budgetroofpainting.com.au/roof-leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/roof-leak-repair/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Painting",
                                    "url": "https://budgetroofpainting.com.au/metal-roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/metal-roof-painting/",
                                            "anchor_text": "Metal Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Steel Roof Installation",
                                    "url": "https://budgetroofpainting.com.au/steel-roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/steel-roof-installation/",
                                            "anchor_text": "Steel Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colourbond Roof Painting",
                                    "url": "https://budgetroofpainting.com.au/colourbond-roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/colourbond-roof-painting/",
                                            "anchor_text": "Colourbond Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Steel Roof Painting",
                                    "url": "https://budgetroofpainting.com.au/steel-roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/steel-roof-painting/",
                                            "anchor_text": "Steel Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repairs",
                                    "url": "https://budgetroofpainting.com.au/metal-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/metal-roof-repairs/",
                                            "anchor_text": "Metal Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing Repairs",
                                    "url": "https://budgetroofpainting.com.au/roof-flashing-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/roof-flashing-repairs/",
                                            "anchor_text": "Roof Flashing Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roof Painting",
                                    "url": "https://budgetroofpainting.com.au/terracotta-roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/terracotta-roof-painting/",
                                            "anchor_text": "Terracotta Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Leak Repairs",
                                    "url": "https://budgetroofpainting.com.au/emergency-roof-leak-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/emergency-roof-leak-repairs/",
                                            "anchor_text": "Emergency Roof Leak Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Repairs",
                                    "url": "https://budgetroofpainting.com.au/commercial-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/commercial-roof-repairs/",
                                            "anchor_text": "Commercial Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation in Sydney",
                                    "url": "https://budgetroofpainting.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation in Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "\u00a9 [y] Budget Roof Painting. Website by Nifty Marketing Australia.",
                                    "url": "https://budgetroofpainting.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/",
                                            "anchor_text": "Budget Roof Painting"
                                        },
                                        {
                                            "url": "http://niftymarketing.com.au/",
                                            "anchor_text": "Nifty Marketing Australia"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms And Conditions",
                                    "url": "https://budgetroofpainting.com.au/terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms And Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://budgetroofpainting.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://budgetroofpainting.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs Cammeray",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "A well-kept roof is essential for shielding your home from weather-related damage. Budget Roof Painting provides expert roof repairs in Cammeray, NSW 2062, with solutions tailored to your specific requirements. Whether you need minor touch-ups or major repairs, we ensure long-lasting results that enhance both durability and appearance. Our skilled professionals utilise premium materials and advanced techniques to restore and strengthen your roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As specialists in all roofing repairs, we provide expert solutions to keep your home secure, durable, and weather-resistant.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Fast Service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10 Yr Warranty",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Professional Tile Roof Repair Services In Cammeray",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Tile roofing adds a refined touch to any property, but it must be properly maintained to preserve its strength and charm. Budget Roof Painting offers expert solutions to help your roof last longer while retaining its beauty. Our skilled team provides quality repairs and routine servicing, ensuring your roof remains in top condition and continues to increase the value of your property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Expert leak detection and fixes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of cracked or missing tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cleaning and resealing to protect tiles from weather damage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ridge capping repairs to prevent water ingress",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We offer tile roof repair services that improve both the integrity and appearance of your roof, ensuring lasting protection. Contact us today to preserve your roof\u2019s aesthetic and function, guaranteeing it remains a reliable barrier for your home in the future.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We offer:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Cammeray",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Budget Roof Painting is committed to assisting homeowners in Cammeray in keeping their roofs strong and secure. We use high-quality materials and expert craftsmanship to ensure long-lasting protection against harsh weather. Don\u2019t wait until small problems worsen\u2014contact us today for reliable and professional roofing repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Cammeray\u2019s Trusted Roofing Repairs",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When looking for reliable roofing repairs in Cammeray, count on the skilled professionals at Budget Roof Painting. We take pride in providing high-quality roofing solutions designed to safeguard your home against harsh weather conditions. Here\u2019s what you can expect when you choose our services:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast response times for prompt solutions, minimising any inconvenience.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive inspections to spot every potential issue in advance, saving you from costly future fixes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repairs tailored to your roofing material, ensuring precise and effective results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Long-lasting results constructed with high-end materials, offering you lasting security and confidence.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Reliable Emergency Roof Repairs In Cammeray",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A compromised roof can lead to major problems if not addressed quickly. When you need urgent repairs, Budget Roof Painting is here to provide efficient and reliable emergency roof repair services. Our professionals ensure:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Immediate attention to leaks or storm damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Temporary fixes to minimise further damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive evaluations to identify and address underlying issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Assistance with insurance claims for a hassle-free experience.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our skilled roofing team is committed to offering rapid, professional, and reliable emergency roof repairs. Budget Roof Painting ensures your home stays protected when you need urgent assistance. Contact us today for expert service.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Is The Process of boarding a roof repair specialist at Cammeray?",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We have refined our roof repair process to be efficient, transparent, and hassle-free. From the initial inspection to the project\u2019s successful completion, we keep you informed and ensure you\u2019re happy with the results. Here\u2019s what to expect:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Initial inspection to identify all issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Detailed cost estimate with no hidden fees.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Scheduling repairs at a convenient time for you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Completing repairs with high-quality workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Final inspection to ensure your satisfaction.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Budget Roof Painting delivers seamless roof repairs with professionalism and transparency. Count on us for reliable service that makes the process hassle-free.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Budget Roof Painting As Your Roof Repairer?",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Backed by more than ten years of expertise, we have built a strong name in the industry for delivering exceptional service. We take pride in using only the finest materials and meticulous workmanship, ensuring every repair is carried out to perfection. Our team stands out for its reliability, offering transparent communication and prompt service, so you\u2019re always aware of each step in the process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As part of our commitment to quality, we offer a warranty on all our services, assuring you of long-lasting results and peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Selecting us ensures you\u2019re working with a reliable partner for all roofing repairs throughout the area.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Cammeray",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Providing the most affordable and cost-effective roof and gutter cleaning service to local surrounding suburbs such as:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Painter Cammeray",
                                        "url": "https://budgetroofpainting.com.au/roof-painter-cammeray/",
                                        "urls": [
                                            {
                                                "url": "https://budgetroofpainting.com.au/roof-painter-cammeray/",
                                                "anchor_text": "Roof Painter Cammeray"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "What is the cost of roof repairs in Cammeray?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The cost of roof repairs is based on damage and materials. Call us for a free, no-obligation quote.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What is the usual duration for a roof repair?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Small roof repairs may take just 1\u20132 days, while large-scale projects could stretch to a week.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you provide emergency roof repair services in Cammeray?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we specialise in emergency roof repairs throughout Cammeray.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Are your roofing services available for commercial properties?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely, our services cover both homes and commercial buildings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Revitalise Your Roof with Expert Roof Repairs in Cammeray!",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Enhance the longevity of your property with Budget Roof Painting\u2019s top-notch Roof Repairs in Cammeray. Our experienced team uses cutting-edge techniques to address leaks, damage, and wear, ensuring your roof stays in peak condition. Protect your home and boost curb appeal\u2014book your roof repair service today for a safer, more secure property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Looking For A Roof Cleaners in Cammeray? Contact us now!",
                                "main_title": "Roof Repairs Cammeray",
                                "author": "aila",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 858,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61 449 175 746",
                                "0491 727 077",
                                "0449 175 746"
                            ],
                            "emails": [
                                "info@budgetroofpainting.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}