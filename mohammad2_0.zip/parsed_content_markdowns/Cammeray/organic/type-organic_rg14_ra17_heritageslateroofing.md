{
    "id": "01190728-1132-0216-0000-a17a7ef9baf5",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0287 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://heritageslateroofing.com.au/service-areas/slate-roofing-cammeray/",
        "target": "heritageslateroofing.com.au",
        "start_url": "https://heritageslateroofing.com.au/service-areas/slate-roofing-cammeray/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cammeray\\organic\\type-organic_rg14_ra17_heritageslateroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 05:00:38 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Cedar Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                            "anchor_text": "Cedar Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asphalt Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                            "anchor_text": "Asphalt Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hardwood Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                            "anchor_text": "Hardwood Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                            "anchor_text": "Terracotta Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Penrhyn)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                            "anchor_text": "Welsh Slate (Penrhyn)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Cwt-y-Bugail)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                            "anchor_text": "Welsh Slate (Cwt-y-Bugail)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate (Glendyne)",
                                    "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                            "anchor_text": "Canadian Slate (Glendyne)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate (Del Carmen)",
                                    "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                            "anchor_text": "Spanish Slate (Del Carmen)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate (SVK Artificial)",
                                    "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                            "anchor_text": "Artificial Slate (SVK Artificial)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Repair",
                                    "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                            "anchor_text": "Slate Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Reclaimed Slate",
                                    "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                            "anchor_text": "Reclaimed Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cast Iron Downpipes",
                                    "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                            "anchor_text": "Cast Iron Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Standing Seam",
                                    "url": "https://heritageslateroofing.com.au/zinc/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/zinc/",
                                            "anchor_text": "Zinc Standing Seam"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Z600 Galvanised Steel",
                                    "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                            "anchor_text": "Z600 Galvanised Steel"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Lead Roofing",
                                    "url": "https://www.heritageleadroofing.com/",
                                    "urls": [
                                        {
                                            "url": "https://www.heritageleadroofing.com/",
                                            "anchor_text": "Heritage Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Case Studies",
                                    "url": "https://heritageslateroofing.com.au/case-studies/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/case-studies/",
                                            "anchor_text": "Case Studies"
                                        }
                                    ]
                                },
                                {
                                    "text": "Video Gallery",
                                    "url": "https://heritageslateroofing.com.au/video-gallery/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/video-gallery/",
                                            "anchor_text": "Video Gallery"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cedar Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                            "anchor_text": "Cedar Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asphalt Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                            "anchor_text": "Asphalt Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hardwood Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                            "anchor_text": "Hardwood Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                            "anchor_text": "Terracotta Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Penrhyn)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                            "anchor_text": "Welsh Slate (Penrhyn)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Cwt-y-Bugail)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                            "anchor_text": "Welsh Slate (Cwt-y-Bugail)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate (Glendyne)",
                                    "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                            "anchor_text": "Canadian Slate (Glendyne)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate (Del Carmen)",
                                    "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                            "anchor_text": "Spanish Slate (Del Carmen)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate (SVK Artificial)",
                                    "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                            "anchor_text": "Artificial Slate (SVK Artificial)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Repair",
                                    "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                            "anchor_text": "Slate Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Reclaimed Slate",
                                    "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                            "anchor_text": "Reclaimed Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cast Iron Downpipes",
                                    "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                            "anchor_text": "Cast Iron Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Standing Seam",
                                    "url": "https://heritageslateroofing.com.au/zinc/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/zinc/",
                                            "anchor_text": "Zinc Standing Seam"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Z600 Galvanised Steel",
                                    "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                            "anchor_text": "Z600 Galvanised Steel"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Lead Roofing",
                                    "url": "https://www.heritageleadroofing.com/",
                                    "urls": [
                                        {
                                            "url": "https://www.heritageleadroofing.com/",
                                            "anchor_text": "Heritage Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Case Studies",
                                    "url": "https://heritageslateroofing.com.au/case-studies/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/case-studies/",
                                            "anchor_text": "Case Studies"
                                        }
                                    ]
                                },
                                {
                                    "text": "Video Gallery",
                                    "url": "https://heritageslateroofing.com.au/video-gallery/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/video-gallery/",
                                            "anchor_text": "Video Gallery"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Lead Roofing",
                                    "url": "https://www.heritageleadroofing.com/",
                                    "urls": [
                                        {
                                            "url": "https://www.heritageleadroofing.com/",
                                            "anchor_text": "Heritage Lead Roofing"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "2017 ~ Best Roof Residential \u2013 Other Materials \u2013 North Sydney Residence (Cedar Shingles)",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2018 ~ Best Roof Residential \u2013 Slate \u2013 Killara Residence (Del Carmen Slate)",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2018 ~ Best Roof Residential \u2013 Other Materials \u2013 Turramurra Residence (SVK Artificial Slate)",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2022 ~ Outstanding Craftsmanship \u2013 Slate \u2013 Kurraba Point (Welsh & Vermont Slate)",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2022 ~ Outstanding Craftsmanship \u2013 Terracotta Shingles \u2013 Wentworth Falls",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2023 ~ Best Commercial \u2013 Public Building Slate & Other Materials ~ Sts Peter & Paul\u2019s Olde Cathedral",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2023 ~ Best Residential Slate & Other Materials ~ Lang Rd, Centennial Park",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2024 ~ MRCCA | Specialist Works Project \u2013 (Specialised in Design & Heritage) ~ The Trust Building",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "0451 399 226",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Google Rating",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Cedar Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                            "anchor_text": "Cedar Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asphalt Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                            "anchor_text": "Asphalt Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hardwood Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                            "anchor_text": "Hardwood Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                            "anchor_text": "Terracotta Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Penrhyn)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                            "anchor_text": "Welsh Slate (Penrhyn)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Cwt-y-Bugail)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                            "anchor_text": "Welsh Slate (Cwt-y-Bugail)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate (Glendyne)",
                                    "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                            "anchor_text": "Canadian Slate (Glendyne)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate (Del Carmen)",
                                    "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                            "anchor_text": "Spanish Slate (Del Carmen)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate (SVK Artificial)",
                                    "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                            "anchor_text": "Artificial Slate (SVK Artificial)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Repair",
                                    "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                            "anchor_text": "Slate Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Reclaimed Slate",
                                    "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                            "anchor_text": "Reclaimed Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cast Iron Downpipes",
                                    "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                            "anchor_text": "Cast Iron Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Standing Seam",
                                    "url": "https://heritageslateroofing.com.au/zinc/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/zinc/",
                                            "anchor_text": "Zinc Standing Seam"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Z600 Galvanised Steel",
                                    "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                            "anchor_text": "Z600 Galvanised Steel"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Lead Roofing",
                                    "url": "https://www.heritageleadroofing.com/",
                                    "urls": [
                                        {
                                            "url": "https://www.heritageleadroofing.com/",
                                            "anchor_text": "Heritage Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Case Studies",
                                    "url": "https://heritageslateroofing.com.au/case-studies/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/case-studies/",
                                            "anchor_text": "Case Studies"
                                        }
                                    ]
                                },
                                {
                                    "text": "Video Gallery",
                                    "url": "https://heritageslateroofing.com.au/video-gallery/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/video-gallery/",
                                            "anchor_text": "Video Gallery"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Slate Roofing Cammeray",
                                "main_title": "Slate Roofing Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Heritage Roofing are experts in all things slate roofing in Cammeray and the surrounding area. Heritage Roofing Group, based in Sydney, Australia, was founded by Kyle Glasby and Luke Godden, who have over 20 years of combined experience in traditional roofing. Kyle and Luke are experts in all things slate roofing in Cammeray and the surrounding area. Both directors hold a Certificate III in traditional slate roofing and license to trade.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing Cammeray services:",
                                "main_title": "Slate Roofing Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Heritage, residential and commercial slate roofing Cammeray",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Chimney, flashings, ridging and valley services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Valley and hip replacements Cammeray",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Copper, zinc or colorbond guttering and downpipes installation Cammeray",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mitred hips, valleys and ridging",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Re-bedding and pointing of terracotta ridges and hips",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hardwood Shingles and shakes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The reliability and beauty of the products make it the ideal solution for architectural purposes. There is no other material that compares to natural slate! We have complete control over every aspect of your slate roof project no matter what size, from how we scope and cost to how we work, behave and deliver. All our work comes with a 20-year New Roof Workmanship Guarantee!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For more information or an obligation-free quote, contact Heritage Roofing Group today for your roofing solution\u00a0by phoning Kyle on 0451-399-226 or fill out the enquiry form below and we will get back to you shortly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Traditional slate roofing Cammeray \u2013 Penrhyn Welsh Slate, Glendyne Canadian Slate, Spanish Slate and Artificial Slate",
                                        "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhhyn/",
                                        "urls": [
                                            {
                                                "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhhyn/",
                                                "anchor_text": "Penrhyn Welsh Slate"
                                            },
                                            {
                                                "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                                "anchor_text": "Glendyne Canadian Slate"
                                            },
                                            {
                                                "url": "https://heritageslateroofing.com.au/slate/spanish-slate/",
                                                "anchor_text": "Spanish Slate"
                                            },
                                            {
                                                "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                                "anchor_text": "Artificial Slate"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cedar Shingles and shakes",
                                        "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                        "urls": [
                                            {
                                                "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                                "anchor_text": "Cedar Shingles"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Contact Us For A Quote",
                                "main_title": "Slate Roofing Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0451 399 226",
                                "+61451399226;",
                                "0451399226"
                            ],
                            "emails": [
                                "kyle@heritageslateroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}