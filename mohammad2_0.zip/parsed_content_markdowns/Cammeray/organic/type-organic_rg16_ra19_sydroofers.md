{
    "id": "01190728-1132-0216-0000-77cdbda1e665",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0246 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.sydroofers.com.au/locations/cammeray-roofing-services",
        "target": "www.sydroofers.com.au",
        "start_url": "https://www.sydroofers.com.au/locations/cammeray-roofing-services",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cammeray\\organic\\type-organic_rg16_ra19_sydroofers.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:32 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Commercial Roof Replacement",
                                    "url": "https://www.sydroofers.com.au/service/commercial-roof-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/commercial-roof-replacement",
                                            "anchor_text": "Commercial Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Replacement",
                                    "url": "https://www.sydroofers.com.au/service/metal-roof-replacement-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/metal-roof-replacement-",
                                            "anchor_text": "Metal Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Replacement",
                                    "url": "https://www.sydroofers.com.au/service/tile-roof-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/tile-roof-replacement",
                                            "anchor_text": "Tile Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://www.sydroofers.com.au/service/tile-roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/tile-roof-restoration",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://www.sydroofers.com.au/service/metal-roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/metal-roof-restoration",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roof Restoration",
                                    "url": "https://www.sydroofers.com.au/service/heritage-roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/heritage-roof-restoration",
                                            "anchor_text": "Heritage Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://www.sydroofers.com.au/service/gutter-replacement-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter-replacement-",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Gutter & Custom Guttering",
                                    "url": "https://www.sydroofers.com.au/service/box-gutter-%26-custom-guttering",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/box-gutter-%26-custom-guttering",
                                            "anchor_text": "Box Gutter & Custom Guttering"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://www.sydroofers.com.au/service/gutter-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter-repairs",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://www.sydroofers.com.au/service/gutter-installation-sydney-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter-installation-sydney-",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.sydroofers.com.au/service/roof-cleaning-sydney-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-cleaning-sydney-",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pressure Cleaning",
                                    "url": "https://www.sydroofers.com.au/service/roof-pressure-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-pressure-cleaning",
                                            "anchor_text": "Roof Pressure Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter, Solar & Skylight Cleaning Sydney",
                                    "url": "https://www.sydroofers.com.au/service/gutter%2C-solar-%26-skylight-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter%2C-solar-%26-skylight-cleaning-sydney",
                                            "anchor_text": "Gutter, Solar & Skylight Cleaning Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wet & Forget Roof Treatment",
                                    "url": "https://www.sydroofers.com.au/service/wet-%26-forget-roof-treatment-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/wet-%26-forget-roof-treatment-",
                                            "anchor_text": "Wet & Forget Roof Treatment"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tiled Roof Installation",
                                    "url": "https://www.sydroofers.com.au/service/tiled-roof-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/tiled-roof-installation",
                                            "anchor_text": "Tiled Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof Installation",
                                    "url": "https://www.sydroofers.com.au/service/colorbond-roof-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/colorbond-roof-installation",
                                            "anchor_text": "Colorbond Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Installation",
                                    "url": "https://www.sydroofers.com.au/service/new-roof-installation-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/new-roof-installation-sydney",
                                            "anchor_text": "New Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pointing",
                                    "url": "https://www.sydroofers.com.au/service/roof-pointing",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-pointing",
                                            "anchor_text": "Roof Pointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Bedding",
                                    "url": "https://www.sydroofers.com.au/service/roof-bedding",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-bedding",
                                            "anchor_text": "Roof Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://www.sydroofers.com.au/service/leaking-roof-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/leaking-roof-repairs",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashing Repairs",
                                    "url": "https://www.sydroofers.com.au/service/flashing-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/flashing-repairs",
                                            "anchor_text": "Flashing Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashing Installation & Replacement",
                                    "url": "https://www.sydroofers.com.au/service/flashing-installation-%26-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/flashing-installation-%26-replacement",
                                            "anchor_text": "Flashing Installation & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Chimney & Vent Flashing Installation",
                                    "url": "https://www.sydroofers.com.au/service/chimney-%26-vent-flashing-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/chimney-%26-vent-flashing-installation",
                                            "anchor_text": "Chimney & Vent Flashing Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Step Flashing & Roof-to-Wall Flashing Services in Sydney",
                                    "url": "https://www.sydroofers.com.au/service/step-flashing",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/step-flashing",
                                            "anchor_text": "Step Flashing & Roof-to-Wall Flashing Services in Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://www.sydroofers.com.au/service/skylight-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/skylight-installation",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Skylight Repairs",
                                    "url": "https://www.sydroofers.com.au/service/leaking-skylight-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/leaking-skylight-repairs",
                                            "anchor_text": "Leaking Skylight Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Replacement",
                                    "url": "https://www.sydroofers.com.au/service/skylight-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/skylight-replacement",
                                            "anchor_text": "Skylight Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Skylights",
                                    "url": "https://www.sydroofers.com.au/service/commercial-skylights",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/commercial-skylights",
                                            "anchor_text": "Commercial Skylights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://www.sydroofers.com.au/service/roof-ventilation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-ventilation",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Insulation",
                                    "url": "https://www.sydroofers.com.au/service/roof-insulation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-insulation",
                                            "anchor_text": "Roof Insulation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Replacement",
                                    "url": "https://www.sydroofers.com.au/service/commercial-roof-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/commercial-roof-replacement",
                                            "anchor_text": "Commercial Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Replacement",
                                    "url": "https://www.sydroofers.com.au/service/metal-roof-replacement-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/metal-roof-replacement-",
                                            "anchor_text": "Metal Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Replacement",
                                    "url": "https://www.sydroofers.com.au/service/tile-roof-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/tile-roof-replacement",
                                            "anchor_text": "Tile Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://www.sydroofers.com.au/service/tile-roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/tile-roof-restoration",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://www.sydroofers.com.au/service/metal-roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/metal-roof-restoration",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roof Restoration",
                                    "url": "https://www.sydroofers.com.au/service/heritage-roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/heritage-roof-restoration",
                                            "anchor_text": "Heritage Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://www.sydroofers.com.au/service/gutter-replacement-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter-replacement-",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Gutter & Custom Guttering",
                                    "url": "https://www.sydroofers.com.au/service/box-gutter-%26-custom-guttering",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/box-gutter-%26-custom-guttering",
                                            "anchor_text": "Box Gutter & Custom Guttering"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://www.sydroofers.com.au/service/gutter-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter-repairs",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://www.sydroofers.com.au/service/gutter-installation-sydney-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter-installation-sydney-",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.sydroofers.com.au/service/roof-cleaning-sydney-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-cleaning-sydney-",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pressure Cleaning",
                                    "url": "https://www.sydroofers.com.au/service/roof-pressure-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-pressure-cleaning",
                                            "anchor_text": "Roof Pressure Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter, Solar & Skylight Cleaning Sydney",
                                    "url": "https://www.sydroofers.com.au/service/gutter%2C-solar-%26-skylight-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter%2C-solar-%26-skylight-cleaning-sydney",
                                            "anchor_text": "Gutter, Solar & Skylight Cleaning Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wet & Forget Roof Treatment",
                                    "url": "https://www.sydroofers.com.au/service/wet-%26-forget-roof-treatment-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/wet-%26-forget-roof-treatment-",
                                            "anchor_text": "Wet & Forget Roof Treatment"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tiled Roof Installation",
                                    "url": "https://www.sydroofers.com.au/service/tiled-roof-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/tiled-roof-installation",
                                            "anchor_text": "Tiled Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof Installation",
                                    "url": "https://www.sydroofers.com.au/service/colorbond-roof-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/colorbond-roof-installation",
                                            "anchor_text": "Colorbond Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Installation",
                                    "url": "https://www.sydroofers.com.au/service/new-roof-installation-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/new-roof-installation-sydney",
                                            "anchor_text": "New Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pointing",
                                    "url": "https://www.sydroofers.com.au/service/roof-pointing",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-pointing",
                                            "anchor_text": "Roof Pointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Bedding",
                                    "url": "https://www.sydroofers.com.au/service/roof-bedding",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-bedding",
                                            "anchor_text": "Roof Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://www.sydroofers.com.au/service/leaking-roof-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/leaking-roof-repairs",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashing Repairs",
                                    "url": "https://www.sydroofers.com.au/service/flashing-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/flashing-repairs",
                                            "anchor_text": "Flashing Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashing Installation & Replacement",
                                    "url": "https://www.sydroofers.com.au/service/flashing-installation-%26-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/flashing-installation-%26-replacement",
                                            "anchor_text": "Flashing Installation & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Chimney & Vent Flashing Installation",
                                    "url": "https://www.sydroofers.com.au/service/chimney-%26-vent-flashing-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/chimney-%26-vent-flashing-installation",
                                            "anchor_text": "Chimney & Vent Flashing Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Step Flashing & Roof-to-Wall Flashing Services in Sydney",
                                    "url": "https://www.sydroofers.com.au/service/step-flashing",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/step-flashing",
                                            "anchor_text": "Step Flashing & Roof-to-Wall Flashing Services in Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://www.sydroofers.com.au/service/skylight-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/skylight-installation",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Skylight Repairs",
                                    "url": "https://www.sydroofers.com.au/service/leaking-skylight-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/leaking-skylight-repairs",
                                            "anchor_text": "Leaking Skylight Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Replacement",
                                    "url": "https://www.sydroofers.com.au/service/skylight-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/skylight-replacement",
                                            "anchor_text": "Skylight Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Skylights",
                                    "url": "https://www.sydroofers.com.au/service/commercial-skylights",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/commercial-skylights",
                                            "anchor_text": "Commercial Skylights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://www.sydroofers.com.au/service/roof-ventilation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-ventilation",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Insulation",
                                    "url": "https://www.sydroofers.com.au/service/roof-insulation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-insulation",
                                            "anchor_text": "Roof Insulation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Book Online",
                                    "url": "https://www.sydroofers.com.au/book-online",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/book-online",
                                            "anchor_text": "Book Online"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Sydney Roofers is a multi-award-winning roofing company based in Sydney, offering expert roof repairs, restorations, and installations backed by decades of experience, industry-leading workmanship, and unmatched local knowledge. We proudly service homes, businesses, and strata properties across all Sydney suburbs.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Customer Support:",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "1800 793 766",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "1800 044 055",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "All Posts",
                                    "url": "https://www.sydroofers.com.au/resources",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/resources",
                                            "anchor_text": "All Posts"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tiled Roof Repairs",
                                    "url": "https://www.sydroofers.com.au/resources/categories/tiled-roof-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/resources/categories/tiled-roof-repairs",
                                            "anchor_text": "Tiled Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "All Posts",
                                    "url": "https://www.sydroofers.com.au/resources",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/resources",
                                            "anchor_text": "All Posts"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tiled Roof Repairs",
                                    "url": "https://www.sydroofers.com.au/resources/categories/tiled-roof-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/resources/categories/tiled-roof-repairs",
                                            "anchor_text": "Tiled Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Client Intake Form",
                                    "url": "https://www.sydroofers.com.au/intake-form",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/intake-form",
                                            "anchor_text": "Client Intake Form"
                                        }
                                    ]
                                },
                                {
                                    "text": "Book Online",
                                    "url": "https://www.sydroofers.com.au/book-online",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/book-online",
                                            "anchor_text": "Book Online"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.sydroofers.com.au/privacy-policy",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/privacy-policy",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Locations (List)",
                                    "url": "https://www.sydroofers.com.au/locations",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/locations",
                                            "anchor_text": "Locations (List)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Replacement",
                                    "url": "https://www.sydroofers.com.au/service/commercial-roof-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/commercial-roof-replacement",
                                            "anchor_text": "Commercial Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Replacement",
                                    "url": "https://www.sydroofers.com.au/service/metal-roof-replacement-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/metal-roof-replacement-",
                                            "anchor_text": "Metal Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Replacement",
                                    "url": "https://www.sydroofers.com.au/service/tile-roof-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/tile-roof-replacement",
                                            "anchor_text": "Tile Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://www.sydroofers.com.au/service/tile-roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/tile-roof-restoration",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://www.sydroofers.com.au/service/metal-roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/metal-roof-restoration",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roof Restoration",
                                    "url": "https://www.sydroofers.com.au/service/heritage-roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/heritage-roof-restoration",
                                            "anchor_text": "Heritage Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://www.sydroofers.com.au/service/gutter-replacement-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter-replacement-",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Gutter & Custom Guttering",
                                    "url": "https://www.sydroofers.com.au/service/box-gutter-%26-custom-guttering",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/box-gutter-%26-custom-guttering",
                                            "anchor_text": "Box Gutter & Custom Guttering"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://www.sydroofers.com.au/service/gutter-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter-repairs",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://www.sydroofers.com.au/service/gutter-installation-sydney-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter-installation-sydney-",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.sydroofers.com.au/service/roof-cleaning-sydney-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-cleaning-sydney-",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pressure Cleaning",
                                    "url": "https://www.sydroofers.com.au/service/roof-pressure-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-pressure-cleaning",
                                            "anchor_text": "Roof Pressure Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter, Solar & Skylight Cleaning Sydney",
                                    "url": "https://www.sydroofers.com.au/service/gutter%2C-solar-%26-skylight-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/gutter%2C-solar-%26-skylight-cleaning-sydney",
                                            "anchor_text": "Gutter, Solar & Skylight Cleaning Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wet & Forget Roof Treatment",
                                    "url": "https://www.sydroofers.com.au/service/wet-%26-forget-roof-treatment-",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/wet-%26-forget-roof-treatment-",
                                            "anchor_text": "Wet & Forget Roof Treatment"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tiled Roof Installation",
                                    "url": "https://www.sydroofers.com.au/service/tiled-roof-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/tiled-roof-installation",
                                            "anchor_text": "Tiled Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof Installation",
                                    "url": "https://www.sydroofers.com.au/service/colorbond-roof-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/colorbond-roof-installation",
                                            "anchor_text": "Colorbond Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Installation",
                                    "url": "https://www.sydroofers.com.au/service/new-roof-installation-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/new-roof-installation-sydney",
                                            "anchor_text": "New Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pointing",
                                    "url": "https://www.sydroofers.com.au/service/roof-pointing",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-pointing",
                                            "anchor_text": "Roof Pointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Bedding",
                                    "url": "https://www.sydroofers.com.au/service/roof-bedding",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-bedding",
                                            "anchor_text": "Roof Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://www.sydroofers.com.au/service/leaking-roof-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/leaking-roof-repairs",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashing Repairs",
                                    "url": "https://www.sydroofers.com.au/service/flashing-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/flashing-repairs",
                                            "anchor_text": "Flashing Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashing Installation & Replacement",
                                    "url": "https://www.sydroofers.com.au/service/flashing-installation-%26-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/flashing-installation-%26-replacement",
                                            "anchor_text": "Flashing Installation & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Chimney & Vent Flashing Installation",
                                    "url": "https://www.sydroofers.com.au/service/chimney-%26-vent-flashing-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/chimney-%26-vent-flashing-installation",
                                            "anchor_text": "Chimney & Vent Flashing Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Step Flashing & Roof-to-Wall Flashing Services in Sydney",
                                    "url": "https://www.sydroofers.com.au/service/step-flashing",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/step-flashing",
                                            "anchor_text": "Step Flashing & Roof-to-Wall Flashing Services in Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://www.sydroofers.com.au/service/skylight-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/skylight-installation",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Skylight Repairs",
                                    "url": "https://www.sydroofers.com.au/service/leaking-skylight-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/leaking-skylight-repairs",
                                            "anchor_text": "Leaking Skylight Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Replacement",
                                    "url": "https://www.sydroofers.com.au/service/skylight-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/skylight-replacement",
                                            "anchor_text": "Skylight Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Skylights",
                                    "url": "https://www.sydroofers.com.au/service/commercial-skylights",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/commercial-skylights",
                                            "anchor_text": "Commercial Skylights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://www.sydroofers.com.au/service/roof-ventilation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-ventilation",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Insulation",
                                    "url": "https://www.sydroofers.com.au/service/roof-insulation",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/service/roof-insulation",
                                            "anchor_text": "Roof Insulation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Book Online",
                                    "url": "https://www.sydroofers.com.au/book-online",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/book-online",
                                            "anchor_text": "Book Online"
                                        }
                                    ]
                                },
                                {
                                    "text": "Media Center",
                                    "url": "https://www.sydroofers.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://www.sydroofers.com.au/",
                                            "anchor_text": "Media Center"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs in Cammeray",
                                "main_title": "Roof Repairs in Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Fast, reliable roof repairs in Cammeray to fix leaks, storm damage, broken tiles, and more. Our expert team delivers permanent repair solutions tailored to Cammeray\u2019s coastal conditions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning Services in Cammeray",
                                "main_title": "Roof Repairs in Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Keep your Cammeray roof clean and protected with our soft-wash and pressure cleaning solutions. We safely remove moss, lichen, dirt, and debris for long-lasting performance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "New Roof Installation in Cammeray",
                                "main_title": "Roof Repairs in Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Building in Cammeray? Our new roof installation service ensures long-lasting performance and architectural alignment using top-quality materials and expert workmanship.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Installation & Repairs in Cammeray",
                                "main_title": "Roof Repairs in Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Upgrade your home with durable guttering and downpipes in Cammeray. Our systems are built to handle heavy rain, reduce overflow, and enhance drainage efficiency.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Ventilation & Whirlybirds Cammeray",
                                "main_title": "Roof Repairs in Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Improve airflow and energy efficiency with whirlybird installations and passive roof ventilation \u2014 ideal for hot Cammeray summers and moisture-prone spaces.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Flashing Services in Cammeray",
                                "main_title": "Roof Repairs in Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Protect vulnerable areas of your roof with high-quality flashing installation and repairs in Cammeray. We handle valleys, chimneys, walls, and roof edges with precision.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Skylight Installation & Repairs Cammeray",
                                "main_title": "Roof Repairs in Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Brighten your Cammeray property with skylight installations or flashing upgrades. We ensure water-tight seals, smooth finishes, and energy-efficient results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration in Bondi Cammeray",
                                "main_title": "Roof Repairs in Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Revive the look and function of your roof with a complete roof restoration in Cammeray. We clean, re-bed, repoint, and seal to extend your roof\u2019s life by decades.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement in Cammeray",
                                "main_title": "Roof Repairs in Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We offer full roof replacement in Cammeray. using premium Colorbond\u00ae or tile \u2014 ideal for aged, damaged, or asbestos roofs needing a fresh start.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cammeray NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Cammeray Roofing Services",
                                "main_title": "Roof Repairs in Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Looking for reliable roofing in Cammeray? Sydney Roofers delivers expert solutions tailored to the coastal climate of Cammeray from roof repairs and replacements to guttering and skylights. Trusted by homeowners and builders since 1955.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": null,
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "1800 793 766"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}