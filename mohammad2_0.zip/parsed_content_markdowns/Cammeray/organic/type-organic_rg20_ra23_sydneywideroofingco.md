{
    "id": "01190728-1132-0216-0000-9b2f05919d20",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0414 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneywideroofingco.com.au/north-sydney/cammeray/",
        "target": "sydneywideroofingco.com.au",
        "start_url": "https://sydneywideroofingco.com.au/north-sydney/cammeray/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cammeray\\organic\\type-organic_rg20_ra23_sydneywideroofingco.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:36 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipes",
                                    "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                            "anchor_text": "Gutters and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tile Pointing and Bedding",
                                    "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                            "anchor_text": "Roof Tile Pointing and Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Roofing",
                                    "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                            "anchor_text": "Zinc Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs in Randwick NSW",
                                    "url": "https://sydneywideroofingco.com.au/randwick/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/randwick/",
                                            "anchor_text": "Roof Repairs in Randwick NSW"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Georges River",
                                    "url": "https://sydneywideroofingco.com.au/georges-river/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/georges-river/",
                                            "anchor_text": "Georges River"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Inner West Roof Repairs",
                                    "url": "https://sydneywideroofingco.com.au/inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/inner-west/",
                                            "anchor_text": "Sydney Inner West Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "City of Sydney",
                                    "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                            "anchor_text": "City of Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "GET QUOTE",
                                    "url": "https://sydneywideroofingco.com.au/get-quote/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/get-quote/",
                                            "anchor_text": "GET QUOTE"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "95 Bellingara Rd, Miranda NSW 2228.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "(02) 8294 4654",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Sydney Wide Roofing Co: Superior Roofing Expertise in Cammeray",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Cammeray, tucked away in Sydney\u2019s lower North Shore, effortlessly marries suburban tranquillity with city convenience. Sydney Wide Roofing Co takes pride in providing Cammeray with bespoke roofing services, complementing the locality\u2019s unique architectural flair.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement in Cammeray",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Cammeray\u2019s architectural horizon boasts a blend of heritage charm and contemporary appeal. Our top-tier roof replacement offerings guarantee that each residence, irrespective of its age, reflects the suburb\u2019s distinctive charisma.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation in Cammeray",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "As Cammeray embraces modern designs, our progressive roof installation techniques accentuate this evolution, providing every structure with a finish that\u2019s both functional and aesthetically pleasing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak Repair Cammeray",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Unexpected roof troubles can disrupt the serene Cammeray lifestyle. We specialize in promptly detecting and rectifying roof leaks, ensuring each Cammeray home remains impeccable and shielded.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Leak Repair Cammeray",
                                        "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                                "anchor_text": "Roof Leak Repair Cammeray"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair Cammeray",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Cammeray homes narrate tales of timeless elegance. From subtle enhancements to expansive overhauls, our roofing repairs imbue resilience and beauty, solidifying Cammeray\u2019s stature as a locale of well-maintained residences.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair Cammeray",
                                        "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                                "anchor_text": "Roof Repair Cammeray"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Cammeray",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Over time, even the finest roofs can face wear. Our exacting roof restoration processes revive older roofs, ensuring they mirror Cammeray\u2019s lush surroundings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration Cammeray",
                                        "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration Cammeray"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters and Downpipes Cammeray",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "In picturesque Cammeray, attention to detail is paramount. Our comprehensive gutters and downpipes solutions ensure effective drainage, while simultaneously augmenting your home\u2019s visual appeal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutters and Downpipes Cammeray",
                                        "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                                "anchor_text": "Gutters and Downpipes Cammeray"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Pointing and Bedding in Cammeray",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Cammeray\u2019s vistas are a sight to behold, accentuated by its rooftops. With our precise tile pointing services, we fortify roof longevity and enhance their aesthetic grace.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tile Pointing and Bedding in Cammeray",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                                "anchor_text": "Tile Pointing and Bedding in Cammeray"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Cammeray\u2019s Premier Roofing Specialist",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Sydney Wide Roofing Co, intertwining mastery with an acute appreciation of Cammeray\u2019s spirit, remains the suburb\u2019s trusted roofing partner.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Connect With Us Today",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For unparalleled roofing craftsmanship in Cammeray, choose Sydney Wide Roofing Co:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cammeray\u2019s Historic Roots",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rich in Aboriginal legacy and colonial tales, Cammeray seamlessly integrates its storied past with its present-day vibrancy.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cammeray\u2019s structures weave a tapestry of architectural epochs, from vintage cottages to avant-garde residences, each echoing its unique chronicle.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Blessed with serene parks, waterfront vistas, and quaint cafes, Cammeray promises an abundance of spots that beckon exploration.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Prominent Institutions in Cammeray",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Playing host to renowned educational hubs and community venues, Cammeray stands as a beacon of learning and communal bonding.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Phone \u2013 (02) 8294 4654",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email \u2013 [email\u00a0protected]",
                                        "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Website \u2013 https://sydneywideroofingco.com.au/",
                                        "url": "https://sydneywideroofingco.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/",
                                                "anchor_text": "https://sydneywideroofingco.com.au/"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cammeray\u2019s Architectural Landscape",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cammeray\u2019s Noteworthy Destinations",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Cammeray",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair Cammeray \u2013 Sydney Wide Roofing Co",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Peerless Roofing Solutions Crafted for Cammeray\u2019s Distinctive Homes",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Highly rated roofing company servicing Cammeray",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You can contact Sydney Wide Roofing Co at the following:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For all your roofing needs, reach out to us today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Highly rated roofing company servicing Cammeray",
                                        "url": "https://maps.app.goo.gl/zu1Uy43jr2YehwCCA",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/zu1Uy43jr2YehwCCA",
                                                "anchor_text": "Cammeray"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact Information",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Phone \u2013 (02) 8294 4654",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email \u2013 [email\u00a0protected]",
                                        "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Website \u2013 https://sydneywideroofingco.com.au/",
                                        "url": "https://sydneywideroofingco.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/",
                                                "anchor_text": "https://sydneywideroofingco.com.au/"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Portfolio",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burraneer Bay Residential",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Burraneer Bay Residential",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                                "anchor_text": "Burraneer Bay Residential"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing Project Sydney",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing Project Sydney",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                                "anchor_text": "Slate Roofing Project Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Project Eastern Suburbs",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Project Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                                "anchor_text": "Metal Roofing Project Eastern Suburbs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Handy Tips About Roofing",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leaks",
                                        "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                                "anchor_text": "Roof Leaks"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-roofing",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Re-roofing",
                                        "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                                "anchor_text": "Re-roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Downpipes",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                                "anchor_text": "Roof Tiling"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations We Service",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sutherland Shire",
                                        "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                                "anchor_text": "Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                                "anchor_text": "Eastern Suburbs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "City of Sydney",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney",
                                                "anchor_text": "City of Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georges River",
                                        "url": "https://sydneywideroofingco.com.au/georges-river/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/georges-river/",
                                                "anchor_text": "Georges River"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Inner West",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/",
                                                "anchor_text": "Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Northern Beaches",
                                        "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                                "anchor_text": "Northern Beaches"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Central Coast",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Building Inspiring Roofs",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Only takes a few seconds!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Suburbs in the North Sydney Council We Service",
                                "main_title": "Roofing Cammeray",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Cremorne Point",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/cremorne-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/cremorne-point",
                                                "anchor_text": "Cremorne Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Crows Nest",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/crows-nest",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/crows-nest",
                                                "anchor_text": "Crows Nest"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kurraba Point",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/kurraba-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/kurraba-point",
                                                "anchor_text": "Kurraba Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lavendar Bay",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/lavendar-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/lavendar-point",
                                                "anchor_text": "Lavendar Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "McMahons Point",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/mcmahons-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/mcmahons-point",
                                                "anchor_text": "McMahons Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Milsons Point",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/milsons-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/milsons-point",
                                                "anchor_text": "Milsons Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Neutral Bay",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/neutral-bay",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/neutral-bay",
                                                "anchor_text": "Neutral Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Leonards",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/st-leonards",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/st-leonards",
                                                "anchor_text": "St Leonards"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wollstone Craft",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/wollstonecraft",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/wollstonecraft",
                                                "anchor_text": "Wollstone Craft"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61 (02) 8294 4654",
                                "+61282944654"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}