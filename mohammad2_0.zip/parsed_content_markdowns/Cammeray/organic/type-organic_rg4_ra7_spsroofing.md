{
    "id": "01190728-1132-0216-0000-6fd361f25478",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0360 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://spsroofing.com.au/roof-repairs-cammeray/",
        "target": "spsroofing.com.au",
        "start_url": "https://spsroofing.com.au/roof-repairs-cammeray/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cammeray\\organic\\type-organic_rg4_ra7_spsroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:35 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Property Check Channel",
                                    "url": "https://www.youtube.com/channel/UCRsC8oPEHOARWLpWoqQ8ItQ",
                                    "urls": [
                                        {
                                            "url": "https://www.youtube.com/channel/UCRsC8oPEHOARWLpWoqQ8ItQ",
                                            "anchor_text": "Property Check  Channel"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become A Member",
                                    "url": "https://spsroofing.com.au/sign-up/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/sign-up/",
                                            "anchor_text": "Become A Member"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacements",
                                    "url": "https://spsroofing.com.au/services/roof-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-replacements/",
                                            "anchor_text": "Roof Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://spsroofing.com.au/services/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restorations",
                                    "url": "https://spsroofing.com.au/services/roof-restorations/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-restorations/",
                                            "anchor_text": "Roof Restorations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://spsroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Services",
                                    "url": "https://spsroofing.com.au/services/gutter-services/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-services/",
                                            "anchor_text": "Gutter Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become a member",
                                    "url": "https://spsroofing.com.au/sign-up/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/sign-up/",
                                            "anchor_text": "Become a member"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://spsroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booking Now",
                                    "url": "https://spsroofing.com.au/booking/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/booking/",
                                            "anchor_text": "Booking Now"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "We're a Multi Award Winning Business",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Address Sydney NSW 2000 Tel 02 9067 9574 Operating Hours 24 hours / 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright 2026 | SPS Roofing | All Rights Reserved | SPS Roofing License No. 394055C",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Replacements",
                                    "url": "https://spsroofing.com.au/services/roof-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-replacements/",
                                            "anchor_text": "Roof Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://spsroofing.com.au/services/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restorations",
                                    "url": "https://spsroofing.com.au/services/roof-restorations/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-restorations/",
                                            "anchor_text": "Roof Restorations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://spsroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Services",
                                    "url": "https://spsroofing.com.au/services/gutter-services/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-services/",
                                            "anchor_text": "Gutter Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Inner West",
                                    "url": "https://spsroofing.com.au/services/roof-repairs-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-repairs-inner-west/",
                                            "anchor_text": "Roof Repairs Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Gutter Replacement",
                                    "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                            "anchor_text": "Box Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaf Gutter Guard",
                                    "url": "https://spsroofing.com.au/services/leaf-guard/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/leaf-guard/",
                                            "anchor_text": "Leaf Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repairs and Replacements",
                                    "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                            "anchor_text": "Downpipe Repairs and Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booking an Urgent Repair",
                                    "url": "https://spsroofing.com.au/booking/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/booking/",
                                            "anchor_text": "Booking an Urgent Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Speak to a Strata Specialist",
                                    "url": "https://spsroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/contact-us/",
                                            "anchor_text": "Speak to a Strata Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become a lifetime Member Now",
                                    "url": "https://spsroofing.com.au/membership/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/membership/",
                                            "anchor_text": "Become a lifetime Member Now"
                                        }
                                    ]
                                },
                                {
                                    "text": "Work With Us",
                                    "url": "https://spsroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/contact-us/",
                                            "anchor_text": "Work With Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roofing Services in Cammeray",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "You may be extending your home or building a new one and need a new roof. Your roof may be in need of repair. You may want to extend the life of your existing roof. Whatever your roofing needs in your Belrose home or commercial building, you will need the services of experienced, licensed, insured, and well-trained roofing contractors. If you need a roofing company that guarantees its work and offers a comprehensive range of services under the same roof, you have come to the right place. Cammeray At SPS Roofing Specialists, we are a team of experienced roofing experts that take care of installation, maintenance, and repair of different types of roofs in the region.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Range of Roofing Services",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We repair, maintain, and install roofs made of different types of materials. Our experience and skills allow us to handle all types of roofing jobs efficiently and quickly. Roof leaks, for instance, can create a lot of issues and challenges. Without professional expertise, you may take hours or days just to figure out the source of the problem. Our team can locate the source immediately and fix the problem the right way to prevent it from reoccurring. Cammeray",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team has decades of combined industry experience. There is no roofing job that we have not handled over the years. We have a proven track record of excellence and we work closely with you to determine the best options and solutions. Besides, we use superior-quality materials to deliver reliable and long-lasting results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Areas We Serve",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We are conveniently located in Sydney and serve homeowners and businessowners throughout Cammeray and the nearby areas. We also serve the greater City of Canterbury-Bankstown and its suburbs including East Hills, Banks, Blaxland, and Lakemba along with Cammeray. Our crews are operational throughout Sydney and all its suburbs. There is always an SPS crew that\u2019s near you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Over the years, we have earned a reputation for quality customer service. From the moment you call us to the moment we complete the job, you will find our services to be prompt and our team courteous and sincere. We keep you informed at all stages of a project about the progress. Whenever any unexpected problems or delays arise, we communicate them immediately. We have a fully licensed, insured, and professional in-house crew of roofers, with some of them having over two decades of industry experience. We strive to complete every roofing job with the highest quality. There is no roofing service or installation job that is too big or too small for us.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At SPS Roofing Specialists, we use only the finest and highest quality materials. From new roof installation to replacement to repairs and maintenance, we take pride in the quality of our workmanship. No matter the scale and type of roofing project you have, we deliver the best quality services to our clients. As already mentioned, we service both commercial and residential properties in Cammeray and the surrounding regions. Call us today at 02 9067 9574 to discuss your roofing problem or new installation project. You may contact us via this Contact Form or fill this Form to schedule an appointment.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Dominique Rollandi",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Michael was excellent \u2013 very friendly, very patient and very professional. He explained everything really well and was open about the pros and cons of what we were having done. It was clear from the way he spoke that he was honest and passionate about doing the best job he could. I would absolutely use SPS again!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "See Full Review",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Beth Gemmell",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Professional, friendly and punctual, friendly, clearly explained the issues and offered options to get resolved. I highly recommend this company if you want reliable and efficient service- my home was back on track so quickly and done in an exceptional manner.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "See Full Review",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Mia Axalan",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Highly recommended!!! Incredible and helpful service! Explained the issues in easy to understand terms and was very efficient. Called in advance and on arrival so I was able to go about my day. Very professional and super friendly. Dylan even helped me move my fridge. What a legend!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "See Full Review",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Daniel Scavone",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "They turned up on time, went out of there way to help us, especially knowing we got ripped off by another company. Completed the job to an excellent standard. Done a sewer inline repair. Went out of there way for us. Polite, courteous, reasonably priced. Highly recommend!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "On time & Excellent!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "See Full Review",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Dominique Rollandi",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Michael was excellent \u2013 very friendly, very patient and very professional. He explained everything really well and was open about the pros and cons of what we were having done. It was clear from the way he spoke that he was honest and passionate about doing the best job he could. I would absolutely use SPS again!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "See Full Review",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Beth Gemmell",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Professional, friendly and punctual, friendly, clearly explained the issues and offered options to get resolved. I highly recommend this company if you want reliable and efficient service- my home was back on track so quickly and done in an exceptional manner.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "See Full Review",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Mia Axalan",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Highly recommended!!! Incredible and helpful service! Explained the issues in easy to understand terms and was very efficient. Called in advance and on arrival so I was able to go about my day. Very professional and super friendly. Dylan even helped me move my fridge. What a legend!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "See Full Review",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Daniel Scavone",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "They turned up on time, went out of there way to help us, especially knowing we got ripped off by another company. Completed the job to an excellent standard. Done a sewer inline repair. Went out of there way for us. Polite, courteous, reasonably priced. Highly recommend!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "On time & Excellent!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "See Full Review",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Dominique Rollandi",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Michael was excellent \u2013 very friendly, very patient and very professional. He explained everything really well and was open about the pros and cons of what we were having done. It was clear from the way he spoke that he was honest and passionate about doing the best job he could. I would absolutely use SPS again!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "See Full Review",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Beth Gemmell",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Professional, friendly and punctual, friendly, clearly explained the issues and offered options to get resolved. I highly recommend this company if you want reliable and efficient service- my home was back on track so quickly and done in an exceptional manner.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "See Full Review",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "0% Interest Payment Plan Get Your New Roof Financed",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We aim to help you solve your home improvements & repair issues without disturbing your household cashflow",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete 0% Interest Plans",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "No catches or gimmicks. Have an option to spend now, pay later!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Cammeray",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Same Day Service Guaranteed!",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Lifetime Workmanship Guarantee",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roofing Repairs",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Box Gutter Replacement",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Box Gutter Replacement",
                                        "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                                "anchor_text": "Box Gutter Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Cleaning",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter & Downpipe Replacement",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter & Downpipe Replacement",
                                        "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                                "anchor_text": "Gutter & Downpipe Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaf Guard",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Leaf Guard",
                                        "url": "https://spsroofing.com.au/services/leaf-guard/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/leaf-guard/",
                                                "anchor_text": "Leaf Guard"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nCleaning",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof\nCleaning",
                                        "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                                "anchor_text": "RoofCleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nRepairs",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof\nRepairs",
                                        "url": "https://spsroofing.com.au/services/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-repairs/",
                                                "anchor_text": "RoofRepairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency\nRoof Repairs",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Emergency\nRoof Repairs",
                                        "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak\nDetection",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leak\nDetection",
                                        "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                                "anchor_text": "Roof Leak Detection"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nReplacements",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof\nReplacements",
                                        "url": "https://spsroofing.com.au/services/roof-replacements/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-replacements/",
                                                "anchor_text": "RoofReplacements"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nPainting",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof\nPainting",
                                        "url": "https://spsroofing.com.au/services/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-painting/",
                                                "anchor_text": "RoofPainting"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof\nRestorations",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof\nRestorations",
                                        "url": "https://spsroofing.com.au/services/roof-restorations/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/roof-restorations/",
                                                "anchor_text": "RoofRestorations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal\nRoofing",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal\nRoofing",
                                        "url": "https://spsroofing.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/metal-roofing/",
                                                "anchor_text": "MetalRoofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter\nServices",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter\nServices",
                                        "url": "https://spsroofing.com.au/services/gutter-services/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/services/gutter-services/",
                                                "anchor_text": "GutterServices"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Clients Say",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Word of Mouth",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "True Local",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Process",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "1. Inspection",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "2. Meet Project Manager",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "3. Job Commences",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Enquire with the team for an Inspection or Quotes",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Send Enquiry",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Same Day Service Guaranteed!",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Lifetime Workmanship Guarantee",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "24/7 EMERGENCY Available",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Same Day Service Guaranteed!",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Lifetime Workmanship Guarantee",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "24/7 EMERGENCY Available",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "5-7 Minute Approval Time",
                                "main_title": "Roof Repairs Cammeray",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Apply & have an outcome in minutes!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+02 9067 9574",
                                "02 9067 9574"
                            ],
                            "emails": [
                                "info@spsroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}