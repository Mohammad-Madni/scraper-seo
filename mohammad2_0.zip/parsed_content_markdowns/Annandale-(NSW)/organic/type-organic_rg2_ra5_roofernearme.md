{
    "id": "01190727-1132-0216-0000-af61b9b4dbdf",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0215 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofernearme.com.au/roofing-annandale/",
        "target": "roofernearme.com.au",
        "start_url": "https://roofernearme.com.au/roofing-annandale/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Annandale-(NSW)\\organic\\type-organic_rg2_ra5_roofernearme.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:50 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Talk to one of our expert roofers- fill in the inquiry form or call us on 0432 822 128",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Couldn't Find What You Were Looking For ?",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Talk to one of our expert roofers before you go..",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email Us",
                                    "url": "https://roofernearme.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofernearme.com.au/contact-us/",
                                            "anchor_text": "Email Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call 0432822128",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Ask a Roofer",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Call Now",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email Us",
                                    "url": "https://roofernearme.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofernearme.com.au/contact-us/",
                                            "anchor_text": "Email Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Your 10% OFF code is ready.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "You're in!",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "RESIDENTIAL, COMMERCIAL & STRATA\nIN Annandale",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From\u00a0roof inspections all the way through to completion of your roo\ufb01ng works, our company\u2019s professional and informative staff will help you with your roo\ufb01ng needs.",
                                        "url": "https://roofernearme.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofernearme.com.au/services/",
                                                "anchor_text": "roof inspections"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "SUPERIOR WORKMANSHIP",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofer Near Me is a Sydney based and family owned business with over 20 years of experience in the roo\ufb01ng industry. We service the Annandale region.",
                                        "url": "https://roofernearme.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofernearme.com.au/contact-us/",
                                                "anchor_text": "Roofer Near Me"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Services in Annandale",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tile to Colorbond",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal to Colorbond",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ridge Cap Repointing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Patios & Polycarbonate",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Contact us to find out more \u2013 or visit our\u00a0Roof Replacement & Repair Services page.",
                                        "url": "https://roofernearme.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofernearme.com.au/services/",
                                                "anchor_text": "Roof Replacement & Repair Services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof replacement is a major undertaking that requires great care and attention to detail. The entire process from beginning to end should be handled by a qualified, certified roofing contractor like\u00a0Roofer Near Me.",
                                        "url": "https://roofernearme.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofernearme.com.au/",
                                                "anchor_text": "Roofer Near Me"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile to Colorbond",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "It may be more cost effective to replace your tile roof with Colorbond roofing. Colorbond roofing is a modern alternative to traditional tile roofing, providing the same level of protection without the need for regular maintenance. Ask us about it.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal to Colorbond",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Colorbond roofing has emerged as an alternative to traditional metal roofs. It combines the strength of steel with the flexibility of Colorbond\u2019s range of colour and design options. This makes it a great choice for those who want to create an attractive and unique look with their roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ridge Cap Repointing",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Over time, the mortar between the ridge caps can deteriorate due to exposure to weathering and erosion, leaving the ridge vulnerable to leaks.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repairing or replacing these ridge caps is an essential part of roof maintenance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Downpipes",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Gutter and downpipe systems divert rainwater away from your home and foundation walls, which can help keep your home structurally sound.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you\u2019re noticing any damage or deterioration in your existing system, it\u2019s important to replace it quickly to prevent further damage to your home. Talk to Roofer Near Me who can advise you on the best solution for your home",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Patios & Polycarbonate",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Patios and polycarbonate are two great ways to improve the look of your outdoor space. Patios can provide an area for outdoor dining or entertaining and can also be used for a recreational space for enjoying the outdoors.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Polycarbonate is a great option for adding durability and protection to your patio",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing Annandale",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Pick\u00a0Roofer Near Me for residential works including roof repairs, gutter repairs, repointing, tile roof repairs all the way through to full roof replacements. All begin with a detailed inspection where we will isolate the exact problem and provide a detailed estimate based on the best solutions for your property.",
                                        "url": "https://roofernearme.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofernearme.com.au/",
                                                "anchor_text": "Roofer Near Me"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing Annandale",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With commercial roofing works it is crucial that the works are correctly estimated, scheduled and that the works are done with minimal disruption to the property. At Roofer near me we understand the importance of having a capable team and a well organised and efficient team so commercial works occur with no delays or surprises.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fill out a commercial enquiry form using the contact button below please.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our roofing material of choice is Colorbond. Colorbond is lightweight while also being a very strong material. Manufactured to Australian standards, Colorbond has been tested and can withstand the harshest conditions. It can endure intense winds, is termite resistant, and non combustible while also being resistant to corrosion, chipping, peeling and cracking.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Have a look at the colour range here\u00a0https://colorbond.com/colour\u00a0or have a look at out frequently asked\u00a0roofing questions",
                                        "url": "https://colorbond.com/colour",
                                        "urls": [
                                            {
                                                "url": "https://colorbond.com/colour",
                                                "anchor_text": "https://colorbond.com/colour"
                                            },
                                            {
                                                "url": "https://roofernearme.com.au/faqs/",
                                                "anchor_text": "roofing questions"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Info",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roofer Near Me (Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Unit 25, 1/7 Short St, Chatswood NSW 2067",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Annandale",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roofer Near Me.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Call:\u00a0(02) 7205 7788",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "or\u00a00432 822 128",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "or\u00a0(02) 3821 1614 (after hours)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "or fill in the contact form for a free\u00a0quote",
                                        "url": "https://roofernearme.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofernearme.com.au/contact-us/",
                                                "anchor_text": "quote"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FULLY INSURED & LICENSED",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Fully licensed and insured- Lic 335427c",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Over 20 years of experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Free Inspection and estimate",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Annandale",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roofing Services",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Email Us",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "call Us",
                                "main_title": "Roofing Annandale",
                                "author": "https://www.facebook.com/roofernearmesydney/",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "(02) 7205 7788 or\u00a00432 822 128",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0432 822 128",
                                "0272057788",
                                "0432822128",
                                "0238211614"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}