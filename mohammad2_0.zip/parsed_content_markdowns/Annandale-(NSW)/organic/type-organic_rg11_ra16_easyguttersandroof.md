{
    "id": "01190727-1132-0216-0000-d89d407ec026",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0180 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-annandale/",
        "target": "easyguttersandroof.com",
        "start_url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-annandale/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Annandale-(NSW)\\organic\\type-organic_rg11_ra16_easyguttersandroof.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:49 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "859 Bourke St, Waterloo, NSW, 2017, Australia",
                                    "url": "https://maps.app.goo.gl/SVoPk4pfjJNueHec6",
                                    "urls": [
                                        {
                                            "url": "https://maps.app.goo.gl/SVoPk4pfjJNueHec6",
                                            "anchor_text": "859 Bourke St, Waterloo, NSW, 2017, Australia"
                                        }
                                    ]
                                },
                                {
                                    "text": "\ud83c\udfe0\ufe0e Home",
                                    "url": "https://easyguttersandroof.com/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/",
                                            "anchor_text": "\ud83c\udfe0\ufe0e Home"
                                        }
                                    ]
                                },
                                {
                                    "text": "Moore Park",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-moore-park/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-moore-park/",
                                            "anchor_text": "Moore Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Centennial Park",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-centennial-park/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-centennial-park/",
                                            "anchor_text": "Centennial Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Queens Park",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-queens-park/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-queens-park/",
                                            "anchor_text": "Queens Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bondi Junction",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bondi-junction/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bondi-junction/",
                                            "anchor_text": "Bondi Junction"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bondi Beach",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bondi-beach/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bondi-beach/",
                                            "anchor_text": "Bondi Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Bondi",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-north-bondi/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-north-bondi/",
                                            "anchor_text": "North Bondi"
                                        }
                                    ]
                                },
                                {
                                    "text": "Rose Bay",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-rose-bay/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-rose-bay/",
                                            "anchor_text": "Rose Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dover Heights",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-dover-heights/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-dover-heights/",
                                            "anchor_text": "Dover Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bellevue Hill",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bellevue-hill/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bellevue-hill/",
                                            "anchor_text": "Bellevue Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Double Bay",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-double-bay/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-double-bay/",
                                            "anchor_text": "Double Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Darling Point",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-darling-point/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-darling-point/",
                                            "anchor_text": "Darling Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Elizabeth Bay",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-elizabeth-bay/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-elizabeth-bay/",
                                            "anchor_text": "Elizabeth Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surry Hills",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-surry-hills/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-surry-hills/",
                                            "anchor_text": "Surry Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Forest Lodge",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-forest-lodge/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-forest-lodge/",
                                            "anchor_text": "Forest Lodge"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-dulwich-hill/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-dulwich-hill/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Neutral Bay",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-neutral-bay/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-neutral-bay/",
                                            "anchor_text": "Neutral Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "St Leonards",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-st-leonards/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-st-leonards/",
                                            "anchor_text": "St Leonards"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lane Cove",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-lane-cove/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-lane-cove/",
                                            "anchor_text": "Lane Cove"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-north-sydney/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Russell Lea",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-russell-lea/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-russell-lea/",
                                            "anchor_text": "Russell Lea"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://easyguttersandroof.com/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guards Installation",
                                    "url": "https://easyguttersandroof.com/gutter-guard-installation/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-guard-installation/",
                                            "anchor_text": "Gutter Guards Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation and Repair",
                                    "url": "https://easyguttersandroof.com/gutter-installation-and-repair/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-installation-and-repair/",
                                            "anchor_text": "Gutter Installation and Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipes Installation and Repair",
                                    "url": "https://easyguttersandroof.com/downpipes-installation-and-repair/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/downpipes-installation-and-repair/",
                                            "anchor_text": "Downpipes Installation and Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof",
                                    "url": "https://easyguttersandroof.com/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/metal-roof/",
                                            "anchor_text": "Metal Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof",
                                    "url": "https://easyguttersandroof.com/tile-roof/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/tile-roof/",
                                            "anchor_text": "Tile Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Service",
                                    "url": "https://easyguttersandroof.com/skylight-service/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/skylight-service/",
                                            "anchor_text": "Skylight Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://easyguttersandroof.com/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "\ud83c\udfe0\ufe0e Home",
                                    "url": "https://easyguttersandroof.com/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/",
                                            "anchor_text": "\ud83c\udfe0\ufe0e Home"
                                        }
                                    ]
                                },
                                {
                                    "text": "Moore Park",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-moore-park/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-moore-park/",
                                            "anchor_text": "Moore Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Centennial Park",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-centennial-park/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-centennial-park/",
                                            "anchor_text": "Centennial Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Queens Park",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-queens-park/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-queens-park/",
                                            "anchor_text": "Queens Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bondi Junction",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bondi-junction/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bondi-junction/",
                                            "anchor_text": "Bondi Junction"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bondi Beach",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bondi-beach/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bondi-beach/",
                                            "anchor_text": "Bondi Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Bondi",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-north-bondi/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-north-bondi/",
                                            "anchor_text": "North Bondi"
                                        }
                                    ]
                                },
                                {
                                    "text": "Rose Bay",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-rose-bay/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-rose-bay/",
                                            "anchor_text": "Rose Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dover Heights",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-dover-heights/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-dover-heights/",
                                            "anchor_text": "Dover Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bellevue Hill",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bellevue-hill/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-bellevue-hill/",
                                            "anchor_text": "Bellevue Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Double Bay",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-double-bay/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-double-bay/",
                                            "anchor_text": "Double Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Darling Point",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-darling-point/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-darling-point/",
                                            "anchor_text": "Darling Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Elizabeth Bay",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-elizabeth-bay/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-elizabeth-bay/",
                                            "anchor_text": "Elizabeth Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surry Hills",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-surry-hills/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-surry-hills/",
                                            "anchor_text": "Surry Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Forest Lodge",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-forest-lodge/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-forest-lodge/",
                                            "anchor_text": "Forest Lodge"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-dulwich-hill/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-dulwich-hill/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Neutral Bay",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-neutral-bay/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-neutral-bay/",
                                            "anchor_text": "Neutral Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "St Leonards",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-st-leonards/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-st-leonards/",
                                            "anchor_text": "St Leonards"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lane Cove",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-lane-cove/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-lane-cove/",
                                            "anchor_text": "Lane Cove"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-north-sydney/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Russell Lea",
                                    "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-russell-lea/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-and-roofing-services-in-russell-lea/",
                                            "anchor_text": "Russell Lea"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://easyguttersandroof.com/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guards Installation",
                                    "url": "https://easyguttersandroof.com/gutter-guard-installation/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-guard-installation/",
                                            "anchor_text": "Gutter Guards Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation and Repair",
                                    "url": "https://easyguttersandroof.com/gutter-installation-and-repair/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/gutter-installation-and-repair/",
                                            "anchor_text": "Gutter Installation and Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipes Installation and Repair",
                                    "url": "https://easyguttersandroof.com/downpipes-installation-and-repair/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/downpipes-installation-and-repair/",
                                            "anchor_text": "Downpipes Installation and Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof",
                                    "url": "https://easyguttersandroof.com/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/metal-roof/",
                                            "anchor_text": "Metal Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof",
                                    "url": "https://easyguttersandroof.com/tile-roof/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/tile-roof/",
                                            "anchor_text": "Tile Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Service",
                                    "url": "https://easyguttersandroof.com/skylight-service/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/skylight-service/",
                                            "anchor_text": "Skylight Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://easyguttersandroof.com/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://easyguttersandroof.com/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Copyright 2025. Easy Gutters & Roof PTY LTD",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": null,
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Gutter and Roofing Services in Annandale, Sydney",
                                "main_title": "Service\u00a0Areas",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Looking for reliable gutter cleaning and roof repairs in Annandale? At Easy Gutters & Roof, we specialize in delivering top-notch roofing services Sydney and guttering solutions for both residential and commercial properties. With over 10 years of experience, our dedicated team ensures every project is completed with precision, efficiency, and high-quality materials to protect your property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "we provide tailored services including emergency roof repairs and gutter maintenance, helping homeowners and businesses save money by preventing costly damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Gutter and Roofing Services Include:",
                                "main_title": "Service\u00a0Areas",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Gutter Cleaning in Annandale \u2013 Keep your gutters clean to avoid water damage and blockages.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Repairs & Replacements \u2013 Durable solutions for leaks and worn-out gutters.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Repairs & Maintenance Sydney \u2013 Extend the life of your roof with regular maintenance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Guard Installation \u2013 Prevent debris buildup with hight-quality protection systems.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Emergency Roof Repairs \u2013 Fast response to storm or water damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Easy Gutters & Roof?",
                                "main_title": "Service\u00a0Areas",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Local Experts: We\u2019re trusted roofers in Annandale for quality roof repairs and gutter cleaning.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Reliable Service: Quick response times for emergency jobs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Affordable Solutions: Transparent pricing with no hidden fees.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Proven Results: Over 500 satisfied customers across Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Testimonials",
                                "main_title": "Service\u00a0Areas",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Hugo was fantastic to deal with, reliable, excellent work, reasonable prices. I would highly recommend Hugo form Easy Gutters. Fast, Efficient, Greate job, Cost Effective",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "~ Dan",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Chippendale, NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "~ J",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Chippendale, NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "~ Dan",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Chippendale, NSW",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us?",
                                "main_title": "Service\u00a0Areas",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Over 10 years of experience in guttering and roofing services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully licensed and insured professionals.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Specialised in leak detection, gutter repairs, and maintenance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "High-quality materials for long-lasting solutions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Commitment",
                                "main_title": "Service\u00a0Areas",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "All work is completed to the highest professional standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We use premium materials for durability and efficiency.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jobs are completed within the agreed time frame.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Customer satisfaction is our top priority.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Service\u00a0Areas",
                                "main_title": "Service\u00a0Areas",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get a Free Quote",
                                "main_title": "Service\u00a0Areas",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Request for a FREE QUOTE",
                                "main_title": "Service\u00a0Areas",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Details",
                                "main_title": "Service\u00a0Areas",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "859 Bourke St, Waterloo, NSW, 2017, Australia",
                                        "url": "https://maps.app.goo.gl/SVoPk4pfjJNueHec6",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/SVoPk4pfjJNueHec6",
                                                "anchor_text": "859 Bourke St, Waterloo, NSW, 2017, Australia"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0435120350"
                            ],
                            "emails": [
                                "info@easygutters.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}