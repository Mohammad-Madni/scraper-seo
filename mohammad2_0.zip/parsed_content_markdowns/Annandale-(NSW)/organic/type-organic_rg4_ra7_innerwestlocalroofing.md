{
    "id": "01190727-1132-0216-0000-90f185cd4e7e",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0726 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://innerwestlocalroofing.com.au/roofing-annandale/",
        "target": "innerwestlocalroofing.com.au",
        "start_url": "https://innerwestlocalroofing.com.au/roofing-annandale/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Annandale-(NSW)\\organic\\type-organic_rg4_ra7_innerwestlocalroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:48 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Inner West Local Roofing",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain East",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-balmain-east/",
                                            "anchor_text": "Balmain East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulwich Hill",
                                    "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/dulwich-hill-roofing/",
                                            "anchor_text": "Dulwich Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "St. Peters",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-st-peters/",
                                            "anchor_text": "St. Peters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Summer Hill",
                                    "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roofing-summer-hill/",
                                            "anchor_text": "Summer Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Address: Inner West, Sydney, NSW",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Opening Hours:\u00a0Monday to Sunday \u2013 24 hours",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://innerwestlocalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://innerwestlocalroofing.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms and Conditions",
                                    "url": "https://innerwestlocalroofing.com.au/terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repairs",
                                    "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://innerwestlocalroofing.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repairs"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "The Roofer You Can Trust",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Local Roofing, we\u2019re proud to serve Annandale with reliable roofing solutions. From Johnston Street to Booth Street and beyond, our team understands the suburb\u2019s mix of heritage terraces and modern homes, delivering expert repairs, maintenance, and replacements tailored to every property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As your local Annandale specialists, we\u2019re committed to keeping roofs strong, secure, and built to last.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Annandale Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Inner West Local Roofing, customer satisfaction is our top priority. We\u2019re proud to serve homeowners and businesses in Annandale with high-quality workmanship, backed by full licensing and insurance for complete peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter the size or complexity of your roofing project, our experienced team is here to help. We specialise in roof repairs, replacements, and new installations in Annandale, and we offer free, no-obligation quotes so you can plan your project with confidence.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professionalism in Roofing Services",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "What sets us apart from other roofing companies in Annandale is our attention to detail and commitment to professionalism. We know how important your roof is, which is why we treat every project with the care it deserves \u2014 from the first on-site inspection to the final clean-up.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our process is straightforward and stress-free: we assess your roof, provide a clear and honest estimate, and deliver quality work on time and within budget. Respecting your schedule, we work efficiently to minimise any disruption to your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Commitment",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing in Annandale isn\u2019t just our job \u2014 it\u2019s our passion. We pride ourselves on honesty, transparency, and integrity, and we\u2019ll never recommend services you don\u2019t need. As your trusted Annandale roofing specialists, our goal is to protect your property, enhance its value, and give you lasting peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Contact us today to discuss your Annandale roofing needs \u2014 whether it\u2019s a minor repair, a full roof replacement, or expert advice. We\u2019re here to help you every step of the way.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Looking for roofing services in the Annandale?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to protecting your home, you deserve a roofing team that combines skill, reliability, and genuine local care. At Inner West Local Roofing, we\u2019re more than just contractors \u2014 we\u2019re your neighbours. With years of experience serving the Annandale community, we understand the unique challenges local homes face and provide tailored roofing solutions built to last. Our commitment to quality workmanship, honest advice, and dependable service sets us apart, ensuring you enjoy peace of mind under every roof we build or repair.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "When storms or sudden damage strike, our Annandale team offers fast emergency roof repairs to keep your home or business safe.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FREQUENTLY ASKED QUESTIONS",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "What types of roofing services do you offer in Annandale?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We provide a full range of roofing services in Annandale, including roof repairs, restorations, new roof installations, roof cleaning, roof painting, and skylight repairs for both residential and commercial properties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How quickly can you respond to roof damage in Annandale?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our local team provides fast response times across Annandale, handling urgent roof repairs from storm damage, leaks, or sudden emergencies to keep your property safe.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you work on older or heritage-style homes in Annandale?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes \u2014 we specialise in Annandale\u2019s Victorian and Federation-style terraces, cottages, and heritage homes, delivering careful roof restorations that maintain original character while improving durability.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What roofing materials do you recommend for homes in Annandale?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We recommend durable, weather-resistant materials suited to Annandale\u2019s climate and housing styles, including Colorbond, terracotta, slate, and metal roofing for long-lasting results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Is roof maintenance really necessary for homes in Annandale?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Regular roof maintenance is essential in Annandale, especially for heritage terraces and older homes, as it helps prevent leaks, rust, and structural damage while extending your roof\u2019s lifespan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Clients Say",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "\"We live in a Victorian terrace in Annandale and had ongoing issues with leaks after heavy rain. The team from Inner West Local Roofing were fantastic \u2014 they explained everything clearly, restored the old slate roof without losing the heritage look, and finished on time. It\u2019s such a relief knowing our home is protected for years to come. Highly recommend them to anyone in Annandale!\"",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "At Inner West Roofing, we\u2019re proud to serve the Annandale community with trusted, high-quality roofing services. From restoring ageing iron roofs on Johnston Street terraces to installing new roofing on modern homes near Booth Street, we\u2019ve helped homeowners across Annandale protect and enhance their properties with tailored solutions and expert workmanship. With Annandale\u2019s mix of heritage and contemporary homes, we understand the specific roofing challenges locals face \u2014 here\u2019s what some of our happy Annandale clients have shared about working with us.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sarah T.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Annandale NSW",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get a Free Quote Today!",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "When it comes to roofing needs, look no further than Inner West Local Roofing. We\u2019re the most reputable choice in the industry. Contact us today and discover the exceptional service we offer. You won\u2019t be let down.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Why Choose Us?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "SAFETY & RELIABILITY",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "LONG-TERM PLANS",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FULLY EXPERIENCED",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "QUALITY MATERIALS",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "OUR SERVICES\u200b",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide reliable commercial roofing solutions across Annandale, ensuring local businesses are protected with durable, long-lasting roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Repair",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From leaks to blockages, we handle all gutter repairs in Annandale, helping to protect your property from water damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our residential roofing services in Annandale are tailored to all home styles, from heritage terraces to modern builds.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide professional roof cleaning across Annandale, restoring the look of your roof while extending its lifespan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspection",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our thorough roof inspections in Annandale help identify issues early, saving you time, money, and stress in the long run.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Looking for a new roof? We specialise in expert roof installations throughout Annandale, using only quality materials.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Regular roof maintenance keeps your Annandale property secure. Our team ensures your roof stays in top condition year-round.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We offer professional roof painting in Annandale to protect your roof from the elements and refresh your home\u2019s appearance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From minor leaks to major damage, our Annandale roof repair services deliver lasting solutions for local homes and businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Bring your roof back to life with our expert roof restoration services in Annandale \u2014 a cost-effective alternative to replacement.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Skylight Repair",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide professional skylight repairs across Annandale, fixing leaks and restoring natural light to your property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Do We Do?",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Built for Annandale\u2019s Urban Climate",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Designed to withstand Annandale\u2019s warm summers, sudden storms, and unpredictable Sydney weather",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Helps prevent common roofing issues found in Annandale, including leaks in older terraces and rust from ageing iron roofs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Uses durable, weather-resistant materials suited to heritage and modern Annandale properties",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Delivers long-lasting roofing solutions tailored to the suburb\u2019s local conditions",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage & Modern Home Expertise",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Experienced in restoring Annandale\u2019s Victorian and Federation-style terraces and cottages",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Careful roof restorations that preserve original features while improving durability",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Custom solutions to suit Annandale\u2019s mix of heritage homes, apartments, and modern builds",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tailored advice for renovations, extensions, and upgrading older Annandale roofs",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fast, Local & Trusted Service",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quick response times for roof repairs in Annandale, from storm damage to everyday wear and tear",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fully familiar with Sydney Inner West council guidelines and Annandale\u2019s building requirements",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted by homeowners and small businesses along Booth Street, Johnston Street, and surrounding areas",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Committed to delivering high-quality workmanship and reliable local service every time",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "GET IN TOUCH",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Copyright \u00a9 2025 | Inner West Local Roofing",
                                "main_title": "The Roofer You Can Trust",
                                "author": "https://www.facebook.com/yourlocalroofersroofrepairs",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 12,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0280743728"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}