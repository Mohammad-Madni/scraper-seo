{
    "id": "01191143-1132-0216-0000-8f238f74b4be",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0978 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.whereis.com/nsw/annandale-2038/yellowId-12511187",
        "target": "whereis.com",
        "start_url": "https://www.whereis.com/nsw/annandale-2038/yellowId-12511187",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": false,
        "load_resources": false,
        "enable_browser_rendering": false,
        "enable_xhr": false,
        "disable_cookie_popup": false,
        "browser_preset": "desktop",
        "tag": "parsed_content_markdowns\\Annandale-(NSW)\\organic\\type-organic_rg13_ra18_whereis.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 07:45:44 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "R.O. Steel Roofing Pty Ltd",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Sorry, maps are currently unavailable",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Map data \u00a9 OpenStreetMap contributors",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Write a review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9566 1554",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Send Email",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Loading map...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "R.O. Steel Roofing Pty Ltd opening hours in Annandale",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Onsite work hours will vary based on client needs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Additional Contacts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Onsite work hours will vary based on client needs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "People Also Viewed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": "https://www.whereis.com/find/roofing-construction-services/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roofing-construction-services/annandale-nsw-2038",
                                                "anchor_text": "Roofing Construction & Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.whereis.com/find/roof-restoration-repairs/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-restoration-repairs/annandale-nsw-2038",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Acid Proofing",
                                        "url": "https://www.whereis.com/find/acid-proofing/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/acid-proofing/annandale-nsw-2038",
                                                "anchor_text": "Acid Proofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": "https://www.whereis.com/find/roofing-construction-services/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roofing-construction-services/annandale-nsw-2038",
                                                "anchor_text": "Roofing Construction & Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tiles",
                                        "url": "https://www.whereis.com/find/roof-tiles/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-tiles/annandale-nsw-2038",
                                                "anchor_text": "Roof Tiles"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Window Roller Shutters",
                                        "url": "https://www.whereis.com/find/window-roller-shutters/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/window-roller-shutters/annandale-nsw-2038",
                                                "anchor_text": "Window Roller Shutters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Popular Categories",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Plumbers in Annandale",
                                        "url": "https://www.whereis.com/find/plumbers-gas-fitters/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/plumbers-gas-fitters/annandale-nsw-2038",
                                                "anchor_text": "Plumbers in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electricians in Annandale",
                                        "url": "https://www.whereis.com/find/electricians-electrical-contractors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/electricians-electrical-contractors/annandale-nsw-2038",
                                                "anchor_text": "Electricians in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lawyers in Annandale",
                                        "url": "https://www.whereis.com/find/lawyers-solicitors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/lawyers-solicitors/annandale-nsw-2038",
                                                "anchor_text": "Lawyers in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pest Control in Annandale",
                                        "url": "https://www.whereis.com/find/pest-control/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/pest-control/annandale-nsw-2038",
                                                "anchor_text": "Pest Control  in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mechanics in Annandale",
                                        "url": "https://www.whereis.com/find/mechanics-motor-engineers/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/mechanics-motor-engineers/annandale-nsw-2038",
                                                "anchor_text": "Mechanics in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Locksmiths in Annandale",
                                        "url": "https://www.whereis.com/find/locksmiths-locksmith-services/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/locksmiths-locksmith-services/annandale-nsw-2038",
                                                "anchor_text": "Locksmiths in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Concreters in Annandale",
                                        "url": "https://www.whereis.com/find/concrete-contractors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/concrete-contractors/annandale-nsw-2038",
                                                "anchor_text": "Concreters in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Fencing Contractors in Annandale",
                                        "url": "https://www.whereis.com/find/fencing-contractors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/fencing-contractors/annandale-nsw-2038",
                                                "anchor_text": "Fencing Contractors in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Builders in Annandale",
                                        "url": "https://www.whereis.com/find/builders-building-contractors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/builders-building-contractors/annandale-nsw-2038",
                                                "anchor_text": "Builders in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Accountants in Annandale",
                                        "url": "https://www.whereis.com/find/accountants-auditors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/accountants-auditors/annandale-nsw-2038",
                                                "anchor_text": "Accountants in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roofing",
                                        "url": "http://rosteelroofing.com.au/commercial-roofing-sydney/",
                                        "urls": [
                                            {
                                                "url": "http://rosteelroofing.com.au/commercial-roofing-sydney/",
                                                "anchor_text": "Commercial Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Asbestos Removal",
                                        "url": "http://rosteelroofing.com.au/asbestos-removal-sydney/",
                                        "urls": [
                                            {
                                                "url": "http://rosteelroofing.com.au/asbestos-removal-sydney/",
                                                "anchor_text": "Asbestos Removal"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Additional Services",
                                        "url": "http://rosteelroofing.com.au/sydney-roofing-services/",
                                        "urls": [
                                            {
                                                "url": "http://rosteelroofing.com.au/sydney-roofing-services/",
                                                "anchor_text": "Additional Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Accreditations",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "R.O. Steel Roofing Pty Ltd - Pic 1",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Products and Services",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Master Builders Association",
                                        "url": "http://www.mbansw.asn.au/",
                                        "urls": [
                                            {
                                                "url": "http://www.mbansw.asn.au/",
                                                "anchor_text": "Master Builders Association"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing and Cladding Association of Australia",
                                        "url": "http://www.mrcaa.com.au/",
                                        "urls": [
                                            {
                                                "url": "http://www.mrcaa.com.au/",
                                                "anchor_text": "Metal Roofing and Cladding Association of Australia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "About Us",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "About R.O. Steel Roofing Pty Ltd",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Specialists in commercial & industrial properties",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Consistent delivery of quality service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast, efficient & minimal disruption to operations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully licensed and insured",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Competitive obligation free quotes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "R.O. Steel Roofing is fully licensed approved and complies with the standards of practice for Master Builders Association (MBA).",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "R.O. Steel Roofing specialise in Roofing, Asbestos Removal and Wall Cladding solutions for industrial and commercial properties. Our experience and track record of delivering quality projects that are safe, on time and to budget has created long term relationships which continue to bring repeat business and referrals from our clients.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Construction And Restoration",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Commercial buildings need to maintain a safe and effective roof to ensure that its day to day operations, staff and visitors are kept safe and are able to perform their tasks at an optimal level. Whether you're building a new property or restoring an existing site we use our many years of experience in the roofing industry to provide expert advice tailored to suit your individual needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Asbestos Removal",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "R.O Steel Roofing offers greater peace of mind to the client with our Asbestos Removal Project Management solutions. Services include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Preparation of removal specification",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Preparation of tender documentation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Analytical management for the duration of the project",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tender analysis",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Completion documentation",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Material",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Aluminium, Asbestos, Concrete, Copper, Fibreglass, Glass, Iron, Malthoid, Metal, Plastic, Polycarbonate, Sheet Metal, Slate, Steel, Terracotta, Tin, Torch-on Membranes",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Cappings, Customising, Designing, Flashings, Installations, Leak Detection, Manufacturing, Re-roofing, Rust Prevention",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Brand",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Colorbond, Corrugated, CSR, Maxiclad, Maxirib, Metroll, Monier, Stratco, Superdek, Topdek 700, Wunderlich, Zincalume",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Offering",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Architectural, Barge Boards, Beams, Brackets, Bullnose, Commercial, Curved, Downpipes, Dutch Gable, Factories, Farms, Fascias, Fasteners, Flat, Gables, Garages, Girts, Gutters, High Rises, Hipped, Houses, Industrial, Insulation, Laminated, Nails, Offices, Patios, Pavilions, Pergolas, Residential, Schools, Sealants, Sheds, Shelters, Shingles, Shopping Centres, Skydome, Skylights, Tiles, Translucent, Workshops",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Features",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Accredited, ARC, Australian Operated, Australian Owned, Bonded, By Appointment, Certified, Consultations, Delivery, Emergency Services, Factory Authorised, Family Operated, Family Owned, First Aid Trained, Free Quotes, Government Contracts, Guaranteed, Insurance Accepted, Insurance Claims, Insured, Licensed, Locally Operated, Locally Owned, Mobile Service, On-Site Services, Owner Operated, Public Liability Insurance, Quotes, Registered, Warranties",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Keywords",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Asbestos Removal Service Sydney, Roofing Projects, Sydney Roofing Services, Roof Repairs Sydney, Metal Wall Cladding, Roofing Construction, Colorbond Steel Roofing, Roofing Sydney, Metal Roofing Construction, Commercial Roofing Sydney, Commercial Roofing Services, Metal Roofing, Zincalume Roofing, Roofing Contractors, Roofing Contractor, Roofing Blog, Metal Roofing Contractor, Commercial Asbestos Removal Sydney, Colorbond Commercial Roofing, Roofing Services, Commercial Roof Restoration Sydney, Metal Roofing Sydney, Industrial Wall Cladding, Commercial Roof Repairs, Asbestos Removal Sydney, Colorbond Roofing Services, Commercial Roof Removal, Sydney Roofing, Roof Removal",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why choose R.O. Steel Roofing?",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "R.O. Steel Roofing Pty Ltd is a well known and highly regarded roofing construction company catering to greater Sydney and Regional NSW. As a well established and experienced company we have taken on a variety of challenging projects and always provide superior workmanship with exceptional customer service. For this reason we enjoy repeat business, R.O. Steel Roofing Pty Ltd is a well-known and highly regarded roofing construction company catering toreferrals and recommendation from our clients.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long will it take to complete my roof?",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "This depends on the size and complexity of your roof but we will work with you to develop a plan that suits your individual needs and minimises disruption to your day-to-day operations.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What colours are available?",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Along with the strength and durability that Colorbond steel provides, the range of colours are superb. The Colorbond steel colour palette is fresh, subtle, sophisticated and draws inspirations from Australia's own backyard To view available colours please visit, http://rosteelroofing.com.au/colorbond-steel-roofing/",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What safety precautions do you take?",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "At R.O. Steel Roofing Pty Ltd, safety is our priority. All procedures comply with Work Cover Regulations, Work, Health & Safety Legislation and Industry Codes and Practices. In addition, site specific safety management plans and safe work methods are formulated and implemented for each individual project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FAQs",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Visit Our Website To Learn More",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing for commercial and industrial properties",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Find out about R.O. Steel Roofing Asbestos related services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "View our projects and photos",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Find out what others say about our services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yellow Pages",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "People Also Viewed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": "https://www.whereis.com/find/roofing-construction-services/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roofing-construction-services/annandale-nsw-2038",
                                                "anchor_text": "Roofing Construction & Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.whereis.com/find/roof-restoration-repairs/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-restoration-repairs/annandale-nsw-2038",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Acid Proofing",
                                        "url": "https://www.whereis.com/find/acid-proofing/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/acid-proofing/annandale-nsw-2038",
                                                "anchor_text": "Acid Proofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": "https://www.whereis.com/find/roofing-construction-services/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roofing-construction-services/annandale-nsw-2038",
                                                "anchor_text": "Roofing Construction & Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tiles",
                                        "url": "https://www.whereis.com/find/roof-tiles/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-tiles/annandale-nsw-2038",
                                                "anchor_text": "Roof Tiles"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Window Roller Shutters",
                                        "url": "https://www.whereis.com/find/window-roller-shutters/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/window-roller-shutters/annandale-nsw-2038",
                                                "anchor_text": "Window Roller Shutters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Popular Categories",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Plumbers in Annandale",
                                        "url": "https://www.whereis.com/find/plumbers-gas-fitters/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/plumbers-gas-fitters/annandale-nsw-2038",
                                                "anchor_text": "Plumbers in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electricians in Annandale",
                                        "url": "https://www.whereis.com/find/electricians-electrical-contractors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/electricians-electrical-contractors/annandale-nsw-2038",
                                                "anchor_text": "Electricians in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lawyers in Annandale",
                                        "url": "https://www.whereis.com/find/lawyers-solicitors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/lawyers-solicitors/annandale-nsw-2038",
                                                "anchor_text": "Lawyers in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pest Control in Annandale",
                                        "url": "https://www.whereis.com/find/pest-control/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/pest-control/annandale-nsw-2038",
                                                "anchor_text": "Pest Control  in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mechanics in Annandale",
                                        "url": "https://www.whereis.com/find/mechanics-motor-engineers/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/mechanics-motor-engineers/annandale-nsw-2038",
                                                "anchor_text": "Mechanics in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Locksmiths in Annandale",
                                        "url": "https://www.whereis.com/find/locksmiths-locksmith-services/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/locksmiths-locksmith-services/annandale-nsw-2038",
                                                "anchor_text": "Locksmiths in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Concreters in Annandale",
                                        "url": "https://www.whereis.com/find/concrete-contractors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/concrete-contractors/annandale-nsw-2038",
                                                "anchor_text": "Concreters in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Fencing Contractors in Annandale",
                                        "url": "https://www.whereis.com/find/fencing-contractors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/fencing-contractors/annandale-nsw-2038",
                                                "anchor_text": "Fencing Contractors in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Builders in Annandale",
                                        "url": "https://www.whereis.com/find/builders-building-contractors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/builders-building-contractors/annandale-nsw-2038",
                                                "anchor_text": "Builders in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Accountants in Annandale",
                                        "url": "https://www.whereis.com/find/accountants-auditors/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/accountants-auditors/annandale-nsw-2038",
                                                "anchor_text": "Accountants in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our directory.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "About Yellow Pages",
                                        "url": "https://www.whereis.com/pages/about-us",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/pages/about-us",
                                                "anchor_text": "About Yellow Pages"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://www.whereis.com/pages/contact-us",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/pages/contact-us",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Site Index",
                                        "url": "https://www.whereis.com/sitemap",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/sitemap",
                                                "anchor_text": "Site Index"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Order or cancel your book",
                                        "url": "https://www.directoryselect.com.au/action/home",
                                        "urls": [
                                            {
                                                "url": "https://www.directoryselect.com.au/action/home",
                                                "anchor_text": "Order or cancel your book"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://www.whereis.com/pages/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/pages/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our advertising.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a free listing",
                                        "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                                "anchor_text": "Get a free listing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Digital marketing solutions",
                                        "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                                "anchor_text": "Digital marketing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Business hub",
                                        "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                                "anchor_text": "Business hub"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "myYellow login",
                                        "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                                "anchor_text": "myYellow login"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Connect with us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What related services can you provide?",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Flashings, downpipes, guttering, skylights, wall cladding, asbestos removal, roof removal, roof repair and restoration, roof construction, insulation. Contact us if you have specific needs and we will customise our service and inclusions to suit.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Construction & Services",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Specialists In Commercial And Industrial Properties",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": "https://www.whereis.com/find/roofing-construction-services/annandale-nsw-2038",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roofing-construction-services/annandale-nsw-2038",
                                                "anchor_text": "Roofing Construction & Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "R.O. Steel Roofing Pty Ltd opening hours in Annandale",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Construction & Services near me",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Us",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Specialties",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "New roof construction",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof removal",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Asbestos removal",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Wall cladding",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Skylight installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guttering and downpipes",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Payment Methods",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "View PDF",
                                        "url": "https://s0.yellowpages.com.au/98459f75-2c08-4366-b1ab-5f472c99992c/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                        "urls": [
                                            {
                                                "url": "https://s0.yellowpages.com.au/98459f75-2c08-4366-b1ab-5f472c99992c/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                                "anchor_text": "View PDF"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "PDF - 2.1mb",
                                        "url": "https://s0.yellowpages.com.au/98459f75-2c08-4366-b1ab-5f472c99992c/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                        "urls": [
                                            {
                                                "url": "https://s0.yellowpages.com.au/98459f75-2c08-4366-b1ab-5f472c99992c/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                                "anchor_text": "PDF - 2.1mb"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View PDF",
                                        "url": "https://s0.yellowpages.com.au/e0300479-b49f-4b03-8229-ef8a0ef42ce0/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                        "urls": [
                                            {
                                                "url": "https://s0.yellowpages.com.au/e0300479-b49f-4b03-8229-ef8a0ef42ce0/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                                "anchor_text": "View PDF"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "PDF - 5.9mb",
                                        "url": "https://s0.yellowpages.com.au/e0300479-b49f-4b03-8229-ef8a0ef42ce0/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                        "urls": [
                                            {
                                                "url": "https://s0.yellowpages.com.au/e0300479-b49f-4b03-8229-ef8a0ef42ce0/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                                "anchor_text": "PDF - 5.9mb"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View PDF",
                                        "url": "https://s0.yellowpages.com.au/ae516f5d-b26c-47ce-a4fe-49d68a110daa/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                        "urls": [
                                            {
                                                "url": "https://s0.yellowpages.com.au/ae516f5d-b26c-47ce-a4fe-49d68a110daa/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                                "anchor_text": "View PDF"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "PDF - 5.6mb",
                                        "url": "https://s0.yellowpages.com.au/ae516f5d-b26c-47ce-a4fe-49d68a110daa/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                        "urls": [
                                            {
                                                "url": "https://s0.yellowpages.com.au/ae516f5d-b26c-47ce-a4fe-49d68a110daa/ro-steel-roofing-pty-ltd-annandale-2038-document.pdf",
                                                "anchor_text": "PDF - 5.6mb"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Products and Services",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hours of Operation",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Flexible Hours, Open Monday - Friday",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Association",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Issues",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Condensation, Leaks, Rust, Storm Damage",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Catering To",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Architects, Builders, Contractors, Engineers, Fabricators, Metal Workers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Rating",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Over 30 Years, Over 40 Years",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FAQs",
                                "main_title": "R.O. Steel Roofing Pty Ltd",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": [
                            {
                                "name": "R.O. Steel Roofing Pty Ltd",
                                "price": 0,
                                "price_currency": null,
                                "price_valid_until": null
                            }
                        ],
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 9566 1554",
                                "0295661554",
                                "0425227097",
                                "0418232538"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}