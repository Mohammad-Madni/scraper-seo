{
    "id": "01190727-1132-0216-0000-da47d2f46315",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0353 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneywideroofingco.com.au/city-of-sydney/annandale/",
        "target": "sydneywideroofingco.com.au",
        "start_url": "https://sydneywideroofingco.com.au/city-of-sydney/annandale/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Annandale-(NSW)\\organic\\type-organic_rg20_ra26_sydneywideroofingco.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:48 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipes",
                                    "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                            "anchor_text": "Gutters and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tile Pointing and Bedding",
                                    "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                            "anchor_text": "Roof Tile Pointing and Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Roofing",
                                    "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                            "anchor_text": "Zinc Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs in Randwick NSW",
                                    "url": "https://sydneywideroofingco.com.au/randwick/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/randwick/",
                                            "anchor_text": "Roof Repairs in Randwick NSW"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Georges River",
                                    "url": "https://sydneywideroofingco.com.au/georges-river/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/georges-river/",
                                            "anchor_text": "Georges River"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Inner West Roof Repairs",
                                    "url": "https://sydneywideroofingco.com.au/inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/inner-west/",
                                            "anchor_text": "Sydney Inner West Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "City of Sydney",
                                    "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                            "anchor_text": "City of Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "GET QUOTE",
                                    "url": "https://sydneywideroofingco.com.au/get-quote/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/get-quote/",
                                            "anchor_text": "GET QUOTE"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "95 Bellingara Rd, Miranda NSW 2228.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "(02) 8294 4654",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "The Annandale Roofing Difference: Why We\u2019re the Top Choice",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "G\u2019day, fellow Annandale residents! Roofing in Annandale has been our game for decades. Whether you\u2019re on the Northside or Southside, chances are you\u2019ve seen our team in action. Remember that big hailstorm a few years back? We were there, offering roof repair in Annandale when our community needed it the most.",
                                        "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                                "anchor_text": "roof repair in Annandale"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Comprehensive Roof Leak Repair in Annandale",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Leaks can be pesky little problems, often causing more damage than one might think. Remember when the community centre had that small drip? Turned out to be a bigger issue. Luckily, we stepped in for a thorough roof leak repair. Whether it\u2019s minor drips or major downpours inside, we\u2019ve got the skills and expertise to seal the deal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Comprehensive Roof Leak Repair in Annandale",
                                        "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                                "anchor_text": "Roof Leak Repair in Annandale"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Annandale \u2013 Breathing Life Back Into Your Home",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "With the unpredictable Aussie weather, your roof can take a beating. Over the years, we\u2019ve turned many a weathered roof into something straight out of a magazine, showcasing our roof restoration in Annandale expertise.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration Annandale \u2013 Breathing Life Back Into Your Home",
                                        "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration Annandale"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Don\u2019t Wait For Damage: Roof Maintenance Annandale",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We can\u2019t stress this enough \u2013 roof maintenance in Annandale can save you heaps in the long run. Regular checks and minor fixes can prevent those bigger issues that hit the wallet hard.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Annandale: The Durable Choice",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Thinking about switching to metal roofing? It\u2019s a great choice for durability, especially in the Annandale climate. Plus, metal roofing offers a modern aesthetic that can completely transform your home\u2019s look.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters and Downpipes Annandale \u2013 More Than Just Accessories",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Your roof\u2019s best friends are its gutters and downpipes. We\u2019ve all seen what happens when these get clogged \u2013 it\u2019s not pretty. Our team ensures your gutters and downpipes are in tip-top shape, preventing potential water damage and keeping your home looking sharp.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Wide Range of Services in Annandale",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From re-roofing in Annandale to introducing the classic charm of roof tiling, we do it all. Our team is equipped with the latest tools and techniques to ensure your home remains the pride of Annandale. With our experience in metal roofing in Annandale and expertise in managing those essential gutters and downpipes, you can be sure your roof is in the best hands.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How to identify issues?",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "The obvious method of detection is to notice dark water stains on your roof or leaks through light fittings. Less noticeable signs of roofing issues include wind drafts, mould development or strange creaking or banging noises emanating from your roof. Is is urged that you immediately call us when you first notice any of these warning signs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You may notice the mortar/concrete or bedding holding the ridge capping together is beginning to deteriorate. Or worse notice that tiles have shifted or are missing altogether. Your gutters may be full or overflowing or possibly pulling away from the house, causing leaks to your fascia\u00a0and soffits. Another common type of problem is your flashing have holes or has been separated from the join along your masonry or chimney.",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                                "anchor_text": "ridge capping"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "You might walk outside and notice that the roof tiles have shifted, or even worse, are missing altogether. Your gutters may be full, or pulling away from the house, causing leaks around the edges of the house. The roof might have flashing pulled away from the edges of the roof surface, or you might have noticed missing bricks or flashing around a chimney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why are roofs so important?",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Our Glebe based roofing company can do so much more for your family than just repair of replace your roof. Your roofs health keeps your family safe and healthy. Our roof ventilation service helps the air circulation throughout your home and prevents mould growth. The roof of a house also adds immense value to the properties \u2018kerb appeal\u2019. Buyers will be sure to notice the clean lines of your gutters and downpipes, the addition of skylights and whirly-birds.",
                                        "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                                "anchor_text": "gutters and downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We are experts in roof materials",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We will give you a variety of options when it comes to the roofing materials used for your job. We have expert knowledge in using; tiles, metal, corrugated, colorbond, zinc, copper and polycarbonate roofing.",
                                        "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                                "anchor_text": "zinc"
                                            },
                                            {
                                                "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                                "anchor_text": "copper"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We have long served the residents of Annandale with a competitively priced and comprehensive roofing service. Some of our fondest past projects are located in the inner city suburb of Annandale. Some of these include; tiled roofing government contract at the Annandale Public School and the Empire Hotel",
                                        "url": "https://goo.gl/maps/55cjcmgTj7oxeD7D7",
                                        "urls": [
                                            {
                                                "url": "https://goo.gl/maps/55cjcmgTj7oxeD7D7",
                                                "anchor_text": "Annandale"
                                            },
                                            {
                                                "url": "https://g.page/empirehotelannandale?share",
                                                "anchor_text": "Empire Hotel"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Experts in Roof Repair",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roof repair service includes general repairs, repairs of broken or damaged tiles, repair of roof hips and skellions and repair of water leaks",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installs",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A re-roofing or brand new roof install project can be stressful project, which is why you need the best contractors to help ease you through the process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Bedding",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Pointing has the function of binding the ridge capping onto the tiles so that the tiles do not get blown off in strong winds.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "December 21st, 2025 |",
                                        "url": "https://sydneywideroofingco.com.au/author/admin/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/author/admin/",
                                                "anchor_text": "admin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Picture water slowly tracking under your roof tiles during Sydney's next downpour. Not through obvious damage you can see, but through tiny gaps where metal meets tile. That's the reality when flashing fails. And it",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                        "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                                "anchor_text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Steps to Fix Broken, Cracked, or Dislodged Roof Tiles",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "November 14th, 2025 |",
                                        "url": "https://sydneywideroofingco.com.au/author/admin/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/author/admin/",
                                                "anchor_text": "admin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Broken, cracked, or dislodged roof tiles can lead to major issues if not repaired quickly. These tiles shield your home from the weather, and any damage could allow leaks or water to cause further harm.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Steps to Fix Broken, Cracked, or Dislodged Roof Tiles",
                                        "url": "https://sydneywideroofingco.com.au/steps-to-fix-broken-cracked-or-dislodged-roof-tiles/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/steps-to-fix-broken-cracked-or-dislodged-roof-tiles/",
                                                "anchor_text": "Steps to Fix Broken, Cracked, or Dislodged Roof Tiles"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "October 10th, 2025 |",
                                        "url": "https://sydneywideroofingco.com.au/author/admin/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/author/admin/",
                                                "anchor_text": "admin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Clogged gutters cause issues for your roof, especially for tiles and ridge capping. Blocked gutters lead to water overflow, which can damage the roof structure. This damages the tiles and ridge capping, resulting in leaks",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                        "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                                "anchor_text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Highly Rated Roofing Company located in Newtown, City of Sydney",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Wide Roofing Co \u2013 Newtown is located on 305/88 King St, Newtown NSW 2042. From Sydney Airport (SYD) take Airport Dr and O\u2019Riordan st to Wyndham st in Alexandria. Turn left onto Wyndham st. Take Cleveland st to Princess Hwy/A36 in Newtown.",
                                        "url": "https://goo.gl/maps/YW9VD72zu1R5jkmB7",
                                        "urls": [
                                            {
                                                "url": "https://goo.gl/maps/YW9VD72zu1R5jkmB7",
                                                "anchor_text": "Sydney Wide Roofing Co \u2013 Newtown"
                                            },
                                            {
                                                "url": "https://goo.gl/maps/VQmcvuzbPFsmxNGk9",
                                                "anchor_text": "Newtown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We\u2019re open Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For additional questions you can call us at 61282944654 or you can find us on Hotfrog.",
                                        "url": "https://www.hotfrog.com.au/company/1072156708818944",
                                        "urls": [
                                            {
                                                "url": "https://www.hotfrog.com.au/company/1072156708818944",
                                                "anchor_text": "Hotfrog"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Freshen up your Roof",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We specialise in the restoration of all types of roofs including; Colorbond, slate, metal, tin, terracotta and tiled.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Roofing",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leak Repair",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof leaks may be insignificant to begin with. However, they can soon turn into an expensive problem with water damage and mould",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters Downpipes",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Freshen up your Roof",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If not properly maintained your gutter and down-pipe system can soon cause an immense amount of damage to your home",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Pointing",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Portfolio",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burraneer Bay Residential",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Burraneer Bay Residential",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                                "anchor_text": "Burraneer Bay Residential"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing Project Sydney",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing Project Sydney",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                                "anchor_text": "Slate Roofing Project Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Project Eastern Suburbs",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Project Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                                "anchor_text": "Metal Roofing Project Eastern Suburbs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Handy Tips About Roofing",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leaks",
                                        "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                                "anchor_text": "Roof Leaks"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-roofing",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Re-roofing",
                                        "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                                "anchor_text": "Re-roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Downpipes",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                                "anchor_text": "Roof Tiling"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Latest News",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                        "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                                "anchor_text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                        "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                                "anchor_text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Read all of our reviews on Google +",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Read all of our reviews on Google +",
                                        "url": "https://plus.google.com/u/0/117630578737877513335/about/",
                                        "urls": [
                                            {
                                                "url": "https://plus.google.com/u/0/117630578737877513335/about/",
                                                "anchor_text": "Read all of our reviews on Google +"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations We Service",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sutherland Shire",
                                        "url": "https://sydneywideroofingco.com.au/home/sutherland-shire/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/home/sutherland-shire/",
                                                "anchor_text": "Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/home/eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/home/eastern-suburbs/",
                                                "anchor_text": "Eastern Suburbs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "City of Sydney",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney",
                                                "anchor_text": "City of Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georges River",
                                        "url": "https://sydneywideroofingco.com.au/sydney/georges-river/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sydney/georges-river/",
                                                "anchor_text": "Georges River"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Inner West",
                                        "url": "https://sydneywideroofingco.com.au/inner-west",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west",
                                                "anchor_text": "Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Northern Beaches",
                                        "url": "https://sydneywideroofingco.com.au/sydney/northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sydney/northern-beaches/",
                                                "anchor_text": "Northern Beaches"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Central Coast",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Building Inspiring Roofs",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Only takes a few seconds!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Roofing",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heritage Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/heritage-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/heritage-roofing/",
                                                "anchor_text": "Heritage Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Copper Roofing",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Copper Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/copper-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/copper-roofing/",
                                                "anchor_text": "Copper Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/slate-roofing/",
                                                "anchor_text": "Slate Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Zinc Roofing",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Zinc Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/zinc-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/zinc-roofing/",
                                                "anchor_text": "Zinc Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations in the City of Sydney Council We Service",
                                "main_title": "Annandale Roofing Service | Call us on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Centennial Park",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/centennial-park",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/centennial-park",
                                                "anchor_text": "Centennial Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dawes Point",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/dawes-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/dawes-point",
                                                "anchor_text": "Dawes Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Elizabeth bay",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/elizabeth-bay",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/elizabeth-bay",
                                                "anchor_text": "Elizabeth bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Forest Lodge",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/forest-lodge",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/forest-lodge",
                                                "anchor_text": "Forest Lodge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Millers Point",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/millers-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/millers-point",
                                                "anchor_text": "Millers Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Moore Park",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/moore-park",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/moore-park",
                                                "anchor_text": "Moore Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Potts Point",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/potts-point",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/potts-point",
                                                "anchor_text": "Potts Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rushcutters Bay",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/rushcutters-bay",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/rushcutters-bay",
                                                "anchor_text": "Rushcutters Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Peters",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/st-peters",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/st-peters",
                                                "anchor_text": "St Peters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Surry Hills",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/surry-hills",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/surry-hills",
                                                "anchor_text": "Surry Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Rocks",
                                        "url": "https://sydneywideroofingco.com.au/city-of-sydney/the-rocks",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/city-of-sydney/the-rocks",
                                                "anchor_text": "The Rocks"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "61282944654",
                                "+61282944654"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}