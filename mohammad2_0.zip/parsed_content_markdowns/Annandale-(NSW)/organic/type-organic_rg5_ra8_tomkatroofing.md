{
    "id": "01190727-1132-0216-0000-5116986b773a",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0272 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://tomkatroofing.com.au/annandale/",
        "target": "tomkatroofing.com.au",
        "start_url": "https://tomkatroofing.com.au/annandale/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Annandale-(NSW)\\organic\\type-organic_rg5_ra8_tomkatroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:48 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Unit 4, 16 Bernera Road Prestons NSW 2170",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "\ud83c\udf84 Christmas Close-Out: Closed from 23 December \u2013 Back on 12 January \ud83c\udf81 | Wishing you a Merry Christmas & Happy New Year! \ud83c\udf85\u2728",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\ud83c\udf84 Christmas Close-Out: Closed from 23 December \u2013 Back on 12 January \ud83c\udf81 | Wishing you a Merry Christmas & Happy New Year! \ud83c\udf85\u2728",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Project",
                                    "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                            "anchor_text": "New Roof Project"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters & Downpipes",
                                    "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                            "anchor_text": "Gutters & Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports & Inspections",
                                    "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                            "anchor_text": "Roof Reports & Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://tomkatroofing.com.au/service-area/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/service-area/",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://tomkatroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Project",
                                    "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                            "anchor_text": "New Roof Project"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters & Downpipes",
                                    "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                            "anchor_text": "Gutters & Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports & Inspections",
                                    "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                            "anchor_text": "Roof Reports & Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://tomkatroofing.com.au/service-area/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/service-area/",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://tomkatroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "1300 866 528",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Call Us Today!",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Roof Repair and Maintenance",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We offer regular maintenance services to prolong the lifespan of your roof. Our Alexandria roofing company offers thorough inspections and preventative maintenance services to identify minor issues before they escalate.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement in Alexandria",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If your roof is beyond repair, our Alexandria roofing company offers expert roof replacement services. We replace tile, metal, flat, and commercial roofs, ensuring a durable and hassle-free solution.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections and Reports",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Property owners, buyers, and insurance companies often require professional roof inspections. Our Alexandria roofing contractors provide detailed reports outlining the condition of your roof, any existing damage, and recommendations for maintenance or repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter and Downpipe Repairs",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Clogged or damaged gutters can cause serious water damage. We provide gutter cleaning, downpipe repairs, and high-quality gutter replacements for long-term protection.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Water Stains and Mould Growth",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Unexplained water stains on ceilings or walls often indicate a leak. Mould growth in damp areas can also signal moisture penetration. Ignoring these signs can lead to structural damage and costly repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Damaged or Missing Roof Tiles",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Broken, cracked, or missing tiles compromise your roof's ability to protect your home. Strong winds, hail, and general wear can cause damage that worsens over time. If you spot visible exterior issues, it's time to call a professional Annandale roofing contractor.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Blocked or Damaged Gutters",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Gutters direct rainwater away from your home. Blocked, sagging, or broken gutters can cause water to pool on your roof, leading to leaks and structural issues. Regular maintenance is essential to avoid costly damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Rising Energy Bills",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Poor insulation due to a damaged roof can cause temperature fluctuations inside your home, leading to higher heating and cooling costs. If your energy bills are increasing without a clear reason, your roof might be the problem.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Annandale Roof Replacement vs. Roof Repair",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If repairs are frequent and costly, replacement may save money in the long run.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "An old roof nearing the end of its lifespan will require increasing maintenance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Structural damage, such as sagging or widespread leaks, often warrants replacement.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Upgrading to modern, energy-efficient materials can improve insulation and reduce bills.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Deciding whether you need to repair or replace your roof can be challenging. Repairs are a cost-effective solution for minor issues, but if your roof is significantly aged or damaged, a full roof replacement in Annandale might be the better option. Our experts will assess your roof\u2019s condition and recommend the most cost-effective and durable solution for your property. Consider the following:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repair Process",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Tomkat Roofing, we follow a straightforward and transparent approach to roof repair in Annandale:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Common Roof Issues We Handle",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Tomkat Roofing offers comprehensive Annandale roof repair services to tackle a range of roofing issues, including:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leak detection and repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof tile and sheet repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Total roof replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rebedding and pointing of ridge capping",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter and downpipe repair and replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fascia and eave repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Skylight repair, replacement and installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Pressure cleaning and restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whirly birds replacement",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Storm damage repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Pergola repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flashing repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaf screen installation",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Over 20 Years of Roofing Expertise",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tomkat Roofing has been a leading Annandale roofing company for more than two decades. Our extensive experience allows us to handle all types of roofing projects, from small repairs to full-scale replacements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Licensed and Insured Professionals",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our team consists of fully licensed and insured Annandale roofing contractors, ensuring all work meets safety standards and local regulations. We use high-quality materials and proven techniques for durable and long-lasting results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Customer-Focused Service",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Each of our roofing contractors in Annandale believes in delivering exceptional customer service. We keep you informed and involved from the initial inspection to project completion. Our transparent pricing and detailed roof reports ensure that you understand every aspect of the job.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commitment to Safety and Compliance",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing work involves risks, but our team is trained in safe work practices, including working at heights. We comply with all occupational health and safety (OH&S) regulations to protect our workers and clients.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Happy Clients Are Saying",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I have had a fantastic experience with this business from start to finish. They are professional experienced, very fair and reasonable. We needed to replace the roof on our outdoor deck which was slightly tricky. Their advice and suggestions regarding product to use was sage. After a downpour there was a bit of a leak between the main building and the deck roof which they came out to fix which resolved the issue. There have been plenty of downpours since and everything is fine. I would highly recommend this company without hesitation. They are excellent.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tomkat did a great job and they were very pleasant to deal with.\nI\u2019d definitely preference them for any similar work in the future!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thankyou to TomKat Roofing and particulary Scott who did an excellent job repairing my roof.\nI had a water stain on the ceiling in one of my rooms, I called TomKat Roofing.\nThey sent out a technician (Tim I think his name was) to have a look at the roof and that was followed by a very clear & comprehensive quote with what work needed to be done. The quote was supported by photos of the roof showing the problem areas. Tim was very polite & knowledgeable. He explained to me what needed to be done as a matter of urgency and what would need to be done for maintenance purpose and he showed me the photos.\nThe price was very reasonable for the work that needed to be done.\nScott carried out the repair work. Scott is very pleasant to deal and he knew exactly what he was doing. He worked just about all day to finish the job for me and I was very happy with the results and my roof problems have now been solved.\nI was very impressed with everyone I dealt with, from the ladies in the office who prepared my quote to Scott who completed the job , they are all very friendly and most of all they know their stuff. I think they're an asset to TomKat.\nI highly recommend TomKat Roofing and I would definitely use them again.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tomkat Roofing was a great place to do business with from the initial phone call, to Gary who came out to give me a quote arrived on time and was very helpfull in his advise.The job was completed in a highly professional manner. I will have no problems using this company for any future roofing work. Great work to the whole team at Tomkat",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I contacted the team at TomKat roofing as I noticed a small leak in my daughters room during the recent storms and I was pleasantly greeted over the phone by the admin team who took down all my details and soon after I had the scheduling team call and arrange a suitable time to come out and review my concerns.\nThe team promptly identified what the issue was and fixed it promptly.\nI can\u2019t thank the team enough and whilst I hope I never need to call them again due to a roof issue, I would gladly recommend them to anyone looking for professional workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I highly recommend Tomkat Roofing for an efficient, well priced and solid quality roof replacement. My old, droopy and leaking terracotta tile roof is now straight and strong with a reinforced structure, new corrugated colorbond roof, gutters, facias, downpipes and leaf guard.\nSome of the key positive experiences I had with Tomkat Roofing are:\nThe efficient and friendly office staff always responded quickly and kept me informed of the progress and when the tradesmen would be onsite.\nAt the start of the job, within a single work day, they had a team of roofers and carpenters to get the old tiles off, the roof structure repaired/reinforced and the colorbond sheets with insulation secured so that my home was protected from the weather. Fortunately the weather was clear for a few days, but it was reassuring to know that they were prepared to work incredibly fast in the summer sun to keep my home safe.\nThe site supervisors were always friendly and took the time to explain everything to me and respond to any concerns or questions I had about the job. Being an older build home, I had a few items that needed particular attention and everything was completed to my satisfaction.\nA word of advice for home owners looking to get a roof replaced with Tomkat Roofing: Raise as many of your objectives and concerns as you can as early as possible. I found the Tomkat team very responsive to my overthinking mind and everything I wanted to get done was outlined in the quote and addressed during the job.\nAlso, they do tidy up and take away all the waste building material during and at the end of the job, which is great. But be prepared each evening to clean up smaller items that take time to find, like random screws or nails that were dropped, if you have children or pets accessing the area around your home in the evenings. It is unreasonable to expect the workers to find every dropped item each day if you also want the job done quickly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Helen O'Connor",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ali Bugeja",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lisa Anthony",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Christine Puckering",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Peter Thomas",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sully 71",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mike Cohen",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does a roof repair cost?",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The cost varies depending on the extent of damage, roof type, and required materials. We provide free inspections and quotes to give you an accurate estimate.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Can I repair my roof myself?",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof repairs should always be handled by professionals to ensure safety and quality workmanship. DIY fixes often lead to more significant problems down the line.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why should I have my roof inspected regularly?",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Getting an inspection is essential for the longevity of your roof; it provides a clear understanding of the roof\u2019s condition and identifies any necessary repairs or replacements that must be addressed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long does a roof repair take?",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Minor repairs can be completed within a day, while more extensive work may take a few days. Our team works in the most efficient manner to minimise disruption to your home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Will my insurance cover roof repairs?",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Insurance policies vary, but many cover storm damage and unexpected leaks. We can assist with insurance claims by providing detailed reports and assessments.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Expert Roof Repair Services in Annandale",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "You Can Count On Us For All Your Roofing Needs!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get Your Free Roofing Quote Today!",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Roof Repair Services for Homes and Businesses in Annandale",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Your roof protects your home from the elements, but years of exposure to rain, wind, and sun can take a toll.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tomkat Roofing is a trusted Annandale roofing company that offers professional repairs and maintenance to keep your roof in top condition.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our skilled team is here to help, whether you need minor roof leak repair in Annandale or a complete roof replacement. We\u2019ve got your roof covered every step of the way!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repair and Maintenance Services in Annandale",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Tomkat Roofing for Reliable Roof Repairs in Alexandria",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Don\u2019t wait for roof damage to worsen\u2014our professional roof repair services in Alexandria keep your home or business protected. Contact Tomkat Roofing for a free quote and expert care from our experienced Alexandria contractors, offering quality, cost-effective solutions tailored to your needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Signs You Need Roof Repair in Annandale",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Not all roofing problems are immediately visible. Some issues develop slowly, causing long-term damage before they are detected. Look out for:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "01",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Inspection & Assessment",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We conduct a thorough inspection to identify issues and evaluate the overall condition of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "02",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Detailed Report & Quote",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We provide a comprehensive report outlining the necessary repairs, along with a clear, upfront quote.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "03",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Repair & Replacement",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Once approved, our expert roofers carry out the repairs or replacements using high-quality materials.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "04",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Final Inspection",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We perform a final quality check to ensure everything is in top condition before completing the job.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose\nTomkat Roofing for Roof Repair in Annandale?",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FAQs About Roof Repairs in Annandale",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get Finance In A Few Minutes",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "No Impact On Your Credit Score",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fast Pre-approval",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fortified Data Protection",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quick Links",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Services",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacements",
                                        "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                                "anchor_text": "Roof Replacements"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "New Roof Projects",
                                        "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                                "anchor_text": "New Roof Projects"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspection & Reports",
                                        "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                                "anchor_text": "Roof Inspection & Reports"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Details",
                                "main_title": "Expert Roof Repair Services in Annandale",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Unit 4, 16 Bernera Road Prestons NSW 2170",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Terms of Use | Privacy Policy",
                                        "url": "https://www.thryv.com/client-terms-of-use/",
                                        "urls": [
                                            {
                                                "url": "https://www.thryv.com/client-terms-of-use/",
                                                "anchor_text": "Terms of Use"
                                            },
                                            {
                                                "url": "https://www.thryv.com/client-privacy-policy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "\u00a9 2025 Tomkat Roofing. All Rights Reserved.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "1300866528"
                            ],
                            "emails": [
                                "%20info@tomkatroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}