{
    "id": "01190727-1132-0216-0000-686ac83cb4f9",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0187 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.allroofingservices.com.au/roof-replacement-annandale/",
        "target": "www.allroofingservices.com.au",
        "start_url": "https://www.allroofingservices.com.au/roof-replacement-annandale/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Annandale-(NSW)\\organic\\type-organic_rg6_ra10_allroofingservices.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:50 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "ARS are local roofing contractors owned and operated by Julian Dirou. Julian is a very experienced and licensed metal roof plumber who believes in doing things properly the first time, without short cuts and never compromising on quality.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright \u00a9 2026 All Roofing Services",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "On Time And On Budget.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "We Never Compromise On Quality.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Fully Insured And Licensed.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "A Great Team Of Experienced, Friendly & Competent Roofers.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Free Inspections, Consultations And Quotes.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Voted Top Roofing Business For 3 Years.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "618 Parramatta Road,",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Croydon NSW 2132 Australia",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Office: 02 8086 2059",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mobile: 0406 969 061",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "info@allroofingservices. com.au",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Website by Nasyana Marketing",
                                    "url": "https://www.nasyana.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://www.nasyana.com.au/",
                                            "anchor_text": "Nasyana Marketing"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Enhance Your Home with High-Quality Roof Replacements",
                                "main_title": "All Roofing Services: Expert Roof Replacement in Annandale and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At All Roofing Services, we specialize in expert roof replacements in Annandale and throughout Sydney. Our fully licensed and insured team of experienced roofers is committed to delivering exceptional results and customer satisfaction. Whether you need a re-roof, roof replacement, or Colorbond roof replacement, we have the expertise to meet your needs.",
                                        "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                                "anchor_text": "roof replacements"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/re-roofing/",
                                                "anchor_text": "re-roof"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                                "anchor_text": "Colorbond roof replacement"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose All Roofing Services for Your Roof Replacement?",
                                "main_title": "All Roofing Services: Expert Roof Replacement in Annandale and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "When it comes to roof replacements, we stand out for several reasons:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully Licensed and Insured: We are a fully licensed and insured roofing contractor, ensuring the highest standards of professionalism and safety.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Experienced and Friendly Roofers: Our team consists of experienced, friendly, and competent roofers who take pride in their work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality Workmanship: We offer a 7-year workmanship guarantee on all our roof replacement projects, giving you peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free Inspections, Consultations, and Quotes: We provide free inspections, consultations, and quotes to assess your roof and provide accurate estimates.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacements in Annandale and Surrounding Suburbs",
                                "main_title": "All Roofing Services: Expert Roof Replacement in Annandale and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Whether you have an aging roof or simply want to upgrade the look of your home, our roof replacement services are tailored to your needs. Our skilled team can handle a variety of roof replacement options, including Colorbond roofs, ensuring a durable and stylish solution for your property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Service Areas: Innerwest, North Sydney Suburbs, and Northwest Sydney",
                                "main_title": "All Roofing Services: Expert Roof Replacement in Annandale and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "While our main service area is the Innerwest, we also cater to the North Sydney Suburbs and Northwest Sydney, particularly for roof replacements. No matter where you are located in Sydney, we are dedicated to providing exceptional roofing services that meet your specific requirements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Award-Winning Roofers with a Strong Reputation",
                                "main_title": "All Roofing Services: Expert Roof Replacement in Annandale and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "All Roofing Services is proud to have been recognized as the best roofers out of 137 top Sydney roofing companies for our reputation and professionalism in 2017, 2018, and 2020. This accolade reflects our commitment to excellence and customer satisfaction.",
                                        "url": "https://www.allroofingservices.com.au/roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/roofing-contractors/",
                                                "anchor_text": "best roofers out of 137 top Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us for Expert Roof Replacements in Annandale",
                                "main_title": "All Roofing Services: Expert Roof Replacement in Annandale and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ready to enhance your home with a high-quality roof replacement? Contact All Roofing Services today on 02 8086 2059 for expert roof replacements in Annandale and Sydney.",
                                        "url": "https://www.allroofingservices.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/contact-us/",
                                                "anchor_text": "Contact"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our friendly team is ready to provide you with a free inspection, consultation, and quote. Trust us to deliver exceptional results and a roof that will protect your home for years to come.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "All Roofing Services: Expert Roof Replacement in Annandale and Sydney",
                                "main_title": "All Roofing Services: Expert Roof Replacement in Annandale and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0406%20969%20061",
                                "0280862059"
                            ],
                            "emails": [
                                "info@allroofingservices.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}