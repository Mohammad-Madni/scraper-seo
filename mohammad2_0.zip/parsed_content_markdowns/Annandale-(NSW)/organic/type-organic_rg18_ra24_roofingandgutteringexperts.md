{
    "id": "01190727-1132-0216-0000-32156efb54c8",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0165 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service/annandale",
        "target": "www.roofingandgutteringexperts.com.au",
        "start_url": "https://www.roofingandgutteringexperts.com.au/areas-we-service/annandale",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Annandale-(NSW)\\organic\\type-organic_rg18_ra24_roofingandgutteringexperts.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:44 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Professional Roofing Solutions Sydney Wide",
                                    "url": "https://www.roofingandgutteringexperts.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/",
                                            "anchor_text": "Professional Roofing Solutions Sydney Wide"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Storm damage, urgent leaks, or emergency roofing issues in Sydney? Our licensed emergency repair team responds fast to prevent further property damage.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Sydney's most trusted roofing company delivering expert roofing solutions across Sydney, specialising in repairs, restorations, and installations for residential and commercial properties.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2025 Roofing & Guttering Experts. All rights reserved. ABN: 64 627 923 415",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://www.roofingandgutteringexperts.com.au/about",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/about",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Areas We Service",
                                    "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                            "anchor_text": "Areas We Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Reviews",
                                    "url": "https://www.roofingandgutteringexperts.com.au/reviews",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/reviews",
                                            "anchor_text": "Our Reviews"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get Quote",
                                    "url": "https://www.roofingandgutteringexperts.com.au/get-quote",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/get-quote",
                                            "anchor_text": "Get Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-restoration",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-repairs",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-replacement",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-replacement",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-painting",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-painting",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installations",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-installations",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-installations",
                                            "anchor_text": "Roof Installations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-inspections",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-inspections",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Skylights",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-skylights",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-skylights",
                                            "anchor_text": "Roof Skylights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Colorbond",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-colorbond",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-colorbond",
                                            "anchor_text": "Roof Colorbond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters, Eaves & Downpipes",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/gutters-eaves-downpipes",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/gutters-eaves-downpipes",
                                            "anchor_text": "Gutters, Eaves & Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-maintenance",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-maintenance",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-gutter-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/roof-gutter-cleaning",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Cleaning",
                                    "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/solar-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/roofing-services/solar-cleaning",
                                            "anchor_text": "Solar Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Shore",
                                    "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                            "anchor_text": "North Shore"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hills District",
                                    "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                            "anchor_text": "Hills District"
                                        }
                                    ]
                                },
                                {
                                    "text": "Western Sydney",
                                    "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                    "urls": [
                                        {
                                            "url": "https://www.roofingandgutteringexperts.com.au/areas-we-service",
                                            "anchor_text": "Western Sydney"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Expert Roofing\nAnnandale, NSW 2038",
                                "main_title": "Expert Roofing\nAnnandale, NSW 2038",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Professional roofing services in Annandale for residential and commercial properties. We service homes, businesses, and multi-unit buildings throughout the Annandale area with expert craftsmanship and reliable service.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Annandale Roofing by the Numbers",
                                "main_title": "Expert Roofing\nAnnandale, NSW 2038",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Available in Annandale",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average in Annandale area",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Annandale Projects",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Completed this year",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Emergency Service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Response Time",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Satisfaction Rate",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Annandale customers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Services in Annandale",
                                "main_title": "Expert Roofing\nAnnandale, NSW 2038",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Comprehensive roofing solutions for Annandale's residential and commercial properties",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Expert Roofing\nAnnandale, NSW 2038",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Emergency and scheduled roof repairs for Annandale homes and businesses",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We Also Service Nearby Areas",
                                "main_title": "Expert Roofing\nAnnandale, NSW 2038",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Professional roofing services across Sydney's suburbs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ready to Get Started in Annandale?",
                                "main_title": "Expert Roofing\nAnnandale, NSW 2038",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Contact Annandale's trusted roofing experts today for a free quote and consultation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Get Your Annandale Quote!",
                                "main_title": "Expert Roofing\nAnnandale, NSW 2038",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Your Phone Number",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installations",
                                "main_title": "Expert Roofing\nAnnandale, NSW 2038",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "New roof installations for Annandale's residential and commercial properties",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Local Area Specialists",
                                "main_title": "Expert Roofing\nAnnandale, NSW 2038",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Expert roofing services tailored to Annandale's unique requirements",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0295387209",
                                "0474349677"
                            ],
                            "emails": [
                                "info@roofingandgutteringexperts.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}