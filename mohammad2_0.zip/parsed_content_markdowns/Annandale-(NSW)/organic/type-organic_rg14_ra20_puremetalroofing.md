{
    "id": "01190727-1132-0216-0000-ae1b0fea98b5",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0391 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://puremetalroofing.com.au/roof-repairs-annandale/",
        "target": "puremetalroofing.com.au",
        "start_url": "https://puremetalroofing.com.au/roof-repairs-annandale/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Annandale-(NSW)\\organic\\type-organic_rg14_ra20_puremetalroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:51 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Pure Metal Roofing Pty Ltd",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Quick Links",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Newtown NSW 2042",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Berala NSW 2141",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN: 18 664 818 357",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Lic No. 388625C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "100% Satisfaction Guaranteed",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs in Annandale",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Protect your Annandale home or business with expert roof repairs from a trusted local team. We deliver fast, high-quality solutions for leaks, damage, and general wear\u2014done right the first time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Reliable Roof Repairs in Annandale You Can Count On",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Pure Metal Roofing, we know how Annandale\u2019s changing weather and older buildings can put pressure on your roof. Whether you\u2019re facing persistent leaks, storm damage, cracked tiles, rusted metal sheets, or deteriorated flashing, these issues can affect your property\u2019s safety, insulation, and overall integrity.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With over 30 years of hands-on Sydney roofing experience, our fully licensed and insured team delivers fast, reliable repairs tailored to Annandale\u2019s homes, commercial properties, and strata buildings. We use premium materials like Colorbond for long-lasting protection and seamless repairs that match your existing roof. Our team\u2019s familiarity with Annandale\u2019s common roofing styles lets us work efficiently and precisely. We identify not just the symptoms, but the root cause of roofing problems, ensuring repairs hold up over time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All work is performed by our in-house professionals\u2014from thorough inspections and clear assessments to precise repairs and final quality checks. No subcontractors, no shortcuts. Just trusted workmanship backed by a 10-Year Workmanship Guarantee for your peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether you\u2019re a homeowner, business owner, or strata manager in Annandale, Pure Metal Roofing provides tailored solutions to safeguard your property and keep your roof performing at its best.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Assessment",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our licensed roofers assess your roof to identify damage, wear, or potential issues.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quote & Approval",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Receive a clear, transparent quote for the required repairs. Once approved, we schedule the work",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Repair Work Begins",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our licensed in-house team completes repairs using high-quality materials for lasting result.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Final Inspection",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We conduct a final inspection to ensure all repairs meet our standards and your expectations.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Benefits of Choosing Pure Metal Roofing",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Over 30 years of trusted roofing experience in Sydney",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully licensed, insured, and compliant with all regulatory standards",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "In-house team (no subcontractors), ensuring quality control on every project",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium materials like Colorbond for durability and weather resistance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thorough inspections and repairs that address the root cause, not just the symptoms",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tailored solutions for residential, commercial, and strata properties in Annandale",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent, itemised quotes and clear communication throughout",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10-Year Workmanship Guarantee for long-lasting peace of mind",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Clients Who Trust Us in Annandale",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Pure Metal Roofing is proud to serve a diverse range of clients throughout Annandale, including:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Homeowners protecting their heritage and modern residences",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local businesses maintaining commercial properties and warehouses",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Strata managers overseeing multi-unit buildings and complexes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Builders and developers requiring reliable roofing solutions during renovations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Real estate agents ensuring roof inspections and repairs for property sales",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our trusted reputation is built on consistent quality, clear communication, and durable repairs tailored to the unique needs of Annandale\u2019s properties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "How quickly can you respond to urgent roof repairs in Annandale?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We aim to schedule repairs as promptly as possible to ensure your roof is protected without delay.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you provide a warranty on roof repairs?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, all our roof repairs come with a 10-Year Workmanship Guarantee for your peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Can you repair roofs on heritage or older homes in Annandale?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. Our team has extensive experience working on heritage and older properties, tailoring repairs to preserve their character.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What types of roofing materials do you repair?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We specialise in repairing metal roofs, including Colorbond, as well as tile roofs and mixed-material roofing systems.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Will you provide a detailed quote before starting any repair work?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we offer clear, transparent, and itemised quotes so you know exactly what to expect before work begins.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Testimonials",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Binbin Liang",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How It Works",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Request a Roof Inspection",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Contact us to schedule a convenient inspection with our expert team.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gallery",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Areas We Serve",
                                "main_title": "Roof Repairs in Annandale",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park",
                                        "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                                "anchor_text": "Croydon Park"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0422088256"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}