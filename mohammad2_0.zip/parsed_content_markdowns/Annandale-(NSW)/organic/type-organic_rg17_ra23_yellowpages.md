{
    "id": "01190727-1132-0216-0000-edee8cf20b6e",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0156 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.yellowpages.com.au/find/roofing-construction-services/balmain-nsw-2041",
        "target": "www.yellowpages.com.au",
        "start_url": "https://www.yellowpages.com.au/find/roofing-construction-services/balmain-nsw-2041",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Annandale-(NSW)\\organic\\type-organic_rg17_ra23_yellowpages.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:48 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roofing Construction & Services Near Me",
                                    "url": "https://www.yellowpages.com.au/find/roofing-construction-services/nsw",
                                    "urls": [
                                        {
                                            "url": "https://www.yellowpages.com.au/find/roofing-construction-services/nsw",
                                            "anchor_text": "Roofing Construction & Services Near Me"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balmain NSW",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Strata Roofing Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "I met with the operation manager who is really professional and gave me a good advice of my roof. And the reception did answer my questions very quickly. Thank you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Types of roof construction",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roofs need to be designed to suit the environment and purpose. A great roofing contractor takes advantage of various structures to build you a long lasting and efficient roof. So how many ways can you construct a roof?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A roof can be made out of thatch or iron, ceramic tiles or slate. Each have different costs and characteristics. Ceramic tiles and slates make up the majority of most household roofing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The slope of the roof can change depending on the weather and climate. Dry climates may have flat roofs, while areas where there\u2019s heavy rainfall or snow tend to have very pitched roofs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Most roofing companies use 3 constructions of roofing: single roofs, double roofs and trussed roofs. Single roofs have one layer of rafters (roofing) on each side of a central ridge. Double roofs have another point of support called a purlin under each rafter. Trussed roofs use framing to provide even stronger support.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Too many variables? Leave it to your professional roofer to build you a reliable roof. Use our \u2018Request Quote\u2019 button to directly get pricing from the roofing companies. View our local listings to find a roofing service near you today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Pro Blast Services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Pressure & Steam Cleaning Contractors, Chiswick, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pro Blast Services",
                                        "url": "https://www.yellowpages.com.au/nsw/chiswick/pro-blast-services-1000002995317-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/chiswick/pro-blast-services-1000002995317-listing.html",
                                                "anchor_text": "Pro Blast Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Izico",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Hunters Hill, NSW 2110",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Izico",
                                        "url": "https://www.yellowpages.com.au/sup/izico-14941886-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/izico-14941886-listing.html",
                                                "anchor_text": "Izico"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1300 557 747",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Safin Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Builders & Building Contractors, Mcmahons Point, NSW 2060",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Experienced in all forms of construction from new works to heritage restoration, from simple offices to complicated medical services and Schools.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Safin Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/mcmahons-point/safin-pty-ltd-12458158-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/mcmahons-point/safin-pty-ltd-12458158-listing.html",
                                                "anchor_text": "Safin Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "135 Blues Point Rd, Mcmahons Point, NSW, 2060",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=135+Blues+Point+Rd&context=undefined&directionMode=true&elat=-33.843537&elon=151.203619&ena=Safin+Pty+Ltd&estr=135+Blues+Point+Rd&esu=Mcmahons+Point%2C+NSW%2C+2060&productVersion=9&productId=486854490&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DSafin+Pty+Ltd%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.843537%26lon%3D151.203619%26selectedViewMode%3Dlist&yellowId=12458158",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=135+Blues+Point+Rd&context=undefined&directionMode=true&elat=-33.843537&elon=151.203619&ena=Safin+Pty+Ltd&estr=135+Blues+Point+Rd&esu=Mcmahons+Point%2C+NSW%2C+2060&productVersion=9&productId=486854490&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DSafin+Pty+Ltd%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.843537%26lon%3D151.203619%26selectedViewMode%3Dlist&yellowId=12458158",
                                                "anchor_text": "135 Blues Point Rd, Mcmahons Point, NSW, 2060"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 8920 0802",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Beach Constructions (NSW) Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Builders & Building Contractors, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Beach builds within live environments and meticulously develop site plans that ensure minimal disruption to day-to-day operations and highest safety standards.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Beach Constructions (NSW) Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/beach-constructions-nsw-pty-ltd-14636226-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/beach-constructions-nsw-pty-ltd-14636226-listing.html",
                                                "anchor_text": "Beach Constructions (NSW) Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:30pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9550 9199",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Piper's Plumbing Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters, Artarmon, NSW 2064",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Piper's Plumbing provide repairs and maintenance for commercial and residential. 24/7 service. Contact us",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Piper's Plumbing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/willoughby/pipers-plumbing-pty-ltd-12981862-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/willoughby/pipers-plumbing-pty-ltd-12981862-listing.html",
                                                "anchor_text": "Piper's Plumbing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9901 4866",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Frames & Trusses",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Trusses & Wall Frames",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For All Your Frames & Trusses Call Us Now For Value",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(02) 8783 8022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Garage Builders & Prefabricators",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Materials",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Custombuilt Frames & Trusses",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Trusses & Wall Frames",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "H2F Termite Resistant Timber Custom And Unique Plans Owner Builders",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(02) 4871 3355",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Gutter & Roof Restoration",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Slaters & Roof Tilers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Warning, Not All Roof Companies Are The Same",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "1300 654 884",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Carport & Pergola Builders",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Regent Skylights",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Factory Direct Skylights, Energy Efficient Patented Press & Flashings",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(07) 3274 3344",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Gutter & Roof Restoration",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Warning, Not All Roof Companies Are The Same",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Guttering & Spouting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 654 884",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Telford's Building Systems",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Steel Building Solutions Built to Last in Yatala",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Rural & Industrial Sheds",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(03) 5821 4399",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Total Steel of Australia Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Profile Cutting Service. Wear Plate. Mining Industry Solutions",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Steel Supplies & Merchants",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 4648 8111",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "43 Results for Roofing Contractors & Services Near You",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "R.O. Steel Roofing Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Annandale, NSW 2038",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "R.O. Steel Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/annandale/ro-steel-roofing-pty-ltd-12511187-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/annandale/ro-steel-roofing-pty-ltd-12511187-listing.html",
                                                "anchor_text": "R.O. Steel Roofing Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, servicing Balmain",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aussie Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/balmain/aussie-roofing-services-1000002965084-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/balmain/aussie-roofing-services-1000002965084-listing.html",
                                                "anchor_text": "Aussie Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Lawmans Frame & Truss Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Trusses & Wall Frames, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Lawmans Frame & Truss Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/lawmans-frame-truss-pty-ltd-1000002084216-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/lawmans-frame-truss-pty-ltd-1000002084216-listing.html",
                                                "anchor_text": "Lawmans Frame & Truss Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Materials, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Stratco",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/stratco-1000002368063-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/stratco-1000002368063-listing.html",
                                                "anchor_text": "Stratco"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aussie Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/aussie-roofing-services-1000002964917-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/aussie-roofing-services-1000002964917-listing.html",
                                                "anchor_text": "Aussie Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Garage Builders & Prefabricators, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Stratco",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/stratco-1000002368049-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/stratco-1000002368049-listing.html",
                                                "anchor_text": "Stratco"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pro Blast Services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Pressure & Steam Cleaning Contractors, Drummoyne, NSW 2047",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pro Blast Services",
                                        "url": "https://www.yellowpages.com.au/nsw/drummoyne/pro-blast-services-1000002995315-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/drummoyne/pro-blast-services-1000002995315-listing.html",
                                                "anchor_text": "Pro Blast Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Featured review",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Handy tips",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Best Carpentry & Renovations",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Builders & Building Contractors, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney Best Carpentry & Renovations",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/sydney-best-carpentry-renovations-1000002946870-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/sydney-best-carpentry-renovations-1000002946870-listing.html",
                                                "anchor_text": "Sydney Best Carpentry & Renovations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "R O Steel Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Asbestos Removal, Annandale, NSW 2038",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "R O Steel Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/annandale/r-o-steel-roofing-12519404-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/annandale/r-o-steel-roofing-12519404-listing.html",
                                                "anchor_text": "R O Steel Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Best Carpentry & Renovations",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Design, Extensions, Renovations & Alterations - Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney Best Carpentry & Renovations",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/sydney-best-carpentry-renovations-1000002988290-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/sydney-best-carpentry-renovations-1000002988290-listing.html",
                                                "anchor_text": "Sydney Best Carpentry & Renovations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "TRP-PRO Roofing and Plumbing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "TRP-PRO Roofing and Plumbing",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/trp-pro-roofing-and-plumbing-1000002932857-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/trp-pro-roofing-and-plumbing-1000002932857-listing.html",
                                                "anchor_text": "TRP-PRO Roofing and Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0407 678 149",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sapphire roofing services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Drummoyne, NSW 2047",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sapphire roofing services",
                                        "url": "https://www.yellowpages.com.au/nsw/drummoyne/sapphire-roofing-services-1000002949102-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/drummoyne/sapphire-roofing-services-1000002949102-listing.html",
                                                "anchor_text": "Sapphire roofing services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:30pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0481 731 731",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Bigger & Better Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Bigger & Better Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/bigger-better-roofing-1000001673933-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/bigger-better-roofing-1000001673933-listing.html",
                                                "anchor_text": "Bigger & Better Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:30pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0423 861 276",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Modern Re Roof & Guttering",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Modern Re Roof & Guttering",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/modern-re-roof-guttering-13050570-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/modern-re-roof-guttering-13050570-listing.html",
                                                "anchor_text": "Modern Re Roof & Guttering"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1-3 Meridian Pl Norwest Business Park, Sydney, NSW, 2000",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=1-3+Meridian+Pl+Norwest+Business+Park&context=undefined&directionMode=true&elat=-33.867495&elon=151.207075&ena=Modern+Re+Roof+%26+Guttering&estr=1-3+Meridian+Pl+Norwest+Business+Park&esu=Sydney%2C+NSW%2C+2000&productVersion=4&productId=999903616575&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DModern+Re+Roof+%26+Guttering%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.867495%26lon%3D151.207075%26selectedViewMode%3Dlist&yellowId=13050570",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=1-3+Meridian+Pl+Norwest+Business+Park&context=undefined&directionMode=true&elat=-33.867495&elon=151.207075&ena=Modern+Re+Roof+%26+Guttering&estr=1-3+Meridian+Pl+Norwest+Business+Park&esu=Sydney%2C+NSW%2C+2000&productVersion=4&productId=999903616575&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DModern+Re+Roof+%26+Guttering%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.867495%26lon%3D151.207075%26selectedViewMode%3Dlist&yellowId=13050570",
                                                "anchor_text": "1-3 Meridian Pl Norwest Business Park, Sydney, NSW, 2000"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "13 1178",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "White Foot Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Leichhardt, NSW 2040",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "White Foot Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/leichhardt/white-foot-roofing-15160428-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/leichhardt/white-foot-roofing-15160428-listing.html",
                                                "anchor_text": "White Foot Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "9A Annesley St, Leichhardt, NSW, 2040",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=9A+Annesley+St&context=undefined&directionMode=true&elat=-33.879627&elon=151.162958&ena=White+Foot+Roofing&estr=9A+Annesley+St&esu=Leichhardt%2C+NSW%2C+2040&productVersion=4&productId=999015888250&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DWhite+Foot+Roofing%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.879627%26lon%3D151.162958%26selectedViewMode%3Dlist&yellowId=15160428",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=9A+Annesley+St&context=undefined&directionMode=true&elat=-33.879627&elon=151.162958&ena=White+Foot+Roofing&estr=9A+Annesley+St&esu=Leichhardt%2C+NSW%2C+2040&productVersion=4&productId=999015888250&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DWhite+Foot+Roofing%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.879627%26lon%3D151.162958%26selectedViewMode%3Dlist&yellowId=15160428",
                                                "anchor_text": "9A Annesley St, Leichhardt, NSW, 2040"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0413 572 946",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Impulse",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Impulse",
                                        "url": "https://www.yellowpages.com.au/sup/impulse-14311844-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/impulse-14311844-listing.html",
                                                "anchor_text": "Impulse"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "13 1178",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "THE ROOF MAINTENANCE COMPANY",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Woolloomooloo, NSW 2011",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "THE ROOF MAINTENANCE COMPANY",
                                        "url": "https://www.yellowpages.com.au/nsw/woolloomooloo/the-roof-maintenance-company-1000002341909-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/woolloomooloo/the-roof-maintenance-company-1000002341909-listing.html",
                                                "anchor_text": "THE ROOF MAINTENANCE COMPANY"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open 24 hours",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "ZD Metal Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Chiswick, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "ZD Metal Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/chiswick/zd-metal-roofing-1000001778161-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/chiswick/zd-metal-roofing-1000001778161-listing.html",
                                                "anchor_text": "ZD Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open by appt",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0458 776 505",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "DEKFAST METAL ROOFING",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Leichhardt, NSW 2040",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "DEKFAST METAL ROOFING",
                                        "url": "https://www.yellowpages.com.au/nsw/leichhhardt/dekfast-metal-roofing-1000002160511-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/leichhhardt/dekfast-metal-roofing-1000002160511-listing.html",
                                                "anchor_text": "DEKFAST METAL ROOFING"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0405 705 625",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Proof Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Newtown, NSW 2042",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Proof Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/newtown/proof-roofing-15140424-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/newtown/proof-roofing-15140424-listing.html",
                                                "anchor_text": "Proof Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1300 070 507",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "JRL City Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Redfern, NSW 2016",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "JRL City Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/redfern/jrl-city-roofing-15051834-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/redfern/jrl-city-roofing-15051834-listing.html",
                                                "anchor_text": "JRL City Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0411 377 780",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "MBO Roofing Services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Wareemba, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "MBO Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/wareemba/mbo-roofing-services-1000002738807-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/wareemba/mbo-roofing-services-1000002738807-listing.html",
                                                "anchor_text": "MBO Roofing Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0499 558 850",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Strata Roofing Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Artarmon, NSW 2064",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Strata Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/artarmon/strata-roofing-pty-ltd-14170444-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/artarmon/strata-roofing-pty-ltd-14170444-listing.html",
                                                "anchor_text": "Strata Roofing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Unit 5/ 12 Clarendon St, Artarmon, NSW, 2064",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Unit+5%252F+12+Clarendon+St&context=undefined&directionMode=true&elat=-33.816735&elon=151.184114&ena=Strata+Roofing+Pty+Ltd&estr=Unit+5%2F+12+Clarendon+St&esu=Artarmon%2C+NSW%2C+2064&productVersion=3&productId=999015384326&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DStrata+Roofing+Pty+Ltd%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.816735%26lon%3D151.184114%26selectedViewMode%3Dlist&yellowId=14170444",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Unit+5%252F+12+Clarendon+St&context=undefined&directionMode=true&elat=-33.816735&elon=151.184114&ena=Strata+Roofing+Pty+Ltd&estr=Unit+5%2F+12+Clarendon+St&esu=Artarmon%2C+NSW%2C+2064&productVersion=3&productId=999015384326&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DStrata+Roofing+Pty+Ltd%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.816735%26lon%3D151.184114%26selectedViewMode%3Dlist&yellowId=14170444",
                                                "anchor_text": "Unit 5/ 12 Clarendon St, Artarmon, NSW, 2064"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9436 3006",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Orchardbusiness Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Chippendale, NSW 2008",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Orchardbusiness Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/chippendale/orchardbusiness-pty-ltd-14968189-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/chippendale/orchardbusiness-pty-ltd-14968189-listing.html",
                                                "anchor_text": "Orchardbusiness Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Suite 1 1 Regent St, Chippendale, NSW, 2008",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Suite+1+1+Regent+St&context=undefined&directionMode=true&elat=-33.884399&elon=151.202363&ena=Orchardbusiness+Pty+Ltd&estr=Suite+1+1+Regent+St&esu=Chippendale%2C+NSW%2C+2008&productVersion=6&productId=489072492&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DOrchardbusiness+Pty+Ltd%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.884399%26lon%3D151.202363%26selectedViewMode%3Dlist&yellowId=14968189",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Suite+1+1+Regent+St&context=undefined&directionMode=true&elat=-33.884399&elon=151.202363&ena=Orchardbusiness+Pty+Ltd&estr=Suite+1+1+Regent+St&esu=Chippendale%2C+NSW%2C+2008&productVersion=6&productId=489072492&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DOrchardbusiness+Pty+Ltd%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.884399%26lon%3D151.202363%26selectedViewMode%3Dlist&yellowId=14968189",
                                                "anchor_text": "Suite 1 1 Regent St, Chippendale, NSW, 2008"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 8007 3711",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Professional Metal Roofing Stanmore - Roof Replacement Sydney",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Stanmore, NSW 2048",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Professional Metal Roofing Stanmore - Roof Replacement Sydney",
                                        "url": "https://www.yellowpages.com.au/nsw/stanmore/professional-metal-roofing-stanmore-roof-replacement-sydney-1000002770642-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/stanmore/professional-metal-roofing-stanmore-roof-replacement-sydney-1000002770642-listing.html",
                                                "anchor_text": "Professional Metal Roofing Stanmore - Roof Replacement Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "74 Railway Ave, Stanmore, NSW, 2048",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=74+Railway+Ave&context=undefined&directionMode=true&elat=-33.893603&elon=151.167212&ena=Professional+Metal+Roofing+Stanmore+-+Roof+Replacement+Sydney&estr=74+Railway+Ave&esu=Stanmore%2C+NSW%2C+2048&productVersion=1&productId=1000002770642&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DProfessional+Metal+Roofing+Stanmore+-+Roof+Replacement+Sydney%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.893603%26lon%3D151.167212%26selectedViewMode%3Dlist&yellowId=1000002770642",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=74+Railway+Ave&context=undefined&directionMode=true&elat=-33.893603&elon=151.167212&ena=Professional+Metal+Roofing+Stanmore+-+Roof+Replacement+Sydney&estr=74+Railway+Ave&esu=Stanmore%2C+NSW%2C+2048&productVersion=1&productId=1000002770642&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DProfessional+Metal+Roofing+Stanmore+-+Roof+Replacement+Sydney%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.893603%26lon%3D151.167212%26selectedViewMode%3Dlist&yellowId=1000002770642",
                                                "anchor_text": "74 Railway Ave, Stanmore, NSW, 2048"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9538 7960",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "AirSafe",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Asbestos Removal, Balmain, NSW 2041",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "AirSafe",
                                        "url": "https://www.yellowpages.com.au/nsw/balmain/airsafe-12487421-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/balmain/airsafe-12487421-listing.html",
                                                "anchor_text": "AirSafe"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "93 Beattie Street, Balmain, NSW, 2041",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=93+Beattie+Street&context=undefined&directionMode=true&elat=-33.85869&elon=151.17711&ena=AirSafe&estr=93+Beattie+Street&esu=Balmain%2C+NSW%2C+2041&productVersion=4&productId=473768620&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DAirSafe%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.85869%26lon%3D151.17711%26selectedViewMode%3Dlist&yellowId=12487421",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=93+Beattie+Street&context=undefined&directionMode=true&elat=-33.85869&elon=151.17711&ena=AirSafe&estr=93+Beattie+Street&esu=Balmain%2C+NSW%2C+2041&productVersion=4&productId=473768620&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DAirSafe%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.85869%26lon%3D151.17711%26selectedViewMode%3Dlist&yellowId=12487421",
                                                "anchor_text": "93 Beattie Street, Balmain, NSW, 2041"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9555 9034",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Baker Developments Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Builders & Building Contractors, Balmain, NSW 2041",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Baker Developments Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/balmain/baker-developments-pty-ltd-15771448-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/balmain/baker-developments-pty-ltd-15771448-listing.html",
                                                "anchor_text": "Baker Developments Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "10 Short St, Balmain, NSW, 2041",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=10+Short+St&context=undefined&directionMode=true&elat=-33.856034&elon=151.178648&ena=Baker+Developments+Pty+Ltd&estr=10+Short+St&esu=Balmain%2C+NSW%2C+2041&productVersion=5&productId=999016294103&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DBaker+Developments+Pty+Ltd%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.856034%26lon%3D151.178648%26selectedViewMode%3Dlist&yellowId=15771448",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=10+Short+St&context=undefined&directionMode=true&elat=-33.856034&elon=151.178648&ena=Baker+Developments+Pty+Ltd&estr=10+Short+St&esu=Balmain%2C+NSW%2C+2041&productVersion=5&productId=999016294103&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DBaker+Developments+Pty+Ltd%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.856034%26lon%3D151.178648%26selectedViewMode%3Dlist&yellowId=15771448",
                                                "anchor_text": "10 Short St, Balmain, NSW, 2041"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0426 246 284",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Mirvac Group",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Builders & Building Contractors, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Mirvac Group",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/mirvac-group-13333255-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/mirvac-group-13333255-listing.html",
                                                "anchor_text": "Mirvac Group"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Level 28 200 George St, Sydney, NSW, 2000",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Level+28+200+George+St&context=undefined&directionMode=true&elat=-33.862644&elon=151.207975&ena=Mirvac+Group&estr=Level+28+200+George+St&esu=Sydney%2C+NSW%2C+2000&productVersion=5&productId=999901766357&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMirvac+Group%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.862644%26lon%3D151.207975%26selectedViewMode%3Dlist&yellowId=13333255",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Level+28+200+George+St&context=undefined&directionMode=true&elat=-33.862644&elon=151.207975&ena=Mirvac+Group&estr=Level+28+200+George+St&esu=Sydney%2C+NSW%2C+2000&productVersion=5&productId=999901766357&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMirvac+Group%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.862644%26lon%3D151.207975%26selectedViewMode%3Dlist&yellowId=13333255",
                                                "anchor_text": "Level 28 200 George St, Sydney, NSW, 2000"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9080 8000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Your Roof Repair",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Redfern, NSW 2016",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Your Roof Repair",
                                        "url": "https://www.yellowpages.com.au/sup/your-roof-repair-1000002043082-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/your-roof-repair-1000002043082-listing.html",
                                                "anchor_text": "Your Roof Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0420 434 752",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Global Roofing Services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Leichhardt, NSW 2040",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Global Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/leichhardt/global-roofing-services-14560861-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/leichhardt/global-roofing-services-14560861-listing.html",
                                                "anchor_text": "Global Roofing Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1C Athol St, Leichhardt, NSW, 2040",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=1C+Athol+St&context=undefined&directionMode=true&elat=-33.87808&elon=151.149576&ena=Global+Roofing+Services&estr=1C+Athol+St&esu=Leichhardt%2C+NSW%2C+2040&productVersion=3&productId=999015539203&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGlobal+Roofing+Services%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.87808%26lon%3D151.149576%26selectedViewMode%3Dlist&yellowId=14560861",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=1C+Athol+St&context=undefined&directionMode=true&elat=-33.87808&elon=151.149576&ena=Global+Roofing+Services&estr=1C+Athol+St&esu=Leichhardt%2C+NSW%2C+2040&productVersion=3&productId=999015539203&ref=ypgd&referredBy=undefined&str=Balmain%2C+NSW+2041&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGlobal+Roofing+Services%26locationClue%3DBalmain%2C+NSW+2041%26lat%3D-33.87808%26lon%3D151.149576%26selectedViewMode%3Dlist&yellowId=14560861",
                                                "anchor_text": "1C Athol St, Leichhardt, NSW, 2040"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1300 762 067",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Average rating for Roofing Construction & Services in Balmain and surrounding suburbs",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Based on 730 reviews of 157 businesses on this page",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Nearby Locations for Roofing Contractors & Services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular Categories in Balmain",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Categories in Balmain",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "A Class Plumbing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Reliable, Professional Industrial & Commercial Specialists",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9630 4227",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Blacktown Industrial Plumbing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Backflow Prevention Commercial Specialists",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9679 0110",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Eco Wool Insulation Services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Insulation Installers & Contractors",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "0481 845 529",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our directory.",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Yellow Pages",
                                        "url": "https://www.yellowpages.com.au/pages/about-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/about-us",
                                                "anchor_text": "About Yellow Pages"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://www.yellowpages.com.au/pages/contact-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/contact-us",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Site Index",
                                        "url": "https://www.yellowpages.com.au/sitemap",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sitemap",
                                                "anchor_text": "Site Index"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Order or cancel your book",
                                        "url": "https://www.directoryselect.com.au/action/home",
                                        "urls": [
                                            {
                                                "url": "https://www.directoryselect.com.au/action/home",
                                                "anchor_text": "Order or cancel your book"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our advertising.",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Get a free listing",
                                        "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                                "anchor_text": "Get a free listing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Digital marketing solutions",
                                        "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                                "anchor_text": "Digital marketing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Business hub",
                                        "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                                "anchor_text": "Business hub"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "myYellow login",
                                        "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                                "anchor_text": "myYellow login"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Connect with us.",
                                "main_title": "35 BEST local Roofing Contractors & Services in Balmain NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Thryv Australia",
                                        "url": "https://corporate.thryv.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/",
                                                "anchor_text": "About Thryv Australia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://corporate.thryv.com/privacy/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com/privacy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://corporate.thryv.com.au/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.2,
                                "max_rating_value": 5,
                                "rating_count": 730,
                                "relative_rating": 0.8400000000000001
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 9566 1554",
                                "0485 800 063",
                                "(02) 4560 2707",
                                "1300 556 541",
                                "0481 941 941",
                                "0401 185 538",
                                "(02) 9692 8472",
                                "0407 678 149",
                                "0481 731 731",
                                "0423 861 276",
                                "13 1178",
                                "0413 572 946",
                                "none",
                                "0458 776 505",
                                "0405 705 625",
                                "1300 070 507",
                                "0411 377 780",
                                "0499 558 850",
                                "(02) 9436 3006",
                                "(02) 8007 3711",
                                "(02) 9538 7960",
                                "1300 557 747",
                                "(02) 9555 9034",
                                "0426 246 284",
                                "(02) 8920 0802",
                                "(02) 9550 9199",
                                "(02) 9080 8000",
                                "0420 434 752",
                                "1300 762 067",
                                "(02) 9901 4866",
                                "0407678149",
                                "0481731731",
                                "0423861276",
                                "131178",
                                "0413572946",
                                "0458776505",
                                "0405705625",
                                "1300070507",
                                "0411377780",
                                "0499558850",
                                "0294363006",
                                "0280073711",
                                "0295387960",
                                "1300557747",
                                "0295559034",
                                "0426246284",
                                "0289200802",
                                "0295509199",
                                "0290808000",
                                "0420434752",
                                "1300762067",
                                "0299014866",
                                "0287838022",
                                "1300556541",
                                "0248713355",
                                "1300654884",
                                "0296304227",
                                "0732743344",
                                "0296790110",
                                "0481845529",
                                "0358214399",
                                "0246488111"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}