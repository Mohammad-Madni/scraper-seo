# Type: people_also_search | Rank: 14 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "14",
    "service": "roofer",
    "suburb": "Annandale (NSW)",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}