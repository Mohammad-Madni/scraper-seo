# Type: people_also_search | Rank: 19 | RG: 2
### Raw Row Data:
{
    "rank_group": "2",
    "rank_absolute": "19",
    "service": "roofer",
    "suburb": "Annandale (NSW)",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}