# Type: people_also_ask | Rank: 9 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "9",
    "service": "roofer",
    "suburb": "Annandale (NSW)",
    "title": "",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_ask"
}