# Type: local_pack | Rank: 3 | RG: 3
### Raw Row Data:
{
    "rank_group": "3",
    "rank_absolute": "3",
    "service": "roofer",
    "suburb": "Annandale (NSW)",
    "title": "G-Force Roofing",
    "domain": "www.google.com",
    "url": "https://www.google.com/viewer/place?sca_esv=ed956a20e7b48028&hl=en&gl=AU&output=search&mid=/g/1tfrs1_5&pip=Cgtyb29mZXIgTlNXKRAC",
    "description": "Open \u00b7 Stanmore NSW",
    "type": "local_pack"
}