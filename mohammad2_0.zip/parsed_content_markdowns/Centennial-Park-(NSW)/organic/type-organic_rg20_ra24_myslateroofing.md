{
    "id": "01190728-1132-0216-0000-76196bc4f259",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0320 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://myslateroofing.com.au/",
        "target": "myslateroofing.com.au",
        "start_url": "https://myslateroofing.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Centennial-Park-(NSW)\\organic\\type-organic_rg20_ra24_myslateroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:56 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Mon-Sat: 7am \u2013 5pm\u00a0| simon@myslateroofing.com.au",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Book your roof inspection",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Book your roof inspection",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Book your roof inspection",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "0424 209 023",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "5 Star Google Reviews",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Google Rating",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "0424 209 023",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate",
                                    "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                            "anchor_text": "Canadian Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate",
                                    "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                            "anchor_text": "Spanish Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate",
                                    "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                            "anchor_text": "Welsh Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Shingles & Shakes",
                                    "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                            "anchor_text": "Shingles & Shakes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate",
                                    "url": "https://myslateroofing.com.au/services/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/artificial-slate/",
                                            "anchor_text": "Artificial Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://myslateroofing.com.au/services/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Galvanised",
                                    "url": "https://myslateroofing.com.au/services/heritage-galvanised-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-galvanised-roofing/",
                                            "anchor_text": "Heritage Galvanised"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate",
                                    "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                            "anchor_text": "Canadian Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate",
                                    "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                            "anchor_text": "Spanish Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate",
                                    "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                            "anchor_text": "Welsh Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Shingles & Shakes",
                                    "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                            "anchor_text": "Shingles & Shakes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate",
                                    "url": "https://myslateroofing.com.au/services/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/artificial-slate/",
                                            "anchor_text": "Artificial Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://myslateroofing.com.au/services/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Galvanised",
                                    "url": "https://myslateroofing.com.au/services/heritage-galvanised-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-galvanised-roofing/",
                                            "anchor_text": "Heritage Galvanised"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "0424 209 023",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate",
                                    "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                            "anchor_text": "Canadian Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate",
                                    "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                            "anchor_text": "Spanish Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate",
                                    "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                            "anchor_text": "Welsh Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Shingles & Shakes",
                                    "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                            "anchor_text": "Shingles & Shakes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate",
                                    "url": "https://myslateroofing.com.au/services/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/artificial-slate/",
                                            "anchor_text": "Artificial Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://myslateroofing.com.au/services/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Galvanised",
                                    "url": "https://myslateroofing.com.au/services/heritage-galvanised-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-galvanised-roofing/",
                                            "anchor_text": "Heritage Galvanised"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate",
                                    "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                            "anchor_text": "Canadian Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate",
                                    "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                            "anchor_text": "Spanish Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate",
                                    "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                            "anchor_text": "Welsh Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Shingles & Shakes",
                                    "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                            "anchor_text": "Shingles & Shakes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate",
                                    "url": "https://myslateroofing.com.au/services/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/artificial-slate/",
                                            "anchor_text": "Artificial Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://myslateroofing.com.au/services/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Galvanised",
                                    "url": "https://myslateroofing.com.au/services/heritage-galvanised-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-galvanised-roofing/",
                                            "anchor_text": "Heritage Galvanised"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Discover the My Slate Roofing difference. Whether you\u2019re looking to address specific concerns with a free quote or ensure your roof is in top condition with a thorough inspection, we\u2019re here to help. Tap into our expertise and secure the future of your roof today.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "My Slate Roofing, mastering heritage and modern slate roofing in Sydney for 20+ years, combines craftsmanship, service, and value for timeless roofing excellence.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday - Saturday: 7am - 5pm",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Come and visit our quarters or simply send us an email anytime you want. We are open to all suggestions from our audience.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About us",
                                    "url": "https://myslateroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/about-us/",
                                            "anchor_text": "About us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Services",
                                    "url": "https://myslateroofing.com.au/services/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/",
                                            "anchor_text": "Our Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Gallery",
                                    "url": "https://myslateroofing.com.au/our-gallery/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/our-gallery/",
                                            "anchor_text": "Our Gallery"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Estimate",
                                    "url": "https://myslateroofing.com.au/free-roof-estimate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/free-roof-estimate/",
                                            "anchor_text": "Free Estimate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact us",
                                    "url": "https://myslateroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/contact-us/",
                                            "anchor_text": "Contact us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing SERVICES",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate",
                                    "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                            "anchor_text": "Canadian Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate",
                                    "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                            "anchor_text": "Spanish Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate",
                                    "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                            "anchor_text": "Welsh Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Shingles & Shakes",
                                    "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                            "anchor_text": "Shingles & Shakes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate",
                                    "url": "https://myslateroofing.com.au/services/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/artificial-slate/",
                                            "anchor_text": "Artificial Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://myslateroofing.com.au/services/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Galvanised",
                                    "url": "https://myslateroofing.com.au/services/heritage-galvanised-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/heritage-galvanised-roofing/",
                                            "anchor_text": "Heritage Galvanised"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact us",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Specialising in superior roofing, My Slate Roofing blends tradition with innovation for Sydney\u2019s homes and heritage buildings. With 20 years of expertise, we\u2019re your trusted choice for bespoke roofing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney's Trusted Slate Roofing Experts",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Welcome to My Slate Roofing, where our heritage craftsmanship meets Sydney\u2019s modern skyline. Led by Simon Williams, we offer over 20 years of unrivaled expertise in slate roofing, ensuring your property is both protected and beautifully adorned.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Specialised Slate Roof Restoration and Installation Services",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At My Slate Roofing, we understand the critical importance of precision in roofing. Just as there\u2019s no room for error when it comes to the integrity of your roof, there\u2019s no compromise in the quality and craftsmanship we bring to every project. From the timeless elegance of slate roofing to the cutting-edge performance of metal solutions, we offer a wide range of services tailored to protect and enhance your property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Your Professional Roofing Experts",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Minor leaks can lead to major troubles. Contact us now for expert roofing repairs or to schedule a detailed roof inspection.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Need help with your roof? At My Slate Roofing in Sydney, we\u2019re all about solving roofing problems, big and small. With over 20 years in the business, we\u2019re experts in slate roofing and more. Whether you need a quick repair or a whole new roof, we\u2019ve got the skills to get it done right.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We offer a range of services to fit any need, from installing beautiful slate roofs on new buildings to restoring old ones with care. Our process is smooth and straightforward, making sure you\u2019re happy from start to finish. Plus, our work comes with a 20-year warranty. Let us take care of your roof, so you don\u2019t have to worry.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ready to secure your roof\u2019s future? Reach out to us now to chat with an expert or request your free quote.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Slate Roof Installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Slate Roof Maintenance",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Heritage Roof Restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leak Detection & Repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Inspection Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Complete Roof Replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Custom Skylight Fitting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Waterproofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "... and more!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "St John of God Richmond Hospital",
                                        "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/st_john_of_god_roofing_project.jpg",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/st_john_of_god_roofing_project.jpg",
                                                "anchor_text": "St John of God Richmond Hospital"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woollahra Project",
                                        "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/woollharah_roofing_project.jpg",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/woollharah_roofing_project.jpg",
                                                "anchor_text": "Woollahra Project"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Petersham Heritage Train Station",
                                        "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/Petersham_Train-_Station_roofing_project.jpg",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/Petersham_Train-_Station_roofing_project.jpg",
                                                "anchor_text": "Petersham Heritage Train Station"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sans Souci",
                                        "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/Sans_Souci_roofing_project.jpg",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/Sans_Souci_roofing_project.jpg",
                                                "anchor_text": "Sans Souci"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mulgoa Gleneleigh Estate",
                                        "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/Mulgoa_roofing_project.jpg",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/Mulgoa_roofing_project.jpg",
                                                "anchor_text": "Mulgoa Gleneleigh Estate"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bunnamagoo Estate Rockley",
                                        "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/Bunnamagoo_Estate_Rockley_roofing_project.jpg",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/wp-content/uploads/2025/04/Bunnamagoo_Estate_Rockley_roofing_project.jpg",
                                                "anchor_text": "Bunnamagoo Estate Rockley"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Hear from Our Satisfied Customers",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Proud of our consistent 5-star Google rating, My Slate Roofing stands out through our commitment to customer satisfaction, quality materials, and unparalleled workmanship. We offer peace of mind with roofing solutions guaranteed to last between 10 to 30 years. Here\u2019s what our customers have to say about the difference our work has made to their homes and lives.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon and the team did an incredible job on our roof. He was more affordable than other businesses while offering more premium materials and products, and his customer service was something else. He stayed back in 40-degree heat making sure our new skylight blended perfectly with the internal masonry... and 6 months later he was back when strong wind blew a wooden piece off another part of our roof. This wasn't anything to do with his work - but he came to fix it within days anyway. It's rare to get such great service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon & team have just completed our roof repairs. The communication was easy, the service reliable, prompt & professional with a very reasonable quote with photos to explain the maintenance required. The pics to confirm the work carried out were brilliant and provided reassurance of a job well done.Highly recommend Simon & team",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon Williams' team of artisanal craftmen (Welsh, Scottish, French, Belgian, English, all) were a delight - precise reinstatement of the mitres, excellent excellent excellent slating, and superlative copper work to gutters, downpipes, and eyebrow awnings. Absolutely no issues with their effort, their attendance, or their care of the site generally. Genuinely nice, skilled, fun team. Very highly recommended. Richard and Susan Mattick, Summer Hill - owners.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We recently had the slate roof on our heritage home replaced by My Slate Roofing, and I genuinely cannot recommend them highly enough. Simon, the owner, was hands down the best trade I've ever dealt with. From the first conversation to the final clean-up, he set a new benchmark for both customer service and quality of work.Simon and his team were incredibly professional, respectful, and clearly take great pride in their craft. The attention to detail was outstanding, and the finished roof looks absolutely stunning\u2014perfectly in keeping with the character of the house. On top of that, the site was kept immaculate throughout the project. Every day they left it spotless and organised, which really impressed me.If you're looking for someone who genuinely cares about doing the job right and delivering an exceptional result, Simon is your guy. Truly a master of his trade and a pleasure to work with. Highly recommend!!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Amazing!! Simon is a Professional Roofer. My worries all stopped, when Simon was able to meticulously diagnose & fix my father's roof, in Croydon. We are very humbled that Simon made immediate time for us, during his busy schedule, of government restoration projects, of Sydney Landmarks.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely beyond expectation from My Slate Roofing for the past six weeks and now my completed new slate roof and gutters.Knowing Simon and My Slate Roofing was by word of mouth and the genuine way of keeping Simon and his team extremely busy throughout the year. The time and patience Simon demonstrates to new customers are super valuable and helping me to fully understand the project and details before it kicked off.During the project, communication was always continuous and smooth that encouraged me asking any questions without hesitation and having the confidence to always get an answer. Simon and every member of his team were super friendly and lovely to talk to, and each of them is absolutely an expert of the field. Progress photos showing details were provided every few days, which I was always excited to look out for. I was also given opportunities to climb up the scaffoldings to see the roof and gutters closely. Very much loving my new slate roof and I highly appraise the work to details on all flashings, ridges, and curved roofs \u2013 nice and neat like an artwork. Simon also went above and beyond to fix extra issues on my roof.I am very happy and impressed by the quality of work delivered by My Slate Roofing, and I highly recommend them to anyone who is looking at repairing/replacing their roofs/chimneys/gutters.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon and his crew were wonderful people. Always on time and respectful of our property. They worked through rain hail or shine on a very difficult multi-faceted wall with bay windows, all mitered cuts. The wall had previously been cladded in ceder some 40 years ago and now has a Spanish slate that has people walking past and stopping to see the beautiful transformation.Well done, Simon.Would recommend Simon to anyone wanting a professional job done.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I recently had my badly deteriorated slate roof replaced by My Slate Roofing, I'm very happy with the completed job, they also replaced the gutters and valleys, and looks fantastic. I wouldn't hesitate to recommend My Slate Roofing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We were so impressed with Simon. He is so responsive, professional and does a really great job. Our house was built in 1906 and the insight, knowledge and solutions that Simon provided for restoring our roof, chimney and leakages were really helpful. I would highly recommend Simon's services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon and the team at My Slate roofing were simply fantastic. Our old slate roof started leaking during the heavy Sydney rain in early 2021. Simon committed getting out to site and getting repairs completed ASAP, and that he did.Not only was the workmanship top class, the communications, timeliness and additional services added to the professionalism and all round service.Would highly recommend My Slate roofing, and we will always rely on the team for Slate Roofing requirements.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon and his team at My Slate Roofing are true professionals. I had my entire slate roof replaced and chimneys restored following severe damage during storms and am extremely happy with the result. They proved to have exceptional craftmanship and delivered the project on time and budget and showed great care for what they do.Highly recommend their service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Wow. What an amazing transformation to the semi. The slate roof to the semi was in dire need of repairs. We called several roof repair companies in Sydney. Many did not bothered to turn up after confirming time. Some quoted rediculous prices due to their busy workload. Simon advised that his team was fully booked out for a few months however could make temporary repairs in the mean time until he could replace the entire roof. From initial quotation, to tile selection, and install, everything was performed professionally, on time and on budget. Nothing was too much trouble for My Slate Roofing. He took pride in his work and even painted the gable at no charge because it was run down. Thank you Simon and team for the incredible job you did.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I called a few people and Simon responded. That's a tick straight away. Simon was able to provide a number of options and the time frame. He was responsive and a very good builder especially when it comes to heritage properties. After the work was completed he called to checked there were no further issues. Would recommend anytime.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon was the epitome of professional throughout our roof install. He showed up every time on time and gave us options to help stay within our budget. His team was courteous and tidy and the new roof looks great. He even installed his scaffolding a few days early so we could use it to perform separate repairs to the house. I cannot recommend highly enough.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon and his team were professional and courteous every step of the way. It was a huge job repairing our entire slate roof, but they carried it out with minimal fuss and low intrusion. The craftsmanship is absolutely outstanding and we are extremely happy with the new roof. Thanks Simon and team. Much appreciated.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon & his team, have been incredibly professional & friendly from beginning to end. Simon\u2019s love of his work, is more a passion of Art. His knowledge & expertise, undeniable. We have enjoyed having this fine group of people working on our property, & are over the top with the finished product. Our property had some very tricky aspects, due the the age & design of residence, which Simon & his team took in their stride. Nothing was an issue or a problem. Our project encompassed re-roofing the house in Colourbond, a massive Porte coch\u00e8re re-roofed with cliplock plus a small garden studio re-roofed in Colourbond. We highly recommend My Slate Roofing Sydney.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We cannot recommend Simon and his team enough. They were professional, a pleasure to have on site and our new roof is stunning. The comments from neighbours and family/friends have been so outstanding. We are very proud of the work of Simon and his Team, their hardwork and attention to detail, especially the personal touch of our house number on the roof makes it very special. Thank you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon did a wonderful job on our roof back on Anglesey. A very professional, knowledgable and courteous young man with quality craftsmanship. Easy to work with and happy to answer any questions I had. I would highly recommend MySlate Roofing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We would highly recommend Simon and his team for any slate roofing works. We have a heritage home that is over 120 years old and so we needed the best possible advice. Simon's advice was perfect and at no time did we feel oversold to which is our experience with other advice and quotes. Simon is a total perfectionist and a craftsman of the highest standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simon is an energetic professional, who has a thorough knowledge of anything to do with roof repairs, improvements, adjustments etc. I found him pleasant to deal with, he knows his business, his quote was fair and he even did 2 additional jobs, not relating to our roof, at no charge. Overall I could recommend him for his honesty, integrity and workmanship.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How to Tell If Your Slate Roof Needs Repair or Full Replacement",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Not sure whether your slate roof needs a simple repair or complete replacement? This guide reveals the key warning signs, explains the industry's 20% rule, and helps Sydney homeowners make confident, cost-effective decisions about their heritage roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "How to Tell If Your Slate Roof Needs Repair or Full Replacement",
                                        "url": "https://myslateroofing.com.au/slate-roof-repair-signs/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/slate-roof-repair-signs/",
                                                "anchor_text": "How to Tell If Your Slate Roof Needs Repair or Full Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Copper Patina: Understanding the Natural Aging Process of Premium Copper Roofing",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If you\u2019ve recently installed a copper roof or you\u2019re considering one for your Sydney home, you might be wondering about that distinctive green-blue colour you\u2019ve seen on older copper roofs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Copper Patina: Understanding the Natural Aging Process of Premium Copper Roofing",
                                        "url": "https://myslateroofing.com.au/copper-patina-process/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/copper-patina-process/",
                                                "anchor_text": "Copper Patina: Understanding the Natural Aging Process of Premium Copper Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Compare Metal Roofing vs Tile Roofing for Sydney\u2019s Climate: Your Complete Guide",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Picture this: Another scorching Sydney summer where the sun beats down relentlessly. Then suddenly, a storm rolls in with hail the size of golf balls. Your roof takes all of",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Compare Metal Roofing vs Tile Roofing for Sydney\u2019s Climate: Your Complete Guide",
                                        "url": "https://myslateroofing.com.au/compare-metal-roofing-vs-tile-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/compare-metal-roofing-vs-tile-roofing/",
                                                "anchor_text": "Compare Metal Roofing vs Tile Roofing for Sydney\u2019s Climate: Your Complete Guide"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Master Craftsmanship",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Benefit from Simon\u2019s 20+ years of global expertise, delivering unmatched quality and durability in every tile.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Experts",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We specialise in the preservation and restoration of heritage properties, ensuring your roofing maintains its classic beauty alongside modern functionality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tailored Solutions",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our approach is personalised, acknowledging each roof's unique story. Expect tailor-made solutions that align perfectly with your home's needs and style.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Harnessing the age-old beauty and durability of slate to offer roofing that stands the test of time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing",
                                        "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/services/slate-roofing/",
                                                "anchor_text": "Slate Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Welsh Slate",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "he world\u2019s premier slate, backed by a century-long warranty, ensuring unparalleled quality and appeal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Welsh Slate",
                                        "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/services/welsh-slate-roofing/",
                                                "anchor_text": "Welsh Slate"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Canadian Slate",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A popular choice for its availability and reliability, fitting seamlessly into both traditional and contemporary designs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Canadian Slate",
                                        "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/services/canadian-slate/",
                                                "anchor_text": "Canadian Slate"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Spanish Slate",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sourced from the prestigious Del Carmen quarry for those who seek exclusivity and distinction in their roofing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Spanish Slate",
                                        "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/services/spanish-slate-roofing/",
                                                "anchor_text": "Spanish Slate"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Lead Roofing",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Specialising in the historic craft of lead roofing, our work pays homage to tradition while ensuring modern efficacy.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Lead Roofing",
                                        "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/services/lead-roofing/",
                                                "anchor_text": "Lead Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Offering zincalume, galvanised steel, or aluminium options for a roofing solution that combines durability with style.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Roofing",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A diverse range of profiles to enhance the architectural style of any home, ensuring beauty and functionality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tile Roofing",
                                        "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/services/tile-roofing/",
                                                "anchor_text": "Tile Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Shingles & Shakes",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Celebrated for natural beauty and insulation, ideal for blending tradition and performance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Shingles & Shakes",
                                        "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/services/western-red-cedar-shingles-shakes/",
                                                "anchor_text": "Shingles & Shakes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From single tile fixes to major repairs, we handle each task with unmatched precision and care.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://myslateroofing.com.au/services/roof-repairs/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Elevating Roofs, Preserving Heritage: Your Slate Experts in Sydney",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "A Glimpse Into Our Work",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Insights & Innovations in Roofing",
                                "main_title": "Mastering Heritage & Modern Roofing Solutions for Over 20 Years",
                                "author": "myslateroofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61-424-209-023",
                                "0424209023"
                            ],
                            "emails": [
                                "simon@myslateroofing.com.au",
                                "%20simon@myslateroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}