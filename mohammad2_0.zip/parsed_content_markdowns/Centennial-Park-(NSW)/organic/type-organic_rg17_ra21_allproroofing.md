{
    "id": "01190728-1132-0216-0000-27491e16f56a",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0245 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://allproroofing.com.au/",
        "target": "allproroofing.com.au",
        "start_url": "https://allproroofing.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Centennial-Park-(NSW)\\organic\\type-organic_rg17_ra21_allproroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:53 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Contact Us",
                                    "url": "https://allproroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://allproroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "All Pro Roofing have been providing unbeatable prices & quality workmanship for all your roofing needs for 20+ years.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Unbeatable prices & quality workmanship for all your roofing needs. Trading off the same licence number since 2005!",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright \u00a9 2026 All Pro Roofing",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "LICENCE NUMBER: 178790c",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof",
                                    "url": "https://allproroofing.com.au/new-roof/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/new-roof/",
                                            "anchor_text": "New Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://allproroofing.com.au/gutter-guard/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/gutter-guard/",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof",
                                    "url": "https://allproroofing.com.au/new-roof/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/new-roof/",
                                            "anchor_text": "New Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://allproroofing.com.au/gutter-guard/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/gutter-guard/",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs-central-coast/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs-central-coast/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration-central-coast/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration-central-coast/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting-central-coast/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting-central-coast/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning-central-coast/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning-central-coast/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs-newcastle/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs-newcastle/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration-newcastle/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration-newcastle/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting-newcastle/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting-newcastle/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning-newcastle/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning-newcastle/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs-lake-macquarie/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs-lake-macquarie/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration-lake-macquarie/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration-lake-macquarie/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting-lake-macquarie/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting-lake-macquarie/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning-lake-macquarie/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning-lake-macquarie/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs-maitland/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs-maitland/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration-maitland/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration-maitland/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting-maitland/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting-maitland/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning-maitland/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning-maitland/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs-singleton/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs-singleton/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration-singleton/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration-singleton/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting-singleton/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting-singleton/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning-singleton/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning-singleton/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs-hunter-valley/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs-hunter-valley/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration-hunter-valley/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration-hunter-valley/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting-hunter-valley/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting-hunter-valley/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning-hunter-valley/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning-hunter-valley/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs-taree/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs-taree/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration-taree/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration-taree/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting-taree/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting-taree/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning-taree/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning-taree/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs-forster/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs-forster/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration-forster/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration-forster/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting-forster/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting-forster/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning-forster/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning-forster/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs-port-stephens/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs-port-stephens/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration-port-stephens/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration-port-stephens/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting-port-stephens/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting-port-stephens/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning-port-stephens/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning-port-stephens/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs-nelson-bay/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs-nelson-bay/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration-nelson-bay/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration-nelson-bay/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting-nelson-bay/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting-nelson-bay/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning-nelson-bay/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning-nelson-bay/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://allproroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://allproroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://allproroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://allproroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof",
                                    "url": "https://allproroofing.com.au/new-roof/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/new-roof/",
                                            "anchor_text": "New Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://allproroofing.com.au/gutter-guard/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/gutter-guard/",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof",
                                    "url": "https://allproroofing.com.au/new-roof/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/new-roof/",
                                            "anchor_text": "New Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://allproroofing.com.au/gutter-guard/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/gutter-guard/",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://allproroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://allproroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://allproroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://allproroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://allproroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://allproroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://allproroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://allproroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof",
                                    "url": "https://allproroofing.com.au/new-roof/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/new-roof/",
                                            "anchor_text": "New Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://allproroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://allproroofing.com.au/gutter-guard/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/gutter-guard/",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://allproroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://allproroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "How we can help",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "For a high-quality roofing specialist, Feel free to call David anytime. When it comes to restoring, repairing or painting your residential, commercial or strata roof at competitive prices\u2014we have your needs covered.\u200b",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Difference",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "What makes All Pro Roofing different? Deal direct with David Millard, the owner and operator. You will receive superior customer service by having your own dedicated roofing specialist to guide you through the process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "David is a little old fashioned and believes that the key to a great business is customer service and being focused on the wants and needs of a customer.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Don\u2019t take our word for it \u2013 hear it from our very happy customers below!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "See what our customers have to say!",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "\"David was very professional and did an excellent job restoring our roof! Looked brand new when he was finished! I highly recommend David for your roof restoration work.\"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Would recommend David to anyone. He is very professional, very clean and tidy. Most important of all I found him to be honest, hard working and fair. Does what he says for a very fair price. Thank you David\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"Thankyou David, owner of All Pro Roofing! I am extremely happy with the results of getting my roof restored. David has done a fantastic job and I would highly recommend you to anyone.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cI had my roof restored only a year ago by someone else and all the paint peeled off within a few months. One of my friends recommend David. David even showed me his contractor license! After 3 days of hard work David completed it and it looks great! Thanks David.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cDavid restored my roof in 2005 and had done a great job. I moved house 12 years later and called David on the exact same number. He fully restored my roof again and has done a very professional job. Thank you David. I\u2019ll be keeping your number in case I move again!\u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Complete roofing specialists",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "All Pro Roofing",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "All Pro Roofing",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "All Pro Roofing",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "All Pro Roofing",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "All Pro Roofing",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "New Roof",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "All Pro Roofing",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Guard",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Over 30 years experience",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Services",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://allproroofing.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://allproroofing.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/roof-repairs/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://allproroofing.com.au/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/roof-painting/",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "New Roof",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "New Roof",
                                        "url": "https://allproroofing.com.au/new-roof/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/new-roof/",
                                                "anchor_text": "New Roof"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Cleaning",
                                        "url": "https://allproroofing.com.au/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/roof-cleaning/",
                                                "anchor_text": "Roof Cleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Guard",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter Guard",
                                        "url": "https://allproroofing.com.au/gutter-guard/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/gutter-guard/",
                                                "anchor_text": "Gutter Guard"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://allproroofing.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://allproroofing.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/roof-repairs/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Cleaning",
                                        "url": "https://allproroofing.com.au/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/roof-cleaning/",
                                                "anchor_text": "Roof Cleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "New Roof",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "New Roof",
                                        "url": "https://allproroofing.com.au/new-roof/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/new-roof/",
                                                "anchor_text": "New Roof"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "New Slate Roofing",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "New Slate Roofing",
                                        "url": "https://allproroofing.com.au/?page_id=4288",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/?page_id=4288",
                                                "anchor_text": "New Slate Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Repairs",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roof Repairs",
                                        "url": "https://allproroofing.com.au/?page_id=4362",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/?page_id=4362",
                                                "anchor_text": "Slate Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Maintenance",
                                        "url": "https://allproroofing.com.au/?page_id=4375",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/?page_id=4375",
                                                "anchor_text": "Roof Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://allproroofing.com.au/?page_id=4375",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/?page_id=4375",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaf Guard Install",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Leaf Guard Install",
                                        "url": "https://allproroofing.com.au/gutter-guard/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/gutter-guard/",
                                                "anchor_text": "Leaf Guard Install"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Services",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "All Services",
                                        "url": "https://allproroofing.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://allproroofing.com.au/services/",
                                                "anchor_text": "All Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Pro Roofing",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Unbeatable prices & quality workmanship",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "All Pro Roofing have been providing unbeatable prices & quality workmanship for all your roofing needs for 30+ years.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Trading off the same licence number since 2005!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "LICENCE NUMBER 178790c",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Top Quality Products",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Dulux Accredited",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Exceptional Customer Service",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Real Value for Money",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "For an obligation free quote on our roofing services, give David a call today.\u200b",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We would love to help with your next project!",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact us for a no obligation free quote today!",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "All Pro Roofing",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete roofing specialists",
                                "main_title": "Complete roofing specialists",
                                "author": "All Pro Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0406620352"
                            ],
                            "emails": [
                                "david.allroofing@gmail.com%20"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}