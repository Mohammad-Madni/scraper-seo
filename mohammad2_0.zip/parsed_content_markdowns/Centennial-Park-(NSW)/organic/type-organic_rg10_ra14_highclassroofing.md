{
    "id": "01190728-1132-0216-0000-243cdd7ae77e",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0207 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://highclassroofing.com.au/suburbs/roof-repairs-centennial-park/",
        "target": "highclassroofing.com.au",
        "start_url": "https://highclassroofing.com.au/suburbs/roof-repairs-centennial-park/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Centennial-Park-(NSW)\\organic\\type-organic_rg10_ra14_highclassroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:51 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "For more information on any of the services offered by High Class Roofing or a free no obligation quotation, please complete the following form or call us on 0405 229 765.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://highclassroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://highclassroofing.com.au/contact/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/contact/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing Contractor",
                                    "url": "https://highclassroofing.com.au/roofing-contractor/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roofing-contractor/",
                                            "anchor_text": "Roofing Contractor"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://highclassroofing.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Coating",
                                    "url": "https://highclassroofing.com.au/roof-coating/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-coating/",
                                            "anchor_text": "Roof Coating"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing",
                                    "url": "https://highclassroofing.com.au/roof-flashing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-flashing/",
                                            "anchor_text": "Roof Flashing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Fascia Repair",
                                    "url": "https://highclassroofing.com.au/roof-fascia/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-fascia/",
                                            "anchor_text": "Roof Fascia Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Gutter Repair",
                                    "url": "https://highclassroofing.com.au/roof-gutter-repair-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-gutter-repair-sydney/",
                                            "anchor_text": "Roof Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Guttering",
                                    "url": "https://highclassroofing.com.au/roof-guttering-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-guttering-sydney/",
                                            "anchor_text": "Roof Guttering"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Insulation",
                                    "url": "https://highclassroofing.com.au/roof-insulation/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-insulation/",
                                            "anchor_text": "Roof Insulation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://highclassroofing.com.au/roof-leak-repair-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-leak-repair-sydney/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://highclassroofing.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://highclassroofing.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://highclassroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://highclassroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Renovation",
                                    "url": "https://highclassroofing.com.au/roof-renovation/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-renovation/",
                                            "anchor_text": "Roof Renovation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Shingles",
                                    "url": "https://highclassroofing.com.au/roof-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-shingles/",
                                            "anchor_text": "Roof Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tiling",
                                    "url": "https://highclassroofing.com.au/roof-tiling/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-tiling/",
                                            "anchor_text": "Roof Tiling"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://highclassroofing.com.au/roof-ventilation/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-ventilation/",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Waterproofing",
                                    "url": "https://highclassroofing.com.au/roof-waterproofing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-waterproofing/",
                                            "anchor_text": "Roof Waterproofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fibre Glass Roof",
                                    "url": "https://highclassroofing.com.au/fibreglass-roof-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/fibreglass-roof-sydney/",
                                            "anchor_text": "Fibre Glass Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Twin Wall Polycarbonate Roofing",
                                    "url": "https://highclassroofing.com.au/twin-wall-polycarbonate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/twin-wall-polycarbonate-roofing/",
                                            "anchor_text": "Twin Wall Polycarbonate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Laserlite Roofing",
                                    "url": "https://highclassroofing.com.au/laserlite-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/laserlite-roofing/",
                                            "anchor_text": "Laserlite Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Trim Deck Roofing",
                                    "url": "https://highclassroofing.com.au/trim-deck-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/trim-deck-roofing/",
                                            "anchor_text": "Trim Deck Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Clip Lock Roofing",
                                    "url": "https://highclassroofing.com.au/clip-lock-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/clip-lock-roofing/",
                                            "anchor_text": "Clip Lock Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Centennial Park",
                                    "url": "https://highclassroofing.com.au/suburbs/roof-repairs-centennial-park/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/suburbs/roof-repairs-centennial-park/",
                                            "anchor_text": "Roof Repairs Centennial Park"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "We at High Class Roofing are committed to providing our customers with the highest quality roofing services available.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "All work will be completed to the highest standards and that any materials used will be of the highest quality.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "All work will be completed in a timely manner, with no delays or disruptions to your daily life.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "We cover any repairs or replacements that may be necessary due to faulty materials or workmanship.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Give us a call today at 0405 229 765 to speak with one of our representatives. We will send our qualified roof inspector and do a full site inspection and quote for free!",
                                    "url": "https://highclassroofing.com.au/contact",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/contact",
                                            "anchor_text": "quote for free!"
                                        }
                                    ]
                                },
                                {
                                    "text": "Top Serving Roofing Suburbs",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://highclassroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://highclassroofing.com.au/contact",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/contact",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://highclassroofing.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms and Conditions",
                                    "url": "https://highclassroofing.com.au/terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing Contractor",
                                    "url": "https://highclassroofing.com.au/roofing-contractor/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roofing-contractor/",
                                            "anchor_text": "Roofing Contractor"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://highclassroofing.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Coating",
                                    "url": "https://highclassroofing.com.au/roof-coating/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-coating/",
                                            "anchor_text": "Roof Coating"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Fascia Repair",
                                    "url": "https://highclassroofing.com.au/roof-fascia/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-fascia/",
                                            "anchor_text": "Roof Fascia Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing",
                                    "url": "https://highclassroofing.com.au/roof-flashing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-flashing/",
                                            "anchor_text": "Roof Flashing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Gutter Repair",
                                    "url": "https://highclassroofing.com.au/roof-gutter-repair-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-gutter-repair-sydney/",
                                            "anchor_text": "Roof Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Guttering",
                                    "url": "https://highclassroofing.com.au/roof-guttering-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-guttering-sydney/",
                                            "anchor_text": "Roof Guttering"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Insulation",
                                    "url": "https://highclassroofing.com.au/roof-insulation/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-insulation/",
                                            "anchor_text": "Roof Insulation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://highclassroofing.com.au/roof-leak-repair-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-leak-repair-sydney/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://highclassroofing.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://highclassroofing.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://highclassroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://highclassroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Renovation",
                                    "url": "https://highclassroofing.com.au/roof-renovation/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-renovation/",
                                            "anchor_text": "Roof Renovation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Shingles",
                                    "url": "https://highclassroofing.com.au/roof-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-shingles/",
                                            "anchor_text": "Roof Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tiling",
                                    "url": "https://highclassroofing.com.au/roof-tiling/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-tiling/",
                                            "anchor_text": "Roof Tiling"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://highclassroofing.com.au/roof-ventilation/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-ventilation/",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Waterproofing",
                                    "url": "https://highclassroofing.com.au/roof-waterproofing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-waterproofing/",
                                            "anchor_text": "Roof Waterproofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fibreglass Roof",
                                    "url": "https://highclassroofing.com.au/fibreglass-roof-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/fibreglass-roof-sydney/",
                                            "anchor_text": "Fibreglass Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://highclassroofing.com.au/skylight-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/skylight-installation-sydney/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Twin Wall Installation",
                                    "url": "https://highclassroofing.com.au/twin-wall-polycarbonate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/twin-wall-polycarbonate-roofing/",
                                            "anchor_text": "Twin Wall Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Fascia Repair",
                                    "url": "https://highclassroofing.com.au/roof-fascia/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-fascia/",
                                            "anchor_text": "Roof Fascia Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Laserlite Sheeting",
                                    "url": "https://highclassroofing.com.au/laserlite-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/laserlite-roofing/",
                                            "anchor_text": "Laserlite Sheeting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Trim Deck Roofing",
                                    "url": "https://highclassroofing.com.au/trim-deck-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/trim-deck-roofing/",
                                            "anchor_text": "Trim Deck Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Clip Lock Roofing",
                                    "url": "https://highclassroofing.com.au/clip-lock-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/clip-lock-roofing/",
                                            "anchor_text": "Clip Lock Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Sydney",
                                    "url": "https://highclassroofing.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://highclassroofing.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration Sydney"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs Centennial Park",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Seeking dependable and experienced roof repairs in Centennial Park NSW 2021? Your quest stops now! Understanding the vital role your roof plays in shielding your family from the elements, High Class Roofing provides a diverse selection of roof repair services in Centennial Park, carried out by skilled and certified professionals.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team is well-equipped to handle a wide array of roof repair needs, addressing anything from minor leaks to major damage caused by storms or wear and tear. We have expertise in working with different roofing materials, including tiles, metal, and concrete.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted Centennial Park Roof Repair Service for Reliable Solutions",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Count on our esteemed Centennial Park roof repair service for the longevity and soundness of your roof. Recognising the vital role of a steadfast roofing system in safeguarding your home or business, our team of skilled professionals is committed to delivering enduring solutions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Backed by years of industry expertise, we proudly present ourselves as the ultimate experts for all your roofing needs. Through the use of cutting-edge techniques and premium materials, we secure the durability and resilience of your roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Beyond repairs, our commitment to quality includes transparent communication and timely project completion. Understanding the urgency of roofing issues, our quick response sets us apart. Rely on us to promptly address any concerns, ensuring peace of mind and a resilient roof for Centennial Park\u2019s unpredictable weather.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Benefits of Roofing Repairs in Centennial Park",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Opting for timely roofing repairs in Centennial Park offers significant benefits for both your property and your peace of mind. Tackling minor issues promptly prevents them from turning into expensive problems in the future. Explore how proactive roof repairs can safeguard your Centennial Park home.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Prevent costly water damage: Centennial Park experiences unpredictable weather patterns, often characterised by heavy rain and storms that can jeopardise the integrity of your roof. Failure to address leaks promptly can result in significant water damage within your home, affecting ceilings, walls, and even electrical systems.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Extend the lifespan of your roof: By promptly addressing minor issues such as loose tiles, cracked flashing, or blocked gutters, you guarantee that your well-maintained roof in Centennial Park performs optimally and enjoys an extended lifespan lasting for decades.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Enhance your home\u2019s energy efficiency: A compromised roof can undermine your home\u2019s insulation, causing higher energy consumption. Leaks and gaps permit conditioned air to leak out, requiring your HVAC system to exert more effort in maintaining comfortable temperatures.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ensure the comfort, safety, and potential value increase of your home by prioritising timely roofing repairs in Centennial Park. Don\u2019t allow minor issues to escalate \u2013 invest in professional roof repairs today and enjoy the peace of mind that comes with a secure and protected home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Unmatched Roof Repairs Leaving a Lasting Impression",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Opt for High Class Roofing when you need expert roof repairs in Centennial Park; our commitment and expertise ensure a seamless solution and a lasting impression on your roofing needs. Our dedicated team of skilled professionals brings years of experience to every project, ensuring expert craftsmanship and attention to detail.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "High Class Roofing is dedicated to using premium quality materials, ensuring the longevity and durability of our repairs. We take pride in providing efficient and timely services that minimise disruptions to your daily life. Trust us for expert roof repairs that not only meet but exceed your expectations, leaving a lasting impression of quality and reliability. Elevate your roofing experience \u2013 choose us for excellence that endures.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "REPAIR YOUR ROOF WITH EXPERT CARE",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Is your roof displaying signs of wear and tear? Take action before leaks become a major concern! Our experienced roofing team is poised to expertly repair and strengthen your roof. Schedule your repair today to safeguard your home from the elements. Have confidence in us to provide reliable solutions and ensure your peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How do I know if my roof needs repairs?",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Seek out signs such as water stains, shingles that are missing, or damage that is visible.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What causes roof tiles to crack?",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tile cracks may manifest as a result of aging and exposure to extreme weather conditions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What is the average duration for a standard roof repair?",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "While timelines may differ, our team\u2019s goal is to consistently provide efficient and timely repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What sets High Class Roofing apart in Centennial Park?",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Distinguishing ourselves through our knowledge, speedy service, and unwavering commitment to quality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you offer warranties on your roof repair services?",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Yes, our repair services include warranties to ensure your peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "CONTACT US",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Address a small leak promptly to avoid a major issue. Reach out to our dependable roofing specialist for a repair quote today. Taking action early can save you money and prevent further damage to your home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Centennial Park",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We also serve in these surrounding areas:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs Abbotsbury",
                                        "url": "https://highclassroofing.com.au/suburbs/roof-repairs-abbotsbury/",
                                        "urls": [
                                            {
                                                "url": "https://highclassroofing.com.au/suburbs/roof-repairs-abbotsbury/",
                                                "anchor_text": "Roof Repairs Abbotsbury"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Abbotsford",
                                        "url": "https://highclassroofing.com.au/suburbs/roof-repairs-abbotsford/",
                                        "urls": [
                                            {
                                                "url": "https://highclassroofing.com.au/suburbs/roof-repairs-abbotsford/",
                                                "anchor_text": "Roof Repairs Abbotsford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Acacia Gardens",
                                        "url": "https://highclassroofing.com.au/suburbs/roof-repairs-acacia-gardens/",
                                        "urls": [
                                            {
                                                "url": "https://highclassroofing.com.au/suburbs/roof-repairs-acacia-gardens/",
                                                "anchor_text": "Roof Repairs Acacia Gardens"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "WE ARE PROUD TO WORK WITH",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FREQUENTLY ASKED QUESTIONS",
                                "main_title": "Roof Repairs Centennial Park",
                                "author": "High Class Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 1289,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0405 229 765"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}