{
    "id": "01190728-1132-0216-0000-9c9d7be84e36",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0253 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.aptroofing.com.au/",
        "target": "www.aptroofing.com.au",
        "start_url": "https://www.aptroofing.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Centennial-Park-(NSW)\\organic\\type-organic_rg16_ra20_aptroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:55 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Our Insurances",
                                    "url": "https://www.aptroofing.com.au/our-insurances/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/our-insurances/",
                                            "anchor_text": "Our Insurances"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms of Trade",
                                    "url": "https://www.aptroofing.com.au/terms-of-trade/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/terms-of-trade/",
                                            "anchor_text": "Terms of Trade"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Area Coverage",
                                    "url": "https://www.aptroofing.com.au/service-area-coverage/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/service-area-coverage/",
                                            "anchor_text": "Service Area Coverage"
                                        }
                                    ]
                                },
                                {
                                    "text": "Meet The Team",
                                    "url": "https://www.aptroofing.com.au/about-us/meet-the-team/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/about-us/meet-the-team/",
                                            "anchor_text": "Meet The Team"
                                        }
                                    ]
                                },
                                {
                                    "text": "Capability Statement",
                                    "url": "https://www.aptroofing.com.au/about-us/capability-statement/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/about-us/capability-statement/",
                                            "anchor_text": "Capability Statement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Owner Roofing",
                                    "url": "https://www.aptroofing.com.au/home-owner-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/home-owner-roofing/",
                                            "anchor_text": "Home Owner Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata & Real Estate Roofing",
                                    "url": "https://www.aptroofing.com.au/strata-real-estate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/strata-real-estate-roofing/",
                                            "anchor_text": "Strata & Real Estate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Boral Roof Tiles",
                                    "url": "https://www.aptroofing.com.au/boral-roof-tiles/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/boral-roof-tiles/",
                                            "anchor_text": "Boral Roof Tiles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Insurance Roofing",
                                    "url": "https://www.aptroofing.com.au/insurance-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/insurance-roofing/",
                                            "anchor_text": "Insurance Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.aptroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Insurances",
                                    "url": "https://www.aptroofing.com.au/our-insurances/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/our-insurances/",
                                            "anchor_text": "Our Insurances"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms of Trade",
                                    "url": "https://www.aptroofing.com.au/terms-of-trade/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/terms-of-trade/",
                                            "anchor_text": "Terms of Trade"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Area Coverage",
                                    "url": "https://www.aptroofing.com.au/service-area-coverage/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/service-area-coverage/",
                                            "anchor_text": "Service Area Coverage"
                                        }
                                    ]
                                },
                                {
                                    "text": "Meet The Team",
                                    "url": "https://www.aptroofing.com.au/about-us/meet-the-team/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/about-us/meet-the-team/",
                                            "anchor_text": "Meet The Team"
                                        }
                                    ]
                                },
                                {
                                    "text": "Capability Statement",
                                    "url": "https://www.aptroofing.com.au/about-us/capability-statement/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/about-us/capability-statement/",
                                            "anchor_text": "Capability Statement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Owner Roofing",
                                    "url": "https://www.aptroofing.com.au/home-owner-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/home-owner-roofing/",
                                            "anchor_text": "Home Owner Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata & Real Estate Roofing",
                                    "url": "https://www.aptroofing.com.au/strata-real-estate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/strata-real-estate-roofing/",
                                            "anchor_text": "Strata & Real Estate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Boral Roof Tiles",
                                    "url": "https://www.aptroofing.com.au/boral-roof-tiles/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/boral-roof-tiles/",
                                            "anchor_text": "Boral Roof Tiles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Insurance Roofing",
                                    "url": "https://www.aptroofing.com.au/insurance-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/insurance-roofing/",
                                            "anchor_text": "Insurance Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.aptroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Apt Roofing Pty Ltd is a family owned business based in Sydney\u2019s Eastern Suburbs specialising in everything roofing \u2013 re-roofing, new roofing, roof repairs, roof restorations, roof ventilation, asbestos removal, guttering and downpipes.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Home Owner Roofing",
                                    "url": "https://www.aptroofing.com.au/home-owner-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/home-owner-roofing/",
                                            "anchor_text": "Home Owner Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata & Real Estate Roofing",
                                    "url": "https://www.aptroofing.com.au/strata-real-estate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/strata-real-estate-roofing/",
                                            "anchor_text": "Strata & Real Estate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Insurance Roofing",
                                    "url": "https://www.aptroofing.com.au/insurance-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/insurance-roofing/",
                                            "anchor_text": "Insurance Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "About APT Roofing",
                                    "url": "https://www.aptroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/about-us/",
                                            "anchor_text": "About APT Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Area Coverage",
                                    "url": "https://www.aptroofing.com.au/service-area-coverage/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/service-area-coverage/",
                                            "anchor_text": "Service Area Coverage"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get A Quote",
                                    "url": "https://www.aptroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/contact-us/",
                                            "anchor_text": "Get A Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Boral Roof Tiles",
                                    "url": "https://www.aptroofing.com.au/boral-roof-tiles/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/boral-roof-tiles/",
                                            "anchor_text": "Boral Roof Tiles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Capability Statement",
                                    "url": "https://www.aptroofing.com.au/about-us/capability-statement/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/about-us/capability-statement/",
                                            "anchor_text": "Capability Statement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Owner Roofing",
                                    "url": "https://www.aptroofing.com.au/home-owner-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/home-owner-roofing/",
                                            "anchor_text": "Home Owner Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata & Real Estate Roofing",
                                    "url": "https://www.aptroofing.com.au/strata-real-estate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/strata-real-estate-roofing/",
                                            "anchor_text": "Strata & Real Estate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Insurance Roofing",
                                    "url": "https://www.aptroofing.com.au/insurance-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/insurance-roofing/",
                                            "anchor_text": "Insurance Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "About APT Roofing",
                                    "url": "https://www.aptroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/about-us/",
                                            "anchor_text": "About APT Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Area Coverage",
                                    "url": "https://www.aptroofing.com.au/service-area-coverage/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/service-area-coverage/",
                                            "anchor_text": "Service Area Coverage"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get A Quote",
                                    "url": "https://www.aptroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/contact-us/",
                                            "anchor_text": "Get A Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Boral Roof Tiles",
                                    "url": "https://www.aptroofing.com.au/boral-roof-tiles/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/boral-roof-tiles/",
                                            "anchor_text": "Boral Roof Tiles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Capability Statement",
                                    "url": "https://www.aptroofing.com.au/about-us/capability-statement/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/about-us/capability-statement/",
                                            "anchor_text": "Capability Statement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flora Street, Roselands",
                                    "url": "https://www.aptroofing.com.au/projects/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/projects/",
                                            "anchor_text": "Flora Street, Roselands"
                                        }
                                    ]
                                },
                                {
                                    "text": "Riverside Girls School, Huntley's Point",
                                    "url": "https://www.aptroofing.com.au/projects/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/projects/",
                                            "anchor_text": "Riverside Girls School, Huntley's Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Floss St, Hurlstone Park",
                                    "url": "https://www.aptroofing.com.au/projects/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/projects/",
                                            "anchor_text": "Floss St, Hurlstone Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Campbell Parade, Bondi",
                                    "url": "https://www.aptroofing.com.au/projects/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/projects/",
                                            "anchor_text": "Campbell Parade, Bondi"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Insurances",
                                    "url": "https://www.aptroofing.com.au/our-insurances/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/our-insurances/",
                                            "anchor_text": "Our Insurances"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms of Trade",
                                    "url": "https://www.aptroofing.com.au/terms-of-trade/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/terms-of-trade/",
                                            "anchor_text": "Terms of Trade"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Area Coverage",
                                    "url": "https://www.aptroofing.com.au/service-area-coverage/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/service-area-coverage/",
                                            "anchor_text": "Service Area Coverage"
                                        }
                                    ]
                                },
                                {
                                    "text": "Meet The Team",
                                    "url": "https://www.aptroofing.com.au/about-us/meet-the-team/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/about-us/meet-the-team/",
                                            "anchor_text": "Meet The Team"
                                        }
                                    ]
                                },
                                {
                                    "text": "Capability Statement",
                                    "url": "https://www.aptroofing.com.au/about-us/capability-statement/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/about-us/capability-statement/",
                                            "anchor_text": "Capability Statement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Owner Roofing",
                                    "url": "https://www.aptroofing.com.au/home-owner-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/home-owner-roofing/",
                                            "anchor_text": "Home Owner Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata & Real Estate Roofing",
                                    "url": "https://www.aptroofing.com.au/strata-real-estate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/strata-real-estate-roofing/",
                                            "anchor_text": "Strata & Real Estate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Boral Roof Tiles",
                                    "url": "https://www.aptroofing.com.au/boral-roof-tiles/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/boral-roof-tiles/",
                                            "anchor_text": "Boral Roof Tiles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Insurance Roofing",
                                    "url": "https://www.aptroofing.com.au/insurance-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/insurance-roofing/",
                                            "anchor_text": "Insurance Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.aptroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.aptroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "ROOF REPLACEMENT AND REPAIR",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "APT Roofing has a long standing commitment in servicing home owners, Strata and Real Estate managed Properties",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "One Stop Roofing Shop",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Our expertise in roofing encompasses re-roofing, new installations, roof repairs, restorations, leak repair, and quality roof replacement. We also offer advanced roofing solutions, ventilation, asbestos removal, along with guttering and downpipe services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "ABOUT US",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Apt Roofing Pty Ltd is a family-owned enterprise located in Sydney\u2019s Eastern Suburbs, specializes in a comprehensive range of roofing services. Our expertise includes re-roofing, the installation of new roofing, precision roof leak repairs, thorough roof restorations, effective roof ventilation solutions, asbestos removal, as well as guttering and downpipes. We are committed to delivering top-quality roofing solutions tailored to meet the unique needs of each project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "OUR COMMITMENT",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We believe in good old fashioned customer service and pride ourselves in providing customers with quality products and quality workmanship each and every time. We endeavour to complete jobs with minimal interruption to both owners and tenants.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Registration",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We\u2019re fully accredited by Trades Monitor, Australia\u2019s top specialists in contractor management and accreditation. With over 150 clients, Trades Monitor maintains a database of tradesmen committed to high safety standards and unparalleled service.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "SYDNEY'S PREMIER ROOFING SPECIALIST",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Offering a full spectrum of roofing services, Apt Roofing Pty Ltd operates from Sydney\u2019s Eastern Suburbs with a family-owned ethos. Our expertise includes re-roofing, new roof installation, urgent roof repairs, detailed roof restorations, roof ventilation improvement, precise asbestos removal, and the handling of guttering and downpipes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "ROOF REPLACEMENT AND REPAIR",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "By the Robin Dods Roof Tile Excellence Award 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "\u2605 \u2605 \u2605 \u2605 \u2605 5/5",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Visit Our Showroom",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Apt Roofing Pty Ltd is proud to announce the opening of the first and only full roofing display center in the Eastern Suburbs. A full display of all Boral \u00ae Roof tiles is available, numerous Colorbond \u00ae displays including all types of metal roofing and guttering.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Please visit us to discuss the color options with our friendly staff. We are open Monday to Friday from 7:00 AM to 4:00PM.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you have more question regarding our showroom, feel free to contact us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose APT Roofing",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "At Apt Roofing Pty Ltd, we specialise in comprehensive roofing solutions that cover everything from roof restoration and roof leak repair to full roof replacement. Our tailored approach in Sydney roof repairs meets the specific needs and budgets of our customers, ensuring lasting value and enhancing the longevity of your home.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our services extend beyond basic roof repair. We are skilled in corrugated roofing, particularly corrugated roof sheeting and corrugated metal roofing. Whether you are interested in Boral Roof Tiles, roof tiles of other brands, or even leaky ceiling repair, we\u2019ve got you covered.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "In addition to home roofing, our expertise extends to apartment roofing as well. We are fully qualified for specialised tasks like the safe removal and disposal of asbestos roof sheeting and the installation of commercial and industrial skylights and insulation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Our Roofing Solutions",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Home Owner Roofing",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "We deliver bespoke roofing solutions paired with expert guidance, ensuring every home and building across Sydney is topped with perfection.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Strata & Real Estate Roofing",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Our company prides itself on a rich legacy of dedicated service to Strata and Real Estate managed properties, consistently delivering excellence and reliability in every project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Insurance Roofing",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Apt Roofing specialises in a wide range of roofing services, including new roofing installations, re-roofing, and roof repairs, often catering to insurance-based projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "OUR HISTORY\u200b",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "ROOFING SERVICES",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "HOME OWNER ROOFING",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We provide practical roofing solutions and expert advice for every home or building across Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "STRATA & REAL ESTATE ROOFING",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Apt Roofing has a longstanding commitment in servicing Strata and Real Estate managed properties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "INSURANCE ROOFING",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "APT Roofing engages in all types of roofing, new roofing, re-roofing, roof repairs and often insurance based projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Customer Testimonials",
                                "main_title": "ROOF REPLACEMENT AND REPAIR",
                                "author": "APT Roofing Pty Ltd",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heather Hawkins",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "October 15, 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lisa Chen",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "October 8, 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jaden Stowe",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "September 24, 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Julia Hall",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "September 20, 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Emma Finn",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "September 16, 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "September 5, 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Greg Brooks",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "September 5, 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Toby Johnson",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "September 2, 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "alan israel",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "August 28, 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mark Uncles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "August 26, 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61296667373",
                                "0296667373"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}