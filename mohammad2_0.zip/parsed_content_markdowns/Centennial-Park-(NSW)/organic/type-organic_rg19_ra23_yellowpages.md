{
    "id": "01190728-1132-0216-0000-45eedc4371fc",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0314 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.yellowpages.com.au/find/builders-building-contractors/Centennial%20Park-NSW-2021/page-3",
        "target": "www.yellowpages.com.au",
        "start_url": "https://www.yellowpages.com.au/find/builders-building-contractors/Centennial%20Park-NSW-2021/page-3",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Centennial-Park-(NSW)\\organic\\type-organic_rg19_ra23_yellowpages.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:54 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Centennial Park NSW",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Builders & Building Contractors Near Me",
                                    "url": "https://www.yellowpages.com.au/find/builders-building-contractors/nsw",
                                    "urls": [
                                        {
                                            "url": "https://www.yellowpages.com.au/find/builders-building-contractors/nsw",
                                            "anchor_text": "Builders & Building Contractors Near Me"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Important Questions to ask building contractors.",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Are you about to build or renovate your home?\u00a0Choosing quality builders and reputable construction companies is paramount to the success of this. Ask these questions when making your selection of home builders.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What is their reputation like? Have they got a good name in the industry. Perhaps see if there are testimonials from past clients",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How long have they been in business? Be cautious of new companies who don't have many examples to demonstrate.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Where are they located? Local builders will have a portfolio of projects in your area which you may be able to inspect for quality control.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do they have a specialisation? Are they residential, townhouse or luxury builders? You want to select a construction company whose forte aligns with your construction project.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do they hold the relevant permits and licenses? Only choose registered builders who are compliant with the required regulation.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do they have an insurance policy and if so when is the coverage valid until?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Use these questions to fuel your investigation and research. Keep searching through our listings, compare quotes and find a builder who is well matched for your project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What do builders do in Australia?",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A builder is a licensed professional that oversees, coordinates and works on the construction or repair of homes and commercial buildings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do I need a builder or can I build a house myself?",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "As long as you're registered and intend to use your own skills to build or extend or renovate your home. An owner builder is someone intent on building their own home for the purposes of using the home as their own domestic dwelling.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How do builders calculate build costs?",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Builders generally use a cost per square metre (m2) to price a job. The costs can differ based on the type of design, materials, locations and many more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What do I look for when hiring a builder?",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Home owners typically select builders based on their quality, experience, qualifications, portfolios and ease of communication.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Where can I find builders or building contractors?",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You can research by speaking to family and friends, browsing the internet or rely on trusted directory listing platforms with honest and transparent reviews.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Resolve",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Management Services & Consultants, Surry Hills, NSW 2010",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Resolve",
                                        "url": "https://www.yellowpages.com.au/nsw/surry-hills/resolve-11959229-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/surry-hills/resolve-11959229-listing.html",
                                                "anchor_text": "Resolve"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lvl 4 10- 14 Waterloo St, Surry Hills, NSW, 2010",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Lvl+4+10-+14+Waterloo+St&context=undefined&directionMode=true&elat=-33.88489&elon=151.21148&ena=Resolve&estr=Lvl+4+10-+14+Waterloo+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=3&productId=999902183078&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DResolve%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.88489%26lon%3D151.21148%26selectedViewMode%3Dlist&yellowId=11959229",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Lvl+4+10-+14+Waterloo+St&context=undefined&directionMode=true&elat=-33.88489&elon=151.21148&ena=Resolve&estr=Lvl+4+10-+14+Waterloo+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=3&productId=999902183078&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DResolve%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.88489%26lon%3D151.21148%26selectedViewMode%3Dlist&yellowId=11959229",
                                                "anchor_text": "Lvl 4 10- 14 Waterloo St, Surry Hills, NSW, 2010"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9213 5500",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Building Management Australia",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Management Services & Consultants, Double Bay, NSW 2028",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Building Management Australia",
                                        "url": "https://www.yellowpages.com.au/nsw/double-bay/building-management-australia-1000001725454-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/double-bay/building-management-australia-1000001725454-listing.html",
                                                "anchor_text": "Building Management Australia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Level 1 23-25 Bay St, Double Bay, NSW, 2028",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Level+1+23-25+Bay+St&context=undefined&directionMode=true&elat=-33.877849&elon=151.241952&ena=Building+Management+Australia&estr=Level+1+23-25+Bay+St&esu=Double+Bay%2C+NSW%2C+2028&productVersion=1&productId=1000001725454&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DBuilding+Management+Australia%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.877849%26lon%3D151.241952%26selectedViewMode%3Dlist&yellowId=1000001725454",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Level+1+23-25+Bay+St&context=undefined&directionMode=true&elat=-33.877849&elon=151.241952&ena=Building+Management+Australia&estr=Level+1+23-25+Bay+St&esu=Double+Bay%2C+NSW%2C+2028&productVersion=1&productId=1000001725454&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DBuilding+Management+Australia%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.877849%26lon%3D151.241952%26selectedViewMode%3Dlist&yellowId=1000001725454",
                                                "anchor_text": "Level 1 23-25 Bay St, Double Bay, NSW, 2028"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 8356 7127",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Park Lane Carpentry",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Carpenters & Joiners, Randwick, NSW 2031",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Park Lane Carpentry is a Sydney based contractor with 17+ years of experience who specialises in all aspects of carpentry and building related works.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Park Lane Carpentry",
                                        "url": "https://www.yellowpages.com.au/nsw/randwick/park-lane-carpentry-1000002264003-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/randwick/park-lane-carpentry-1000002264003-listing.html",
                                                "anchor_text": "Park Lane Carpentry"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Legal ID: 302517C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0403 136 596",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Unique bath and kitchens",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Kitchen Renovations & Designs, Surry Hills, NSW 2010",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Unique Bath and Kitchens in Sydney - making your design dreams a reality at an affordable price",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Unique bath and kitchens",
                                        "url": "https://www.yellowpages.com.au/nsw/surry-hills/unique-bath-and-kitchens-1000002257617-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/surry-hills/unique-bath-and-kitchens-1000002257617-listing.html",
                                                "anchor_text": "Unique bath and kitchens"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Shop 12 553-555 Elizabeth St, Surry Hills, NSW, 2010",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Shop+12+553-555+Elizabeth+St&context=undefined&directionMode=true&elat=-33.889509&elon=151.207679&ena=Unique+bath+and+kitchens&estr=Shop+12+553-555+Elizabeth+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=8&productId=1000002257617&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DUnique+bath+and+kitchens%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.889509%26lon%3D151.207679%26selectedViewMode%3Dlist&yellowId=1000002257617",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Shop+12+553-555+Elizabeth+St&context=undefined&directionMode=true&elat=-33.889509&elon=151.207679&ena=Unique+bath+and+kitchens&estr=Shop+12+553-555+Elizabeth+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=8&productId=1000002257617&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DUnique+bath+and+kitchens%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.889509%26lon%3D151.207679%26selectedViewMode%3Dlist&yellowId=1000002257617",
                                                "anchor_text": "Shop 12 553-555 Elizabeth St, Surry Hills, NSW, 2010"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 8959 9533",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Brooks Hire Service Pty Ltd",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Builders & Contractors Equipment Hire",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Family Owned & Operated Since 1979",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "1300 276 657",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Patio Builders",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Garage Builders & Prefabricators",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Rural & Industrial Sheds",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Telford's Building Systems",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Steel Building Solutions Built to Last in Yatala",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Rural & Industrial Sheds",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(03) 5821 4399",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Custombuilt Frames & Trusses",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Trusses & Wall Frames",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "H2F Termite Resistant Timber Custom And Unique Plans Owner Builders",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(02) 4871 3355",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Keep It Simple Systems",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Supplying Quality New And Recycled Timber Pallets Since 1986.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pallets & Platforms",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9791 0714",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "98 Results for Builders Near You",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "NSW Pre-Purchase Inspections",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Inspection, Bondi Junction, NSW 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "NSW Pre-Purchase Inspections",
                                        "url": "https://www.yellowpages.com.au/nsw/bondi-junction/nsw-pre-purchase-inspections-12343644-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/bondi-junction/nsw-pre-purchase-inspections-12343644-listing.html",
                                                "anchor_text": "NSW Pre-Purchase Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Suite 1d/ 79 Oxford St, Bondi Junction, NSW, 2022",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Suite+1d%252F+79+Oxford+St&context=undefined&directionMode=true&elat=-33.89175&elon=151.24587&ena=NSW+Pre-Purchase+Inspections&estr=Suite+1d%2F+79+Oxford+St&esu=Bondi+Junction%2C+NSW%2C+2022&productVersion=3&productId=474079001&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DNSW+Pre-Purchase+Inspections%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.89175%26lon%3D151.24587%26selectedViewMode%3Dlist&yellowId=12343644",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Suite+1d%252F+79+Oxford+St&context=undefined&directionMode=true&elat=-33.89175&elon=151.24587&ena=NSW+Pre-Purchase+Inspections&estr=Suite+1d%2F+79+Oxford+St&esu=Bondi+Junction%2C+NSW%2C+2022&productVersion=3&productId=474079001&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DNSW+Pre-Purchase+Inspections%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.89175%26lon%3D151.24587%26selectedViewMode%3Dlist&yellowId=12343644",
                                                "anchor_text": "Suite 1d/ 79 Oxford St, Bondi Junction, NSW, 2022"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9369 2787",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "N.S.W Master Building Consultants",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Consultants, Bondi Junction, NSW 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "N.S.W Master Building Consultants",
                                        "url": "https://www.yellowpages.com.au/nsw/bondi-junction/nsw-master-building-consultants-13593004-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/bondi-junction/nsw-master-building-consultants-13593004-listing.html",
                                                "anchor_text": "N.S.W Master Building Consultants"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Suite 1d/ 79 Oxford St, Bondi Junction, NSW, 2022",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Suite+1d%252F+79+Oxford+St&context=undefined&directionMode=true&elat=-33.89175&elon=151.24587&ena=N.S.W+Master+Building+Consultants&estr=Suite+1d%2F+79+Oxford+St&esu=Bondi+Junction%2C+NSW%2C+2022&productVersion=3&productId=474053223&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DN.S.W+Master+Building+Consultants%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.89175%26lon%3D151.24587%26selectedViewMode%3Dlist&yellowId=13593004",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Suite+1d%252F+79+Oxford+St&context=undefined&directionMode=true&elat=-33.89175&elon=151.24587&ena=N.S.W+Master+Building+Consultants&estr=Suite+1d%2F+79+Oxford+St&esu=Bondi+Junction%2C+NSW%2C+2022&productVersion=3&productId=474053223&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DN.S.W+Master+Building+Consultants%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.89175%26lon%3D151.24587%26selectedViewMode%3Dlist&yellowId=13593004",
                                                "anchor_text": "Suite 1d/ 79 Oxford St, Bondi Junction, NSW, 2022"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9369 2787",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Luka Design Studio",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Paddington, NSW 2021",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Luka Design Studio",
                                        "url": "https://www.yellowpages.com.au/nsw/paddington/luka-design-studio-13399627-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/paddington/luka-design-studio-13399627-listing.html",
                                                "anchor_text": "Luka Design Studio"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "107 Hargrave St, Paddington, NSW, 2021",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=107+Hargrave+St&context=undefined&directionMode=true&elat=-33.884777&elon=151.234171&ena=Luka+Design+Studio&estr=107+Hargrave+St&esu=Paddington%2C+NSW%2C+2021&productVersion=4&productId=999903541248&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DLuka+Design+Studio%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.884777%26lon%3D151.234171%26selectedViewMode%3Dlist&yellowId=13399627",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=107+Hargrave+St&context=undefined&directionMode=true&elat=-33.884777&elon=151.234171&ena=Luka+Design+Studio&estr=107+Hargrave+St&esu=Paddington%2C+NSW%2C+2021&productVersion=4&productId=999903541248&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DLuka+Design+Studio%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.884777%26lon%3D151.234171%26selectedViewMode%3Dlist&yellowId=13399627",
                                                "anchor_text": "107 Hargrave St, Paddington, NSW, 2021"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0404 837 327",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "BUILD ON RENOVATIONS",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Design, Extensions, Renovations & Alterations - Bondi Junction, NSW 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "BUILD ON RENOVATIONS",
                                        "url": "https://www.yellowpages.com.au/nsw/bondi-junction/build-on-renovations-1000002806333-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/bondi-junction/build-on-renovations-1000002806333-listing.html",
                                                "anchor_text": "BUILD ON RENOVATIONS"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0402 301 580",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Planahead Designs",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Bondi Junction, NSW 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Planahead Designs",
                                        "url": "https://www.yellowpages.com.au/nsw/bondi-junction/planahead-designs-13581995-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/bondi-junction/planahead-designs-13581995-listing.html",
                                                "anchor_text": "Planahead Designs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9389 0440",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Need A Draftsman",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Paddington, NSW 2021",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Need A Draftsman",
                                        "url": "https://www.yellowpages.com.au/nsw/paddington/need-a-draftsman-1000001882338-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/paddington/need-a-draftsman-1000001882338-listing.html",
                                                "anchor_text": "Need A Draftsman"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0434 262 300",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Casta Constructions Pty Ltd",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Design, Extensions, Renovations & Alterations - Paddington, NSW 2021",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Casta Constructions Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/paddington/casta-constructions-pty-ltd-13032646-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/paddington/casta-constructions-pty-ltd-13032646-listing.html",
                                                "anchor_text": "Casta Constructions Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0419 148 627",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Handy tips",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Builders - Common Questions",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "N.S.W Master Building Consultants",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Inspection, Bondi Junction, NSW 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "N.S.W Master Building Consultants",
                                        "url": "https://www.yellowpages.com.au/nsw/bondi-junction/nsw-master-building-consultants-12792004-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/bondi-junction/nsw-master-building-consultants-12792004-listing.html",
                                                "anchor_text": "N.S.W Master Building Consultants"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "9 Bronte Rd, Bondi Junction, NSW, 2022",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=9+Bronte+Rd&context=undefined&directionMode=true&elat=-33.892909&elon=151.249069&ena=N.S.W+Master+Building+Consultants&estr=9+Bronte+Rd&esu=Bondi+Junction%2C+NSW%2C+2022&productVersion=3&productId=473990200&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DN.S.W+Master+Building+Consultants%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.892909%26lon%3D151.249069%26selectedViewMode%3Dlist&yellowId=12792004",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=9+Bronte+Rd&context=undefined&directionMode=true&elat=-33.892909&elon=151.249069&ena=N.S.W+Master+Building+Consultants&estr=9+Bronte+Rd&esu=Bondi+Junction%2C+NSW%2C+2022&productVersion=3&productId=473990200&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DN.S.W+Master+Building+Consultants%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.892909%26lon%3D151.249069%26selectedViewMode%3Dlist&yellowId=12792004",
                                                "anchor_text": "9 Bronte Rd, Bondi Junction, NSW, 2022"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9369 2787",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Uri T Design",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Bondi Junction, NSW 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Uri T Design",
                                        "url": "https://www.yellowpages.com.au/nsw/bondi/uri-t-design-13775706-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/bondi/uri-t-design-13775706-listing.html",
                                                "anchor_text": "Uri T Design"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Blair St, Bondi, NSW, 2026",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Blair+St&context=undefined&directionMode=true&elat=-33.89197&elon=151.25054&ena=Uri+T+Design&estr=Blair+St&esu=Bondi%2C+NSW%2C+2026&productVersion=3&productId=999015086450&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DUri+T+Design%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.89197%26lon%3D151.25054%26selectedViewMode%3Dlist&yellowId=13775706",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Blair+St&context=undefined&directionMode=true&elat=-33.89197&elon=151.25054&ena=Uri+T+Design&estr=Blair+St&esu=Bondi%2C+NSW%2C+2026&productVersion=3&productId=999015086450&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DUri+T+Design%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.89197%26lon%3D151.25054%26selectedViewMode%3Dlist&yellowId=13775706",
                                                "anchor_text": "Blair St, Bondi, NSW, 2026"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0416 321 982",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ross Earthmoving",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Foundation & Excavation, Woollahra, NSW 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ross Earthmoving",
                                        "url": "https://www.yellowpages.com.au/nsw/woollahra/ross-earthmoving-13449769-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/woollahra/ross-earthmoving-13449769-listing.html",
                                                "anchor_text": "Ross Earthmoving"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "154 Fletcher St, Woollahra, NSW, 2025",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=154+Fletcher+St&context=undefined&directionMode=true&elat=-33.888806&elon=151.249061&ena=Ross+Earthmoving&estr=154+Fletcher+St&esu=Woollahra%2C+NSW%2C+2025&productVersion=6&productId=999903137859&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRoss+Earthmoving%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.888806%26lon%3D151.249061%26selectedViewMode%3Dlist&yellowId=13449769",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=154+Fletcher+St&context=undefined&directionMode=true&elat=-33.888806&elon=151.249061&ena=Ross+Earthmoving&estr=154+Fletcher+St&esu=Woollahra%2C+NSW%2C+2025&productVersion=6&productId=999903137859&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRoss+Earthmoving%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.888806%26lon%3D151.249061%26selectedViewMode%3Dlist&yellowId=13449769",
                                                "anchor_text": "154 Fletcher St, Woollahra, NSW, 2025"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0409 444 402",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Transcend Property Services",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Commercial Building Maintenance, Surry Hills, NSW 2010",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Transcend Property Services",
                                        "url": "https://www.yellowpages.com.au/nsw/strawberry-hills/transcend-property-services-13620986-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/strawberry-hills/transcend-property-services-13620986-listing.html",
                                                "anchor_text": "Transcend Property Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9590 3399",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Collective Design Studio",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Surry Hills, NSW 2010",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Collective Design Studio",
                                        "url": "https://www.yellowpages.com.au/nsw/surry-hills/collective-design-studio-15155568-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/surry-hills/collective-design-studio-15155568-listing.html",
                                                "anchor_text": "Collective Design Studio"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0415 777 987",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "NSW Coast Building Design",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Randwick, NSW 2031",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "NSW Coast Building Design",
                                        "url": "https://www.yellowpages.com.au/nsw/randwick/nsw-coast-building-design-1000002901736-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/randwick/nsw-coast-building-design-1000002901736-listing.html",
                                                "anchor_text": "NSW Coast Building Design"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0475 209 691",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Arquitectonico",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Randwick, NSW 2031",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Arquitectonico",
                                        "url": "https://www.yellowpages.com.au/nsw/randwick/arquitectonico-12982930-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/randwick/arquitectonico-12982930-listing.html",
                                                "anchor_text": "Arquitectonico"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Unit 27 244 Allison Rd, Randwick, NSW, 2031",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Unit+27+244+Allison+Rd&context=undefined&directionMode=true&elat=-33.91312&elon=151.24585&ena=Arquitectonico&estr=Unit+27+244+Allison+Rd&esu=Randwick%2C+NSW%2C+2031&productVersion=3&productId=999902828406&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DArquitectonico%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.91312%26lon%3D151.24585%26selectedViewMode%3Dlist&yellowId=12982930",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Unit+27+244+Allison+Rd&context=undefined&directionMode=true&elat=-33.91312&elon=151.24585&ena=Arquitectonico&estr=Unit+27+244+Allison+Rd&esu=Randwick%2C+NSW%2C+2031&productVersion=3&productId=999902828406&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DArquitectonico%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.91312%26lon%3D151.24585%26selectedViewMode%3Dlist&yellowId=12982930",
                                                "anchor_text": "Unit 27 244 Allison Rd, Randwick, NSW, 2031"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9398 5135",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "SA Smits & Associates Pty Ltd",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Surry Hills, NSW 2010",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "SA Smits & Associates Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/surry-hills/sa-smits-associates-pty-ltd-15217070-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/surry-hills/sa-smits-associates-pty-ltd-15217070-listing.html",
                                                "anchor_text": "SA Smits & Associates Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "355 Crown St, Surry Hills, NSW, 2010",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=355+Crown+St&context=undefined&directionMode=true&elat=-33.88409&elon=151.214231&ena=SA+Smits+%26+Associates+Pty+Ltd&estr=355+Crown+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=3&productId=999015931951&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DSA+Smits+%26+Associates+Pty+Ltd%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.88409%26lon%3D151.214231%26selectedViewMode%3Dlist&yellowId=15217070",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=355+Crown+St&context=undefined&directionMode=true&elat=-33.88409&elon=151.214231&ena=SA+Smits+%26+Associates+Pty+Ltd&estr=355+Crown+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=3&productId=999015931951&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DSA+Smits+%26+Associates+Pty+Ltd%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.88409%26lon%3D151.214231%26selectedViewMode%3Dlist&yellowId=15217070",
                                                "anchor_text": "355 Crown St, Surry Hills, NSW, 2010"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9331 2999",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Development Design Services",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Surry Hills, NSW 2010",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Development Design Services",
                                        "url": "https://www.yellowpages.com.au/nsw/surry-hills/development-design-services-12745723-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/surry-hills/development-design-services-12745723-listing.html",
                                                "anchor_text": "Development Design Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "340A Riley St, Surry Hills, NSW, 2010",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=340A+Riley+St&context=undefined&directionMode=true&elat=-33.88507&elon=151.21293&ena=Development+Design+Services&estr=340A+Riley+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=3&productId=999903084361&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DDevelopment+Design+Services%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.88507%26lon%3D151.21293%26selectedViewMode%3Dlist&yellowId=12745723",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=340A+Riley+St&context=undefined&directionMode=true&elat=-33.88507&elon=151.21293&ena=Development+Design+Services&estr=340A+Riley+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=3&productId=999903084361&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DDevelopment+Design+Services%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.88507%26lon%3D151.21293%26selectedViewMode%3Dlist&yellowId=12745723",
                                                "anchor_text": "340A Riley St, Surry Hills, NSW, 2010"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0400 228 335",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "MSB Design",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Surry Hills, NSW 2010",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "MSB Design",
                                        "url": "https://www.yellowpages.com.au/nsw/surry-hills/msb-design-1000002817707-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/surry-hills/msb-design-1000002817707-listing.html",
                                                "anchor_text": "MSB Design"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Studio 413 / 55 Holt St, Surry Hills, NSW, 2010",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Studio+413+%252F+55+Holt+St&context=undefined&directionMode=true&elat=-33.88623&elon=151.20898&ena=MSB+Design&estr=Studio+413+%2F+55+Holt+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=1&productId=1000002817707&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMSB+Design%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.88623%26lon%3D151.20898%26selectedViewMode%3Dlist&yellowId=1000002817707",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Studio+413+%252F+55+Holt+St&context=undefined&directionMode=true&elat=-33.88623&elon=151.20898&ena=MSB+Design&estr=Studio+413+%2F+55+Holt+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=1&productId=1000002817707&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMSB+Design%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.88623%26lon%3D151.20898%26selectedViewMode%3Dlist&yellowId=1000002817707",
                                                "anchor_text": "Studio 413 / 55 Holt St, Surry Hills, NSW, 2010"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9211 3434",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "MBA Accredited Consultants",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Inspection, Surry Hills, NSW 2010",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "MBA Accredited Consultants",
                                        "url": "https://www.yellowpages.com.au/nsw/surry-hills/mba-accredited-consultants-12810591-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/surry-hills/mba-accredited-consultants-12810591-listing.html",
                                                "anchor_text": "MBA Accredited Consultants"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "51- 57 Holt St, Surry Hills, NSW, 2010",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=51-+57+Holt+St&context=undefined&directionMode=true&elat=-33.88623&elon=151.208976&ena=MBA+Accredited+Consultants&estr=51-+57+Holt+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=4&productId=999901900876&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMBA+Accredited+Consultants%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.88623%26lon%3D151.208976%26selectedViewMode%3Dlist&yellowId=12810591",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=51-+57+Holt+St&context=undefined&directionMode=true&elat=-33.88623&elon=151.208976&ena=MBA+Accredited+Consultants&estr=51-+57+Holt+St&esu=Surry+Hills%2C+NSW%2C+2010&productVersion=4&productId=999901900876&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMBA+Accredited+Consultants%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.88623%26lon%3D151.208976%26selectedViewMode%3Dlist&yellowId=12810591",
                                                "anchor_text": "51- 57 Holt St, Surry Hills, NSW, 2010"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9281 4508",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "ATWD Studio",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Zetland, NSW 2017",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "ATWD Studio",
                                        "url": "https://www.yellowpages.com.au/nsw/zetland/atwd-studio-1000001904416-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/zetland/atwd-studio-1000001904416-listing.html",
                                                "anchor_text": "ATWD Studio"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0433 604 436",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Home Inspectors Of Sydney",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Inspection, Double Bay, NSW 2028",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Home Inspectors Of Sydney",
                                        "url": "https://www.yellowpages.com.au/sup/home-inspectors-of-sydney-12038219-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/home-inspectors-of-sydney-12038219-listing.html",
                                                "anchor_text": "Home Inspectors Of Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1300 308 276",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "TomarcK",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Designers, Zetland, NSW 2017",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "TomarcK",
                                        "url": "https://www.yellowpages.com.au/sup/tomarck-15181264-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/tomarck-15181264-listing.html",
                                                "anchor_text": "TomarcK"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0412 893 315",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Matt Shuter & Associates",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building Surveyors, Bondi Junction, NSW 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Matt Shuter & Associates",
                                        "url": "https://www.yellowpages.com.au/nsw/bondi-junction/matt-shuter-associates-14602210-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/bondi-junction/matt-shuter-associates-14602210-listing.html",
                                                "anchor_text": "Matt Shuter & Associates"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Ste 602/ 26 Spring St, Bondi Junction, NSW, 2022",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Ste+602%252F+26+Spring+St&context=undefined&directionMode=true&elat=-33.891888&elon=151.246523&ena=Matt+Shuter+%26+Associates&estr=Ste+602%2F+26+Spring+St&esu=Bondi+Junction%2C+NSW%2C+2022&productVersion=3&productId=999015565957&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMatt+Shuter+%26+Associates%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.891888%26lon%3D151.246523%26selectedViewMode%3Dlist&yellowId=14602210",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Ste+602%252F+26+Spring+St&context=undefined&directionMode=true&elat=-33.891888&elon=151.246523&ena=Matt+Shuter+%26+Associates&estr=Ste+602%2F+26+Spring+St&esu=Bondi+Junction%2C+NSW%2C+2022&productVersion=3&productId=999015565957&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMatt+Shuter+%26+Associates%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.891888%26lon%3D151.246523%26selectedViewMode%3Dlist&yellowId=14602210",
                                                "anchor_text": "Ste 602/ 26 Spring St, Bondi Junction, NSW, 2022"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9387 4441",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Property Maintenance Services",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Commercial Building Maintenance, Edgecliff, NSW 2027",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Complete Property Maintenance Services",
                                        "url": "https://www.yellowpages.com.au/nsw/edgecliff/complete-property-maintenance-services-1000000744593-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/edgecliff/complete-property-maintenance-services-1000000744593-listing.html",
                                                "anchor_text": "Complete Property Maintenance Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "203 New South Head Road, Edgecliff, NSW, 2027",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=203+New+South+Head+Road&context=undefined&directionMode=true&elat=-33.879181&elon=151.23551&ena=Complete+Property+Maintenance+Services&estr=203+New+South+Head+Road&esu=Edgecliff%2C+NSW%2C+2027&productVersion=2&productId=1000000744593&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DComplete+Property+Maintenance+Services%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.879181%26lon%3D151.23551%26selectedViewMode%3Dlist&yellowId=1000000744593",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=203+New+South+Head+Road&context=undefined&directionMode=true&elat=-33.879181&elon=151.23551&ena=Complete+Property+Maintenance+Services&estr=203+New+South+Head+Road&esu=Edgecliff%2C+NSW%2C+2027&productVersion=2&productId=1000000744593&ref=ypgd&referredBy=undefined&str=Centennial+Park%2C+NSW+2021&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DComplete+Property+Maintenance+Services%26locationClue%3DCentennial+Park%2C+NSW+2021%26lat%3D-33.879181%26lon%3D151.23551%26selectedViewMode%3Dlist&yellowId=1000000744593",
                                                "anchor_text": "203 New South Head Road, Edgecliff, NSW, 2027"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9327 5302",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Planahead Designs",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Draftsman & Drafting Services, Bondi Junction, NSW 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Planahead Designs",
                                        "url": "https://www.yellowpages.com.au/nsw/bondi-junction/planahead-designs-13014216-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/bondi-junction/planahead-designs-13014216-listing.html",
                                                "anchor_text": "Planahead Designs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9314 0044",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Playsafe Fencing Pty Ltd",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Secure Your Properties With Playsafe Fencing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Fencing Contractors",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9820 1200",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Seymour Building Supplies",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Delivery All Areas, Professional Services & Competitive Prices",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Building Supplies",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9817 5693",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Skyrise Scaffolding Pty Ltd",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Aluminium Scaffolding Swinging Stage Hire",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(02) 9833 4170",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Southside Roofing",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0411 192 858",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Principal Certifiers",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Construction Certificates & Principal Certifying Authority (PCA).",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Building Surveyors",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9518 5105",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pace Structural Pty Ltd",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Structural Engineers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Consulting Engineers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 8048 6373",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our directory.",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Yellow Pages",
                                        "url": "https://www.yellowpages.com.au/pages/about-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/about-us",
                                                "anchor_text": "About Yellow Pages"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://www.yellowpages.com.au/pages/contact-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/contact-us",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Site Index",
                                        "url": "https://www.yellowpages.com.au/sitemap",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sitemap",
                                                "anchor_text": "Site Index"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Order or cancel your book",
                                        "url": "https://www.directoryselect.com.au/action/home",
                                        "urls": [
                                            {
                                                "url": "https://www.directoryselect.com.au/action/home",
                                                "anchor_text": "Order or cancel your book"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our advertising.",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Get a free listing",
                                        "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                                "anchor_text": "Get a free listing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Digital marketing solutions",
                                        "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                                "anchor_text": "Digital marketing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Business hub",
                                        "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                                "anchor_text": "Business hub"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "myYellow login",
                                        "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                                "anchor_text": "myYellow login"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Connect with us.",
                                "main_title": "28 BEST local Builders in Centennial Park NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Thryv Australia",
                                        "url": "https://corporate.thryv.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/",
                                                "anchor_text": "About Thryv Australia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://corporate.thryv.com/privacy/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com/privacy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://corporate.thryv.com.au/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 9369 2787",
                                "0404 837 327",
                                "0402 301 580",
                                "(02) 9389 0440",
                                "0434 262 300",
                                "0419 148 627",
                                "0416 321 982",
                                "0409 444 402",
                                "(02) 9590 3399",
                                "0415 777 987",
                                "0475 209 691",
                                "(02) 9398 5135",
                                "(02) 9331 2999",
                                "0400 228 335",
                                "(02) 9213 5500",
                                "(02) 9211 3434",
                                "(02) 9281 4508",
                                "0433 604 436",
                                "1300 308 276",
                                "0412 893 315",
                                "(02) 9387 4441",
                                "(02) 9327 5302",
                                "(02) 8356 7127",
                                "0403 136 596",
                                "(02) 8959 9533",
                                "(02) 9314 0044",
                                "0293692787",
                                "0404837327",
                                "0402301580",
                                "0293890440",
                                "0434262300",
                                "0419148627",
                                "0416321982",
                                "0409444402",
                                "0295903399",
                                "0415777987",
                                "0475209691",
                                "0293985135",
                                "0293312999",
                                "0400228335",
                                "0292135500",
                                "0292113434",
                                "0292814508",
                                "0433604436",
                                "1300308276",
                                "0412893315",
                                "0293874441",
                                "0293275302",
                                "0283567127",
                                "0403136596",
                                "0289599533",
                                "0293140044",
                                "1300276657",
                                "1300556541",
                                "0298201200",
                                "0298175693",
                                "0298334170",
                                "0411192858",
                                "0295185105",
                                "0280486373",
                                "0358214399",
                                "0248713355",
                                "0297910714"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}