{
    "id": "01191221-1132-0216-0000-9f21382f4a7e",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0413 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://heritageslateroofing.com.au/",
        "target": "heritageslateroofing.com.au",
        "start_url": "https://heritageslateroofing.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": true,
        "load_resources": true,
        "enable_browser_rendering": true,
        "enable_xhr": true,
        "disable_cookie_popup": true,
        "browser_preset": "desktop",
        "custom_js": "window.scrollTo(0, document.body.scrollHeight);",
        "tag": "parsed_content_markdowns\\Centennial-Park-(NSW)\\organic\\type-organic_rg6_ra10_heritageslateroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 08:43:07 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Cedar Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                            "anchor_text": "Cedar Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asphalt Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                            "anchor_text": "Asphalt Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hardwood Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                            "anchor_text": "Hardwood Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                            "anchor_text": "Terracotta Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Penrhyn)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                            "anchor_text": "Welsh Slate (Penrhyn)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Cwt-y-Bugail)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                            "anchor_text": "Welsh Slate (Cwt-y-Bugail)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate (Glendyne)",
                                    "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                            "anchor_text": "Canadian Slate (Glendyne)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate (Del Carmen)",
                                    "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                            "anchor_text": "Spanish Slate (Del Carmen)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate (SVK Artificial)",
                                    "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                            "anchor_text": "Artificial Slate (SVK Artificial)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Repair",
                                    "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                            "anchor_text": "Slate Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Reclaimed Slate",
                                    "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                            "anchor_text": "Reclaimed Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cast Iron Downpipes",
                                    "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                            "anchor_text": "Cast Iron Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Standing Seam",
                                    "url": "https://heritageslateroofing.com.au/zinc/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/zinc/",
                                            "anchor_text": "Zinc Standing Seam"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Z600 Galvanised Steel",
                                    "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                            "anchor_text": "Z600 Galvanised Steel"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Lead Roofing",
                                    "url": "https://www.heritageleadroofing.com/",
                                    "urls": [
                                        {
                                            "url": "https://www.heritageleadroofing.com/",
                                            "anchor_text": "Heritage Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Case Studies",
                                    "url": "https://heritageslateroofing.com.au/case-studies/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/case-studies/",
                                            "anchor_text": "Case Studies"
                                        }
                                    ]
                                },
                                {
                                    "text": "Video Gallery",
                                    "url": "https://heritageslateroofing.com.au/video-gallery/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/video-gallery/",
                                            "anchor_text": "Video Gallery"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cedar Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                            "anchor_text": "Cedar Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asphalt Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                            "anchor_text": "Asphalt Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hardwood Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                            "anchor_text": "Hardwood Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                            "anchor_text": "Terracotta Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Penrhyn)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                            "anchor_text": "Welsh Slate (Penrhyn)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Cwt-y-Bugail)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                            "anchor_text": "Welsh Slate (Cwt-y-Bugail)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate (Glendyne)",
                                    "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                            "anchor_text": "Canadian Slate (Glendyne)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate (Del Carmen)",
                                    "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                            "anchor_text": "Spanish Slate (Del Carmen)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate (SVK Artificial)",
                                    "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                            "anchor_text": "Artificial Slate (SVK Artificial)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Repair",
                                    "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                            "anchor_text": "Slate Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Reclaimed Slate",
                                    "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                            "anchor_text": "Reclaimed Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cast Iron Downpipes",
                                    "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                            "anchor_text": "Cast Iron Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Standing Seam",
                                    "url": "https://heritageslateroofing.com.au/zinc/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/zinc/",
                                            "anchor_text": "Zinc Standing Seam"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Z600 Galvanised Steel",
                                    "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                            "anchor_text": "Z600 Galvanised Steel"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Lead Roofing",
                                    "url": "https://www.heritageleadroofing.com/",
                                    "urls": [
                                        {
                                            "url": "https://www.heritageleadroofing.com/",
                                            "anchor_text": "Heritage Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Case Studies",
                                    "url": "https://heritageslateroofing.com.au/case-studies/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/case-studies/",
                                            "anchor_text": "Case Studies"
                                        }
                                    ]
                                },
                                {
                                    "text": "Video Gallery",
                                    "url": "https://heritageslateroofing.com.au/video-gallery/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/video-gallery/",
                                            "anchor_text": "Video Gallery"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Lead Roofing",
                                    "url": "https://www.heritageleadroofing.com/",
                                    "urls": [
                                        {
                                            "url": "https://www.heritageleadroofing.com/",
                                            "anchor_text": "Heritage Lead Roofing"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "2017 ~ Best Roof Residential \u2013 Other Materials \u2013 North Sydney Residence (Cedar Shingles)",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2018 ~ Best Roof Residential \u2013 Slate \u2013 Killara Residence (Del Carmen Slate)",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2018 ~ Best Roof Residential \u2013 Other Materials \u2013 Turramurra Residence (SVK Artificial Slate)",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2022 ~ Outstanding Craftsmanship \u2013 Slate \u2013 Kurraba Point (Welsh & Vermont Slate)",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2022 ~ Outstanding Craftsmanship \u2013 Terracotta Shingles \u2013 Wentworth Falls",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2023 ~ Best Commercial \u2013 Public Building Slate & Other Materials ~ Sts Peter & Paul\u2019s Olde Cathedral",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2023 ~ Best Residential Slate & Other Materials ~ Lang Rd, Centennial Park",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "2024 ~ MRCCA | Specialist Works Project \u2013 (Specialised in Design & Heritage) ~ The Trust Building",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "0451 399 226",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Google Rating",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Cedar Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/cedar-shingles/",
                                            "anchor_text": "Cedar Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asphalt Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/asphalt-shingles/",
                                            "anchor_text": "Asphalt Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hardwood Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/hardwood-shingles/",
                                            "anchor_text": "Hardwood Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Shingles",
                                    "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/shingles/terracotta-shingles/",
                                            "anchor_text": "Terracotta Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Penrhyn)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-penrhyn/",
                                            "anchor_text": "Welsh Slate (Penrhyn)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate (Cwt-y-Bugail)",
                                    "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/welsh-slate-cwt-y-bugail/",
                                            "anchor_text": "Welsh Slate (Cwt-y-Bugail)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate (Glendyne)",
                                    "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/canadian-slate-glendyne/",
                                            "anchor_text": "Canadian Slate (Glendyne)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate (Del Carmen)",
                                    "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/spanish-slate-del-carmen/",
                                            "anchor_text": "Spanish Slate (Del Carmen)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artificial Slate (SVK Artificial)",
                                    "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/artificial-slate/",
                                            "anchor_text": "Artificial Slate (SVK Artificial)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Repair",
                                    "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/slate-repair/",
                                            "anchor_text": "Slate Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Reclaimed Slate",
                                    "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/reclaimed-slate/",
                                            "anchor_text": "Reclaimed Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cast Iron Downpipes",
                                    "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/slate/cast-iron-downpipes/",
                                            "anchor_text": "Cast Iron Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Standing Seam",
                                    "url": "https://heritageslateroofing.com.au/zinc/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/zinc/",
                                            "anchor_text": "Zinc Standing Seam"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lead Roofing",
                                    "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/lead-roofing/",
                                            "anchor_text": "Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Z600 Galvanised Steel",
                                    "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/galvanised-steel/",
                                            "anchor_text": "Z600 Galvanised Steel"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Lead Roofing",
                                    "url": "https://www.heritageleadroofing.com/",
                                    "urls": [
                                        {
                                            "url": "https://www.heritageleadroofing.com/",
                                            "anchor_text": "Heritage Lead Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Case Studies",
                                    "url": "https://heritageslateroofing.com.au/case-studies/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/case-studies/",
                                            "anchor_text": "Case Studies"
                                        }
                                    ]
                                },
                                {
                                    "text": "Video Gallery",
                                    "url": "https://heritageslateroofing.com.au/video-gallery/",
                                    "urls": [
                                        {
                                            "url": "https://heritageslateroofing.com.au/video-gallery/",
                                            "anchor_text": "Video Gallery"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Welcome to Heritage Roofing Group",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Heritage Roofing Group, based in Sydney, Australia, was founded by Kyle Glasby and Luke Godden, who have over 30 years of combined experience in traditional roofing. Renowned for our great attention to detail, we have worked on some of the biggest slate jobs in New South Wales, Victoria, ACT, England and Wales. We specialise in both complete re-roofs and restoration of slate, shingles, shakes, copper, lead and zinc roofing systems for both heritage & modern design buildings. Click below to download our online brochure for further details on our offering.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Canadian Slate",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Slate Roofing",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Heritage Roofing Group has many years of experience in commercial slate projects all across NSW including: schools, churches, court houses and more.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Newcastle East Public School - Welsh Slate",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Lead Roofing",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Lead roofs and flashing have added prestige to buildings for centuries and still add a touch of first class roofing that no modern material can.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Heritage Lead Roof - Balmain",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "AWARDED PROJECT PORTFOLIO",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Heritage Roofing Group has won a wide range of awards over the years. Look through a brief portfolio on what amazing projects have taken out honourable accolades.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Canadian Slate",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "DOES YOUR QUOTE FOR A NEW SLATE/SHINGLE ROOF SEEM EXTORTIONATE? YOU\u2019VE COME TO THE RIGHT PLACE!",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Here at Heritage Roofing Group we pride ourselves on honesty and integrity and that reflects in our fair pricing of work. Our small but dedicated team will look after your project from start to finish. Weather your looking for a new roof to a Church/chapel or shingles on your Balinese style hut, we treat all jobs the same no matter what the size.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We not only carry out 100% of the work, from advising on what materials suit your project and budget all the way through to the finishing stage of your roof. We break down our quotes into sections, which makes them easily understandable to see where your money is going.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "AWARD: Best Roof Residential - Slate - Killara Residence (Del Carmen Slate) (2018)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "AWARD: Best Roof Residential - Other Materials - Bondi Residence (SVK Artificial Slate) (2018)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our full time team consist of fully licensed Slater/Shingle experts, Carpenter and Roof plumber. This means we don\u2019t sub-contract work out to others, so we can ensure the quality stay\u2019s to the highest standard and costs are kept competitive.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All advice, samples and quotations are free of charge and are guided by our 3rd generation Master slate roofer owner.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "AWARD: Best Use of Other Materials - Cedar Shingles - North Sydney (2017)",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact us for a Quote",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Please leave your details with your preferred method of contact and time of day, and we'll be in touch.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "why choose heritage roofing group?",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our products come with up-to a 100 year warranty",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free 2 Year inspection, every 2 years for the life of the warranty",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney\u2019s only Slate roofing company to held a license for Slate/Shingles, Carpentry and Roof plumbing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free advice and product samples supplied on request",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free design and colour matching advice",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free no obligation quote, broken down for easy understanding",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our owner Kyle Glasby is a Master Slater and a 3rd generation Slate roofer, born in the heart of the Slate roofing community in Wales. Slate roofing is in his blood and that shows with his knowledge and understanding of the product and services. Before you commit to a contractor and the questions:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Does the director have a hands on approach",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Are employees full time",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Is the contractor trading license registered under an individual person or a Company",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Are they qualified and licensed to carry out all work on quotation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do they take on all work from start to finish",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Can they provide details for genuine testimonials",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "WHAT OUR CLIENTS ARE SAYING",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "\u201cWe have a slate roof that has seen a few tiles slip. To say roof access is tricky is an understatement. I didn\u2019t want to risk my roof, or my life for that matter clambering about on it. So I rang Kyle at Heritage, he was straight on the case & he sent out his team who did a report and replaced my slipped tiles, even replacing a busted one I didn\u2019t know about. After all they did I was amazed at the price! I thought it would\u2019ve been expensive, but no. These guys have earned a customer for life. I would recommend them to anyone doing a slate roof. Seeing their body of work on line speaks volumes about their professionalism. Way to go guys! Thank you!\u201d Brendan \u201cJonesy\u201d Jones - Jonesy and Amanda WSfm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cKyle's team have recently replaced our Penryhn Blue Welsh Slate roof, lined our new attic space with Black butt timber panelling, replaced our gutters, downpipes and bullnose veranda all in Zinc, lined our new zinc dormer and installed two new skylights. The end result is spectacular, a talking point in our neighbourhood and has made our family immensely proud. This has been a challenging feat in that utmost attention to detail and skill has been warranted to achieve a harmonious and elegant marriage of new and old to honour the history and yesteryears skill of slate artisans of our beautiful 1881 timber cottage in Woolwich whilst bringing it into the 21st century (new streamlined zinc dormer) and later a new modern extension. Kyle's team have been engaged, energetic, highly skilled and professional. We would also like to thank them for being polite friendly and respectful and on hand to help with tasks beyond their call. This also included their patience and developing mate ship with our fiercely protective and pesky but oh so cute miniature Dachshund. Thanks boys!\u201d Tania Grippi",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"My partner and I purchased a derelict Victorian Gothic house in Balmain East which required total renovation. One of the hero aspects of the building is its roof line - having very steeply pitched roofs. Kyle and his team performed an amazing transformation that attracts comments daily from passers by and visitors. Everything was achievable - he went above and beyond with incorporating detailed lead roofing, slate tiling and copper spines and gutters, all working together perfectly. We would thoroughly recommend Heritage Slate to anyone for their professionalism and end result.\" Malcolm Day",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"We were in quite a predicament. Our rental property \u2013 an 1890s gentleman\u2019s residence had seen better days. Patching the roof was no longer working and water was slowly ruining the building. The thought of replacing the roof was a daunting task, so we continued to put it off. In part because we did not know which roofers had the skills to work with terracotta tiles and we were concerned heritage roofers would be too expensive. We compared some quotes. Heritage Roofing Group was competitive. They delivered a wonderful product. Most of the team has been trained in Europe and it shows. What was considered a challenging job by other roofers was what this company does every day. It has almost been a year and there have been no further leaks. They even came out to replace some tiles free of charge that our gutter cleaner broke. Our tenants are ecstatic. Thank you!\" Anne Miehs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cI have been in Design and construction for over 35 years and held the post of President of The Master Builders Association of Australia (Eastern Suburbs Branch) for 4 years, I am currently the Design and renovation mentor on the Logie award winning lifestyle show The Living Room. I have had Kyle complete restoration work of my family home, replacing copper gutters and renewing slate work. The level of professionalism and craftsmanship of Kyle and his team is second to none I have ever come across in my entire career. Equally to that he is a top bloke.\u201d Barry Du Bois",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Who's on your roof?",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney's Leading Architectural Roofing Company",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Work Highlights",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Respect for Historical Integrity",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our CLients",
                                "main_title": "HERITAGE ROOFING GROUP\nSYDNEY'S TRUSTED SLATE & SHINGLE EXPERTS",
                                "author": "heritageslate",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0451 399 226",
                                "0451399226"
                            ],
                            "emails": [
                                "kyle@heritageslateroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}