{
    "id": "01190728-1132-0216-0000-e0f2383b1f32",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0194 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.oneflare.com.au/roofing/nsw/centennial-park",
        "target": "www.oneflare.com.au",
        "start_url": "https://www.oneflare.com.au/roofing/nsw/centennial-park",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Centennial-Park-(NSW)\\organic\\type-organic_rg2_ra5_oneflare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:52 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Best roofing experts in Centennial Park",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Post a job now to get quotes from local roofing experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Centennial Park",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average rating of roofing experts in Centennial Park based on 117 reviews of 27 businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oneflare /",
                                        "url": "https://www.oneflare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/",
                                                "anchor_text": "Oneflare"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Categories /",
                                        "url": "https://www.oneflare.com.au/directory",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/directory",
                                                "anchor_text": "Categories"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.oneflare.com.au/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NSW /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw",
                                                "anchor_text": "NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                                "anchor_text": "Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "NGP Projects",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Randwick, NSW (2.1km from Randwick)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "New Generation Plus (NGP) is an established, multi-skilled Sydney based Building company in operation for over 17 years, with a focus on customer service, quality tradesmanship and the highest standard of excellence. We have extensive experience within the commercial, residential, retail, hospitality & healthcare sectors. With excellent management and coordination, we give every project 100% commitment and our project teams have a reputation for quality and efficiency. We have the capacity to integrate services from make good to complete product so we can have a greater control on the outcome of the project. We provide a free quotation service and offer extremely competitive rates whether on an hourly rate or square metre rate. Our trades are painter, plasterer including commercial",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "NGP Projects",
                                        "url": "https://www.oneflare.com.au/b/new-generation-plus",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/new-generation-plus",
                                                "anchor_text": "NGP Projects"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Brown Wilson Roofing",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Bondi, NSW (3.3km from Bondi)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality Roofing done right the first time. Quality roofing, with trustworthy work and trusted prices. Specialists in works such as \u2022new roofs/reroofs\n\u2022roofing maintenance \u2022gutters/downpipes\n\u2022leak detection Happy and reliable workers who assure 100% effort in work for our customers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Brown Wilson Roofing",
                                        "url": "https://www.oneflare.com.au/b/brown-wilson-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/brown-wilson-roofing",
                                                "anchor_text": "Brown Wilson Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Reynolds Roofing & Son",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Moore Park, NSW (1.2km from Moore Park)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All types of roof repairs and replacement Metal\nSlate\nTile Guttering & Downpipes\nAll repairs guaranteed for 3-5 years\nAll new roofs 10 year guarantee",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Reynolds Roofing & Son",
                                        "url": "https://www.oneflare.com.au/b/reynolds-roofing-son",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/reynolds-roofing-son",
                                                "anchor_text": "Reynolds Roofing & Son"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Skyline Roofing",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Randwick, NSW (2.2km from Randwick)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Skyline Roofing are aim is customers satisfaction and to ensure every job is completed to a high standard we strive for perfection with over 15years experience in the building industry are reputation speaks for itself call us today for a no obligation free quote we cover everything from roof repairs restoration cleaning slate and tiles roof colorbond and much more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Skyline Roofing",
                                        "url": "https://www.oneflare.com.au/b/skyline-roofing-868",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/skyline-roofing-868",
                                                "anchor_text": "Skyline Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Harwood Roofing Verified Business",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Randwick, NSW (1.1km from Randwick)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Welcome to Harwood Roofing - your premier destination for exceptional roofing services in Sydney and throughout New South Wales. With over 15 years dedication to the roofing industry, we take pride in being the go-to experts for slate roofs, tile roofs, leadworks, and roof repairs. We take pride in providing top-notch roofing services that you can rely on. Our team brings a wealth of experience and knowledge, ensuring that every project, whether it's a slate roofing installation, tile roof upgrade, intricate leadworks, or efficient roof repairs, is executed with precision. Whether you're in need of roof repairs, installations, inspections, or maintenance, we've got you covered.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Harwood Roofing Verified Business",
                                        "url": "https://www.oneflare.com.au/b/harwood-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/harwood-roofing",
                                                "anchor_text": "Harwood Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Miton Metal Roofing",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Randwick, NSW (2.1km from Randwick)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Miton Metal Roofing are professional roofers who complete a wide range of roofing projects. No Job To Small All Your metal roofing jobs including Gutters , Downpipes, Flashings, Gutter Cleaning, Roofleaks (tile or metal). Attention to detail is the focus of our business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Miton Metal Roofing",
                                        "url": "https://www.oneflare.com.au/b/miton-metal-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/miton-metal-roofing",
                                                "anchor_text": "Miton Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Creative Concrete",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Bondi Junction, NSW (1.7km from Bondi Junction)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hi my name is John Maher director of Creative Concrete. We have over twenty years experience in all aspects of concrete, ranging from decorative concrete to structural. Excavation, form work, steel and concrete. All our subcontractors are fully insured and licensed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Creative Concrete",
                                        "url": "https://www.oneflare.com.au/b/creativeconcrete",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/creativeconcrete",
                                                "anchor_text": "Creative Concrete"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Invision Property Solutions",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Randwick, NSW (2.1km from Randwick)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "invision p property solutions provides you with the best quality workmanship we cover most areas home home improvements including - Roofing\n- Painting and decorating\n- Gutter cleaning\n- Guttering repair/replacement\n- High pressure cleaning\n- Roof coating\n- Roof cleaning\n- fencing\nNo job to big or small\nFree quotes provided Customer satisfaction is guaranteed Call for a free quote and inspection",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Invision Property Solutions",
                                        "url": "https://www.oneflare.com.au/b/invision-property-solutions",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/invision-property-solutions",
                                                "anchor_text": "Invision Property Solutions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Murnane Carpentry pty ltd",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Coogee, NSW (3.1km from Coogee)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We specialize in 2nd story additions , roof attic conversions and general house Renovations.We started off being a carpentry company . I did my apprentice in a joinery workshop and also out on the sites.I have over 24 years experience in both commercial and Domestic Construction.\nI started doing my own and started the company back in 2003. I got my Builders license and kept moving forward.We mostly do our work Between the Shire all the way to Manly Area. We have also done Heritage and Maintenance work. I have also bought houses and renovated and built townhouses/villas and then sold them.\nPlease free to call me if you have any questions that it might help you get more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Murnane Carpentry pty ltd",
                                        "url": "https://www.oneflare.com.au/b/murnane-carpentry",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/murnane-carpentry",
                                                "anchor_text": "Murnane Carpentry pty ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Quick Silver Roofing",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Maroubra, NSW (4.9km from Maroubra)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal Roof Specialist\nWe focus on exceeding customer satisfaction through honest work done to standard in a timely manner. We provide all metal repairs for flashings, valleys, cappings and Replacements and repairs for terracotta and cement tile roofs, Roofing can be a risky trade, heights can sometimes get the best of people and so can cutting corners to get the job done. I don\u2019t shy away from a task and ensure I feel 1000% certain that the task is completed to standard and regulations",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Quick Silver Roofing",
                                        "url": "https://www.oneflare.com.au/b/quicksilver-roofing-586",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/quicksilver-roofing-586",
                                                "anchor_text": "Quick Silver Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Quicksilver Roofing",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Maroubra, NSW (4.9km from Maroubra)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal roof new installations and repairs. We focus on exceeding customer satisfaction through honest work done to standard in a timely manner. New Colourbond roofs and reroofs for residential and commercial. We provide all metal repairs for flashings, valleys, cappings and more. Replacements and repairs for terracotta and cement tile roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Quicksilver Roofing",
                                        "url": "https://www.oneflare.com.au/b/quicksilver-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/quicksilver-roofing",
                                                "anchor_text": "Quicksilver Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "CTA Roofing Pty Ltd",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Paddington, NSW (1.6km from Paddington)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Over ten years experience in metal roofing. Servicing the eastern suburbs and inner city. Specialising in all metal roofing requirements including; - Installation of new metal roofs - Tile to metal re-roofs - Gutters - Downpipes - Gutter guard - Residential and commercial Large and small jobs, fully licensed and insured. Call today for a free no obligation quote.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "CTA Roofing Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/cta-roofing-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/cta-roofing-pty-ltd",
                                                "anchor_text": "CTA Roofing Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Render My Home Pty Ltd",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Waterloo, NSW (2.4km from Waterloo)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Render My Home is your one-stop design and building service that Renovates, Rejuvenates and Restores your home facade. We only deal with quality products and systems from trusted suppliers. Render My Home are accredited and use products by Dulux and CSR.\nRender My Home \u2013 Exterior Fa\u00e7ade Home Improvement Specialists, can dramatically boost your home\u2019s value by transforming your home into a vibrant and intriguing reflection of your own personal style and individualism. For all small and large jobs, Render My Home specialises in restoring and rejuvenating your homes facade, by using renders, coatings, wall panels, paints, landscaping, tiling, balustrade upgrades, roof restorations, awnings and shutters to breathe new life into your home.\nThe Render My Home design team are",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Render My Home Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/render-my-home-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/render-my-home-pty-ltd",
                                                "anchor_text": "Render My Home Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "DNP Building",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Maroubra, NSW (5.2km from Maroubra)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "New Era Carpentry & Building provide Sydney and the Eastern suburbs with cost effective boutique building and carpentry solutions.\nA family owned building company with over 25 years experience in all aspects of home construction and renovations. We pride ourselves on delivery of flexible, high quality services.\nOur core business is residential works, transforming family homes through renovation, addition or alteration. However we undertake all types of building and carpentry and have experience in new home builds, deck and pergola construction, bathroom and kitchen renovations, general building maintenance and small commercial works and storm damage and break-in rectification.\nWe also offer pre-purchase inspections for property buyers to advise on likely costs of any renovation or rectification works required.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "DNP Building",
                                        "url": "https://www.oneflare.com.au/b/dnp-building",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/dnp-building",
                                                "anchor_text": "DNP Building"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Metal Roofing Projects Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Surry Hills, NSW (3.0km from Surry Hills)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Trade Lic # 381129C\nFor all your metal roofing requirements, domestic & commercial New roofs, extensions, repairs, guttering & downpipes, box gutters. Zincalume & Colorbond\nFully qualified Roof Plumber with over 30years experience. Servicing eastern suburbs, inner west, southern suburbs & lower north shore Obligation free quote\nCompetitive pricing\nFully insured for your protection",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney Metal Roofing Projects Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/sydney-metal-roofing-projects",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/sydney-metal-roofing-projects",
                                                "anchor_text": "Sydney Metal Roofing Projects Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pro Cut Sydney",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Zetland, NSW (2.8km from Zetland)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a family run roofing and property maintenance company. With over 20 years of experience as carpenters and roofers, we pride ourselves on honesty, hard work and reliability. With a wide range of services from carpentry and roofing to cleaning and garden maintenance, we guarantee you\u2019ll love our work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pro Cut Sydney",
                                        "url": "https://www.oneflare.com.au/b/pro-cut-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/pro-cut-sydney",
                                                "anchor_text": "Pro Cut Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Infront roofing",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.9km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Over 10 years of experience within this trade!\nA very friendly and quality orientated service within the guttering trade. Very mobile and always on time! Contact me for any of your guttering needs, gutter guard or gutter cleaning jobs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Infront roofing",
                                        "url": "https://www.oneflare.com.au/b/moores-gutters",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/moores-gutters",
                                                "anchor_text": "Infront roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Dunne, Cian Sean Verified Business",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Maroubra, NSW (5.5km from Maroubra)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At C.D. Roofing and Restoration, we\u2019re more than just another roofing company \u2014 we\u2019re your local, reliable partner in protecting what matters most: your home. With a commitment to quality craftsmanship, honest service, and attention to detail, we deliver roofing and repair solutions that are built to last.\nWhat sets us apart? We don\u2019t cut corners. Every project, big or small, is handled with the same care and precision we\u2019d want for our own homes. Whether you\u2019re dealing with storm damage, a leaky roof, or need a full replacement, we provide clear communication, fair pricing, and dependable results \u2014 without the runaround.\nWe specialize in:\n\u2022. Slate and Tile roofs \u2022. Leadwork \u2022 Roof inspections, repairs, and full replacements\n\u2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Dunne, Cian Sean Verified Business",
                                        "url": "https://www.oneflare.com.au/b/dunne-s-roofing-solutions",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/dunne-s-roofing-solutions",
                                                "anchor_text": "Dunne, Cian Sean"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get the right price for your job",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Oneflare Cost Guide Centre is your one-stop shop to help you set your budget; from smaller tasks to larger projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Top Centennial Park roofing experts near you",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Browse top Roofing Expert experts with top ratings and reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leo's review for a Roofing job in Abbotsford",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Provided a very competitive quote, was very punctual and professional and I would highly recommend Cta roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best roofing experts in Centennial Park",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "View more roofing experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Truss costs",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Truss costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Roof Truss costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $9,000 - $15,000",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Average price $9,000 - $15,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof costs",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roof costs",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Colorbond Roof costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $15,000 - $25,000",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Average price $15,000 - $25,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling costs",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Roof Tiling costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $35 - $140 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Average price $35 - $140 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing costs",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing costs",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Roofing costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $45 - $90 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Average price $45 - $90 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse roofing experts by suburb",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular searches on Oneflare",
                                "main_title": "Best roofing experts in Centennial Park",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.7,
                                "max_rating_value": 5,
                                "rating_count": 117,
                                "relative_rating": 0.9400000000000001
                            }
                        ],
                        "offers": null,
                        "comments": [
                            {
                                "rating": null,
                                "title": null,
                                "publish_date": null,
                                "author": "Leo Raiti",
                                "primary_content": [
                                    {
                                        "text": "Provided a very competitive quote, was very punctual and professional and I would highly recommend Cta roofing ",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            }
                        ],
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}