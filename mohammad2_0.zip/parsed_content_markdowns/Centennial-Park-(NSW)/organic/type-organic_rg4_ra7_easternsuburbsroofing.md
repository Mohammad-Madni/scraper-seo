{
    "id": "01190728-1132-0216-0000-075ecaf8421c",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0132 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://easternsuburbsroofing.com.au/services/centennial-park-nsw-2021/",
        "target": "easternsuburbsroofing.com.au",
        "start_url": "https://easternsuburbsroofing.com.au/services/centennial-park-nsw-2021/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Centennial-Park-(NSW)\\organic\\type-organic_rg4_ra7_easternsuburbsroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:52 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://easternsuburbsroofing.com.au/roofing-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/roofing-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting and Sealing",
                                    "url": "https://easternsuburbsroofing.com.au/painting-sealing/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/painting-sealing/",
                                            "anchor_text": "Roof Painting and Sealing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement & Reroofing",
                                    "url": "https://easternsuburbsroofing.com.au/replacement-installation-reroofing/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/replacement-installation-reroofing/",
                                            "anchor_text": "Roof Replacement & Reroofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://easternsuburbsroofing.com.au/repointing/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair & Replacement",
                                    "url": "https://easternsuburbsroofing.com.au/gutter-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/gutter-repair-replacement/",
                                            "anchor_text": "Gutter Repair & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation Systems",
                                    "url": "https://easternsuburbsroofing.com.au/roofing-ventilation-systems/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/roofing-ventilation-systems/",
                                            "anchor_text": "Roof Ventilation Systems"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://easternsuburbsroofing.com.au/roofing-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/roofing-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting and Sealing",
                                    "url": "https://easternsuburbsroofing.com.au/painting-sealing/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/painting-sealing/",
                                            "anchor_text": "Roof Painting and Sealing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://easternsuburbsroofing.com.au/repointing/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://easternsuburbsroofing.com.au/roofing-ventilation-systems/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/roofing-ventilation-systems/",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair & Replacement",
                                    "url": "https://easternsuburbsroofing.com.au/gutter-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/gutter-repair-replacement/",
                                            "anchor_text": "Gutter Repair & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bellevue Hill",
                                    "url": "https://easternsuburbsroofing.com.au/services/bellevue-hill-nsw-2023/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/services/bellevue-hill-nsw-2023/",
                                            "anchor_text": "Bellevue Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bondi Beach",
                                    "url": "https://easternsuburbsroofing.com.au/services/bondi-beach-nsw-2026/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/services/bondi-beach-nsw-2026/",
                                            "anchor_text": "Bondi Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bondi Junction",
                                    "url": "https://easternsuburbsroofing.com.au/services/bondi-junction-nsw-2022/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/services/bondi-junction-nsw-2022/",
                                            "anchor_text": "Bondi Junction"
                                        }
                                    ]
                                },
                                {
                                    "text": "Double Bay",
                                    "url": "https://easternsuburbsroofing.com.au/services/double-bay-nsw-2028/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/services/double-bay-nsw-2028/",
                                            "anchor_text": "Double Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dover Heights",
                                    "url": "https://easternsuburbsroofing.com.au/services/dover-heights-nsw-2030/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/services/dover-heights-nsw-2030/",
                                            "anchor_text": "Dover Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Bondi",
                                    "url": "https://easternsuburbsroofing.com.au/services/north-bondi-nsw-2026/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/services/north-bondi-nsw-2026/",
                                            "anchor_text": "North Bondi"
                                        }
                                    ]
                                },
                                {
                                    "text": "Queens Park",
                                    "url": "https://easternsuburbsroofing.com.au/services/queens-park-nsw-2022/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/services/queens-park-nsw-2022/",
                                            "anchor_text": "Queens Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Rose Bay",
                                    "url": "https://easternsuburbsroofing.com.au/services/rose-bay-nsw-2029/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/services/rose-bay-nsw-2029/",
                                            "anchor_text": "Rose Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "South Coogee",
                                    "url": "https://easternsuburbsroofing.com.au/services/south-coogee-nsw-2034/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/services/south-coogee-nsw-2034/",
                                            "anchor_text": "South Coogee"
                                        }
                                    ]
                                },
                                {
                                    "text": "Watsons Bay",
                                    "url": "https://easternsuburbsroofing.com.au/services/watsons-bay-nsw-2030/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/services/watsons-bay-nsw-2030/",
                                            "anchor_text": "Watsons Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Unit 2/86 Denison St, Bondi Junction NSW 2022",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2026 Eastern Suburbs Roofing Experts, all rights reserved.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Privacy Policy | Terms and Conditions",
                                    "url": "https://easternsuburbsroofing.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        },
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://easternsuburbsroofing.com.au/roofing-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/roofing-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting and Sealing",
                                    "url": "https://easternsuburbsroofing.com.au/painting-sealing/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/painting-sealing/",
                                            "anchor_text": "Roof Painting and Sealing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement & Reroofing",
                                    "url": "https://easternsuburbsroofing.com.au/replacement-installation-reroofing/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/replacement-installation-reroofing/",
                                            "anchor_text": "Roof Replacement & Reroofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://easternsuburbsroofing.com.au/repointing/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair & Replacement",
                                    "url": "https://easternsuburbsroofing.com.au/gutter-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/gutter-repair-replacement/",
                                            "anchor_text": "Gutter Repair & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation Systems",
                                    "url": "https://easternsuburbsroofing.com.au/roofing-ventilation-systems/",
                                    "urls": [
                                        {
                                            "url": "https://easternsuburbsroofing.com.au/roofing-ventilation-systems/",
                                            "anchor_text": "Roof Ventilation Systems"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "The Best Roof Restoration Contractor In Centennial Park 2021",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We guarantee that you\u2019ll love the results of Eastern Suburbs Roofing Experts!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We are expert Centennial Park roof restorers",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "[We are an expert roof restoration business servicing clients all over Centennial Park. We are a one-stop shop for all things roof restoration. From broken roof tiles to rusty metal sheets, or severely damaged roofs, we can tackle it all. We work with all types of roofs \u2013 metal, tiled, colorbond, terracotta and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Repair and Replacement",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If your roof is in poor condition, give us a call! We can discuss a tailored solution for your premises that is unlikely to involve a brand-new roof. You\u2019d be surprised at how a restored roof looks very much like a brand new one\u00a0\u2013 at a much cheaper price!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Eastern Suburbs Roofing Experts can provide a comprehensive assessment of the current status of your roof and recommend the most cost-effective solution for you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter Repair and Replacement",
                                        "url": "https://easternsuburbsroofing.com.au/gutter-repair-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://easternsuburbsroofing.com.au/gutter-repair-replacement/",
                                                "anchor_text": "Gutter Repair and Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "About Our Roof Restoration Company",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With over 10 years of experience in the roofing sector, Eastern Suburbs Roofing Experts prides itself for excellent outcomes and many happy customers.\u00a0Our knowledge of roofs is vast and includes all sorts of roofing materials: tiled, metal, colorbond, terracotta and more.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a local Centennial Park family-owned small business. We have up-to-date equipment and strictly follow industry best practice and safety standards. We are fully certified and have comprehensive insurance. Our staff is fully trained and have qualifications in different types of roofing trades, including:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof plumbers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof carpenters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof tilers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof painters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof installers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have the finest roof restoration professionals in Centennial Park!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Centennial Park Roof Repair & Restoration \u2013 Our Process",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We undertake a full roof assessment",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Feedback detailing the most cost-efficient and appropriate solution for your house",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019ll discuss an estimate of restoration pricing and timeframes with you",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "After accepting our quote, we\u2019ll schedule a day/time to come over to do the restoration job.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tidy up \u2013 we make sure no mess is left behind!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What type of roof do you restore?",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We can restore it all! The most common types of roof found in Centennial Park are tiled roofs, metal, colorbond and terracotta, however, we have worked with innovative roof materials such as rubber or super traditional material such as shingles. It\u2019s extremely rare that we\u2019ll find a roof that we can\u2019t tackle. In case we do, there are good chances we can recommend other roofing professionals.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Is roof restoration just for traditional roofs?",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "No! Although the term restoration is often associated with historical buildings, antiques and ancient objects; roof restoration applies to modern and sometimes fairly new roofs. In summary, roof restoration is about fixing, re-coating, re-pointing and, more generally, carrying out any work that will bring a damaged roof to a point where it\u2019s like a brand new one.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Is it better to restore a roof than re-roof?",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "A newlybuilt roof is more expensive. In that sense, roof restoration offers a cost-effective solution compared to re-roofing. However, when a roof is too damaged and/or is deemed structurally unsound, re-roofing is often the only and safest solution. Eastern Suburbs Roofing Experts usually recommends re-roofing as a \u2018last-resort\u2019 option.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you do storm damage roof inspection and repairs?",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes, we sure do! Storms are easily one of your roof\u2019s worst enemies! Eastern Suburbs Roofing Experts can inspect your roof and look for any possible damage that may not be visible. We can also restore, repair and wash your roof post-storm.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you replace roofs that contain asbestos?",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes, we certainly do! Under these circumstances, the first step is to get all asbestos materials safely removed before we get started on the new roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Centennial Park Roof Restoration Specialists",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We restore roofs of all types in Centennial Park. Call Eastern Suburbs Roofing Experts today!",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Get a FREE Quote Today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We are a one-stop-shop roofing company and our expertise includes all facets of roof restorations in Centennial Park:",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://easternsuburbsroofing.com.au/roofing-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://easternsuburbsroofing.com.au/roofing-repairs/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting and Sealing",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Painting and Sealing",
                                        "url": "https://easternsuburbsroofing.com.au/painting-sealing/",
                                        "urls": [
                                            {
                                                "url": "https://easternsuburbsroofing.com.au/painting-sealing/",
                                                "anchor_text": "Roof Painting and Sealing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Roofing (brand new roof)",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Re-Roofing (brand new roof)",
                                        "url": "https://easternsuburbsroofing.com.au/replacement-installation-reroofing/",
                                        "urls": [
                                            {
                                                "url": "https://easternsuburbsroofing.com.au/replacement-installation-reroofing/",
                                                "anchor_text": "Re-Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Ventilation Systems",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Ventilation Systems",
                                        "url": "https://easternsuburbsroofing.com.au/roofing-ventilation-systems/",
                                        "urls": [
                                            {
                                                "url": "https://easternsuburbsroofing.com.au/roofing-ventilation-systems/",
                                                "anchor_text": "Roof Ventilation Systems"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Re-pointing",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Re-pointing",
                                        "url": "https://easternsuburbsroofing.com.au/repointing/",
                                        "urls": [
                                            {
                                                "url": "https://easternsuburbsroofing.com.au/repointing/",
                                                "anchor_text": "Roof Re-pointing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "We Restore Roofs in Centennial Park 2021",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u2026 and surrounding areas, including:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Moore Park",
                                        "url": "https://easternsuburbsroofing.com.au/services/moore-park-nsw-2021/",
                                        "urls": [
                                            {
                                                "url": "https://easternsuburbsroofing.com.au/services/moore-park-nsw-2021/",
                                                "anchor_text": "Moore Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bondi Junction",
                                        "url": "https://easternsuburbsroofing.com.au/services/bondi-junction-nsw-2022/",
                                        "urls": [
                                            {
                                                "url": "https://easternsuburbsroofing.com.au/services/bondi-junction-nsw-2022/",
                                                "anchor_text": "Bondi Junction"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Queens Park",
                                        "url": "https://easternsuburbsroofing.com.au/services/queens-park-nsw-2022/",
                                        "urls": [
                                            {
                                                "url": "https://easternsuburbsroofing.com.au/services/queens-park-nsw-2022/",
                                                "anchor_text": "Queens Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Surry Hills",
                                        "url": "https://easternsuburbsroofing.com.au/services/surry-hills-nsw-2010/",
                                        "urls": [
                                            {
                                                "url": "https://easternsuburbsroofing.com.au/services/surry-hills-nsw-2010/",
                                                "anchor_text": "Surry Hills"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Other Centennial Park Roofing Services:",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof repairs",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof painting & sealing",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Roofing",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof ventilation systems",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof repointing",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter repairs",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions About Roof Restorations",
                                "main_title": "Centennial Park Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61295387091"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}