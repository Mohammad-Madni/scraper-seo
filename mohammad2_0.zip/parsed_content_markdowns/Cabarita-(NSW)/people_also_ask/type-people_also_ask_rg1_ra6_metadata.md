# Type: people_also_ask | Rank: 6 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "6",
    "service": "roofer",
    "suburb": "Cabarita (NSW)",
    "title": "",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_ask"
}