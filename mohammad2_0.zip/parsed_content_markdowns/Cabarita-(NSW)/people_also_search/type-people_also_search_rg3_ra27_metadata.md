# Type: people_also_search | Rank: 27 | RG: 3
### Raw Row Data:
{
    "rank_group": "3",
    "rank_absolute": "27",
    "service": "roofer",
    "suburb": "Cabarita (NSW)",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}