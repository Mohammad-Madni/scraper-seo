# Type: people_also_search | Rank: 9 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "9",
    "service": "roofer",
    "suburb": "Cabarita (NSW)",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}