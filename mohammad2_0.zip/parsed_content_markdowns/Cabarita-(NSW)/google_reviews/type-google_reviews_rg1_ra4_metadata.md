# Type: google_reviews | Rank: 4 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "4",
    "service": "roofer",
    "suburb": "Cabarita (NSW)",
    "title": "",
    "domain": "",
    "url": "",
    "description": "",
    "type": "google_reviews"
}