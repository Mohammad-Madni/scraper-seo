{
    "id": "01191205-1132-0216-0000-d779cddce799",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0150 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sokoconstruction.com.au/project/cabarita-home-builder/",
        "target": "sokoconstruction.com.au",
        "start_url": "https://sokoconstruction.com.au/project/cabarita-home-builder/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": false,
        "load_resources": false,
        "enable_browser_rendering": false,
        "enable_xhr": false,
        "disable_cookie_popup": false,
        "browser_preset": "desktop",
        "tag": "parsed_content_markdowns\\Cabarita-(NSW)\\organic\\type-organic_rg13_ra19_sokoconstruction.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 0,
            "items": null
        }
    ]
}