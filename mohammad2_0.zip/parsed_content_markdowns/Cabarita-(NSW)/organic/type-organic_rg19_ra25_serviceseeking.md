{
    "id": "01190728-1132-0216-0000-0d376ffc2727",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0209 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.serviceseeking.com.au/roof-restorations/nsw/cabarita",
        "target": "www.serviceseeking.com.au",
        "start_url": "https://www.serviceseeking.com.au/roof-restorations/nsw/cabarita",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cabarita-(NSW)\\organic\\type-organic_rg19_ra25_serviceseeking.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:30 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "We Get Jobs Done",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Request a quote from all matching businesses",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Air Conditioner Installation",
                                    "url": "https://www.serviceseeking.com.au/air-conditioner-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/air-conditioner-installation",
                                            "anchor_text": "Air Conditioner Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Antenna Installation",
                                    "url": "https://www.serviceseeking.com.au/antenna-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/antenna-installation",
                                            "anchor_text": "Antenna Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Appliance Installation",
                                    "url": "https://www.serviceseeking.com.au/appliance-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/appliance-installation",
                                            "anchor_text": "Appliance Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asbestos Removal",
                                    "url": "https://www.serviceseeking.com.au/asbestos-removal",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/asbestos-removal",
                                            "anchor_text": "Asbestos Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bath Resurfacing",
                                    "url": "https://www.serviceseeking.com.au/bath-resurfacing",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/bath-resurfacing",
                                            "anchor_text": "Bath Resurfacing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bathroom Renovators",
                                    "url": "https://www.serviceseeking.com.au/bathroom-renovators",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/bathroom-renovators",
                                            "anchor_text": "Bathroom Renovators"
                                        }
                                    ]
                                },
                                {
                                    "text": "Carpet Cleaning",
                                    "url": "https://www.serviceseeking.com.au/carpet-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/carpet-cleaning",
                                            "anchor_text": "Carpet Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Carpet Installation",
                                    "url": "https://www.serviceseeking.com.au/carpet-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/carpet-installation",
                                            "anchor_text": "Carpet Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cctv Installation",
                                    "url": "https://www.serviceseeking.com.au/cctv-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/cctv-installation",
                                            "anchor_text": "Cctv Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ceiling Fan Installation",
                                    "url": "https://www.serviceseeking.com.au/ceiling-fan-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/ceiling-fan-installation",
                                            "anchor_text": "Ceiling Fan Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cement Rendering",
                                    "url": "https://www.serviceseeking.com.au/cement-rendering",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/cement-rendering",
                                            "anchor_text": "Cement Rendering"
                                        }
                                    ]
                                },
                                {
                                    "text": "Computer Repairs",
                                    "url": "https://www.serviceseeking.com.au/computer-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/computer-repairs",
                                            "anchor_text": "Computer Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Curtains And Blinds",
                                    "url": "https://www.serviceseeking.com.au/curtains-and-blinds",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/curtains-and-blinds",
                                            "anchor_text": "Curtains And Blinds"
                                        }
                                    ]
                                },
                                {
                                    "text": "Demolition Experts",
                                    "url": "https://www.serviceseeking.com.au/demolition-experts",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/demolition-experts",
                                            "anchor_text": "Demolition Experts"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dishwasher Repairs",
                                    "url": "https://www.serviceseeking.com.au/dishwasher-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/dishwasher-repairs",
                                            "anchor_text": "Dishwasher Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Door Fitters",
                                    "url": "https://www.serviceseeking.com.au/door-fitters",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/door-fitters",
                                            "anchor_text": "Door Fitters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Plumber",
                                    "url": "https://www.serviceseeking.com.au/emergency-plumber",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/emergency-plumber",
                                            "anchor_text": "Emergency Plumber"
                                        }
                                    ]
                                },
                                {
                                    "text": "End Of Lease Cleaners",
                                    "url": "https://www.serviceseeking.com.au/end-of-lease-cleaners",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/end-of-lease-cleaners",
                                            "anchor_text": "End Of Lease Cleaners"
                                        }
                                    ]
                                },
                                {
                                    "text": "Exposed Aggregate Concrete",
                                    "url": "https://www.serviceseeking.com.au/exposed-aggregate-concrete",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/exposed-aggregate-concrete",
                                            "anchor_text": "Exposed Aggregate Concrete"
                                        }
                                    ]
                                },
                                {
                                    "text": "Exterior Painting",
                                    "url": "https://www.serviceseeking.com.au/exterior-painting",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/exterior-painting",
                                            "anchor_text": "Exterior Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Floor Sanding",
                                    "url": "https://www.serviceseeking.com.au/floor-sanding",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/floor-sanding",
                                            "anchor_text": "Floor Sanding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Fitting",
                                    "url": "https://www.serviceseeking.com.au/gas-fitting",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/gas-fitting",
                                            "anchor_text": "Gas Fitting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Glass Installation",
                                    "url": "https://www.serviceseeking.com.au/glass-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/glass-installation",
                                            "anchor_text": "Glass Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Graphic Designers",
                                    "url": "https://www.serviceseeking.com.au/graphic-designers",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/graphic-designers",
                                            "anchor_text": "Graphic Designers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hair And Makeup",
                                    "url": "https://www.serviceseeking.com.au/hair-and-makeup",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/hair-and-makeup",
                                            "anchor_text": "Hair And Makeup"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Renovation",
                                    "url": "https://www.serviceseeking.com.au/home-renovation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/home-renovation",
                                            "anchor_text": "Home Renovation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Theatre Installation",
                                    "url": "https://www.serviceseeking.com.au/home-theatre-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/home-theatre-installation",
                                            "anchor_text": "Home Theatre Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Interior Design",
                                    "url": "https://www.serviceseeking.com.au/interior-design",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/interior-design",
                                            "anchor_text": "Interior Design"
                                        }
                                    ]
                                },
                                {
                                    "text": "Interior Painting",
                                    "url": "https://www.serviceseeking.com.au/interior-painting",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/interior-painting",
                                            "anchor_text": "Interior Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen Renovations",
                                    "url": "https://www.serviceseeking.com.au/kitchen-renovations",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/kitchen-renovations",
                                            "anchor_text": "Kitchen Renovations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lawn Mowing Services",
                                    "url": "https://www.serviceseeking.com.au/lawn-mowing-services",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/lawn-mowing-services",
                                            "anchor_text": "Lawn Mowing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Light Installation",
                                    "url": "https://www.serviceseeking.com.au/light-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/light-installation",
                                            "anchor_text": "Light Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Office Cleaning",
                                    "url": "https://www.serviceseeking.com.au/office-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/office-cleaning",
                                            "anchor_text": "Office Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Oven Installation",
                                    "url": "https://www.serviceseeking.com.au/oven-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/oven-installation",
                                            "anchor_text": "Oven Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pest Control",
                                    "url": "https://www.serviceseeking.com.au/pest-control",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/pest-control",
                                            "anchor_text": "Pest Control"
                                        }
                                    ]
                                },
                                {
                                    "text": "Phone Line Installation",
                                    "url": "https://www.serviceseeking.com.au/phone-line-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/phone-line-installation",
                                            "anchor_text": "Phone Line Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Retaining Wall Experts",
                                    "url": "https://www.serviceseeking.com.au/retaining-wall-experts",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/retaining-wall-experts",
                                            "anchor_text": "Retaining Wall Experts"
                                        }
                                    ]
                                },
                                {
                                    "text": "Rubbish Removal",
                                    "url": "https://www.serviceseeking.com.au/rubbish-removal",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/rubbish-removal",
                                            "anchor_text": "Rubbish Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Shop Fitters",
                                    "url": "https://www.serviceseeking.com.au/shop-fitters",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/shop-fitters",
                                            "anchor_text": "Shop Fitters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skip Bins",
                                    "url": "https://www.serviceseeking.com.au/skip-bins",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/skip-bins",
                                            "anchor_text": "Skip Bins"
                                        }
                                    ]
                                },
                                {
                                    "text": "Structural Engineer",
                                    "url": "https://www.serviceseeking.com.au/structural-engineer",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/structural-engineer",
                                            "anchor_text": "Structural Engineer"
                                        }
                                    ]
                                },
                                {
                                    "text": "Stump Grinder",
                                    "url": "https://www.serviceseeking.com.au/stump-grinder",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/stump-grinder",
                                            "anchor_text": "Stump Grinder"
                                        }
                                    ]
                                },
                                {
                                    "text": "T Shirt Printing",
                                    "url": "https://www.serviceseeking.com.au/t-shirt-printing",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/t-shirt-printing",
                                            "anchor_text": "T Shirt Printing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tax Returns",
                                    "url": "https://www.serviceseeking.com.au/tax-returns",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/tax-returns",
                                            "anchor_text": "Tax Returns"
                                        }
                                    ]
                                },
                                {
                                    "text": "Timber Flooring",
                                    "url": "https://www.serviceseeking.com.au/timber-flooring",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/timber-flooring",
                                            "anchor_text": "Timber Flooring"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tree Removal",
                                    "url": "https://www.serviceseeking.com.au/tree-removal",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/tree-removal",
                                            "anchor_text": "Tree Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wedding Photography",
                                    "url": "https://www.serviceseeking.com.au/wedding-photography",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/wedding-photography",
                                            "anchor_text": "Wedding Photography"
                                        }
                                    ]
                                },
                                {
                                    "text": "Window Cleaners",
                                    "url": "https://www.serviceseeking.com.au/window-cleaners",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/window-cleaners",
                                            "anchor_text": "Window Cleaners"
                                        }
                                    ]
                                },
                                {
                                    "text": "Window Installation",
                                    "url": "https://www.serviceseeking.com.au/window-installation",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/window-installation",
                                            "anchor_text": "Window Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "News & Blog",
                                    "url": "https://www.serviceseeking.com.au/news",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/news",
                                            "anchor_text": "News & Blog"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get Quotes",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Log In",
                                    "url": "https://www.serviceseeking.com.au/users/sign_in",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/users/sign_in",
                                            "anchor_text": "Log In"
                                        }
                                    ]
                                },
                                {
                                    "text": "List Your Business",
                                    "url": "https://www.serviceseeking.com.au/list-your-business?action=show&area=epping&controller=seo%2Fkeyword_pages&keyword=furniture-assembly-services&state=vic",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/list-your-business?action=show&area=epping&controller=seo%2Fkeyword_pages&keyword=furniture-assembly-services&state=vic",
                                            "anchor_text": "List Your Business"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Contact us",
                                    "url": "https://www.serviceseeking.com.au/knowledge",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/knowledge",
                                            "anchor_text": "Contact us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Press & Partners",
                                    "url": "https://www.serviceseeking.com.au/press-coverage",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/press-coverage",
                                            "anchor_text": "Press & Partners"
                                        }
                                    ]
                                },
                                {
                                    "text": "For Customers:",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "For Businesses:",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Contact us",
                                    "url": "https://www.serviceseeking.com.au/knowledge",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/knowledge",
                                            "anchor_text": "Contact us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Press & Partners",
                                    "url": "https://www.serviceseeking.com.au/press-coverage",
                                    "urls": [
                                        {
                                            "url": "https://www.serviceseeking.com.au/press-coverage",
                                            "anchor_text": "Press & Partners"
                                        }
                                    ]
                                },
                                {
                                    "text": "For Customers",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "For Businesses",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Best Roof Restorations Services in Cabarita, NSW*",
                                "main_title": "Best Roof Restorations Services in Cabarita, NSW*",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Don't rely on 3 quotes. Our FREE service sends you the MOST quotes of any of our competitors. Competition gets you the best deal.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "*Published price ranges are indicative only and may vary from actual quotes for a variety of reasons including, but not limited to, seasonality, local demographics and market dynamics, job urgency, and other factors.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Select your filters and scroll down or tap hide filters to view the results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "SkyDeck Roofing specialises in all Colorbond metal roof works, where no job is too small.\nWe pride ourselves on exceptional workmanship, friendly customer service, high quality control and competitive prices.\nWe use only the best and most current materials and systems on the market to ensure your roof looks outstanding, and every job is treated like a priority.\nWe do;\n- New metal roofs\n- Re-roofing\n- Tile to metal roofs\n- Gutter, fascia and downpipes\n- Flashings\n- Leak investigation and repair\n- Skylights and whirly birds\nCall Chad for an obligation free quote on 0408 495 069 or email skydeckroofing@gmail.com\nLIC. 259217C See more",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "From the ridgcap to the downpipe. From stripping tiles to reroofing metal sheeting. Gutter cleaning or replacement. Downpipes replaces or added. Leaks is one of my major call outs as the rain of the past 18 months has found a way to penetrate flashings rooves , overflowing gutters and downpipes. Please ring so I can at least assess any of those issues listed above.\n0450039525 peter",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Kesov Roofing is a roof repairs , roof replacement and guttering service in Sydney. We also cleaning gutters and installing gutter protection. Every roof repair job is different so if you want to get complete and appropriate quote contact us for inspection. Our quotes are free of charge.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I do Roof replacement and Roof maintenance I have 6 years experience in Roof maintenance, I do a lot of jobs for insurance companies related to leaks issues. Services: -Roof replacement metal roofs\n-Repointing ridge tiles\n-guttering & downpipes work (new installation, replacement, maintenance, cleaning) -Install flashing (metal flashing, lead flashing) tiled roof & metal roofs\n-Expert in finding leaks issues and fix it with warranty\n-Replacing tiles\n-Install vents, pipes, fans, whirlybirds for roof plumbing & ventilating Attic area.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2705 Company Introduction \u2013 Enterprise Roofs Ltd\nHi there, thanks for getting in touch.\nMy name is Lawrence and I\u2019m the owner of Enterprise Roofs Ltd, a family-run roofing business with over 10 years of experience in the industry. We specialise in roof repairs, flashing replacement, roof restorations, re-roofs, leak detection, guttering and Colorbond roofing.\nWe take pride in delivering quality workmanship, honest pricing and reliable service on every job. No shortcuts, no rushed work \u2013 just roofing done properly. All of our work is fully insured, compliant with Australian Standards, and backed by a workmanship guarantee for your peace of mind.\nWe offer:\n\u2705 Free roof inspections\n\u2705 Free quotes\n\u2705 Friendly and professional service\n\u2705 High-quality materials\n\u2705 Photos before and after every job\n\u2e3b\n\ud83c\udfd7 Business Details\nBusiness Name: Enterprise Roofs Ltd\nOwner: Lawrence\nABN: 77686547240\nPhone: 0451 110 939\nEmail: lawrenceprice123@icloud.com\nServices: Roof Repairs, Flashing Replacement, Leak Detection, Roof Restorations, Re-roofs, Colorbond, Guttering & Fascia\nArea: Servicing all of Sydney & surrounding areas\nFully Insured & Safety Focused See more",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hi, I\u2019m James, a professional and experienced tradesman with over 8 years of hands-on experience across roofing, carpentry, gyprock installation/repairs, and painting.\nI take pride in delivering high-quality work, attention to detail, and honest, reliable service on every job\u2014big or small. Whether it\u2019s a roof repair, new plastering, timber work, or a fresh coat of paint, I\u2019ve got you covered.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2022 We Specialise in Metal & Tile Roofing, Repairs, Maintenance & Replacement\n\u2022 Skylight installation\n\u2022 Carpentry Services\n\u2022 Kitchen Cabinetry plus Joinery - Repairs & Maintenance\n\u2022 Painting & Decorating\n\u2022 Plastering, Gyprock Repairs & Replacement\n\u2022 Bathroom & Kitchen RenovationsWe specialise in Roofing and Building maintenance\nFor 25 years John Arhontakis has two blue dogs building co. continues that legacy with a skilled and dedicated team delivering reliable, high-quality work across residential, strata, and commercial projects across t he Sydney metro area.\nOur skilled craftsmen are experts in restoring the integrity of your roof, ensuring it withstands the elements for years to come. In addition to roofing services, we offer high-quality plastering, painting, and joinery solutions to enhance the aesthetics and functionality of your property.\nWhether it's a small repair or a complete renovation, our commitment to excellence and customer satisfaction is unmatched.\nWith decades of experience behind us, we're committed to delivering your vision with care and precision. See more",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Proline Roofing will provide you with smooth, hassle-free customer experience for your residential or commercial roofing needs. Our professional team prides itself on a \"no excuses\" approach to service and job standards. Give us a call for a free roof inspection and quote.\nFully insured and licensed roofer",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney is an extremely large city that has many different types of roofs and roofing needs. Finding the right roofer can be a real challenge. We provide the solution.\nOur website puts you in touch with our local roofing contractors that service most suburbs of Sydney and work on tile and metal roofs. With many years experience in the industry, our roofers understand the ins and outs of keeping your roof looking and functioning its best. Our roofers back their work with an industry leading guarantee and are focused on providing the best quality of workmanship and customer satisfaction.\nOur team of expert roofers use only the highest quality materials. Restoration and roof repair can be a costly investment, so it makes good financial sense to use only the best materials. Our tradesmen are highly skilled and experienced professionals. Every roofer is compliant with OHS Regulations and implements safety management systems to ensure the safety of workers, clients and the general public. We provide a 10 year warranty on Restorations and Re-roofs and a 2 year warranty on repairs.\nComplete Roofing Services\nWe provide the complete spectrum of professional roofing services to Sydney and surrounds. See more",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have roofing business which includes roof restoration, gutter guard, whirlybird vent, Velley guard, wash,paint repointing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average and Latest Reviews",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"The roofer brett was prompt and did a great job fixing my roof yesterday. it was also competitively priced. i would definitely use and recommend residentail roofing in the future. alison\"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"A good job at a good price.\"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"Fast, efficient and not too expensive.\"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"Mathew did a very nice jobs. thanks\"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"Responded quickly and price was good\"",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Get Quotes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restorations",
                                        "url": "https://www.serviceseeking.com.au/roof-restorations",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/roof-restorations",
                                                "anchor_text": "Roof Restorations"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "CABARITA, NSW 2137",
                                        "url": "https://www.serviceseeking.com.au/roof-restorations/nsw/cabarita",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/roof-restorations/nsw/cabarita",
                                                "anchor_text": "CABARITA, NSW 2137"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Chad Cashman",
                                        "url": "https://www.serviceseeking.com.au/profile/86245?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/86245?source='business_directory",
                                                "anchor_text": "Chad Cashman"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Caringbah South, NSW",
                                        "url": "https://www.serviceseeking.com.au/profile/86245?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/86245?source='business_directory",
                                                "anchor_text": "Caringbah South, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Peter Clune",
                                        "url": "https://www.serviceseeking.com.au/profile/268190?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/268190?source='business_directory",
                                                "anchor_text": "Peter Clune"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gladesville, NSW",
                                        "url": "https://www.serviceseeking.com.au/profile/268190?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/268190?source='business_directory",
                                                "anchor_text": "Gladesville, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Newtown, NSW",
                                        "url": "https://www.serviceseeking.com.au/profile/105240?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/105240?source='business_directory",
                                                "anchor_text": "Newtown, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kellyville, NSW",
                                        "url": "https://www.serviceseeking.com.au/profile/303144?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/303144?source='business_directory",
                                                "anchor_text": "Kellyville, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Oakhurst, NSW",
                                        "url": "https://www.serviceseeking.com.au/profile/321911?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/321911?source='business_directory",
                                                "anchor_text": "Oakhurst, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Xiaoning Wang",
                                        "url": "https://www.serviceseeking.com.au/profile/316965?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/316965?source='business_directory",
                                                "anchor_text": "Xiaoning Wang"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Granville, NSW",
                                        "url": "https://www.serviceseeking.com.au/profile/316965?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/316965?source='business_directory",
                                                "anchor_text": "Granville, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Completed a nationally recognized criminal background check.",
                                        "url": "https://www.serviceseeking.com.au/profile/316965?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/316965?source='business_directory",
                                                "anchor_text": "Completed a nationally recognized criminal background check."
                                            }
                                        ]
                                    },
                                    {
                                        "text": "John Arhontakis",
                                        "url": "https://www.serviceseeking.com.au/profile/318457?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/318457?source='business_directory",
                                                "anchor_text": "John Arhontakis"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "TWO BLUE DOGS BUILDING CO PTY LTD",
                                        "url": "https://www.serviceseeking.com.au/profile/318457?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/318457?source='business_directory",
                                                "anchor_text": "TWO BLUE DOGS BUILDING CO PTY LTD"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rosebery, NSW",
                                        "url": "https://www.serviceseeking.com.au/profile/318457?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/318457?source='business_directory",
                                                "anchor_text": "Rosebery, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Proline Roofing",
                                        "url": "https://www.serviceseeking.com.au/profile/193048?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/193048?source='business_directory",
                                                "anchor_text": "Proline Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cronulla, NSW",
                                        "url": "https://www.serviceseeking.com.au/profile/193048?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/193048?source='business_directory",
                                                "anchor_text": "Cronulla, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hamada Yahia",
                                        "url": "https://www.serviceseeking.com.au/profile/271186?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/271186?source='business_directory",
                                                "anchor_text": "Hamada Yahia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Parramatta, NSW",
                                        "url": "https://www.serviceseeking.com.au/profile/271186?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/271186?source='business_directory",
                                                "anchor_text": "Parramatta, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney, NSW",
                                        "url": "https://www.serviceseeking.com.au/profile/274121?source='business_directory",
                                        "urls": [
                                            {
                                                "url": "https://www.serviceseeking.com.au/profile/274121?source='business_directory",
                                                "anchor_text": "Sydney, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Based on 140 reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Nearby Areas",
                                "main_title": "Best Roof Restorations Services in Cabarita, NSW*",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "First, we need the location",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What's the postcode of the suburb where the job will take place?",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Related Services",
                                "main_title": "Best Roof Restorations Services in Cabarita, NSW*",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Are you sure you want to exit?",
                                "main_title": "Best Roof Restorations Services in Cabarita, NSW*",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 52,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 27,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 8,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 8,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 1,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 1,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 1,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 4.8,
                                "max_rating_value": 5,
                                "rating_count": 6,
                                "relative_rating": 0.96
                            },
                            {
                                "name": null,
                                "rating_value": 4.7,
                                "max_rating_value": 5,
                                "rating_count": 10,
                                "relative_rating": 0.9400000000000001
                            },
                            {
                                "name": null,
                                "rating_value": 4.7,
                                "max_rating_value": 5,
                                "rating_count": 26,
                                "relative_rating": 0.9400000000000001
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}