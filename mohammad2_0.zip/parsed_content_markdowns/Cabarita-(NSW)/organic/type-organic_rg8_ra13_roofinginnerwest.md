{
    "id": "01190728-1132-0216-0000-9bdbd958285d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0130 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-cabarita/",
        "target": "roofinginnerwest.com.au",
        "start_url": "https://roofinginnerwest.com.au/locations/roofing-services-in-cabarita/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cabarita-(NSW)\\organic\\type-organic_rg8_ra13_roofinginnerwest.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:29 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Elevate Your Property with Zenith Roof Restorations & Replacements Inner West",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ROOFING INNER WEST",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Inner West, NSW 2204",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Open 24 hours a day, 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a92026\u00a0Roofing Inner West",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Phone: (02) 9167 0228",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email: [email\u00a0protected]",
                                    "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                            "anchor_text": "[email\u00a0protected]"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofinginnerwest.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofinginnerwest.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://roofinginnerwest.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://roofinginnerwest.com.au/terms-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/terms-conditions/",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Cabarita Roofing: Local Expertise for Inner West Homes",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Located in Sydney\u2019s Inner West, Cabarita residents rely on Roofing Inner West for robust roof restorations and dependable maintenance. We specialise in both Tile Roofs and Metal Roofs, delivering durable results with premium materials and meticulous workmanship. With years of local experience, we understand Cabarita homes and the unique challenges of urban rooftops.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Coastal humidity and salt spray common to the Inner West can accelerate wear on metal flashings and tiles. Our team conducts thorough inspections, pinpointing leaks and weak points, then applying precise flashing installation and sarking to protect the structure and extend roof life. We aim for quick, neat jobs that minimise disruption for Cabarita households and businesses.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Key capabilities in Cabarita:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Roof Restorations for Tile Roofs and Metal Roofs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Guttering, flashing, and ridge capping to prevent leaks and boost curb appeal",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Being a locally trusted provider, we stay up-to-date with Inner West building codes and regulations, and back our work with warranties on Cabarita projects. Details about Cabarita-focused solutions are available on our services page, and you can learn more about Roofing Inner West on our homepage.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "services"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/",
                                                "anchor_text": "homepage"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Specialised Roofing Services for Cabarita Homes and Businesses",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Cabarita sits in Sydney\u2019s Inner West, and Roofing Inner West brings specialist roofing solutions to local homes and businesses. We work with Tile Roofs and Metal Roofs using premium materials, backed by years of hands-on experience. For Cabarita properties, this means durable roofs that resist the salt spray and humidity common in the area while lifting curb appeal.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our method begins with a thorough inspection and pinpoint leak detection, followed by targeted repairs. In Cabarita, we prioritise flashing installation and sarking to guard the structure and extend roof life. We keep the work neat and unobtrusive, with careful adherence to Inner West building codes and regulations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Led by Riley Alcorn, Roofing Inner West brings a practical, no-nonsense approach to Cabarita projects. We back our work with warranties, giving you confidence in long\u2011term performance. For details, our services page covers Cabarita-specific offerings. Or you can Email us for direct advice.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "services page"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "Email us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tile and Metal Roofing Restorations and Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guttering, Flashing, and Ridge Capping",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Roofing Inner West in Cabarita",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From Cabarita to the wider Inner West, Roofing Inner West delivers practical, durable roofing solutions for homes and businesses. Led by Riley Alcorn, we specialise in tile and metal roof restorations using premium materials and meticulous workmanship. The result is a roof that stands up to the coastal climate and boosts property value, with less disruption to your day.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local conditions in Cabarita\u2014salt spray and humidity\u2014mean you need a team that truly understands the area. We start with thorough inspections, then tackle leaks with precise flashing installation and sarking to guard the structure and extend roof life. Our approach is neat, efficient, and aligned with Inner West building regulations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local knowledge of Cabarita and the Inner West ensures compliant, fit-for-purpose solutions",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Warranties on all roofing restorations and repairs provide long\u2011term protection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium materials and transparent workmanship deliver real value for your investment",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For Cabarita residents, our services page and homepage offer detailed information: services | homepage",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "services"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/",
                                                "anchor_text": "homepage"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Cost and Pricing in Cabarita",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Pricing in Cabarita and Sydney\u2019s Inner West reflects the scope, roof type, and condition of your property. Roofing Inner West delivers value through durable, long\u2011lasting results using premium materials, with careful attention to salt spray and urban wear that can affect metal flashings and tile roofs. By tailoring pricing to the specifics of your roof, we help Cabarita residents and businesses protect their investment.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We provide a transparent quote that breaks down materials, labour, scaffolding, waste removal, and essential components like flashing and sarking. After a thorough inspection, you\u2019ll receive a clear estimate for Tile Roof Restorations, Metal Roofs, and related works, with warranties noted for peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What\u2019s included in the price : Thorough roof assessment, premium materials, flashing, sarking, gutter work, waste disposal, and warranties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What can influence the final figure : Roof type, age and condition, access for scaffolding, permits, and heritage considerations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For a detailed view of pricing inclusions, see our pricing and inclusions on the Services page. Find more about our work across the Inner West on our homepage.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "pricing and inclusions on the Services page"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/",
                                                "anchor_text": "homepage"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Commitment to Quality Roofing Services in Cabarita",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our pledge to Cabarita is simple: deliver quality roofing that lasts. Led by Riley Alcorn, the team brings practical Inner West know-how to every job, ensuring roofs perform well against salt spray, humidity, and urban wear. For Cabarita residents, that means dependable protection and real property value.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality isn\u2019t just talk\u2014it\u2019s in the process. We begin with a thorough inspection, then tackle leaks with precise flashing installation and sarking, using premium materials suitable for both Tile Roofs and Metal Roofs. We keep work neat and compliant with Inner West regulations, minimising disruption while protecting your home or business. All Cabarita projects are backed by robust warranties for long\u2011term peace of mind.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What you can count on in Cabarita:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Transparent communication and meticulous workmanship",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Warranties and long\u2011term performance to protect your investment",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For more detail on Cabarita-focused offerings, explore our Services page and our Homepage.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services page"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/",
                                                "anchor_text": "Homepage"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "The Cabarita Roofing Advantage: Local Expertise That Lasts",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Cabarita sits in Sydney\u2019s Inner West, where coastal humidity and salt spray test roofs. Roofing Inner West, led by Riley Alcorn, specialises in Tile Roof Restorations and Metal Roofs, delivering premium materials and meticulous workmanship that stand up to Cabarita\u2019s daily wear. We begin with thorough inspections and leak detection, then move to targeted repairs with a focus on flashing installation and sarking to protect the structure and extend roof life.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For Cabarita homes and businesses, the benefits go beyond a fresh cover. Our local knowledge helps us navigate Inner West building regulations, keep disruptions to a minimum, and back work with strong warranties for long\u2011term peace of mind. By choosing Roofing Inner West, you\u2019re investing in real value, enhanced curb appeal, and reliable protection against salt-induced wear.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local knowledge within Cabarita and the Inner West ensures compliant, fit-for-purpose solutions",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Durable materials and warranties deliver long\u2011term protection and peace of mind",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Learn more about Cabarita\u2011focused offerings on our Services page or get a broader view on our Homepage.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services page"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/",
                                                "anchor_text": "Homepage"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FAQs for Cabarita Roofing with Roofing Inner West",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "These answers tackle the questions Cabarita homeowners and businesses commonly ask about roofing work in Sydney\u2019s Inner West. Led by Riley Alcorn, Roofing Inner West specialises in Tile Roof Restorations and Metal Roofs, and we tailor solutions for Cabarita\u2019s coastal climate. Expect clear explanations, kvalit materials, and workmanship that stands up to salt spray and humidity. For more detail on our offerings, see our services page.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "services page"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "What roofing services do you offer in Cabarita?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We handle Tile Roofs and Metal Roofs with restorations, repairs, and replacements, plus related work like guttering, flashing, ridge capping, and skylight installation.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you provide warranties or guarantees?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes. All Cabarita projects are backed by warranties on workmanship and materials where applicable, giving long\u2011term protection.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How long does a typical roof restoration take?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Most projects are completed efficiently with minimal disruption, depending on roof size, access, and weather; we aim for neat, durable results within a few days.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How do you address Cabarita\u2019s local conditions?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We prioritise flashing installation and sarking to combat salt spray and humidity, protecting the structure and extending roof life.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How can I get a quote for Cabarita roofing work?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "After a no\u2011obligation inspection, we provide a transparent estimate outlining materials, labour, and warranties. See our services page for more details.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "services page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Cabarita Roofing, Local Expertise You Can Trust",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Cabarita residents rely on Roofing Inner West for durable roof restorations and dependable maintenance. Led by Riley Alcorn, we specialise in Tile Roof Restorations and Metal Roofs, using premium materials and straight\u2011talk workmanship. Our local focus means we understand Cabarita\u2019s coastal climate and the daily wear on urban rooftops.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We start with a thorough inspection to detect leaks and wear, then apply targeted repairs. In Cabarita, we prioritise flashing installation and sarking to shield the structure from salt spray and humidity, delivering neat, low\u2011disruption work that stays compliant with Inner West building standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive roof assessments with premium materials and long\u2011lasting warranties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent pricing with clear inclusions and tidy, compliant workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you\u2019re weighing roof solutions for Cabarita, explore our Services page or get a broader view on our Homepage.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/",
                                                "anchor_text": "Homepage"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get in Touch with Us Today",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For a comprehensive overview of our services, call us today on (02) 9167 0228. For more information about us, visit our homepage or for more information on our other areas we service, please visit our locations page.",
                                        "url": "https://roofinginnerwest.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/",
                                                "anchor_text": "homepage"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/",
                                                "anchor_text": "locations page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Services in Cabarita",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Service Locations",
                                "main_title": "Roofing Services in Cabarita",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Balmain East",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-balmain-east/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-balmain-east/",
                                                "anchor_text": "Balmain East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canada Bay",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-canada-bay/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-canada-bay/",
                                                "anchor_text": "Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-croydon-park/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-croydon-park/",
                                                "anchor_text": "Croydon Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-five-dock/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-five-dock/",
                                                "anchor_text": "Five Dock"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Peters",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-st-peters/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-st-peters/",
                                                "anchor_text": "St Peters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-summer-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-summer-hill/",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61291670228"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}