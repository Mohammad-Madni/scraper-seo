{
    "id": "01190728-1132-0216-0000-ff7b2f6442e9",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0244 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrestohq.com.au/roofers/cabarita-beach/iroof/",
        "target": "roofrestohq.com.au",
        "start_url": "https://roofrestohq.com.au/roofers/cabarita-beach/iroof/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cabarita-(NSW)\\organic\\type-organic_rg6_ra11_roofrestohq.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:30 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Add Business",
                                    "url": "https://roofrestohq.com.au/add-listing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestohq.com.au/add-listing/",
                                            "anchor_text": "Add Business"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrestohq.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestohq.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Add Business",
                                    "url": "https://roofrestohq.com.au/add-listing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestohq.com.au/add-listing/",
                                            "anchor_text": "Add Business"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrestohq.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestohq.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Unit 2B/50 Logan Rd, Woolloongabba QLD 4102",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "0489 071 924",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2026 Roof Resto HQ. All rights reserved.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Terms and Conditions",
                                    "url": "https://roofrestohq.com.au/terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestohq.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://roofrestohq.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestohq.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Change Location",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Find awesome listings near you!",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Add Business",
                                    "url": "https://roofrestohq.com.au/add-listing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestohq.com.au/add-listing/",
                                            "anchor_text": "Add Business"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrestohq.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestohq.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "iRoof",
                                "main_title": "iRoof",
                                "author": "Roof Resto HQ",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "iRoof is a professional roofing contractor located at 37 Tallowood Ave, Cabarita Beach NSW 2488. The company is dedicated to providing high-quality roofing solutions tailored to meet the needs of both residential and commercial clients. iRoof offers a comprehensive range of services, including roof installation, maintenance, and repair. They specialise in metal roofing, tile roofing, and roof restoration, ensuring that every project is completed with attention to detail and a commitment to customer satisfaction.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "In addition to their core services, iRoof also provides gutter installation and repair, as well as roof inspections to help identify potential issues before they become major problems. With a team of experienced professionals, iRoof is equipped to handle projects of any size, delivering reliable and efficient service. For those interested in learning more or scheduling a free estimate, iRoof encourages potential clients to call them directly at 0407 440 986.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "iRoof",
                                        "url": "https://roofrestohq.com.au/roofers/cabarita-beach/iroof/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestohq.com.au/roofers/cabarita-beach/iroof/",
                                                "anchor_text": "iRoof"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "iRoof",
                                "main_title": "iRoof",
                                "author": "Roof Resto HQ",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "37 Tallowood Ave",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cabarita Beach, New South Wales 2488",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "iRoof",
                                "main_title": "iRoof",
                                "author": "Roof Resto HQ",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof-Resto-HQ-logo-black-bg-1500x900",
                                "main_title": "iRoof",
                                "author": "Roof Resto HQ",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Map",
                                "main_title": "iRoof",
                                "author": "Roof Resto HQ",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Service Types",
                                "main_title": "iRoof",
                                "author": "Roof Resto HQ",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Services Offered",
                                "main_title": "iRoof",
                                "author": "Roof Resto HQ",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Location & Contact",
                                "main_title": "iRoof",
                                "author": "Roof Resto HQ",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0407 440 986",
                                "+61489071924"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}