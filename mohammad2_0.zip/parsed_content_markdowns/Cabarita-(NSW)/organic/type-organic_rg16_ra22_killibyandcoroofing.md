{
    "id": "01190728-1132-0216-0000-6be91ead03dd",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0147 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.killibyandcoroofing.com.au/",
        "target": "www.killibyandcoroofing.com.au",
        "start_url": "https://www.killibyandcoroofing.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cabarita-(NSW)\\organic\\type-organic_rg16_ra22_killibyandcoroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:28 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Inspections & Reports",
                                    "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                            "anchor_text": "Inspections & Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://www.killibyandcoroofing.com.au/guttering",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/guttering",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panels",
                                    "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                            "anchor_text": "Solar Panels"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gold Coast",
                                    "url": "https://www.killibyandcoroofing.com.au/locations/roofing-gold-coast",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/locations/roofing-gold-coast",
                                            "anchor_text": "Gold Coast"
                                        }
                                    ]
                                },
                                {
                                    "text": "Banora Point",
                                    "url": "https://www.killibyandcoroofing.com.au/locations/roofing-banora-point",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/locations/roofing-banora-point",
                                            "anchor_text": "Banora Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tweed Heads",
                                    "url": "https://www.killibyandcoroofing.com.au/locations/roofing-tweed-heads",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/locations/roofing-tweed-heads",
                                            "anchor_text": "Tweed Heads"
                                        }
                                    ]
                                },
                                {
                                    "text": "Palm Beach",
                                    "url": "https://www.killibyandcoroofing.com.au/locations/palm-beach",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/locations/palm-beach",
                                            "anchor_text": "Palm Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cabarita Beach",
                                    "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
                                            "anchor_text": "Cabarita Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "0411 162 857",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Your Expert Roofers",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Killiby & Co Roofing Pty Ltd are local, family-owned roofing contractors with decades of experience in all roof repairs,\u00a0roof restorations and roof maintenance. We provide a prompt same-day response to all enquiries, quotes and advice. Senior discounts are also available.",
                                        "url": "https://www.killibyandcoroofing.com.au/repairs",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/repairs",
                                                "anchor_text": "roof repairs"
                                            },
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/restorations",
                                                "anchor_text": "roof restorations"
                                            },
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/maintenance",
                                                "anchor_text": "roof maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are members of the Housing Industry Association (HIA) and the quality of our roofing services is guaranteed. We are fully licensed and insured; our Queensland licence number is 1163759 and our New South Wales licence number is 100204C.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We service roofs throughout the Gold Coast and Northern NSW, including:",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/roofing-gold-coast",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/roofing-gold-coast",
                                                "anchor_text": "Gold Coast"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tweed Heads",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/roofing-tweed-heads",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/roofing-tweed-heads",
                                                "anchor_text": "Tweed Heads"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Banora Point",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/roofing-banora-point",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/roofing-banora-point",
                                                "anchor_text": "Banora Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cabarita Beach",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
                                                "anchor_text": "Cabarita Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Palm Beach",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/palm-beach",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/palm-beach",
                                                "anchor_text": "Palm Beach"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Repairs",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof got a leak? Our qualified roofers provide same-day and emergency roof repairs for residential and commercial clients.",
                                        "url": "https://www.killibyandcoroofing.com.au/repairs",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/repairs",
                                                "anchor_text": "roof repairs"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Repairs",
                                        "url": "https://www.killibyandcoroofing.com.au/repairs",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/repairs",
                                                "anchor_text": "Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Maintenance",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide regular roof maintenance for residential and commercial clients to determine the state of your roof and fix any problems if present.",
                                        "url": "https://www.killibyandcoroofing.com.au/maintenance",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/maintenance",
                                                "anchor_text": "roof maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Maintenance",
                                        "url": "https://www.killibyandcoroofing.com.au/maintenance",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/maintenance",
                                                "anchor_text": "Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Need a roof repair? We install high-quality roof tiles from renowned brands Monier, Bristol and Boral. Our tiles are stylish, don\u2019t rust and outlast metal.",
                                        "url": "https://www.killibyandcoroofing.com.au/tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/tiling",
                                                "anchor_text": "roof tiles"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling",
                                        "url": "https://www.killibyandcoroofing.com.au/tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/tiling",
                                                "anchor_text": "Roof Tiling"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Inspections & Reports",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Whether you\u2019re buying a home, selling one or need peace of mind, our skilled roofers provide comprehensive roof inspections and reports.",
                                        "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                                "anchor_text": "roof inspections and reports"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Inspections & Reports",
                                        "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                                "anchor_text": "Inspections & Reports"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Whirlybirds/Vents/Skylights",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Let there be light and fresh air! We install whirlybirds, vents and skylights from renowned brands to enhance the value and aesthetic of your home.",
                                        "url": "https://www.killibyandcoroofing.com.au/whirlybirds-vents-skylights",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/whirlybirds-vents-skylights",
                                                "anchor_text": "whirlybirds, vents and skylights"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Whirlybirds/Vents/Skylights",
                                        "url": "https://www.killibyandcoroofing.com.au/whirlybirds-vents-skylights",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/whirlybirds-vents-skylights",
                                                "anchor_text": "Whirlybirds/Vents/Skylights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Restorations",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our skilled roofers provide roof restorations for roof tiles and metal roofing.",
                                        "url": "https://www.killibyandcoroofing.com.au/restorations",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/restorations",
                                                "anchor_text": "roof restorations"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Restorations",
                                        "url": "https://www.killibyandcoroofing.com.au/restorations",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/restorations",
                                                "anchor_text": "Restorations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Guttering",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide first-rate gutter mesh and repairs for residential, body corporate and real estate clients.",
                                        "url": "https://www.killibyandcoroofing.com.au/guttering",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/guttering",
                                                "anchor_text": "gutter mesh and repairs"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Guttering",
                                        "url": "https://www.killibyandcoroofing.com.au/guttering",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/guttering",
                                                "anchor_text": "Guttering"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Cleaning",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our skilled roofers\u2014using specialised equipment\u2014 clean roofs, gutters and solar panels to ensure they look great and perform at their best.",
                                        "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                                "anchor_text": "clean"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Cleaning",
                                        "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                                "anchor_text": "Cleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "About Us",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Killiby & Co Roofing was established in 1995. We are roof tile specialists. We are a family-owned and operated business, providing a wide range of roof and gutter maintenance work on the Gold Coast and beyond. Whether you\u2019re a homeowner, real estate agency or body corp, our qualified roofers will ensure your roof and/or gutter is ready to take on the elements. Get in touch with us today for a free, no-obligation quote. Emergency roof and gutter repair services are also available.",
                                        "url": "https://www.killibyandcoroofing.com.au/repairs",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/repairs",
                                                "anchor_text": "roof"
                                            },
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/guttering",
                                                "anchor_text": "gutter"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Servicing Northern NSW & Gold Coast",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "QLD Lic: 1163759",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "NSW Lic: 100204C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\ufeff HIA Member: 391885",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Book an appointment",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Book an appointment",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Testimonials",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Previous Projects",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "View more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Site Links",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Areas We Service",
                                        "url": "https://www.killibyandcoroofing.com.au/locations",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations",
                                                "anchor_text": "Areas We Service"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Services",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Inspections & Reports",
                                        "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                                "anchor_text": "Inspections & Reports"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Areas We Service",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gold Coast",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/roofing-gold-coast",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/roofing-gold-coast",
                                                "anchor_text": "Gold Coast"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Banora Point",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/roofing-banora-point",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/roofing-banora-point",
                                                "anchor_text": "Banora Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tweed Heads",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/roofing-tweed-heads",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/roofing-tweed-heads",
                                                "anchor_text": "Tweed Heads"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Palm Beach",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/palm-beach",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/palm-beach",
                                                "anchor_text": "Palm Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cabarita Beach",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
                                                "anchor_text": "Cabarita Beach"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Operating Hours",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "Killiby & Co Roofing: Roof & Gutter Specialists",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Tweed NSW 2486",
                                        "url": "https://maps.app.goo.gl/wHnrjd9sFgE2dray5",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/wHnrjd9sFgE2dray5",
                                                "anchor_text": "Tweed NSW 2486"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "PO Box 534 Coolangatta QLD 4225",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0411 162 857",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ABN: 31 072 068 029",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "QLD Lic: 1163759",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "NSW Lic: 100204C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "HIA Member: 391885",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u00a9 2026",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Killiby & Co Roofing Pty Ltd",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0411 162 857"
                            ],
                            "emails": [
                                "killibyandco@hotmail.com"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}