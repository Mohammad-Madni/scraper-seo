{
    "id": "01190728-1132-0216-0000-8459e82e2381",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0392 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
        "target": "www.killibyandcoroofing.com.au",
        "start_url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cabarita-(NSW)\\organic\\type-organic_rg5_ra10_killibyandcoroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:28 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Cabarita Beach",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Inspections & Reports",
                                    "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                            "anchor_text": "Inspections & Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://www.killibyandcoroofing.com.au/guttering",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/guttering",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panels",
                                    "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                            "anchor_text": "Solar Panels"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gold Coast",
                                    "url": "https://www.killibyandcoroofing.com.au/locations/roofing-gold-coast",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/locations/roofing-gold-coast",
                                            "anchor_text": "Gold Coast"
                                        }
                                    ]
                                },
                                {
                                    "text": "Banora Point",
                                    "url": "https://www.killibyandcoroofing.com.au/locations/roofing-banora-point",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/locations/roofing-banora-point",
                                            "anchor_text": "Banora Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tweed Heads",
                                    "url": "https://www.killibyandcoroofing.com.au/locations/roofing-tweed-heads",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/locations/roofing-tweed-heads",
                                            "anchor_text": "Tweed Heads"
                                        }
                                    ]
                                },
                                {
                                    "text": "Palm Beach",
                                    "url": "https://www.killibyandcoroofing.com.au/locations/palm-beach",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/locations/palm-beach",
                                            "anchor_text": "Palm Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cabarita Beach",
                                    "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
                                    "urls": [
                                        {
                                            "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
                                            "anchor_text": "Cabarita Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "0411 162 857",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Strong, Secure Roofs You Can Trust",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Killiby & Co Roofing Pty Ltd, we take pride in offering expert roofing services backed by years of experience and a commitment to quality.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As a family-owned business, we understand the importance of trust, transparency, and providing lasting roofing solutions rather than temporary fixes. Whether you need urgent repairs, ongoing maintenance or expert advice, our dedicated team is here to help.",
                                        "url": "https://www.killibyandcoroofing.com.au/repairs",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/repairs",
                                                "anchor_text": "repairs"
                                            },
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/maintenance",
                                                "anchor_text": "maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "What sets us apart? We provide same-day responses, free quotes and fully licensed and insured workmanship to ensure every job meets the highest standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team is also available for emergency roofing services, helping homeowners and businesses in Cabarita Beach when they need it most. No matter the size of the job, you can count on us for expert solutions and honest service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you need roofing assistance, call us today at 0411 162 857 for a free quote.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Cabarita Beach Locals Choose Us?",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Quick and Effective Roof Repairs \u2013 We fix leaks, broken tiles and other roofing issues in Cabarita Beach before they become bigger problems.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Proactive Roof Maintenance \u2013 Regular upkeep helps prevent costly damage and keeps your roof in top shape year-round.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Expert Tiling Services \u2013 Whether replacing damaged tiles or improving aesthetics, we deliver long-lasting tiling solutions for Cabarita Beach homes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whirlybirds, Vents & Skylights Installation \u2013 Improve airflow, increase natural light and enhance energy efficiency with smart roofing upgrades.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive Roof Inspections & Reports \u2013 Get a professional assessment of your roof to catch potential issues early and avoid expensive repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thorough Guttering & Roof Cleaning \u2013 Prevent water damage and buildup with regular gutter and roof cleaning for your Cabarita Beach home.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Locally Owned & Operated \u2013 We understand the coastal roofing challenges in Cabarita Beach and tailor solutions to suit local conditions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully Licensed & Insured Team \u2013 Our professionals provide safe, high-quality roofing services that meet industry standards for peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Repairs",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From small leaks to major damage, we act quickly to repair and restore your roof\u2019s strength and durability in Cabarita Beach.",
                                        "url": "https://www.killibyandcoroofing.com.au/repairs",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/repairs",
                                                "anchor_text": "repair and restore"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Repairs",
                                        "url": "https://www.killibyandcoroofing.com.au/repairs",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/repairs",
                                                "anchor_text": "Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Maintenance",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Regular roof maintenance prevent expensive repairs and keep your Cabarita Beach home safe from wear and tear.",
                                        "url": "https://www.killibyandcoroofing.com.au/maintenance",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/maintenance",
                                                "anchor_text": "maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Maintenance",
                                        "url": "https://www.killibyandcoroofing.com.au/maintenance",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/maintenance",
                                                "anchor_text": "Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tiling",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Whether fixing broken tiles or improving kerb appeal, our expert tiling services enhance the durability and appearance of your roof.",
                                        "url": "https://www.killibyandcoroofing.com.au/tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/tiling",
                                                "anchor_text": "tiling services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tiling",
                                        "url": "https://www.killibyandcoroofing.com.au/tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/tiling",
                                                "anchor_text": "Tiling"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Restorations",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Complete roof restorations strengthen Cabarita Beach homes' exterior, improves aesthetics and adds years to their roofs' lifespan.",
                                        "url": "https://www.killibyandcoroofing.com.au/restorations",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/restorations",
                                                "anchor_text": "restorations"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Restorations",
                                        "url": "https://www.killibyandcoroofing.com.au/restorations",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/restorations",
                                                "anchor_text": "Restorations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Whirlybirds / Vents / Skylights",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Enhance airflow, reduce energy costs and bring more natural light into your Cabarita Beach home with our expert roofing installations.",
                                        "url": "https://www.killibyandcoroofing.com.au/whirlybirds-vents-skylights",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/whirlybirds-vents-skylights",
                                                "anchor_text": "roofing installations"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Whirlybirds / Vents / Skylights",
                                        "url": "https://www.killibyandcoroofing.com.au/whirlybirds-vents-skylights",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/whirlybirds-vents-skylights",
                                                "anchor_text": "Whirlybirds / Vents / Skylights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Inspections & Reports",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our detailed inspections help Cabarita Beach's residents identify hidden problems before they turn into costly repairs, providing confidence.",
                                        "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                                "anchor_text": "inspections"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Inspections & Reports",
                                        "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                                "anchor_text": "Inspections & Reports"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Guttering",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Blocked gutters and debris lead to leaks and other issues. Our thorough guttering services protect Cabarita Beach homeowners from potential high costs.",
                                        "url": "https://www.killibyandcoroofing.com.au/guttering",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/guttering",
                                                "anchor_text": "guttering services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Guttering",
                                        "url": "https://www.killibyandcoroofing.com.au/guttering",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/guttering",
                                                "anchor_text": "Guttering"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Cleaning",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Dirt, moss and debris can cause long-term damage. Our expert cleaning service helps Cabarita Beach residents by maintaining roof health year-round.",
                                        "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                                "anchor_text": "cleaning service"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Cleaning",
                                        "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/cleaning",
                                                "anchor_text": "Cleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What areas do you service around Cabarita Beach?",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We provide roofing services throughout Cabarita Beach and nearby areas, including:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you\u2019re unsure whether we cover your location, feel free to reach out.",
                                        "url": "https://www.killibyandcoroofing.com.au/contact",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/contact",
                                                "anchor_text": "reach out"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Hastings Point",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Does roof colour impact home temperature?",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Absolutely! Lighter-coloured roofs reflect more sunlight, helping to keep homes cooler, while darker roofs absorb heat, making indoor spaces warmer.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Are there specific coatings to protect roofs near the ocean?",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes! Protective sealants and coatings help prevent rust, moisture absorption and UV damage, making your roof more resilient to coastal weather.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Can strong coastal winds damage my roof?",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes, coastal winds can loosen tiles, damage flashing and wear down roofing materials faster. Regular inspections help catch potential wind-related damage early.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "HOME / CABARITA BEACH",
                                        "url": "https://www.killibyandcoroofing.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/",
                                                "anchor_text": "HOME"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Our Team",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Cabarita Beach, NSW 2488",
                                        "url": "https://maps.app.goo.gl/6guTEd7dcAPsGVKu5",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/6guTEd7dcAPsGVKu5",
                                                "anchor_text": "Cabarita Beach, NSW 2488"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0411 162 857",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Operating Hours:",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Site Links",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Areas We Service",
                                        "url": "https://www.killibyandcoroofing.com.au/locations",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations",
                                                "anchor_text": "Areas We Service"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Services",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Inspections & Reports",
                                        "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/inspections-reports",
                                                "anchor_text": "Inspections & Reports"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Areas We Service",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gold Coast",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/roofing-gold-coast",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/roofing-gold-coast",
                                                "anchor_text": "Gold Coast"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Banora Point",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/roofing-banora-point",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/roofing-banora-point",
                                                "anchor_text": "Banora Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tweed Heads",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/roofing-tweed-heads",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/roofing-tweed-heads",
                                                "anchor_text": "Tweed Heads"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Palm Beach",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/palm-beach",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/palm-beach",
                                                "anchor_text": "Palm Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cabarita Beach",
                                        "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
                                        "urls": [
                                            {
                                                "url": "https://www.killibyandcoroofing.com.au/locations/cabaraita-beach",
                                                "anchor_text": "Cabarita Beach"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Operating Hours",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "We Maintain & Repair Roofing in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Tweed NSW 2486",
                                        "url": "https://maps.app.goo.gl/wHnrjd9sFgE2dray5",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/wHnrjd9sFgE2dray5",
                                                "anchor_text": "Tweed NSW 2486"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "PO Box 534 Coolangatta QLD 4225",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0411 162 857",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ABN: 31 072 068 029",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "QLD Lic: 1163759",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "NSW Lic: 100204C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "HIA Member: 391885",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u00a9 2026",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Killiby & Co Roofing Pty Ltd",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0411 162 857"
                            ],
                            "emails": [
                                "killibyandco@hotmail.com"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}