{
    "id": "01191205-1132-0216-0000-eb8e8f7201db",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0188 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.whereis.com/nsw/cabarita-2137/yellowId-15609661",
        "target": "whereis.com",
        "start_url": "https://www.whereis.com/nsw/cabarita-2137/yellowId-15609661",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": false,
        "load_resources": false,
        "enable_browser_rendering": false,
        "enable_xhr": false,
        "disable_cookie_popup": false,
        "browser_preset": "desktop",
        "tag": "parsed_content_markdowns\\Cabarita-(NSW)\\organic\\type-organic_rg18_ra24_whereis.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 08:06:26 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Newtown Roofing",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Sorry, maps are currently unavailable",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Map data \u00a9 OpenStreetMap contributors",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Loading map...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Newtown Roofing opening hours in Cabarita",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Explore similar businesses nearby",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Business Owners - Is Newtown Roofing in Cabarita, NSW your business?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Attract more customers by adding more content such as opening hours, logo and more",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Remove your competitors from this page",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "CONCORD NSW 2137",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0485 800 063",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Emergencies, Extensions, Gutter Cleaning, Installations, Leaf Screening, Maintenance, Painting, Re-roofing, Renovations, Repairs, Replacements, Restorations, Resurfacing, Roof Cleaning, Roofing, Sealing, Spouting, Tiling, Waterproofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Features",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "By Appointment, Consultations, Guaranteed, Inspections, Licensed, Locally Operated, Locally Owned, Owner Operated, Pick-up, Quotes, Same Day Service",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Additional Locations",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Showing 1 locations in 1 states",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yellow Pages",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "People Also Viewed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.whereis.com/find/roof-restoration-repairs/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-restoration-repairs/cabarita-nsw-2137",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.whereis.com/find/roof-restoration-repairs/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-restoration-repairs/cabarita-nsw-2137",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Acid Proofing",
                                        "url": "https://www.whereis.com/find/acid-proofing/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/acid-proofing/cabarita-nsw-2137",
                                                "anchor_text": "Acid Proofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Insulation Installers & Contractors",
                                        "url": "https://www.whereis.com/find/insulation-installers-contractors/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/insulation-installers-contractors/cabarita-nsw-2137",
                                                "anchor_text": "Insulation Installers & Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": "https://www.whereis.com/find/roofing-construction-services/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roofing-construction-services/cabarita-nsw-2137",
                                                "anchor_text": "Roofing Construction & Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tiles",
                                        "url": "https://www.whereis.com/find/roof-tiles/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-tiles/cabarita-nsw-2137",
                                                "anchor_text": "Roof Tiles"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Popular Categories",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Plumbers in Cabarita",
                                        "url": "https://www.whereis.com/find/plumbers-gas-fitters/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/plumbers-gas-fitters/cabarita-nsw-2137",
                                                "anchor_text": "Plumbers in Cabarita"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electricians in Cabarita",
                                        "url": "https://www.whereis.com/find/electricians-electrical-contractors/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/electricians-electrical-contractors/cabarita-nsw-2137",
                                                "anchor_text": "Electricians in Cabarita"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lawyers in Cabarita",
                                        "url": "https://www.whereis.com/find/lawyers-solicitors/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/lawyers-solicitors/cabarita-nsw-2137",
                                                "anchor_text": "Lawyers in Cabarita"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pest Control in Cabarita",
                                        "url": "https://www.whereis.com/find/pest-control/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/pest-control/cabarita-nsw-2137",
                                                "anchor_text": "Pest Control  in Cabarita"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mechanics in Cabarita",
                                        "url": "https://www.whereis.com/find/mechanics-motor-engineers/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/mechanics-motor-engineers/cabarita-nsw-2137",
                                                "anchor_text": "Mechanics in Cabarita"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Locksmiths in Cabarita",
                                        "url": "https://www.whereis.com/find/locksmiths-locksmith-services/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/locksmiths-locksmith-services/cabarita-nsw-2137",
                                                "anchor_text": "Locksmiths in Cabarita"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Concreters in Cabarita",
                                        "url": "https://www.whereis.com/find/concrete-contractors/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/concrete-contractors/cabarita-nsw-2137",
                                                "anchor_text": "Concreters in Cabarita"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Fencing Contractors in Cabarita",
                                        "url": "https://www.whereis.com/find/fencing-contractors/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/fencing-contractors/cabarita-nsw-2137",
                                                "anchor_text": "Fencing Contractors in Cabarita"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Builders in Cabarita",
                                        "url": "https://www.whereis.com/find/builders-building-contractors/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/builders-building-contractors/cabarita-nsw-2137",
                                                "anchor_text": "Builders in Cabarita"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Accountants in Cabarita",
                                        "url": "https://www.whereis.com/find/accountants-auditors/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/accountants-auditors/cabarita-nsw-2137",
                                                "anchor_text": "Accountants in Cabarita"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Find out more",
                                        "url": "https://www.whereis.com/quotes",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/quotes",
                                                "anchor_text": "Find out more"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our directory.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "About Yellow Pages",
                                        "url": "https://www.whereis.com/pages/about-us",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/pages/about-us",
                                                "anchor_text": "About Yellow Pages"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://www.whereis.com/pages/contact-us",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/pages/contact-us",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Site Index",
                                        "url": "https://www.whereis.com/sitemap",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/sitemap",
                                                "anchor_text": "Site Index"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Order or cancel your book",
                                        "url": "https://www.directoryselect.com.au/action/home",
                                        "urls": [
                                            {
                                                "url": "https://www.directoryselect.com.au/action/home",
                                                "anchor_text": "Order or cancel your book"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://www.whereis.com/pages/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/pages/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our advertising.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a free listing",
                                        "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                                "anchor_text": "Get a free listing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Digital marketing solutions",
                                        "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                                "anchor_text": "Digital marketing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Business hub",
                                        "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                                "anchor_text": "Business hub"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "myYellow login",
                                        "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                                "anchor_text": "myYellow login"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Connect with us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Restoration & Repairs",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.whereis.com/find/roof-restoration-repairs/cabarita-nsw-2137",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-restoration-repairs/cabarita-nsw-2137",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0427 121 800",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Newtown Roofing opening hours in Cabarita",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Us",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Payment Methods",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Products and Services",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hours of Operation",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Flexible Hours, Open Monday - Friday",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Material",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Aluminium, Cedar, Concrete, Copper, Fibreglass, Malthoid, Metal, Steel, Tiles",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Offering",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Box Guttering, Commercial, Farms, Fascias, Houses, Industrial, Rainwater Tanks, Residential",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Issues",
                                "main_title": "Newtown Roofing",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Blocked Drains, Broken Tiles, Leaks",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": [
                            {
                                "name": "Newtown Roofing",
                                "price": 0,
                                "price_currency": null,
                                "price_valid_until": null
                            }
                        ],
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0427 121 800",
                                "0427121800",
                                "0485800063"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}