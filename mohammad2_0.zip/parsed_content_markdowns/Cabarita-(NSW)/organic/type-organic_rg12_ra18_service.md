{
    "id": "01190728-1132-0216-0000-995e86079e22",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0201 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.service.com.au/find/roofing/cabarita-nsw?page=1",
        "target": "www.service.com.au",
        "start_url": "https://www.service.com.au/find/roofing/cabarita-nsw?page=1",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cabarita-(NSW)\\organic\\type-organic_rg12_ra18_service.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:30 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Sign in",
                                    "url": "https://www.service.com.au/login",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/login",
                                            "anchor_text": "Sign in"
                                        }
                                    ]
                                },
                                {
                                    "text": "How it works",
                                    "url": "https://www.service.com.au/how-it-works/its-so-easy",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/how-it-works/its-so-easy",
                                            "anchor_text": "How it works"
                                        }
                                    ]
                                },
                                {
                                    "text": "List your business",
                                    "url": "https://www.service.com.au/businesses/join",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/businesses/join",
                                            "anchor_text": "List your business"
                                        }
                                    ]
                                },
                                {
                                    "text": "Post a job",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Service.com.au is Australia\u2019s leading platform for connecting anyone looking\nfor local trades and service providers, to top quality, verified, small to medium-sized\nservice businesses.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://www.service.com.au/about",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/about",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.service.com.au/privacy",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/privacy",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://www.service.com.au/terms",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/terms",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "List Your Business",
                                    "url": "https://www.service.com.au/why-us",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/why-us",
                                            "anchor_text": "List Your Business"
                                        }
                                    ]
                                },
                                {
                                    "text": "How It Works",
                                    "url": "https://www.service.com.au/how-it-works",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/how-it-works",
                                            "anchor_text": "How It Works"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get The App",
                                    "url": "https://www.service.com.au/app",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/app",
                                            "anchor_text": "Get The App"
                                        }
                                    ]
                                },
                                {
                                    "text": "\u00a9 2026 Service.com.au",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Find trusted and local Roofing in Cabarita",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Looking for a roofer that meets or exceeds your needs doesn\u2019t have to be a difficult task. Service.com.au is the perfect tool to match you with a premier roofing specialist in Cabarita, NSW. If you need someone who\u2019s dedicated to completing your job to the highest of standards, the local roofers on our site are committed to doing just that. Request a quote and let these skilled professionals tender for your project today. Extra perks include:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Make the right choice",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Find the perfect roofing team at Service.com.au from amongst the best your location has to offer. It\u2019s as simple as entering your location and your project requirements, then sitting back and waiting for some of the best roofers to quote you for your next project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Comfortable living",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Old ineffective roofing can cause your home to be too hot or too cold. A roof reno will help you dramatically increase the comfort and aesthetics of your building.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quality processes",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "You can be sure that all the roofers listed on our platform are subjected to quality checks and you can confirm this by all the positive customer feedback they\u2019ve received.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing\nin Cabarita",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roofing by state",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing by suburb",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "List your business for free",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Have your own roofing business?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Be found online and start receiving qualified leads today.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Choose the business that suits you",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free to use with no obligation to hire",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Dawes Point",
                                        "url": "https://www.service.com.au/find/roofing/dawes-point-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/dawes-point-nsw",
                                                "anchor_text": "Dawes Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Forest Lodge",
                                        "url": "https://www.service.com.au/find/roofing/forest-lodge-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/forest-lodge-nsw",
                                                "anchor_text": "Forest Lodge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Get multiple quotes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "3 step verification process",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Find trusted and local Roofing in Cabarita",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Looking for a roofer that meets or exceeds your needs doesn\u2019t have to be a difficult task. Service.com.au is the perfect tool to match you with a premier roofing specialist in Cabarita, NSW. If you need someone who\u2019s dedicated to completing your job to the highest of standards, the local roofers on our site are committed to doing just that. Request a quote and let these skilled professionals tender for your project today. Extra perks include:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Make the right choice",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Find the perfect roofing team at Service.com.au from amongst the best your location has to offer. It\u2019s as simple as entering your location and your project requirements, then sitting back and waiting for some of the best roofers to quote you for your next project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Improved efficiency",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Upgrading your outdated roofing enhances functionality and energy efficiency, resulting in long-term cost savings and environmental benefits. A must for this day and age!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Comfortable living",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Old ineffective roofing can cause your home to be too hot or too cold. A roof reno will help you dramatically increase the comfort and aesthetics of your building.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quality processes",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "You can be sure that all the roofers listed on our platform are subjected to quality checks and you can confirm this by all the positive customer feedback they\u2019ve received.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing\nin Cabarita",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Average rating\nof 4.83",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Canada Bay",
                                        "url": "https://www.service.com.au/find/roofing/canada-bay-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/canada-bay-nsw",
                                                "anchor_text": "Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Top 10 results for Roofing in Cabarita",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Millmans Plumbing",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Millmans Plumbing has been proudly serving the Sydney community for over 20 years. Founded by Joh",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Millmans Plumbing",
                                        "url": "https://www.service.com.au/listing/bathroom-renovations-ashbury-2193-nsw-point-plumbing-pty-ltd-emergency-plumber-gas-fitting?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/bathroom-renovations-ashbury-2193-nsw-point-plumbing-pty-ltd-emergency-plumber-gas-fitting?rc=Roofing",
                                                "anchor_text": "Millmans Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "16km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pacific Building Services",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "High-quality, affordable Painting/Building repairs solutions.\nAustraliawide Painters",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pacific Building Services",
                                        "url": "https://www.service.com.au/listing/painter-north-sydney-2060-nsw-australia-wide-painters?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/painter-north-sydney-2060-nsw-australia-wide-painters?rc=Roofing",
                                                "anchor_text": "Pacific Building Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "9km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofers Pty ltd",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We are expert in all type of roofing system and cladding\u00a0metal roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofers Pty ltd",
                                        "url": "https://www.service.com.au/listing/roof-repairs-plumpton-2761-nsw-commercial-roofers-pty-ltd?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/roof-repairs-plumpton-2761-nsw-commercial-roofers-pty-ltd?rc=Roofing",
                                                "anchor_text": "Commercial Roofers Pty ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "28km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "ABADI HOMES",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "ABADI HOMES is a construction company based in Sydney, Australia, specializing in decking and per",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "ABADI HOMES",
                                        "url": "https://www.service.com.au/listing/builders-seven-hills-2147-nsw-abadi-construction?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/builders-seven-hills-2147-nsw-abadi-construction?rc=Roofing",
                                                "anchor_text": "ABADI HOMES"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "19km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gorilla Projects",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Gorilla Projects is a Sydney-based building company specialising in residential, commercial, and",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gorilla Projects",
                                        "url": "https://www.service.com.au/listing/termites-sydney-2000-nsw-eradicate-pest-solutions?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/termites-sydney-2000-nsw-eradicate-pest-solutions?rc=Roofing",
                                                "anchor_text": "Gorilla Projects"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "2km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "TDE METAL ROOFING & CLADDING",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "ABN 21622503738TDE METAL ROOFING & CLADDING, we have extensive experience in re-roofin",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "TDE METAL ROOFING & CLADDING",
                                        "url": "https://www.service.com.au/listing/roofing-merrylands-west-2160-nsw-tde-metal-roofing-cladding?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/roofing-merrylands-west-2160-nsw-tde-metal-roofing-cladding?rc=Roofing",
                                                "anchor_text": "TDE METAL ROOFING & CLADDING"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "12km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "MK Antoun Bathrooms Pty Ltd",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "With over 20 years of experience and a dynamic group of specialists",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "MK Antoun Bathrooms Pty Ltd",
                                        "url": "https://www.service.com.au/listing/bathroom-renovations-picnic-point-2213-nsw-m-k-antoun-bathrooms-pty-ltd?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/bathroom-renovations-picnic-point-2213-nsw-m-k-antoun-bathrooms-pty-ltd?rc=Roofing",
                                                "anchor_text": "MK Antoun Bathrooms Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "19km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "STAS CARPENTRY & BUILDING PTY LTD",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "STAS Carpentry offers a full range of carpentry and building services, handling projects from sta",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "STAS CARPENTRY & BUILDING PTY LTD",
                                        "url": "https://www.service.com.au/listing/carpenters-clemton-park-2206-nsw-stas-carpentry?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/carpenters-clemton-park-2206-nsw-stas-carpentry?rc=Roofing",
                                                "anchor_text": "STAS CARPENTRY & BUILDING PTY LTD"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "9km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Apex Roofing",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Apex Roofing: Trusted Roofing Solutions\n- Expertise Professional roofing services for r",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Apex Roofing",
                                        "url": "https://www.service.com.au/listing/roofing-ipswich-4305-qld-apex-roofing?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/roofing-ipswich-4305-qld-apex-roofing?rc=Roofing",
                                                "anchor_text": "Apex Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "9km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Master painting & landscaping services",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "sydney RELIABLESmart luxury renovations\u00a0HO",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Master painting & landscaping services",
                                        "url": "https://www.service.com.au/listing/retaining-walls-narre-warren-3805-vic-ds-rubbish-removal?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/retaining-walls-narre-warren-3805-vic-ds-rubbish-removal?rc=Roofing",
                                                "anchor_text": "Master painting & landscaping services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "17km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Improved efficiency",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Upgrading your outdated roofing enhances functionality and energy efficiency, resulting in long-term cost savings and environmental benefits. A must for this day and age!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Find trusted and local Roofing in Cabarita",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Average reviews for Roofing in Cabarita",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Based on 536 reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Recommended for you",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Read the article",
                                        "url": "https://www.service.com.au/articles/business/airtasker-alternatives-tradie-jobs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/business/airtasker-alternatives-tradie-jobs",
                                                "anchor_text": "Read the article"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Airtasker alternatives: finding the right platform for tradie jobs",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Airtasker alternatives: finding the right platform for tradie jobs",
                                        "url": "https://www.service.com.au/articles/business/airtasker-alternatives-tradie-jobs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/business/airtasker-alternatives-tradie-jobs",
                                                "anchor_text": "Airtasker alternatives: finding the right platform for tradie jobs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georgia Budden",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "09 Sep 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Read the article",
                                        "url": "https://www.service.com.au/articles/swimming-pools/how-much-does-a-pool-cost",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/swimming-pools/how-much-does-a-pool-cost",
                                                "anchor_text": "Read the article"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How Much Does a Pool Cost? 2025 Cost Guide",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How Much Does a Pool Cost? 2025 Cost Guide",
                                        "url": "https://www.service.com.au/articles/swimming-pools/how-much-does-a-pool-cost",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/swimming-pools/how-much-does-a-pool-cost",
                                                "anchor_text": "How Much Does a Pool Cost? 2025 Cost Guide"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Jared Jeffery",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "11 Feb 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Read the article",
                                        "url": "https://www.service.com.au/articles/general/how-much-does-asbestos-removal-cost",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/general/how-much-does-asbestos-removal-cost",
                                                "anchor_text": "Read the article"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How Much Does Asbestos Removal Cost? 2025 Cost Guide",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How Much Does Asbestos Removal Cost? 2025 Cost Guide",
                                        "url": "https://www.service.com.au/articles/general/how-much-does-asbestos-removal-cost",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/general/how-much-does-asbestos-removal-cost",
                                                "anchor_text": "How Much Does Asbestos Removal Cost? 2025 Cost Guide"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Shreya Kulkarni",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "09 Feb 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse Roofing by State",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing in QLD",
                                        "url": "https://www.service.com.au/find/roofing/qld/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/qld/suburbs",
                                                "anchor_text": "Roofing in QLD"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in VIC",
                                        "url": "https://www.service.com.au/find/roofing/vic/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/vic/suburbs",
                                                "anchor_text": "Roofing in VIC"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in ACT",
                                        "url": "https://www.service.com.au/find/roofing/act/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/act/suburbs",
                                                "anchor_text": "Roofing in ACT"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in NSW",
                                        "url": "https://www.service.com.au/find/roofing/nsw/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/nsw/suburbs",
                                                "anchor_text": "Roofing in NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in WA",
                                        "url": "https://www.service.com.au/find/roofing/wa/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/wa/suburbs",
                                                "anchor_text": "Roofing in WA"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in TAS",
                                        "url": "https://www.service.com.au/find/roofing/tas/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/tas/suburbs",
                                                "anchor_text": "Roofing in TAS"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in SA",
                                        "url": "https://www.service.com.au/find/roofing/sa/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/sa/suburbs",
                                                "anchor_text": "Roofing in SA"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in NT",
                                        "url": "https://www.service.com.au/find/roofing/nt/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/nt/suburbs",
                                                "anchor_text": "Roofing in NT"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse Roofing by City",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing in Darwin",
                                        "url": "https://www.service.com.au/find/roofing/darwin-nt",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/darwin-nt",
                                                "anchor_text": "Roofing in Darwin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Sydney",
                                        "url": "https://www.service.com.au/find/roofing/sydney-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/sydney-nsw",
                                                "anchor_text": "Roofing in Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Canberra",
                                        "url": "https://www.service.com.au/find/roofing/canberra-act",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/canberra-act",
                                                "anchor_text": "Roofing in Canberra"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Perth",
                                        "url": "https://www.service.com.au/find/roofing/perth-wa",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/perth-wa",
                                                "anchor_text": "Roofing in Perth"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Melbourne",
                                        "url": "https://www.service.com.au/find/roofing/melbourne-vic",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/melbourne-vic",
                                                "anchor_text": "Roofing in Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Brisbane",
                                        "url": "https://www.service.com.au/find/roofing/brisbane-qld",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/brisbane-qld",
                                                "anchor_text": "Roofing in Brisbane"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Adelaide",
                                        "url": "https://www.service.com.au/find/roofing/adelaide-sa",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/adelaide-sa",
                                                "anchor_text": "Roofing in Adelaide"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Hobart",
                                        "url": "https://www.service.com.au/find/roofing/hobart-tas",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/hobart-tas",
                                                "anchor_text": "Roofing in Hobart"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse Roofing by Region",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing in Dawes Point",
                                        "url": "https://www.service.com.au/find/roofing/dawes-point-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/dawes-point-nsw",
                                                "anchor_text": "Roofing in Dawes Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Broadway",
                                        "url": "https://www.service.com.au/find/roofing/broadway-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/broadway-nsw",
                                                "anchor_text": "Roofing in Broadway"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Chippendale",
                                        "url": "https://www.service.com.au/find/roofing/chippendale-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/chippendale-nsw",
                                                "anchor_text": "Roofing in Chippendale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Pyrmont",
                                        "url": "https://www.service.com.au/find/roofing/pyrmont-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/pyrmont-nsw",
                                                "anchor_text": "Roofing in Pyrmont"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Alexandria",
                                        "url": "https://www.service.com.au/find/roofing/alexandria-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/alexandria-nsw",
                                                "anchor_text": "Roofing in Alexandria"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Redfern",
                                        "url": "https://www.service.com.au/find/roofing/redfern-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/redfern-nsw",
                                                "anchor_text": "Roofing in Redfern"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Forest Lodge",
                                        "url": "https://www.service.com.au/find/roofing/forest-lodge-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/forest-lodge-nsw",
                                                "anchor_text": "Roofing in Forest Lodge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Annandale",
                                        "url": "https://www.service.com.au/find/roofing/annandale-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/annandale-nsw",
                                                "anchor_text": "Roofing in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Rozelle",
                                        "url": "https://www.service.com.au/find/roofing/rozelle-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/rozelle-nsw",
                                                "anchor_text": "Roofing in Rozelle"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Leichhardt",
                                        "url": "https://www.service.com.au/find/roofing/leichhardt-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/leichhardt-nsw",
                                                "anchor_text": "Roofing in Leichhardt"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Related categories",
                                "main_title": "Roofing\nin Cabarita",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Painters in QLD",
                                        "url": "https://www.service.com.au/find/painters/qld/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/painters/qld/suburbs",
                                                "anchor_text": "Painters in QLD"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electricians in VIC",
                                        "url": "https://www.service.com.au/find/electrician/vic/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/electrician/vic/suburbs",
                                                "anchor_text": "Electricians in VIC"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Plumbers in ACT",
                                        "url": "https://www.service.com.au/find/plumbers-gasfitters/act/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/plumbers-gasfitters/act/suburbs",
                                                "anchor_text": "Plumbers in ACT"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Carpenters in NSW",
                                        "url": "https://www.service.com.au/find/carpenters/nsw/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/carpenters/nsw/suburbs",
                                                "anchor_text": "Carpenters in NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gardeners in WA",
                                        "url": "https://www.service.com.au/find/gardeners/wa/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/gardeners/wa/suburbs",
                                                "anchor_text": "Gardeners in WA"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in TAS",
                                        "url": "https://www.service.com.au/find/roofing/tas/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/tas/suburbs",
                                                "anchor_text": "Roofing in TAS"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Painters in SA",
                                        "url": "https://www.service.com.au/find/painters/sa/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/painters/sa/suburbs",
                                                "anchor_text": "Painters in SA"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electricians in NT",
                                        "url": "https://www.service.com.au/find/electrician/nt/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/electrician/nt/suburbs",
                                                "anchor_text": "Electricians in NT"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.83,
                                "max_rating_value": 5,
                                "rating_count": 536,
                                "relative_rating": 0.966
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}