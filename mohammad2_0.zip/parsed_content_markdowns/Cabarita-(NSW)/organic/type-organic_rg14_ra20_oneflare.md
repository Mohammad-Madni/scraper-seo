{
    "id": "01190728-1132-0216-0000-8f322476afa5",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0316 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.oneflare.com.au/roofing/nsw/cabarita-beach",
        "target": "www.oneflare.com.au",
        "start_url": "https://www.oneflare.com.au/roofing/nsw/cabarita-beach",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Cabarita-(NSW)\\organic\\type-organic_rg14_ra20_oneflare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:29 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Best roofing experts in Cabarita Beach",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Post a job now to get quotes from local roofing experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cabarita Beach",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average rating of roofing experts in Cabarita Beach based on 103 reviews of 22 businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oneflare /",
                                        "url": "https://www.oneflare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/",
                                                "anchor_text": "Oneflare"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Categories /",
                                        "url": "https://www.oneflare.com.au/directory",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/directory",
                                                "anchor_text": "Categories"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.oneflare.com.au/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NSW /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw",
                                                "anchor_text": "NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Coastal Metal Roofing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Kingscliff, NSW (5.8km from Kingscliff)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Coastal Metal Roofing is a family owned business, servicing the Gold Coast and Northern NSW for all your roofing and guttering repairs. Some of the services that we provide are include:\nMetal Roofing Repairs\nRe-roof\nNew roof\nGuttering repairs & maintenance\nGutter installation\nWhirlybird installations\nRoof leak repair\nDownpipes Tile repairs\nEmergency call outs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Coastal Metal Roofing",
                                        "url": "https://www.oneflare.com.au/b/coastal-metal-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/coastal-metal-roofing",
                                                "anchor_text": "Coastal Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Jelcon Sheds & Roofing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Pottsville, NSW (6.0km from Pottsville)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "JELCON is a family-owned and operated business that has proudly been servicing the Tweed Heads and Northern Rivers regions for over 15 years. We design, supply, and install a wide range of high-quality sheds and roofs for your commercial, residential & farm needs.\nDon't hesitate to contact us to see how we can help get your projects underway.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Jelcon Sheds & Roofing",
                                        "url": "https://www.oneflare.com.au/b/jelcon-sheds-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/jelcon-sheds-roofing",
                                                "anchor_text": "Jelcon Sheds & Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Richard Smythe Plumbing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Kingscliff, NSW (8.2km from Kingscliff)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Richard Smythe Plumbing is a friendly plumbing business with 12 years experience that can cater for all your commercial and domestic plumbing needs. We cover all aspects of plumbing from repairing leaks, installation of new rainwater tanks, hot water heaters, thermostatic mixing valves to backflow prevention devices. Our professional and courteous service ensures you that all our work is completed to the highest standard at affordable rates. Call us now for a Free quotation, no job is too small!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Richard Smythe Plumbing",
                                        "url": "https://www.oneflare.com.au/b/richard-smythe-plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/richard-smythe-plumbing",
                                                "anchor_text": "Richard Smythe Plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Montys Metal Roofing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ocean Shores, NSW (19.8km from Ocean Shores)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We specialise in Metal Roofing, Guttering , Downpipes, Fascia, Skylights, Whirlybirds, Patios, Leaf Guard, New and Repairs. Domestic, Industrial and Commercial no job to big or to small.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Montys Metal Roofing",
                                        "url": "https://www.oneflare.com.au/b/montys-metal-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/montys-metal-roofing",
                                                "anchor_text": "Montys Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "RidgeyDidge Roof Plumbing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Banora Point, NSW (13.3km from Banora Point)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Your fully licensed local bloke with 10+ yrs experience in roofing & plumbing . New roofs, re-roofs and roof & gutter repairs, & general plumbing services! Call today to arrange a free quote!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "RidgeyDidge Roof Plumbing",
                                        "url": "https://www.oneflare.com.au/b/ridgeydidge-roof-plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/ridgeydidge-roof-plumbing",
                                                "anchor_text": "RidgeyDidge Roof Plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Border Metal Roofing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tweed Heads, NSW (18.0km from Tweed Heads)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Border Metal Roofing is an Australian owned, family run company specialising in all your roofing needs. We have vast experience in completing all residential roofing jobs and dealing with all materials.\nBorder Metal Roofing specialises in all aspects of re-roofing & new roofing and have been offering professional services to homeowners and builders alike. No job is too big or too small, from guttering jobs, complete re-roofing of existing homes to new roofing of new homes.\nOUR EXPERIENCE\nBorder Metal Roofing is a company made up of dedicated & experienced people and along with good customer service, quality workmanship, quality materials & competitive prices, we will make your roofing experience a pleasant experience.\nBorder Metal Roofing has 25 years experience",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Border Metal Roofing",
                                        "url": "https://www.oneflare.com.au/b/border-metal-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/border-metal-roofing",
                                                "anchor_text": "Border Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tru Coat Roofing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tweed Heads, NSW (18.0km from Tweed Heads)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "TrueCoat Roofing is a premier painting and roofing contractor specializing in house painting, residential interior and industrial exterior painting as well as roof coating, sealing and water damage repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tru Coat Roofing",
                                        "url": "https://www.oneflare.com.au/b/tony-k-roof-painting",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/tony-k-roof-painting",
                                                "anchor_text": "Tru Coat Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Lee Meehan Roofing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tweed Heads, NSW (18.0km from Tweed Heads)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The Biggest Little Roofing Company on the Gold Coast!\nWith our Zero Defect Policy and personal service we are THE go to metal roofing company on the Gold Coast for builders, developers and homeowners!\nLMR COMMERCIAL\nLMR has a reputation for taking on architecturally challenging projects. Our commercial sector caters for large builders and their roofing needs meeting key milestones on time and on budget.\nLMR RESIDENTIAL\nLMR's domestic housing sector gives each and every homeowner a very personal touch when choosing your new roof, with all the colours, profiles and systems available. We also ensure you receive your new Bluescope Warranty and provide you with detailed information on how to prolong the life of your roof.\nOTHER SERVICES\nWe",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Lee Meehan Roofing",
                                        "url": "https://www.oneflare.com.au/b/lee-meehan-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/lee-meehan-roofing",
                                                "anchor_text": "Lee Meehan Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Reliance Roof Restoration",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Bilambil Heights, NSW (16.7km from Bilambil Heights)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Reliance Roof Restoration can restore your roof back to its former glory with a quality roof restoration. Or maybe you need a re-roof, Or maybe repair from a leaking roof. From re-points to full roof restoration, we do all of that plus more. with over 25 years of experience in the roofing industry we are your local experts.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Reliance Roof Restoration",
                                        "url": "https://www.oneflare.com.au/b/reliance-roof-restoration-702",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/reliance-roof-restoration-702",
                                                "anchor_text": "Reliance Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Clear Sky Roofing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Palm Beach, QLD (26.9km from Palm Beach)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clear Sky Roofing is a Queensland based company providing quality roofing services for your home.\nWe can help with any job, big or small.\nProvide all aspects of Roofing, Guttering Patios, Carports and anything Roof related.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Clear Sky Roofing",
                                        "url": "https://www.oneflare.com.au/b/clear-sky-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/clear-sky-roofing",
                                                "anchor_text": "Clear Sky Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Coast2 Coast Metal Roofing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Currumbin Valley, QLD (22.8km from Currumbin Valley)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Coast2Coast Metal Roofing are an exceptional roofing firm who provide first class workmanship and customer service.Metal Roofing Specialists. Over 20 years experience. Servicing Gold Coast Southport Currumbin Tweed Byron Bay We specialise in metal re-roofing, asbetos removal, new homes and existing homes, battens and we clean up our site and remove rubish.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Coast2 Coast Metal Roofing",
                                        "url": "https://www.oneflare.com.au/b/coast2-coast-metal-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/coast2-coast-metal-roofing",
                                                "anchor_text": "Coast2 Coast Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Northern Rivers Metal Roofing pty ltd",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Byron Bay, NSW (34.2km from Byron Bay)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully licensed & insured Metal Roofing company Specialising in \u2022 Re- Roofs & New roof installation \u2022 guttering & downpipes & gutterguard \u2022 20 years experience \u2022 professional company \u2022 great service & efficient Covering the northern rivers area ( Grafton to Gold Coast ) Contact Luke on : 0415 065 780 ABN 11 627 618 633 Northern rivers metal roofing PTY Ltd .",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Northern Rivers Metal Roofing pty ltd",
                                        "url": "https://www.oneflare.com.au/b/northern-rivers-metal-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/northern-rivers-metal-roofing",
                                                "anchor_text": "Northern Rivers Metal Roofing pty ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Rain Safe Roofing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tweed Heads South, NSW (15.5km from Tweed Heads South)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With over 25 years experience in happy to look after all your roofing needs, from general maintenance and repairs to new roofs re-roofs. Regarding repair work I generally do all the work myself, I can guarantee a high quality standard and I'm not looking to over charge anyone, I enjoy my work and all ways happy to help.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Rain Safe Roofing",
                                        "url": "https://www.oneflare.com.au/b/rain-safe-roofing-606",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/rain-safe-roofing-606",
                                                "anchor_text": "Rain Safe Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Shaw Trade Services",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burleigh Heads, QLD (29.3km from Burleigh Heads)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Shaw Trade Services offers a professional and friendly service to ensure a high quality of service for our customers. Our services include the following:\n-Roofing\n-Guttering\n-Rendering\n-Roof painting\n-High pressure cleaning\n-Roof restoration & repair -Plastering\n-Interior and exterior painting\nPlease contact us today if you have any questions!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Shaw Trade Services",
                                        "url": "https://www.oneflare.com.au/b/shaw-trade-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/shaw-trade-services",
                                                "anchor_text": "Shaw Trade Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Techo Roof Plumbing",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Varsity Lakes, QLD (31.9km from Varsity Lakes)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Techo prides it's self in knowing we are offering extremely high standards in the roof plumbing industry. If your looking to have your job done right the first time,we are the business for you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Techo Roof Plumbing",
                                        "url": "https://www.oneflare.com.au/b/techo-roof-plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/techo-roof-plumbing",
                                                "anchor_text": "Techo Roof Plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "First Response 24/7",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burleigh Heads, QLD (29.3km from Burleigh Heads)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof roof restoration, roof repairs, gutter cleaning.\nI specialise in all aspects of roofing.\nThe company are skilled, professional and extremely reliable providing the very best roofing services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "First Response 24/7",
                                        "url": "https://www.oneflare.com.au/b/first-response-24-7",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/first-response-24-7",
                                                "anchor_text": "First Response 24/7"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tuct Verified Business",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burleigh Heads, QLD (29.7km from Burleigh Heads)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Finding Quality Tradies For Homeowners\nIf you\u2019re looking to make a home improvement, let Trades U Can Trust find you a tradie team to get the job done quickly and effectively. We have the highest reviewed tradies in your local area and put them in touch with you to help you complete any kind of renovation on your home.\nWe take the stress out of the hiring process. We\u2019ll organise, follow up, obtain a competitive quote and actually get the tradie to show up on time!\nWe keep business dollars going strong in your community by only connecting you with skilled tradies who have been recommended by locals for locals\nWe\u2019re a 5 star company with exceptional customer service to",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tuct Verified Business",
                                        "url": "https://www.oneflare.com.au/b/trades-u-can-trust",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/trades-u-can-trust",
                                                "anchor_text": "Tuct"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "TLP EMERGENCY PLUMBING",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Varsity Lakes, QLD (32.3km from Varsity Lakes)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24/7 plumber/drainer/roofer/gasfitter (maintenance & tree lopping)\n- blocked drains\n- roof leaks\n- water leaks\n- tap/toilet servicing\n- hot water heaters\nTLP EMERGENCY PLUMBING offer a range of plumbing services including plumbing repairs, maintenance and installations.\nWe ensure that all aspects of plumbing work is completed to the highest standard at affordable rates.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "TLP EMERGENCY PLUMBING",
                                        "url": "https://www.oneflare.com.au/b/tuggerah-lakes-plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/tuggerah-lakes-plumbing",
                                                "anchor_text": "TLP EMERGENCY PLUMBING"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get the right price for your job",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Oneflare Cost Guide Centre is your one-stop shop to help you set your budget; from smaller tasks to larger projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Top Cabarita Beach roofing experts near you",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Browse top Roofing Expert experts with top ratings and reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best roofing experts in Cabarita Beach",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "View more roofing experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Truss costs",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Truss costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Roof Truss costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $9,000 - $15,000",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Average price $9,000 - $15,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof costs",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roof costs",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Colorbond Roof costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $15,000 - $25,000",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Average price $15,000 - $25,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling costs",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Roof Tiling costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $35 - $140 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Average price $35 - $140 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing costs",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing costs",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Roofing costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $45 - $90 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Average price $45 - $90 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse roofing experts by suburb",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular searches on Oneflare",
                                "main_title": "Best roofing experts in Cabarita Beach",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.7,
                                "max_rating_value": 5,
                                "rating_count": 103,
                                "relative_rating": 0.9400000000000001
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}