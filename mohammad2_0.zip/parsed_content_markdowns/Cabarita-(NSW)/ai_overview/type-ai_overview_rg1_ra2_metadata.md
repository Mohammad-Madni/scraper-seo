# Type: ai_overview | Rank: 2 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "2",
    "service": "roofer",
    "suburb": "Cabarita (NSW)",
    "title": "",
    "domain": "",
    "url": "",
    "description": "",
    "type": "ai_overview"
}