# Type: knowledge_graph | Rank: 3 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "3",
    "service": "roofer",
    "suburb": "Cabarita (NSW)",
    "title": "iRoof",
    "domain": "",
    "url": "",
    "description": "",
    "type": "knowledge_graph"
}