{
    "id": "01190728-1132-0216-0000-0f6b990f184c",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0282 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.wsggroup.com.au/roofing/carlingford/",
        "target": "www.wsggroup.com.au",
        "start_url": "https://www.wsggroup.com.au/roofing/carlingford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg12_ra16_wsggroup.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:46 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Roofing Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Hot Water System Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Your Local Service Provider",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Your Local Service Provider",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Your Local Service Provider",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Your Local Service Provider",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Your Local Service Provider",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roofing Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Hot Water System Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Your Local Service Provider",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Your Local Service Provider",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Your Local Service Provider",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Your Local Service Provider",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Your Local Service Provider",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Google Rating",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Open 24/7",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Hot Water",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/",
                                            "anchor_text": "Hot Water"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/",
                                            "anchor_text": "Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Services",
                                    "url": "https://www.wsggroup.com.au/electrical-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/",
                                            "anchor_text": "Electrical Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/",
                                            "anchor_text": "Roofing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water System Services",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/",
                                            "anchor_text": "Hot Water System Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Services",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/",
                                            "anchor_text": "Blocked Drains Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumbing Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "24/7 Emergency Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                            "anchor_text": "24/7 Emergency Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tap and Sink",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                            "anchor_text": "Tap and Sink"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Plumbing",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                            "anchor_text": "Toilet Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Backflow Prevention",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                            "anchor_text": "Backflow Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Leak Detection and Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                            "anchor_text": "Gas Leak Detection and Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Showers",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                            "anchor_text": "Leaking Showers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Burst Pipe Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                            "anchor_text": "Burst Pipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water Leak Detection and Repair",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                            "anchor_text": "Water Leak Detection and Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                            "anchor_text": "Gas Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Electrical Fault Finding",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                            "anchor_text": "Electrical Fault Finding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Rewire",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                            "anchor_text": "Electrical Rewire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Safety Switches Installation and Upgrade",
                                    "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                            "anchor_text": "Safety Switches Installation and Upgrade"
                                        }
                                    ]
                                },
                                {
                                    "text": "SwitchBoard Upgrades",
                                    "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                            "anchor_text": "SwitchBoard Upgrades"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ceiling Fans Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                            "anchor_text": "Ceiling Fans Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Smoke Detectors",
                                    "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                            "anchor_text": "Smoke Detectors"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Electrical Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                            "anchor_text": "24/7 Electrical Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Power Point Installation",
                                    "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                            "anchor_text": "Power Point Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surge Protector Installations Services",
                                    "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                            "anchor_text": "Surge Protector Installations Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lighting Electrician",
                                    "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                            "anchor_text": "Lighting Electrician"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                            "anchor_text": "Emergency Roof Repairs Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection and Repair Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                            "anchor_text": "Roof Leak Detection and Repair Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning and Vacuuming",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                            "anchor_text": "Gutter Cleaning and Vacuuming"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipe Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                            "anchor_text": "Gutters and Downpipe Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                            "anchor_text": "Gas Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electric Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                            "anchor_text": "Electric Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Hot Water Services",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                            "anchor_text": "Emergency Hot Water Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Storm Water Drain",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                            "anchor_text": "Storm Water Drain"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspection",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                            "anchor_text": "CCTV Drain Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sewer Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                            "anchor_text": "Sewer Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "High-Pressure Water Jetting",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                            "anchor_text": "High-Pressure Water Jetting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen And Sink Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                            "anchor_text": "Kitchen And Sink Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet and Bathroom Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                            "anchor_text": "Toilet and Bathroom Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tree Root Removal and Prevention",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                            "anchor_text": "Tree Root Removal and Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/",
                                            "anchor_text": "Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Emergency Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                            "anchor_text": "24/7 Emergency Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water Leak Detection and Repair",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                            "anchor_text": "Water Leak Detection and Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tap and Sink",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                            "anchor_text": "Tap and Sink"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Plumbing",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                            "anchor_text": "Toilet Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Backflow Prevention",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                            "anchor_text": "Backflow Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Leak Detection and Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                            "anchor_text": "Gas Leak Detection and Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Showers",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                            "anchor_text": "Leaking Showers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Burst Pipe Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                            "anchor_text": "Burst Pipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                            "anchor_text": "Gas Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Services",
                                    "url": "https://www.wsggroup.com.au/electrical-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/",
                                            "anchor_text": "Electrical Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Electrical Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                            "anchor_text": "24/7 Electrical Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Smoke Detectors",
                                    "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                            "anchor_text": "Smoke Detectors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ceiling Fans Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                            "anchor_text": "Ceiling Fans Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "SwitchBoard Upgrades",
                                    "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                            "anchor_text": "SwitchBoard Upgrades"
                                        }
                                    ]
                                },
                                {
                                    "text": "Safety Switches Installation and Upgrade",
                                    "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                            "anchor_text": "Safety Switches Installation and Upgrade"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Rewire",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                            "anchor_text": "Electrical Rewire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Fault Finding",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                            "anchor_text": "Electrical Fault Finding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Power Point Installation",
                                    "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                            "anchor_text": "Power Point Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surge Protector Installations Services",
                                    "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                            "anchor_text": "Surge Protector Installations Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lighting Electrician",
                                    "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                            "anchor_text": "Lighting Electrician"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/",
                                            "anchor_text": "Roofing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                            "anchor_text": "Emergency Roof Repairs Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection and Repair Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                            "anchor_text": "Roof Leak Detection and Repair Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning and Vacuuming",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                            "anchor_text": "Gutter Cleaning and Vacuuming"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipe Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                            "anchor_text": "Gutters and Downpipe Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water System Services",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/",
                                            "anchor_text": "Hot Water System Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                            "anchor_text": "Gas Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electric Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                            "anchor_text": "Electric Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Hot Water Services",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                            "anchor_text": "Emergency Hot Water Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Services",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/",
                                            "anchor_text": "Blocked Drains Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Water Drain",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                            "anchor_text": "Storm Water Drain"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspection",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                            "anchor_text": "CCTV Drain Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sewer Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                            "anchor_text": "Sewer Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "High-Pressure Water Jetting",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                            "anchor_text": "High-Pressure Water Jetting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen And Sink Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                            "anchor_text": "Kitchen And Sink Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet and Bathroom Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                            "anchor_text": "Toilet and Bathroom Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tree Root Removal and Prevention",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                            "anchor_text": "Tree Root Removal and Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water System",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Blocked Drains",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Killarney Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                            "anchor_text": "Killarney Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                            "anchor_text": "Umina Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy",
                                    "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                            "anchor_text": "Woy Woy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay\u200b",
                                    "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                            "anchor_text": "Bateau Bay\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy",
                                    "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                            "anchor_text": "Woy Woy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                            "anchor_text": "Umina Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                            "anchor_text": "Bateau Bay\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale\u200b\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale\u200b\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                            "anchor_text": "Killarney Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/roofing/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/roofing/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/roofing/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/roofing/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/roofing/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/roofing/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/roofing/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/roofing/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/roofing/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                            "anchor_text": "Umina Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy",
                                    "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                            "anchor_text": "Woy Woy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                            "anchor_text": "Killarney Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay\u200b",
                                    "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                            "anchor_text": "Bateau Bay\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy",
                                    "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                            "anchor_text": "Woy Woy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                            "anchor_text": "Bateau Bay\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                            "anchor_text": "Umina Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale\u200b\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale\u200b\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                            "anchor_text": "Killarney Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/roofing/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/roofing/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/roofing/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/roofing/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/roofing/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/roofing/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/roofing/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/roofing/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/roofing/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://www.wsggroup.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Projects",
                                    "url": "https://www.wsggroup.com.au/our-projects/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/our-projects/",
                                            "anchor_text": "Our Projects"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/",
                                            "anchor_text": "Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Services",
                                    "url": "https://www.wsggroup.com.au/electrical-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/",
                                            "anchor_text": "Electrical Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/",
                                            "anchor_text": "Roofing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water System Services",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/",
                                            "anchor_text": "Hot Water System Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Services",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/",
                                            "anchor_text": "Blocked Drains Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumbing Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "24/7 Emergency Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                            "anchor_text": "24/7 Emergency Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tap and Sink",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                            "anchor_text": "Tap and Sink"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Plumbing",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                            "anchor_text": "Toilet Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Backflow Prevention",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                            "anchor_text": "Backflow Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Leak Detection and Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                            "anchor_text": "Gas Leak Detection and Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Showers",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                            "anchor_text": "Leaking Showers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Burst Pipe Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                            "anchor_text": "Burst Pipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water Leak Detection and Repair",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                            "anchor_text": "Water Leak Detection and Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                            "anchor_text": "Gas Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Electrical Fault Finding",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                            "anchor_text": "Electrical Fault Finding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Rewire",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                            "anchor_text": "Electrical Rewire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Safety Switches Installation and Upgrade",
                                    "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                            "anchor_text": "Safety Switches Installation and Upgrade"
                                        }
                                    ]
                                },
                                {
                                    "text": "SwitchBoard Upgrades",
                                    "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                            "anchor_text": "SwitchBoard Upgrades"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ceiling Fans Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                            "anchor_text": "Ceiling Fans Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Smoke Detectors",
                                    "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                            "anchor_text": "Smoke Detectors"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Electrical Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                            "anchor_text": "24/7 Electrical Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Power Point Installation",
                                    "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                            "anchor_text": "Power Point Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surge Protector Installations Services",
                                    "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                            "anchor_text": "Surge Protector Installations Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lighting Electrician",
                                    "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                            "anchor_text": "Lighting Electrician"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                            "anchor_text": "Emergency Roof Repairs Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection and Repair Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                            "anchor_text": "Roof Leak Detection and Repair Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning and Vacuuming",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                            "anchor_text": "Gutter Cleaning and Vacuuming"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipe Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                            "anchor_text": "Gutters and Downpipe Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                            "anchor_text": "Gas Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electric Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                            "anchor_text": "Electric Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Hot Water Services",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                            "anchor_text": "Emergency Hot Water Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Storm Water Drain",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                            "anchor_text": "Storm Water Drain"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspection",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                            "anchor_text": "CCTV Drain Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sewer Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                            "anchor_text": "Sewer Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "High-Pressure Water Jetting",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                            "anchor_text": "High-Pressure Water Jetting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen And Sink Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                            "anchor_text": "Kitchen And Sink Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet and Bathroom Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                            "anchor_text": "Toilet and Bathroom Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tree Root Removal and Prevention",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                            "anchor_text": "Tree Root Removal and Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/",
                                            "anchor_text": "Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Emergency Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                            "anchor_text": "24/7 Emergency Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water Leak Detection and Repair",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                            "anchor_text": "Water Leak Detection and Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tap and Sink",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                            "anchor_text": "Tap and Sink"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Plumbing",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                            "anchor_text": "Toilet Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Backflow Prevention",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                            "anchor_text": "Backflow Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Leak Detection and Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                            "anchor_text": "Gas Leak Detection and Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Showers",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                            "anchor_text": "Leaking Showers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Burst Pipe Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                            "anchor_text": "Burst Pipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                            "anchor_text": "Gas Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Services",
                                    "url": "https://www.wsggroup.com.au/electrical-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/",
                                            "anchor_text": "Electrical Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Electrical Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                            "anchor_text": "24/7 Electrical Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Smoke Detectors",
                                    "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                            "anchor_text": "Smoke Detectors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ceiling Fans Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                            "anchor_text": "Ceiling Fans Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "SwitchBoard Upgrades",
                                    "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                            "anchor_text": "SwitchBoard Upgrades"
                                        }
                                    ]
                                },
                                {
                                    "text": "Safety Switches Installation and Upgrade",
                                    "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                            "anchor_text": "Safety Switches Installation and Upgrade"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Rewire",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                            "anchor_text": "Electrical Rewire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Fault Finding",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                            "anchor_text": "Electrical Fault Finding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Power Point Installation",
                                    "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                            "anchor_text": "Power Point Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surge Protector Installations Services",
                                    "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                            "anchor_text": "Surge Protector Installations Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lighting Electrician",
                                    "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                            "anchor_text": "Lighting Electrician"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/",
                                            "anchor_text": "Roofing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                            "anchor_text": "Emergency Roof Repairs Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection and Repair Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                            "anchor_text": "Roof Leak Detection and Repair Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning and Vacuuming",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                            "anchor_text": "Gutter Cleaning and Vacuuming"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipe Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                            "anchor_text": "Gutters and Downpipe Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water System Services",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/",
                                            "anchor_text": "Hot Water System Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                            "anchor_text": "Gas Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electric Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                            "anchor_text": "Electric Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Hot Water Services",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                            "anchor_text": "Emergency Hot Water Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Services",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/",
                                            "anchor_text": "Blocked Drains Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Water Drain",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                            "anchor_text": "Storm Water Drain"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspection",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                            "anchor_text": "CCTV Drain Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sewer Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                            "anchor_text": "Sewer Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "High-Pressure Water Jetting",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                            "anchor_text": "High-Pressure Water Jetting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen And Sink Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                            "anchor_text": "Kitchen And Sink Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet and Bathroom Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                            "anchor_text": "Toilet and Bathroom Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tree Root Removal and Prevention",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                            "anchor_text": "Tree Root Removal and Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water System",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Blocked Drains",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Killarney Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                            "anchor_text": "Killarney Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                            "anchor_text": "Umina Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy",
                                    "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                            "anchor_text": "Woy Woy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay\u200b",
                                    "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                            "anchor_text": "Bateau Bay\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy",
                                    "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                            "anchor_text": "Woy Woy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                            "anchor_text": "Umina Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                            "anchor_text": "Bateau Bay\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale\u200b\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale\u200b\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                            "anchor_text": "Killarney Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/roofing/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/roofing/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/roofing/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/roofing/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/roofing/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/roofing/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/roofing/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/roofing/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/roofing/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                            "anchor_text": "Umina Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy",
                                    "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                            "anchor_text": "Woy Woy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                            "anchor_text": "Killarney Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay\u200b",
                                    "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                            "anchor_text": "Bateau Bay\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy",
                                    "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                            "anchor_text": "Woy Woy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                            "anchor_text": "Bateau Bay\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                            "anchor_text": "Umina Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale\u200b\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale\u200b\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                            "anchor_text": "Killarney Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pearl Beach",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                            "anchor_text": "Pearl Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Entrance",
                                    "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                            "anchor_text": "The Entrance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Colah",
                                    "url": "https://www.wsggroup.com.au/roofing/mount-colah/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/mount-colah/",
                                            "anchor_text": "Mount Colah"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hornsby Heights",
                                    "url": "https://www.wsggroup.com.au/roofing/hornsby-heights/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/hornsby-heights/",
                                            "anchor_text": "Hornsby Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bateau Bay",
                                    "url": "https://www.wsggroup.com.au/roofing/bateau-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/bateau-bay/",
                                            "anchor_text": "Bateau Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "Umina Beach\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/umina-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/umina-beach/",
                                            "anchor_text": "Umina Beach\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pennant Hills",
                                    "url": "https://www.wsggroup.com.au/roofing/pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/pennant-hills/",
                                            "anchor_text": "Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hamlyn Terrace\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/hamlyn-terrace/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/hamlyn-terrace/",
                                            "anchor_text": "Hamlyn Terrace\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Berkeley Vale",
                                    "url": "https://www.wsggroup.com.au/roofing/berkeley-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/berkeley-vale/",
                                            "anchor_text": "Berkeley Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Woy Woy\u200b",
                                    "url": "https://www.wsggroup.com.au/roofing/woy-woy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/woy-woy/",
                                            "anchor_text": "Woy Woy\u200b"
                                        }
                                    ]
                                },
                                {
                                    "text": "Killarney Vale",
                                    "url": "https://www.wsggroup.com.au/roofing/killarney-vale/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/killarney-vale/",
                                            "anchor_text": "Killarney Vale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Avoca Beach",
                                    "url": "https://www.wsggroup.com.au/roofing/avoca-beach/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/avoca-beach/",
                                            "anchor_text": "Avoca Beach"
                                        }
                                    ]
                                },
                                {
                                    "text": "Green Point",
                                    "url": "https://www.wsggroup.com.au/roofing/green-point/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/green-point/",
                                            "anchor_text": "Green Point"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booker Bay",
                                    "url": "https://www.wsggroup.com.au/roofing/booker-bay/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/booker-bay/",
                                            "anchor_text": "Booker Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://www.wsggroup.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Projects",
                                    "url": "https://www.wsggroup.com.au/our-projects/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/our-projects/",
                                            "anchor_text": "Our Projects"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home - Roofing - Carlingford",
                                    "url": "https://www.wsggroup.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/",
                                            "anchor_text": "Home"
                                        },
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing/",
                                            "anchor_text": "Roofing"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "All right reserved. ABN 88 169 060 995.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "15 Koonora Ave, Blackwall NSW 2256, Australia",
                                    "url": "https://maps.app.goo.gl/5AsjRREmDfUTKJZX7",
                                    "urls": [
                                        {
                                            "url": "https://maps.app.goo.gl/5AsjRREmDfUTKJZX7",
                                            "anchor_text": "15 Koonora Ave, Blackwall NSW 2256, Australia"
                                        }
                                    ]
                                },
                                {
                                    "text": "Quick Links",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://www.wsggroup.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Projects",
                                    "url": "https://www.wsggroup.com.au/our-projects/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/our-projects/",
                                            "anchor_text": "Our Projects"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.wsggroup.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://www.wsggroup.com.au/terms-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/terms-conditions/",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://www.wsggroup.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Projects",
                                    "url": "https://www.wsggroup.com.au/our-projects/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/our-projects/",
                                            "anchor_text": "Our Projects"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.wsggroup.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://www.wsggroup.com.au/terms-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/terms-conditions/",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Emergency Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                            "anchor_text": "24/7 Emergency Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water Leak Detection and Repair",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                            "anchor_text": "Water Leak Detection and Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Plumbing",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                            "anchor_text": "Toilet Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tap and Sink",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                            "anchor_text": "Tap and Sink"
                                        }
                                    ]
                                },
                                {
                                    "text": "Backflow Prevention",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                            "anchor_text": "Backflow Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                            "anchor_text": "Gas Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Leak Detection and Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                            "anchor_text": "Gas Leak Detection and Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Burst Pipe Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                            "anchor_text": "Burst Pipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Showers",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                            "anchor_text": "Leaking Showers"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Emergency Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/24-7-emergency-plumbing-services/",
                                            "anchor_text": "24/7 Emergency Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water Leak Detection and Repair",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/water-leak-detection-and-repair/",
                                            "anchor_text": "Water Leak Detection and Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet Plumbing",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/toilet-plumbing/",
                                            "anchor_text": "Toilet Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tap and Sink",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/tap-and-sink/",
                                            "anchor_text": "Tap and Sink"
                                        }
                                    ]
                                },
                                {
                                    "text": "Backflow Prevention",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/backflow-prevention/",
                                            "anchor_text": "Backflow Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing Services",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-plumbing-services/",
                                            "anchor_text": "Gas Plumbing Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Leak Detection and Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/gas-leak-detection-and-repairs/",
                                            "anchor_text": "Gas Leak Detection and Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Burst Pipe Repairs",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/burst-pipe-repairs/",
                                            "anchor_text": "Burst Pipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Showers",
                                    "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/plumbing-services/leaking-showers/",
                                            "anchor_text": "Leaking Showers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Fault Finding",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                            "anchor_text": "Electrical Fault Finding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Safety Switches Installation and Upgrade",
                                    "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                            "anchor_text": "Safety Switches Installation and Upgrade"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Rewire",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                            "anchor_text": "Electrical Rewire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lighting Electrician",
                                    "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                            "anchor_text": "Lighting Electrician"
                                        }
                                    ]
                                },
                                {
                                    "text": "SwitchBoard Upgrades",
                                    "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                            "anchor_text": "SwitchBoard Upgrades"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ceiling Fans Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                            "anchor_text": "Ceiling Fans Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Smoke Detectors",
                                    "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                            "anchor_text": "Smoke Detectors"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Electrical Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                            "anchor_text": "24/7 Electrical Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surge Protector Installations Services",
                                    "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                            "anchor_text": "Surge Protector Installations Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Power Point Installation",
                                    "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                            "anchor_text": "Power Point Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Fault Finding",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-fault-finding/",
                                            "anchor_text": "Electrical Fault Finding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Safety Switches Installation and Upgrade",
                                    "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/safety-switches-installation-and-upgrade/",
                                            "anchor_text": "Safety Switches Installation and Upgrade"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electrical Rewire",
                                    "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/electrical-rewire/",
                                            "anchor_text": "Electrical Rewire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lighting Electrician",
                                    "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/lighting-electrician/",
                                            "anchor_text": "Lighting Electrician"
                                        }
                                    ]
                                },
                                {
                                    "text": "SwitchBoard Upgrades",
                                    "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/switchboard-upgrades/",
                                            "anchor_text": "SwitchBoard Upgrades"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ceiling Fans Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/ceiling-fans-service/",
                                            "anchor_text": "Ceiling Fans Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Smoke Detectors",
                                    "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/smoke-detectors/",
                                            "anchor_text": "Smoke Detectors"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Electrical Service",
                                    "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/24-7-electrical-service/",
                                            "anchor_text": "24/7 Electrical Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surge Protector Installations Services",
                                    "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/surge-protector-installations-services/",
                                            "anchor_text": "Surge Protector Installations Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Power Point Installation",
                                    "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/electrical-services/power-point-installation/",
                                            "anchor_text": "Power Point Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection and Repair Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                            "anchor_text": "Roof Leak Detection and Repair Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipe Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                            "anchor_text": "Gutters and Downpipe Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning and Vacuuming",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                            "anchor_text": "Gutter Cleaning and Vacuuming"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                            "anchor_text": "Emergency Roof Repairs Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection and Repair Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                            "anchor_text": "Roof Leak Detection and Repair Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipe Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                            "anchor_text": "Gutters and Downpipe Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning and Vacuuming",
                                    "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                            "anchor_text": "Gutter Cleaning and Vacuuming"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs Services",
                                    "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                            "anchor_text": "Emergency Roof Repairs Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Emergency Hot Water Services",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                            "anchor_text": "Emergency Hot Water Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                            "anchor_text": "Gas Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electric Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                            "anchor_text": "Electric Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Hot Water Services",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/emergency-hot-water-services/",
                                            "anchor_text": "Emergency Hot Water Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/gas-hot-water-repairs/",
                                            "anchor_text": "Gas Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Electric Hot Water Repairs",
                                    "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/hot-water-system-services/electric-hot-water-repairs/",
                                            "anchor_text": "Electric Hot Water Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "CCTV Drain Inspection",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                            "anchor_text": "CCTV Drain Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Water Drain",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                            "anchor_text": "Storm Water Drain"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sewer Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                            "anchor_text": "Sewer Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "High-Pressure Water Jetting",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                            "anchor_text": "High-Pressure Water Jetting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen And Sink Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                            "anchor_text": "Kitchen And Sink Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet and Bathroom Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                            "anchor_text": "Toilet and Bathroom Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tree Root Removal and Prevention",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                            "anchor_text": "Tree Root Removal and Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "CCTV Drain Inspection",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/cctv-drain-inspection/",
                                            "anchor_text": "CCTV Drain Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Water Drain",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/storm-water-drain/",
                                            "anchor_text": "Storm Water Drain"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sewer Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/sewer-drain-cleaning/",
                                            "anchor_text": "Sewer Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "High-Pressure Water Jetting",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/high-pressure-water-jetting/",
                                            "anchor_text": "High-Pressure Water Jetting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen And Sink Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/kitchen-and-sink-drain-cleaning/",
                                            "anchor_text": "Kitchen And Sink Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Toilet and Bathroom Drain Cleaning",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/toilet-and-bathroom-drain-cleaning/",
                                            "anchor_text": "Toilet and Bathroom Drain Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tree Root Removal and Prevention",
                                    "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/blocked-drains-services/tree-root-removal-and-prevention/",
                                            "anchor_text": "Tree Root Removal and Prevention"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copyright \u00a9 2026",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.wsggroup.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://www.wsggroup.com.au/terms-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://www.wsggroup.com.au/terms-conditions/",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "With over 70+ years of experience, WSG Group delivers quality roof repairs and expert roofing services across Carlingford.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaks, storm damage & roof maintenance covered",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Skilled local team with years of roofing experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get Your Instant Free Quote",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Services in Carlingford \u2013 Reliable, Fast & Local",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Protect your home or business with our professional roof repairs and maintenance services. From minor leaks to urgent storm damage, our skilled roofing team delivers fast, lasting solutions that keep your property safe and secure. Call us today and experience quality workmanship done right the first time!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019ve earned a strong reputation for providing affordable, high-quality roofing backed by friendly, reliable service. Every project is handled with care and attention to detail, ensuring durable results that stand the test of time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Emergency Roof Repairs Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Leak Detection and Repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Cleaning and Vacuuming",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutters and Downpipe Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We provide roofing services across Carlingford and the surrounding suburbs, and are trusted by local homeowners for our quality workmanship and reliable service.",
                                        "url": "https://www.wsggroup.com.au/roofing-services/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing-services/",
                                                "anchor_text": "roofing services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We offer:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What\u2019s the Process of Hiring a Roof Repair Specialist in Carlingford?",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our roof repair process is designed to be simple, clear, and stress-free. From the first call to the final check, we keep you informed and make sure the job is done right.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Here\u2019s how it works:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We begin with a thorough inspection to identify any issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You\u2019ll receive a clear, upfront quote with no hidden costs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repairs are scheduled at a time that suits you best.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our experienced team carries out the repairs with care and precision.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We finish with a final inspection to make sure you\u2019re happy with the result.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We make roof repairs straightforward and hassle-free, delivering reliable, honest, and high-quality service from start to finish.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roofing Services in Carlingford",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Had a big storm roll through or sudden bad weather left your roof damaged? When time is critical, our local team is here to help with fast and reliable emergency roof repairs across Carlingford \u2014 even on weekends and public holidays.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Immediate response for leaks and storm damage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Temporary fixes to prevent further issues",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Full assessments to identify and resolve underlying problems",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Support with insurance claims to make the process easier",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Unexpected roof damage puts your property at risk \u2014 but with our skilled team on the job, you\u2019ll have peace of mind knowing your roof is in safe hands.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Make an Online Enquiry or call us now on 1800 186 597",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We provide:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted Roofing Services in Carlingford",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Proudly serving the Carlingford community for years, we offer reliable roof repairs and maintenance tailored to your needs. Whether it\u2019s a minor fix or major repairs, our experienced team delivers quality workmanship to keep your home or business safe and secure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What to Look for in an Carlingford Roofer",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "It\u2019s important to understand how you can choose the right roofing contractor for your house. Let\u2019s see the top things you need to look for.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Experience That Counts: WSG Group has been in the industry since 1947, providing a variety of services to the Carlingford people.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local Knowledge: We understand the roofing needs of Carlingford homes, from storm-prone zones to older roof structures.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No Surprises: We offer transparent pricing, so you know what you\u2019re paying for. No hidden charges or surprises.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Proven Trust: Our happy customers in Carlingford rely on us. That\u2019s why we are rated 4.8 stars on Google ratings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation and Replacement in Carlingford",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Looking for professional roof installation or replacement services in Carlingford? Our experienced team provides high-quality roofing solutions tailored to your property\u2019s needs. Whether you\u2019re building a new home or replacing an ageing roof, we deliver expert workmanship using durable materials that stand up to Australian weather conditions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are committed to customer satisfaction and safety, ensuring every project is completed to the highest standards. Our fully licensed and insured team uses only the best materials, so you can trust us to keep your roof secure, functional, and looking great\u2014whether it\u2019s for repairs, maintenance, full roof replacements, or guttering services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our Roofing Solutions:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "New Roof Installations for Homes and Businesses",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Replacement for Damaged or Ageing Roofs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "High-Quality Materials and Modern Roofing Solutions",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast, Reliable, and Professional Service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Keep your property protected and looking its best with a roof built to last.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Killarney Vale",
                                        "url": "https://www.wsggroup.com.au/roofing/killarney-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/killarney-vale/",
                                                "anchor_text": "Killarney Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hamlyn Terrace\u200b",
                                        "url": "https://www.wsggroup.com.au/roofing/hamlyn-terrace/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/hamlyn-terrace/",
                                                "anchor_text": "Hamlyn Terrace\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avoca Beach",
                                        "url": "https://www.wsggroup.com.au/roofing/avoca-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/avoca-beach/",
                                                "anchor_text": "Avoca Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Booker Bay",
                                        "url": "https://www.wsggroup.com.au/roofing/booker-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/booker-bay/",
                                                "anchor_text": "Booker Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Point",
                                        "url": "https://www.wsggroup.com.au/roofing/green-point/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/green-point/",
                                                "anchor_text": "Green Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Colah",
                                        "url": "https://www.wsggroup.com.au/roofing/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/mount-colah/",
                                                "anchor_text": "Mount Colah"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hornsby Heights",
                                        "url": "https://www.wsggroup.com.au/roofing/hornsby-heights/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/hornsby-heights/",
                                                "anchor_text": "Hornsby Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://www.wsggroup.com.au/roofing/pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/pennant-hills/",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Umina Beach\u200b",
                                        "url": "https://www.wsggroup.com.au/roofing/umina-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/umina-beach/",
                                                "anchor_text": "Umina Beach\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bateau Bay",
                                        "url": "https://www.wsggroup.com.au/roofing/bateau-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/bateau-bay/",
                                                "anchor_text": "Bateau Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woy Woy\u200b",
                                        "url": "https://www.wsggroup.com.au/roofing/woy-woy/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/woy-woy/",
                                                "anchor_text": "Woy Woy\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berkeley Vale",
                                        "url": "https://www.wsggroup.com.au/roofing/berkeley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing/berkeley-vale/",
                                                "anchor_text": "Berkeley Vale"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Specialising in the Supply & Installation of Quality Roofing Solutions",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Protect your property with expert roofing that lasts. Get in touch today for a quote!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Happy Customers",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Thanks to WSG for sorting out our blockage problem in all three of our units. Very helpful and quick service, and advice. Would highly recommend them.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We love WSG. They\u2019re quick to respond, great to deal with. Hard recommend to anyone.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Very efficient team, good communication, punctual & responsive to requests. Thank you for your help.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jake from WSG found the leak that three different tradespeople from the insurer gave up on finding. He was very easy to communicate with, on time and actually identified the problem quickly which was fantastic.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A great and wonderful team",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fid their job well and gave me a brand new bedroom thanks &##x1f60a;",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Excellent professional, friendly and capable staff. Highly recommended for your maintenance needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I found them efficient & quick in attending our premises. Job was done well & as we expected.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Based on 46 reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "How do I know if my roof needs repairs or a full replacement?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Signs like frequent leaks, sagging areas, cracked or missing shingles, and extensive storm damage may indicate the need for a replacement. We\u2019re happy to assess your roof and recommend the best option.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you provide regular roof maintenance plans?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we offer scheduled roof maintenance services to help prevent costly repairs and extend the life of your roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Are your roofing services available for both residential and commercial properties?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we provide roofing solutions for both homes and commercial buildings, including offices, warehouses, and retail spaces.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Can you help improve my home\u2019s energy efficiency with roofing solutions?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. We can recommend roofing materials and solutions that help with insulation and reduce energy costs, keeping your home cooler in summer and warmer in winter.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How long does a typical roof repair or replacement take?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The timeline depends on the size and condition of the roof. Minor repairs can often be completed on the same day, while full roof replacements may take several days. We\u2019ll provide a clear timeframe after inspection.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Areas We Serve",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "WSG Group services Sydney Metro and the Central Coast, delivering trusted solutions for plumbing, electrical, roofing, hot water, and blocked drains to homes and businesses. With local teams and 24/7 support, we respond fast and get the job done right.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Mount Colah",
                                        "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                                "anchor_text": "Mount Colah"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hornsby Heights",
                                        "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                                "anchor_text": "Hornsby Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Umina Beach",
                                        "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                                "anchor_text": "Umina Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bateau Bay",
                                        "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                                "anchor_text": "Bateau Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woy Woy",
                                        "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                                "anchor_text": "Woy Woy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berkeley Vale",
                                        "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                                "anchor_text": "Berkeley Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hamlyn Terrace",
                                        "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                                "anchor_text": "Hamlyn Terrace"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Killarney Vale\u200b",
                                        "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                                "anchor_text": "Killarney Vale\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Booker Bay",
                                        "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                                "anchor_text": "Booker Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avoca Beach",
                                        "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                                "anchor_text": "Avoca Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Entrance",
                                        "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                                "anchor_text": "The Entrance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pearl Beach",
                                        "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                                "anchor_text": "Pearl Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Point",
                                        "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                                "anchor_text": "Green Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Colah",
                                        "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/mount-colah/",
                                                "anchor_text": "Mount Colah"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hornsby Heights",
                                        "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/hornsby-heights/",
                                                "anchor_text": "Hornsby Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/pennant-hills/",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Umina Beach",
                                        "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/umina-beach/",
                                                "anchor_text": "Umina Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bateau Bay",
                                        "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/bateau-bay/",
                                                "anchor_text": "Bateau Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woy Woy",
                                        "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/woy-woy/",
                                                "anchor_text": "Woy Woy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berkeley Vale",
                                        "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/berkeley-vale/",
                                                "anchor_text": "Berkeley Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hamlyn Terrace",
                                        "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/hamlyn-terrace/",
                                                "anchor_text": "Hamlyn Terrace"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Killarney Vale\u200b",
                                        "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/killarney-vale/",
                                                "anchor_text": "Killarney Vale\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Booker Bay",
                                        "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/booker-bay/",
                                                "anchor_text": "Booker Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avoca Beach",
                                        "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/avoca-beach/",
                                                "anchor_text": "Avoca Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Entrance",
                                        "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/the-entrance/",
                                                "anchor_text": "The Entrance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pearl Beach",
                                        "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/pearl-beach/",
                                                "anchor_text": "Pearl Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Point",
                                        "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/plumbing/green-point/",
                                                "anchor_text": "Green Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Colah",
                                        "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                                "anchor_text": "Mount Colah"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hornsby Heights",
                                        "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                                "anchor_text": "Hornsby Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Umina Beach\u200b",
                                        "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                                "anchor_text": "Umina Beach\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bateau Bay\u200b",
                                        "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                                "anchor_text": "Bateau Bay\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woy Woy",
                                        "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                                "anchor_text": "Woy Woy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berkeley Vale",
                                        "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                                "anchor_text": "Berkeley Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hamlyn Terrace",
                                        "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                                "anchor_text": "Hamlyn Terrace"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Killarney Vale",
                                        "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                                "anchor_text": "Killarney Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Booker Bay",
                                        "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                                "anchor_text": "Booker Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avoca Beach",
                                        "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                                "anchor_text": "Avoca Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Entrance",
                                        "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                                "anchor_text": "The Entrance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pearl Beach",
                                        "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                                "anchor_text": "Pearl Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Point",
                                        "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                                "anchor_text": "Green Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Colah",
                                        "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/mount-colah/",
                                                "anchor_text": "Mount Colah"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hornsby Heights",
                                        "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/hornsby-heights/",
                                                "anchor_text": "Hornsby Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/pennant-hills/",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Umina Beach\u200b",
                                        "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/umina-beach/",
                                                "anchor_text": "Umina Beach\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bateau Bay\u200b",
                                        "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/bateau-bay/",
                                                "anchor_text": "Bateau Bay\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woy Woy",
                                        "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/woy-woy/",
                                                "anchor_text": "Woy Woy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berkeley Vale",
                                        "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/berkeley-vale/",
                                                "anchor_text": "Berkeley Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hamlyn Terrace",
                                        "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/hamlyn-terrace/",
                                                "anchor_text": "Hamlyn Terrace"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Killarney Vale",
                                        "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/killarney-vale/",
                                                "anchor_text": "Killarney Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Booker Bay",
                                        "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/booker-bay/",
                                                "anchor_text": "Booker Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avoca Beach",
                                        "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/avoca-beach/",
                                                "anchor_text": "Avoca Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Entrance",
                                        "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/the-entrance/",
                                                "anchor_text": "The Entrance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pearl Beach",
                                        "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/pearl-beach/",
                                                "anchor_text": "Pearl Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Point",
                                        "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/electrical/green-point/",
                                                "anchor_text": "Green Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Colah",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                                "anchor_text": "Mount Colah"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hornsby Heights",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                                "anchor_text": "Hornsby Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bateau Bay\u200b",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                                "anchor_text": "Bateau Bay\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Umina Beach",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                                "anchor_text": "Umina Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hamlyn Terrace",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                                "anchor_text": "Hamlyn Terrace"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berkeley Vale\u200b\u200b",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                                "anchor_text": "Berkeley Vale\u200b\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woy Woy\u200b",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                                "anchor_text": "Woy Woy\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Killarney Vale",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                                "anchor_text": "Killarney Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Booker Bay",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                                "anchor_text": "Booker Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avoca Beach",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                                "anchor_text": "Avoca Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Entrance",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                                "anchor_text": "The Entrance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pearl Beach",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                                "anchor_text": "Pearl Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Point",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                                "anchor_text": "Green Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Colah",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/mount-colah/",
                                                "anchor_text": "Mount Colah"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hornsby Heights",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/hornsby-heights/",
                                                "anchor_text": "Hornsby Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bateau Bay\u200b",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/bateau-bay/",
                                                "anchor_text": "Bateau Bay\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Umina Beach",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/umina-beach/",
                                                "anchor_text": "Umina Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/pennant-hills/",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hamlyn Terrace",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/hamlyn-terrace/",
                                                "anchor_text": "Hamlyn Terrace"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berkeley Vale\u200b\u200b",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/berkeley-vale/",
                                                "anchor_text": "Berkeley Vale\u200b\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woy Woy\u200b",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/woy-woy/",
                                                "anchor_text": "Woy Woy\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Killarney Vale",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/killarney-vale/",
                                                "anchor_text": "Killarney Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Booker Bay",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/booker-bay/",
                                                "anchor_text": "Booker Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avoca Beach",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/avoca-beach/",
                                                "anchor_text": "Avoca Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Entrance",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/the-entrance/",
                                                "anchor_text": "The Entrance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pearl Beach",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/pearl-beach/",
                                                "anchor_text": "Pearl Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Point",
                                        "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/hot-water-system/green-point/",
                                                "anchor_text": "Green Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Colah",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                                "anchor_text": "Mount Colah"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hornsby Heights",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                                "anchor_text": "Hornsby Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Umina Beach\u200b",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                                "anchor_text": "Umina Beach\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bateau Bay",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                                "anchor_text": "Bateau Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hamlyn Terrace\u200b",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                                "anchor_text": "Hamlyn Terrace\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berkeley Vale\u200b",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                                "anchor_text": "Berkeley Vale\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woy Woy\u200b",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                                "anchor_text": "Woy Woy\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Killarney Vale\u200b",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                                "anchor_text": "Killarney Vale\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Booker Bay",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                                "anchor_text": "Booker Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avoca Beach",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                                "anchor_text": "Avoca Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Point",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                                "anchor_text": "Green Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pearl Beach",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                                "anchor_text": "Pearl Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Entrance",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                                "anchor_text": "The Entrance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Colah",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/mount-colah/",
                                                "anchor_text": "Mount Colah"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hornsby Heights",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/hornsby-heights/",
                                                "anchor_text": "Hornsby Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Umina Beach\u200b",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/umina-beach/",
                                                "anchor_text": "Umina Beach\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/pennant-hills/",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bateau Bay",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/bateau-bay/",
                                                "anchor_text": "Bateau Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hamlyn Terrace\u200b",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/hamlyn-terrace/",
                                                "anchor_text": "Hamlyn Terrace\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berkeley Vale\u200b",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/berkeley-vale/",
                                                "anchor_text": "Berkeley Vale\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woy Woy\u200b",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/woy-woy/",
                                                "anchor_text": "Woy Woy\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Killarney Vale\u200b",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/killarney-vale/",
                                                "anchor_text": "Killarney Vale\u200b"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Booker Bay",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/booker-bay/",
                                                "anchor_text": "Booker Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avoca Beach",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/avoca-beach/",
                                                "anchor_text": "Avoca Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Point",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/green-point/",
                                                "anchor_text": "Green Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pearl Beach",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/pearl-beach/",
                                                "anchor_text": "Pearl Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Entrance",
                                        "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/blocked-drains/the-entrance/",
                                                "anchor_text": "The Entrance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Emergency Roof Repairs Services",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Emergency Roof Repairs Services",
                                        "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing-services/emergency-roof-repairs-services/",
                                                "anchor_text": "Emergency Roof Repairs Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak Detection and Repair",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leak Detection and Repair",
                                        "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing-services/roof-leak-detection-and-repair-services/",
                                                "anchor_text": "Roof Leak Detection and Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Cleaning and Vacuuming",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter Cleaning and Vacuuming",
                                        "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing-services/gutter-cleaning-and-vacuuming-services/",
                                                "anchor_text": "Gutter Cleaning and Vacuuming"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters and Downpipe Services",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutters and Downpipe Services",
                                        "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                        "urls": [
                                            {
                                                "url": "https://www.wsggroup.com.au/roofing-services/gutters-and-downpipe-services/",
                                                "anchor_text": "Gutters and Downpipe Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Book Your Local Roofing Expert Today - Fast, Reliable, and Affordable",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get In Touch",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Location",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "15 Koonora Ave Blackwall NSW 2256",
                                        "url": "https://maps.app.goo.gl/5AsjRREmDfUTKJZX7",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/5AsjRREmDfUTKJZX7",
                                                "anchor_text": "15 Koonora Ave Blackwall NSW 2256"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Details",
                                "main_title": "Looking for a Trusted Roofing Professional in Carlingford",
                                "author": "WSG Group",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "1800 186 597 | Email Us",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "1800186597"
                            ],
                            "emails": [
                                "info@wsggroup.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}