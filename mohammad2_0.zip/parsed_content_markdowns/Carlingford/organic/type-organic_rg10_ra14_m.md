{
    "id": "01190728-1132-0216-0000-c8f3e0027903",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0136 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://m.yelp.com/search?cflt=roofing&find_loc=Carlingford+New+South+Wales",
        "target": "m.yelp.com",
        "start_url": "https://m.yelp.com/search?cflt=roofing&find_loc=Carlingford+New+South+Wales",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg10_ra14_m.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 0,
            "items": null
        }
    ]
}