{
    "id": "01190728-1132-0216-0000-ac2f4a24de97",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0212 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://thehillsdistrictroofers.com.au/roofers-carlingford/",
        "target": "thehillsdistrictroofers.com.au",
        "start_url": "https://thehillsdistrictroofers.com.au/roofers-carlingford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg8_ra11_thehillsdistrictroofers.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:44 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://thehillsdistrictroofers.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Annangrove",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-annangrove/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-annangrove/",
                                            "anchor_text": "Roofers Annangrove"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Baulkham Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-baulkham-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-baulkham-hills/",
                                            "anchor_text": "Roofers Baulkham Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Bella Vista",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-bella-vista/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-bella-vista/",
                                            "anchor_text": "Roofers Bella Vista"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Beaumont Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-beaumont-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-beaumont-hills/",
                                            "anchor_text": "Roofers Beaumont Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Box Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-box-hill/",
                                            "anchor_text": "Roofers Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Castle Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-castle-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-castle-hill/",
                                            "anchor_text": "Roofers Castle Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Carlingford",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-carlingford/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-carlingford/",
                                            "anchor_text": "Roofers Carlingford"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Cherrybrook",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-cherrybrook/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-cherrybrook/",
                                            "anchor_text": "Roofers Cherrybrook"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Dural",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-dural/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-dural/",
                                            "anchor_text": "Roofers Dural"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Glenorie",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-glenorie/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-glenorie/",
                                            "anchor_text": "Roofers Glenorie"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Glenhaven",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-glenhaven/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-glenhaven/",
                                            "anchor_text": "Roofers Glenhaven"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Kellyville",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-kellyville/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-kellyville/",
                                            "anchor_text": "Roofers Kellyville"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Kenthurst",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-kenthurst/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-kenthurst/",
                                            "anchor_text": "Roofers Kenthurst"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Nelson",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-nelson/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-nelson/",
                                            "anchor_text": "Roofers Nelson"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North Kellyville",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-north-kellyville/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-north-kellyville/",
                                            "anchor_text": "Roofers North Kellyville"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North Rocks",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-north-rocks/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-north-rocks/",
                                            "anchor_text": "Roofers North Rocks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Norwest",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-norwest/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-norwest/",
                                            "anchor_text": "Roofers Norwest"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Rouse Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-rouse-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-rouse-hill/",
                                            "anchor_text": "Roofers Rouse Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers West Pennant Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-west-pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-west-pennant-hills/",
                                            "anchor_text": "Roofers West Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Winston Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-winston-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-winston-hills/",
                                            "anchor_text": "Roofers Winston Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://thehillsdistrictroofers.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://thehillsdistrictroofers.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Annangrove",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-annangrove/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-annangrove/",
                                            "anchor_text": "Roofers Annangrove"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Baulkham Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-baulkham-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-baulkham-hills/",
                                            "anchor_text": "Roofers Baulkham Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Bella Vista",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-bella-vista/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-bella-vista/",
                                            "anchor_text": "Roofers Bella Vista"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Beaumont Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-beaumont-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-beaumont-hills/",
                                            "anchor_text": "Roofers Beaumont Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Box Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-box-hill/",
                                            "anchor_text": "Roofers Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Castle Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-castle-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-castle-hill/",
                                            "anchor_text": "Roofers Castle Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Carlingford",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-carlingford/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-carlingford/",
                                            "anchor_text": "Roofers Carlingford"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Cherrybrook",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-cherrybrook/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-cherrybrook/",
                                            "anchor_text": "Roofers Cherrybrook"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Dural",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-dural/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-dural/",
                                            "anchor_text": "Roofers Dural"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Glenorie",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-glenorie/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-glenorie/",
                                            "anchor_text": "Roofers Glenorie"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Glenhaven",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-glenhaven/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-glenhaven/",
                                            "anchor_text": "Roofers Glenhaven"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Kellyville",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-kellyville/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-kellyville/",
                                            "anchor_text": "Roofers Kellyville"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Kenthurst",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-kenthurst/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-kenthurst/",
                                            "anchor_text": "Roofers Kenthurst"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Nelson",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-nelson/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-nelson/",
                                            "anchor_text": "Roofers Nelson"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North Kellyville",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-north-kellyville/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-north-kellyville/",
                                            "anchor_text": "Roofers North Kellyville"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North Rocks",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-north-rocks/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-north-rocks/",
                                            "anchor_text": "Roofers North Rocks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Norwest",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-norwest/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-norwest/",
                                            "anchor_text": "Roofers Norwest"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Rouse Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-rouse-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-rouse-hill/",
                                            "anchor_text": "Roofers Rouse Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers West Pennant Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-west-pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-west-pennant-hills/",
                                            "anchor_text": "Roofers West Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Winston Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-winston-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-winston-hills/",
                                            "anchor_text": "Roofers Winston Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://thehillsdistrictroofers.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://thehillsdistrictroofers.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Annangrove",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-annangrove/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-annangrove/",
                                            "anchor_text": "Roofers Annangrove"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Baulkham Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-baulkham-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-baulkham-hills/",
                                            "anchor_text": "Roofers Baulkham Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Bella Vista",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-bella-vista/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-bella-vista/",
                                            "anchor_text": "Roofers Bella Vista"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Beaumont Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-beaumont-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-beaumont-hills/",
                                            "anchor_text": "Roofers Beaumont Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Box Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-box-hill/",
                                            "anchor_text": "Roofers Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Castle Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-castle-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-castle-hill/",
                                            "anchor_text": "Roofers Castle Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Carlingford",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-carlingford/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-carlingford/",
                                            "anchor_text": "Roofers Carlingford"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Cherrybrook",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-cherrybrook/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-cherrybrook/",
                                            "anchor_text": "Roofers Cherrybrook"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Dural",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-dural/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-dural/",
                                            "anchor_text": "Roofers Dural"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Glenorie",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-glenorie/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-glenorie/",
                                            "anchor_text": "Roofers Glenorie"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Glenhaven",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-glenhaven/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-glenhaven/",
                                            "anchor_text": "Roofers Glenhaven"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Kellyville",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-kellyville/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-kellyville/",
                                            "anchor_text": "Roofers Kellyville"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Kenthurst",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-kenthurst/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-kenthurst/",
                                            "anchor_text": "Roofers Kenthurst"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Nelson",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-nelson/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-nelson/",
                                            "anchor_text": "Roofers Nelson"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North Kellyville",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-north-kellyville/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-north-kellyville/",
                                            "anchor_text": "Roofers North Kellyville"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North Rocks",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-north-rocks/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-north-rocks/",
                                            "anchor_text": "Roofers North Rocks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Norwest",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-norwest/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-norwest/",
                                            "anchor_text": "Roofers Norwest"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Rouse Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-rouse-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-rouse-hill/",
                                            "anchor_text": "Roofers Rouse Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers West Pennant Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-west-pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-west-pennant-hills/",
                                            "anchor_text": "Roofers West Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Winston Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-winston-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-winston-hills/",
                                            "anchor_text": "Roofers Winston Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://thehillsdistrictroofers.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repair",
                                    "url": "https://thehillsdistrictroofers.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Annangrove",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-annangrove/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-annangrove/",
                                            "anchor_text": "Roofers Annangrove"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Baulkham Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-baulkham-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-baulkham-hills/",
                                            "anchor_text": "Roofers Baulkham Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Bella Vista",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-bella-vista/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-bella-vista/",
                                            "anchor_text": "Roofers Bella Vista"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Beaumont Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-beaumont-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-beaumont-hills/",
                                            "anchor_text": "Roofers Beaumont Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Box Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-box-hill/",
                                            "anchor_text": "Roofers Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Castle Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-castle-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-castle-hill/",
                                            "anchor_text": "Roofers Castle Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Carlingford",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-carlingford/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-carlingford/",
                                            "anchor_text": "Roofers Carlingford"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Cherrybrook",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-cherrybrook/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-cherrybrook/",
                                            "anchor_text": "Roofers Cherrybrook"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Dural",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-dural/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-dural/",
                                            "anchor_text": "Roofers Dural"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Glenorie",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-glenorie/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-glenorie/",
                                            "anchor_text": "Roofers Glenorie"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Glenhaven",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-glenhaven/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-glenhaven/",
                                            "anchor_text": "Roofers Glenhaven"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Kellyville",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-kellyville/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-kellyville/",
                                            "anchor_text": "Roofers Kellyville"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Kenthurst",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-kenthurst/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-kenthurst/",
                                            "anchor_text": "Roofers Kenthurst"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Nelson",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-nelson/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-nelson/",
                                            "anchor_text": "Roofers Nelson"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North Kellyville",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-north-kellyville/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-north-kellyville/",
                                            "anchor_text": "Roofers North Kellyville"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North Rocks",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-north-rocks/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-north-rocks/",
                                            "anchor_text": "Roofers North Rocks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Norwest",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-norwest/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-norwest/",
                                            "anchor_text": "Roofers Norwest"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Rouse Hill",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-rouse-hill/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-rouse-hill/",
                                            "anchor_text": "Roofers Rouse Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers West Pennant Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-west-pennant-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-west-pennant-hills/",
                                            "anchor_text": "Roofers West Pennant Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Winston Hills",
                                    "url": "https://thehillsdistrictroofers.com.au/roofers-winston-hills/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roofers-winston-hills/",
                                            "anchor_text": "Roofers Winston Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://thehillsdistrictroofers.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "This site puts you in touch with trusted roofing contractors who specialise in metal and tile roofing across residential and commercial projects. The contractors we work with take pride in their workmanship and stand behind every job with a workmanship warranty. We\u2019re here to help you find someone who gets the job done right. This website is owned and operated by Client Connect Australia Pty Ltd.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright \u00a9 2025 THE HILLS DISTRICT ROOFERS",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://thehillsdistrictroofers.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://thehillsdistrictroofers.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms and Conditions",
                                    "url": "https://thehillsdistrictroofers.com.au/terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Baulkham Hills NSW 2153",
                                    "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/about-us/",
                                            "anchor_text": "Baulkham Hills NSW 2153"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repairs",
                                    "url": "https://thehillsdistrictroofers.com.au/skylight-repair/",
                                    "urls": [
                                        {
                                            "url": "https://thehillsdistrictroofers.com.au/skylight-repair/",
                                            "anchor_text": "Skylight Repairs"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Understanding Carlingford\u2019s Roofing Environment",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Carlingford features a mix of older brick homes and modern estates. Many properties in the area face the challenges of seasonal storms and intense summer sun, which can gradually wear down roofing materials.",
                                        "url": "https://en.wikipedia.org/wiki/Carlingford,_New_South_Wales",
                                        "urls": [
                                            {
                                                "url": "https://en.wikipedia.org/wiki/Carlingford,_New_South_Wales",
                                                "anchor_text": "Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The suburb\u2019s leafy streets add another factor, as falling leaves and debris can accumulate on roofs and in gutters, increasing the risk of blockages and water damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofs in Carlingford also need to withstand heavy rainfall, occasional hail, and strong westerly winds. These local conditions make regular inspections and maintenance essential for protecting your home.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our roofing services are specifically designed to address these challenges. By using quality materials and expert techniques, we help extend the lifespan of your roof while keeping your property safe and weather-ready.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professional Roofing Services for Baulkham Hills Properties",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Whether your property overlooks the Canterbury Bowling Club or you\u2019re near the retail hub around Stockland Baulkham Hills, our comprehensive roofing services protect what matters most to you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Protect your home with our residential roofing solutions. We work with terracotta and concrete tiles, Colorbond metal roofing, and other materials common in Carlingford homes. Our team provides repairs, new installations, and roof restoration services to keep your roof secure and looking its best.",
                                        "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/residential-roofing/",
                                                "anchor_text": "residential roofing"
                                            },
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                                "anchor_text": "roof restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We also manage challenges posed by large trees and overhanging branches, ensuring moss, leaf litter, and potential damage are addressed effectively.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Carlingford is home to offices, retail shops, and medical centres that require reliable roofing. Our commercial roofing services cover installations, repairs, and preventative maintenance with minimal disruption to your operations. All work complies with Australian building standards and is carried out efficiently.",
                                        "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/commercial-roofing/",
                                                "anchor_text": "commercial roofing"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs That Last",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Carlingford roofs face weather extremes, from hot summers to heavy storms. Our roof repairs cover:",
                                        "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roof-repairs/",
                                                "anchor_text": "roof repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cracked or displaced tiles due to heat or wind",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Damaged ridge capping and valley irons",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Moss and debris removal to prevent leaks",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs \u2013 Available 24/7",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Severe storms can strike without warning. Our emergency roof repairs team responds rapidly to secure properties, repair leaks, and manage storm damage throughout Carlingford.",
                                        "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                                "anchor_text": "emergency roof repairs"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professional Roof Installation",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Planning a new build or full roof replacement? Our roof installation service ensures your roof meets Australian standards and complements your property\u2019s architecture. We account for orientation, tree coverage, and sun exposure to recommend the best roofing solution.",
                                        "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roof-installation/",
                                                "anchor_text": "roof installation"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Services",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Many Carlingford homes are now decades old. Our roof restoration extends the life of your roof by:",
                                        "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roof-restoration/",
                                                "anchor_text": "roof restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cleaning and repairing tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Re-bedding and repointing ridge capping",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacing worn valley irons",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "This process adds 10\u201315 years to your roof\u2019s lifespan while boosting your home\u2019s value.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Applying protective coatings",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance Programs",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roof maintenance programs include gutter cleaning, tile inspection, and valley clearing. Regular maintenance prevents minor issues from becoming costly repairs, especially in tree-lined areas or near bush reserves.",
                                        "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roof-maintenance/",
                                                "anchor_text": "roof maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Thorough Roof Inspections",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Buying or selling in Carlingford? Our roof inspections provide detailed reports on:",
                                        "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roof-inspection/",
                                                "anchor_text": "roof inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We deliver honest assessments with photographic evidence. Free inspections are available contact us today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Structural integrity",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tile condition",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sarking and flashings",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Potential issues",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "contact us today",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Cleaning Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Repair and Maintenance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Skylight Repair and Installation",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Carlingford roofs are prone to leaf, moss, and lichen buildup. Our roof cleaning services safely remove debris, prevent pooling, and restore your roof\u2019s appearance, particularly for shaded areas or homes with northern aspects.",
                                        "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roof-cleaning/",
                                                "anchor_text": "roof cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Expert Roof Painting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Refresh and protect your home with our roof painting service. Using premium Australian paints formulated for Sydney\u2019s climate, roof painting helps protect against UV damage and enhances property aesthetics.",
                                        "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roof-painting/",
                                                "anchor_text": "roof painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our gutter repair service ensures rainwater flows correctly, preventing foundation damage and soil erosion. We also recommend gutter guard systems to reduce leaf blockages common in Carlingford.",
                                        "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/gutter-repair/",
                                                "anchor_text": "gutter repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Many Carlingford homes feature skylights for natural light. Our skylight repairs address cracked domes, failed seals, and flashing leaks, while new installations enhance interiors with quality Australian products.",
                                        "url": "https://thehillsdistrictroofers.com.au/skylight-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/skylight-repairs/",
                                                "anchor_text": "skylight repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose The Hills District Roofers in Carlingford?",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Deep Local Knowledge: Hundreds of roofs completed in Carlingford, from Pennant Hills Road to North Rocks.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Heritage Awareness: Respecting older home styles while ensuring modern performance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality Australian Workmanship: All work meets Australian Standards with high-quality materials.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully Licensed and Insured: Compliant with NSW regulations and OH&S requirements.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent Service: Honest assessments, clear quotes, and no hidden costs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free Quotes and Inspections: Available for all Carlingford properties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Servicing All of Carlingford",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Carlingford Court and surrounding retail areas",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Properties near Carlingford Village and Pennant Hills Road",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Schools, commercial premises, and local parks",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Our team services every part of Carlingford:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Established residential streets",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We also cover nearby Hills District suburbs, including:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofers Baulkham Hills",
                                        "url": "https://thehillsdistrictroofers.com.au/roofers-baulkham-hills/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roofers-baulkham-hills/",
                                                "anchor_text": "Roofers Baulkham Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers Bella Vista",
                                        "url": "https://thehillsdistrictroofers.com.au/roofers-bella-vista/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roofers-bella-vista/",
                                                "anchor_text": "Roofers Bella Vista"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers Beaumont Hills",
                                        "url": "https://thehillsdistrictroofers.com.au/roofers-beaumont-hills/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roofers-beaumont-hills/",
                                                "anchor_text": "Roofers Beaumont Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers Box Hill",
                                        "url": "https://thehillsdistrictroofers.com.au/roofers-box-hill/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roofers-box-hill/",
                                                "anchor_text": "Roofers Box Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers Castle Hill",
                                        "url": "https://thehillsdistrictroofers.com.au/roofers-castle-hill/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roofers-castle-hill/",
                                                "anchor_text": "Roofers Castle Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers Kellyville",
                                        "url": "https://thehillsdistrictroofers.com.au/roofers-kellyville/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roofers-kellyville/",
                                                "anchor_text": "Roofers Kellyville"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers North Kellyville",
                                        "url": "https://thehillsdistrictroofers.com.au/roofers-north-kellyville/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roofers-north-kellyville/",
                                                "anchor_text": "Roofers North Kellyville"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers Rouse Hill",
                                        "url": "https://thehillsdistrictroofers.com.au/roofers-rouse-hill/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roofers-rouse-hill/",
                                                "anchor_text": "Roofers Rouse Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers West Pennant Hills",
                                        "url": "https://thehillsdistrictroofers.com.au/roofers-west-pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roofers-west-pennant-hills/",
                                                "anchor_text": "Roofers West Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers Winston Hills",
                                        "url": "https://thehillsdistrictroofers.com.au/roofers-winston-hills/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/roofers-winston-hills/",
                                                "anchor_text": "Roofers Winston Hills"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Costs vary depending on materials, roof size, and damage. We provide free inspections and detailed quotes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Annual inspections are recommended, with twice-yearly checks for homes near bushland or trees.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, our 24/7 emergency roof repair service is available for sudden leaks and storm damage.",
                                        "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/emergency-roof-repairs/",
                                                "anchor_text": "emergency roof repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terracotta, Colorbond, and concrete tiles all perform well. We advise based on property style and budget.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Minor repairs usually don\u2019t. For full replacements, we can guide you through council approval processes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get Your Free Roofing Quote Today",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Don\u2019t let small roofing issues turn into costly repairs. Contact The Hills District Roofers today for a free, no-obligation quote and roof inspection. Whether you need emergency repairs, routine maintenance, or a complete roof replacement, our professional team is ready to assist.",
                                        "url": "https://thehillsdistrictroofers.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/",
                                                "anchor_text": "The Hills District Roofers"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofers Carlingford",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Local Roofing Experts You Can Rely On",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted Roofers Carlingford",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Looking for dependable roofing services in Carlingford? The Hills District Roofers provide professional workmanship for homes and businesses across the suburb. From emergency repairs to full roof restorations, our team delivers reliable solutions tailored to Carlingford\u2019s unique properties.",
                                        "url": "https://thehillsdistrictroofers.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://thehillsdistrictroofers.com.au/",
                                                "anchor_text": "The Hills District Roofers"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We service properties from the busy Carlingford Court and surrounding shopping areas to quiet residential streets and local schools. Our local knowledge ensures fast response times and roofing solutions that meet the challenges of this well-established Hills District suburb.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Range of Roofing Services",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Don't Hesitate To Call Us!",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "(02) 8503 9976",
                                "main_title": "Roofers Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0285039976"
                            ],
                            "emails": [
                                "info@thehillsdistrictroofers.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}