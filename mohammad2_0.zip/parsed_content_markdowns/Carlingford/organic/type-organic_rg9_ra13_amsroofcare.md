{
    "id": "01190728-1132-0216-0000-8352323e1463",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0113 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.amsroofcare.com.au/roofing-carlingford/",
        "target": "www.amsroofcare.com.au",
        "start_url": "https://www.amsroofcare.com.au/roofing-carlingford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg9_ra13_amsroofcare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:47 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration Sydney",
                                    "url": "https://www.amsroofcare.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "High Pressure Roof Cleaning",
                                    "url": "https://www.amsroofcare.com.au/high-pressure-roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/high-pressure-roof-cleaning/",
                                            "anchor_text": "High Pressure Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://www.amsroofcare.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painters",
                                    "url": "https://www.amsroofcare.com.au/roof-painters/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-painters/",
                                            "anchor_text": "Roof Painters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.amsroofcare.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Service",
                                    "url": "https://www.amsroofcare.com.au/gutter-cleaning-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/gutter-cleaning-service/",
                                            "anchor_text": "Gutter Cleaning Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://www.amsroofcare.com.au/gutter-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/gutter-repairs/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Driveway Cleaning",
                                    "url": "https://www.amsroofcare.com.au/driveway-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/driveway-cleaning/",
                                            "anchor_text": "Driveway Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Driveway Painters",
                                    "url": "https://www.amsroofcare.com.au/driveway-painters/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/driveway-painters/",
                                            "anchor_text": "Driveway Painters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://www.amsroofcare.com.au/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://www.amsroofcare.com.au/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://www.amsroofcare.com.au/skylight-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/skylight-installation-sydney/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Laserlite Polycarbonate Roofing",
                                    "url": "https://www.amsroofcare.com.au/laserlite-polycarbonate-roofing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/laserlite-polycarbonate-roofing-sydney/",
                                            "anchor_text": "Laserlite Polycarbonate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tile Clipping",
                                    "url": "https://www.amsroofcare.com.au/clip-replacement-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/clip-replacement-sydney/",
                                            "anchor_text": "Roof Tile Clipping"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Valley",
                                    "url": "https://www.amsroofcare.com.au/roof-valley-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-valley-sydney/",
                                            "anchor_text": "Roof Valley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://www.amsroofcare.com.au/roof-ventilation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-ventilation-sydney/",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Waterproofing",
                                    "url": "https://www.amsroofcare.com.au/roof-waterproofing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-waterproofing-sydney/",
                                            "anchor_text": "Roof Waterproofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Bedding & Pointing",
                                    "url": "https://www.amsroofcare.com.au/roof-bedding-pointing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-bedding-pointing-sydney/",
                                            "anchor_text": "Roof Bedding & Pointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Extension",
                                    "url": "https://www.amsroofcare.com.au/roof-extension-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-extension-sydney/",
                                            "anchor_text": "Roof Extension"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing Sydney",
                                    "url": "https://www.amsroofcare.com.au/roof-flashing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-flashing-sydney/",
                                            "anchor_text": "Roof Flashing Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Insulation Sydney",
                                    "url": "https://www.amsroofcare.com.au/roof-insulation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.amsroofcare.com.au/roof-insulation-sydney/",
                                            "anchor_text": "Roof Insulation Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "0415 999 919",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Sydney Wide",
                                    "url": "https://goo.gl/maps/G5GEB7fcFKGdSQnk9",
                                    "urls": [
                                        {
                                            "url": "https://goo.gl/maps/G5GEB7fcFKGdSQnk9",
                                            "anchor_text": "Sydney Wide"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copyright \u00a9 2024 AMS Care Roof. All Rights Reserved | Design by Nextweb",
                                    "url": "http://nextweb.com.au/",
                                    "urls": [
                                        {
                                            "url": "http://nextweb.com.au/",
                                            "anchor_text": "Copyright \u00a9 2024 AMS Care Roof. All Rights Reserved | Design by Nextweb"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "AMS Roof Care: Your Roofing Experts in Carlingford",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof repairs & restoration are crucial for maintaining the structural integrity and aesthetic appeal of your property in Carlingford. At AMS Roof Care, we specialize in providing top-tier roof repairs in Carlingford catering to a wide range of roofing needs, from minor fixes to comprehensive restorations. Our dedicated approach ensures that your roof is always in optimal condition, protecting your property and enhancing its value.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Carlingford: Swift and Reliable Solutions",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to roof restoration in Carlingford we understand the importance of a reliable and professional service. Our team of experts is equipped to handle various roofing issues, including leaking roof repairs, roof repointing, and metal roof restoration. We utilize high-quality materials and advanced techniques to deliver durable and affordable solutions. Whether you need roof painters in Carlingford to refresh the look of your roof or comprehensive repairs to address structural damage, our trusted and expert team is here to help. We pride ourselves on offering the best roofing services in Carlingford, ensuring that your property is well-maintained and protected from the elements. Our commitment to excellence and customer satisfaction sets us apart, making us the go-to choice for all your roofing needs in Carlingford.",
                                        "url": "https://www.amsroofcare.com.au/roofing-caringbah/",
                                        "urls": [
                                            {
                                                "url": "https://www.amsroofcare.com.au/roofing-caringbah/",
                                                "anchor_text": "roof restoration"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us for Roof Repairs & Restoration in Carlingford?",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At AMS Roof Care, we take pride in delivering exceptional roof repairs & restoration services. Here are some compelling reasons why you should choose us:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Expert and Trained Professionals : Our team consists of highly skilled and trained professionals who specialize in roof repairs & restoration. Each member undergoes rigorous training to ensure they are equipped to provide the best possible service. Our experts are not only skilled but also reliable, ensuring that your roof is always in good hands.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "High-Quality Materials : We use only the best materials for our roof repairs & restoration services. This ensures that your roof is not only repaired but also strengthened, providing long-lasting protection for your property. Our commitment to using top-notch materials reflects our dedication to delivering durable and reliable solutions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Advanced Techniques : Our team employs advanced techniques and the latest technology to address various roofing issues. Whether it\u2019s leaking roof repairs, roof repointing, or metal roof restoration, we have the expertise and tools to handle any challenge. Our innovative approaches ensure that your roof is repaired efficiently and effectively.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Affordable Solutions : We understand that roofing services can be a significant investment. That\u2019s why we offer cheap and affordable solutions without compromising on quality. Our competitive pricing ensures that you get the best value for your money, making our services accessible to all.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Customized Plans : We offer customized plans tailored to the unique needs of your property. Whether you need minor repairs or a comprehensive restoration, we have a plan that fits your requirements. Our flexible and adaptable plans ensure that we can accommodate your specific needs, providing a personalized service that meets your expectations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Timely and Efficient Service : We value your time and understand the importance of prompt service. Our team works efficiently to complete your roof repairs & restoration project on time, minimizing any disruption to your daily routine. Our timely and efficient service ensures that your roof is repaired quickly and effectively.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Customer Satisfaction : Our top priority is customer satisfaction. We strive to exceed your expectations and deliver exceptional results with every project we undertake. Our commitment to quality and customer service sets us apart, making us a trusted choice for roof repairs & restoration in Carlingford.",
                                        "url": "https://www.amsroofcare.com.au/roofing-merrylands/",
                                        "urls": [
                                            {
                                                "url": "https://www.amsroofcare.com.au/roofing-merrylands/",
                                                "anchor_text": "roof repairs & restoration"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Approach to Roof Repairs & Restoration Carlingford",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our approach to roof repairs & restoration is centered on providing reliable and professional services that meet the unique needs of your property. We understand that every roof is different, and our customized plans ensure that we can accommodate your specific requirements. Our team of experts is dedicated to delivering the best possible service, using high-quality materials and advanced techniques to address various roofing issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We begin by assessing the specific needs of your roof, taking into account factors such as the type of roof, the extent of damage, and the desired outcome. Based on this assessment, we develop a customized plan that meets your unique requirements. Our plans are designed to be flexible and adaptable, ensuring that we can accommodate your changing needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our process involves a thorough and detailed inspection of your roof to identify any issues that need to be addressed. We pay special attention to areas that are prone to damage, such as leaking roof repairs, roof repointing, and metal roof restoration. Our detailed inspection ensures that no issue is left unaddressed, providing a comprehensive solution for your roofing needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We understand that the success of your roof depends on reliable and professional services. Our team works efficiently to complete your roof repairs & restoration project on time, minimizing any disruption to your daily routine. Our timely and efficient service ensures that your roof is repaired quickly and effectively, providing long-lasting protection for your property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "The Roof Restoration Additional Services",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Painting : Our roof painters in Carlingford provide professional painting services to refresh the look of your roof. We use high-quality paints that are durable and weather-resistant, ensuring that your roof looks great and is protected from the elements.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Cleaning : Our gutter cleaning services ensure that your gutters are clean and free from debris, promoting proper water flow and preventing water damage. Regular gutter cleaning is essential for maintaining the integrity of your roof and property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Insulation : Our roof insulation services help improve the energy efficiency of your property, keeping it cool in the summer and warm in the winter. Proper insulation can significantly reduce your energy bills and enhance the comfort of your property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Maintenance : Our roof maintenance services include regular inspections, cleaning, and minor repairs to keep your roof in optimal condition. Regular maintenance can extend the lifespan of your roof and prevent costly repairs in the future.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Emergency Roof Repairs : Our emergency roof repair services are available 24/7 to address any urgent roofing issues. We understand that roofing emergencies can happen at any time, and our prompt and reliable service ensures that your roof is repaired quickly and effectively.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "In addition to our core",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "we also offer a range of additional services to enhance the performance and aesthetic appeal of your roof. These services include:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Commitment to Quality and Customer Satisfaction",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At AMS Roof Care, we are committed to delivering the best possible roof repairs & restoration services in Carlingford. Our dedication to quality and customer satisfaction sets us apart, making us a trusted choice for all your roofing needs. We understand that your roof is a crucial component of your property, and our expert and reliable services ensure that it is always in optimal condition.We believe in providing a personalized service that caters to the unique needs of each property, ensuring that your roof is always in good hands. Our team of professionals is dedicated to delivering the best possible service, using high-quality materials and advanced techniques to address various roofing issues. We strive to exceed your expectations and deliver exceptional results with every project we undertake.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For top-notch roof restoration services in Carlingford contact AMS Roof Care today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repointing Carlingford: Strengthening Your Roof",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At AMS Roof Care, we are proud of the positive feedback we receive from our clients. Their satisfaction is a testament to our commitment to quality and customer service. We strive to exceed expectations and deliver exceptional results with every project we undertake.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why is Roof Repairs Important?",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "In conclusion, AMS Roof Care is your go-to provider for top-tier roof repairs & restoration services in Carlingford. Our expert and trained professionals, high-quality materials, advanced techniques, affordable solutions, customized plans, timely and efficient service, and commitment to customer satisfaction set us apart from the competition. Whether you need roof repairs, roof restoration, roof repointing, roof painters, leaking roof repairs, or metal roof restoration in Carlingford, we have the expertise and experience to meet your needs.Contact us today to discuss your roofing requirements and experience the difference with AMS Roof Care. Our team is ready to provide you with a customized plan that meets your specific needs, ensuring that your roof is always in optimal condition. Trust us to provide the best possible roof repairs & restoration services in Carlingford, and let us help you protect and enhance the value of your property. Your satisfaction is our top priority, and we are committed to delivering exceptional results with every roofing project we undertake.",
                                        "url": "https://www.amsroofcare.com.au/roofing-mosman/",
                                        "urls": [
                                            {
                                                "url": "https://www.amsroofcare.com.au/roofing-mosman/",
                                                "anchor_text": "roof repairs, roof restoration, roof repointing, roof painters, leaking roof repairs, or metal roof restoration"
                                            },
                                            {
                                                "url": "https://www.amsroofcare.com.au/roofing-mosman/",
                                                "anchor_text": "roof repointing"
                                            },
                                            {
                                                "url": "https://www.amsroofcare.com.au/roofing-mosman/",
                                                "anchor_text": "roof painters"
                                            },
                                            {
                                                "url": "https://www.amsroofcare.com.au/roofing-mosman/",
                                                "anchor_text": "leaking roof repairs"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us Today!",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Don\u2019t wait until it\u2019s too late to address your roofing issues. Contact AMS Roof Care today to schedule an inspection or request a quote. Our team is here to help you with all your roofing needs, providing reliable and professional services that you can trust. Let us help you protect and enhance the value of your property with our top-tier roof repairs & restoration services in Carlingford.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We look forward to serving you and helping you with all your roofing needs in Carlingford. Thank you for choosing AMS Roof Care in Sydney for your roof repairs & restoration services.",
                                        "url": "https://www.amsroofcare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.amsroofcare.com.au/",
                                                "anchor_text": "AMS Roof Care in Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Reviews",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Fast and prompt pressure cleaning service, we got our roof, house brick walls, and driveway pressure cleaned and it turned out pristine. Excellent job and well worth the money spent.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We had a leaking roof during the rainy season and AMS Roof Care came in the same day within a few hours on urgent notice and stopped the roof leak immediately with a temporary solution and then came back the next day and finalised the full repair.\u00a0These guys are awesome and I highly recommend them.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thank you for replacing our new metal roof we are so thankful it has turned out perfectly as expected in such a short turn around time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What makes AMS Roof Care different from other roofing services?",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "AMS Roof Care stands out due to our specialized approach to roof repairs & restoration. Our team is trained to handle the specific needs of various roofing issues, ensuring a reliable and professional service. We use high-quality materials and advanced techniques to provide durable and affordable solutions. Our commitment to quality and customer satisfaction sets us apart from other roofing services. We believe in providing a personalized service that caters to the unique needs of each property, ensuring that your roof is always in optimal condition.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What kind of materials do you use for roof repairs?",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "It replaces mortar, preventing leaks. Regular inspection ensures a sound, long-lasting roof. Act now for security.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Can you provide roof restoration services for metal roofs?",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes, we offer comprehensive metal roof restoration services in Carlingford. Our team is equipped to handle the specific needs of metal roofs, ensuring a durable and long-lasting restoration. We understand the unique challenges of metal roof restoration and are committed to providing the best possible service. Our services include thorough cleaning, repairing, and coating of metal roofs to enhance their performance and aesthetic appeal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How often should I get my roof inspected?",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We recommend getting your roof inspected at least once a year to ensure it is in good condition. Regular inspections help identify any potential issues early, allowing for timely repairs and maintenance. This proactive approach can save you from costly repairs in the future and extend the lifespan of your roof. Our expert team can provide a thorough inspection and advise you on the best course of action for your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Are your roofing services affordable?",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes, our roofing services are designed to be cheap and affordable without compromising on quality. We understand that roofing services can be a significant investment, and our competitive pricing ensures that you get the best value for your money. Our affordable solutions make our services accessible to all, providing you with reliable and professional roofing services at a reasonable cost.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney's Roofing Specialist",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "For all your roofing repairs, roof painting\u00a0and pressure cleaning needs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Carlingford",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "QUICK QUOTE",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "QUICK ENQUIRY",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "FAQ",
                                "main_title": "Roofing Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61-415-999-919",
                                "+61415999919",
                                "0415999919"
                            ],
                            "emails": [
                                "info@amsroofcare.com.au?Subject=Email enquiry from website AMS Roof Care&amp;cc=reports@nextweb.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}