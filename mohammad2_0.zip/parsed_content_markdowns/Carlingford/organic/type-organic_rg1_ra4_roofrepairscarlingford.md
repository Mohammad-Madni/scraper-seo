{
    "id": "01190728-1132-0216-0000-7b250feb7983",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0302 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrepairscarlingford.com.au/",
        "target": "roofrepairscarlingford.com.au",
        "start_url": "https://roofrepairscarlingford.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg1_ra4_roofrepairscarlingford.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:43 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairscarlingford.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairscarlingford.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairscarlingford.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairscarlingford.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairscarlingford.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairscarlingford.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairscarlingford.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairscarlingford.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairscarlingford.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairscarlingford.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairscarlingford.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairscarlingford.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairscarlingford.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairscarlingford.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairscarlingford.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairscarlingford.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairscarlingford.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairscarlingford.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Our website connects you with skilled roofing contractors servicing suburbs in the Carlingford region. Our contractors have extensive experience in the industry, and have a track record of maintaining, improving, and building metal and tile roofs, both for residential and commercial jobs. They pride themselves on providing top quality workmanship and ensuring customer satisfaction. Our contractors back their workmanship with a warranty, so you can take confidence in our contractor\u2019s ability to complete the works to a high standard. This website is owned and operated by Client Connect Australia Pty Ltd.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Talk to us today about roofing services for your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "GET IN TOUCH",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our website connects you with skilled local roofing contractors servicing most Carlingford suburb, including Epping, Eastwood, and Oatlands. With extensive experience in the industry, our roofers are experts in maintaining and enhancing both tile and metal roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Your Connection to Roofing Experts in Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Tile or metal roof repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Re-roofing and full roof replacements",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leak detection and minor roof fixes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter and flashing assistance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Advice on roofing materials and upgrades",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Through our platform, you can be matched with roofing contractors who work in Carlingford and provide services such as:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Each enquiry you submit is passed directly to roofing professionals who operate in the area and are ready to help.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Roof Repairs Carlingford?",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roofing-specific referrals \u2013 We handle only roofing-related enquiries",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local focus \u2013 We connect you with roofers who work in your suburb or region",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quick responses \u2013 Contractors we refer to can respond directly with quotes and timelines",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You stay in control \u2013 There\u2019s no obligation to proceed with any referral",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We\u2019re focused solely on helping people in Carlingford find qualified roofing professionals. We do not carry out any work ourselves\u2014instead, we refer your request to roofing contractors who are active and available.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Here\u2019s what makes our service useful:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We understand that emergencies can happen anytime and require quick action to minimize damage. Our team of experienced professionals is available 24/7 to provide fast and reliable emergency roof repair services. From minor repairs to more extensive work, we can be counted on to get the job done right.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Emergency Roof Repairs Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs Carlingford"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "About Us \u2013 Connecting Carlingford Residents with Roofing Professionals",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roof Repairs Carlingford, we\u2019re here to make it easier for local homeowners to find qualified roofing contractors. Whether you\u2019re facing roof repairs after a storm or planning a new installation, our referral platform connects you with independent roofing professionals who can assist based on your specific needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We understand that roof work is a significant investment. That\u2019s why our service is designed to help you connect with roofing contractors who offer advice, quotes, and services tailored to your project and budget.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Supporting Homeowners in Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Through our platform, residents across Carlingford can quickly access roofing professionals for:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repairs and leak detection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Re-roofing and roof replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tile and metal roofing services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter and flashing solutions",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "General roofing advice",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our goal is to streamline the process of finding the right roofer\u2014so you don\u2019t have to spend hours searching or making calls.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Makes Roof Repairs Carlingford Different?",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We\u2019re not a roofing company. Instead, we serve as a connection point between homeowners and qualified third-party roofing contractors in Carlingford.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What you can expect from us:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Focused referrals \u2013 Roofing-only enquiries matched with relevant professionals",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local knowledge \u2013 We prioritise referrals to contractors working in your area",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flexible outcomes \u2013 There\u2019s no obligation to move forward with a quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Simple process \u2013 Just submit a request, and we\u2019ll take care of the rest",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Helping You Make the First Move",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Finding reliable roof repairs in Carlingford can be overwhelming\u2014especially when urgent action is needed. We make that first step easier by connecting you with roofing contractors who can assess your situation and offer next steps.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You remain in control of how and when you proceed. Any quotes, timelines, or services will be provided directly by the contractor.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get Connected Today",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If you\u2019re a homeowner in Carlingford looking for roof repairs, replacements, or advice, let Roof Repairs Carlingford refer you to a roofing professional in your area. Submit a quick enquiry today and we\u2019ll put you in touch with someone who can help.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "We Take Care Of Your Roof",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Us \u2013 Helping Carlingford Residents Connect With Roofing Professionals",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Extreme weather, ageing materials, and everyday wear can all impact the performance of your roof. When that happens, finding the right professional to assess the situation and provide reliable advice is crucial. That\u2019s where Roof Repairs Carlingford comes in.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We connect homeowners and property managers in Carlingford with independent, third-party roofing contractors who are experienced in a wide range of roof repair and replacement services. Whether you\u2019re dealing with a minor leak or planning a full re-roof, our service makes it easier to find a roofer who understands local conditions and project needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Supporting Smarter Roofing Decisions",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We understand that roofing projects\u2014whether large or small\u2014can be stressful. Our role is to make that first step easier by helping you connect with professionals who know how to handle your specific roofing needs. The contractors we work with manage the inspection, quoting, scheduling, and completion of the job.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You\u2019ll receive guidance and quotes directly from the roofing contractor, and they\u2019ll be your point of contact throughout the process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Start Today",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If you\u2019re dealing with roof repairs in Carlingford or looking for advice on a potential upgrade, submit a quick enquiry through Roof Repairs Carlingford. We\u2019ll connect you with roofing professionals in the area who are ready to assist.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Let us help you take the guesswork out of finding the right roofing contractor.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repairs Services",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We provide a wide range of roofing services, including:",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Colorbond roofing is a popular choice for both residential and commercial properties. Our team of experienced professionals is trained in the installation of colorbond roofing and uses the highest-quality materials to ensure your roof looks its best.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing Contractors Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing Contractors Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whether you need a complete replacement or repairs for an existing roof, our team of qualified professionals can help. We understand that a slight disruption in business can be costly. We work around your schedule to minimize downtime, which includes weekends and/or evenings if needed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Carlingford Roof and Gutter",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Carlingford Roof and Gutter",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Carlingford Roof and Gutter"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Don\u2019t let a small leak turn into a bigger problem. We use the latest leak detection techniques to diagnose and repair any issues accurately. They include water tests, thermal imaging, and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Inspections Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Let our team of qualified professionals help you assess the condition of your roof. We\u2019ll provide an in-depth inspection to diagnose roof issues and accurately recommend cost-effective solutions. We provide a detailed report of our findings, which can then be used to plan any necessary repairs or replacements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Roof Repairs Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Leaking Roof Repairs Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Don\u2019t let a small leak turn into a bigger problem. We use the latest leak detection techniques to diagnose and repair any issues accurately. They include water tests, thermal imaging, and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Installation Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our team of qualified professionals can install all roofing materials, including metal roofs, slate roofs, solar roofs, tile roofs, and more. We believe in quality workmanship and use only the highest-quality materials to ensure your roof is strong and secure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal roofs are becoming increasingly popular due to their durability, low maintenance, and energy efficiency. We deal with different kinds of metal roofing, from corrugated to standing seam, and multiple color options. Additionally, we can install soaker panels and other accessories for a more custom look.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our team of experienced professionals can provide a full roof replacement service if your roof is beyond repair. We\u2019ll help you choose the right material, size, and shape to match your property and budget.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Carlingford Roof Restoration",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Carlingford Roof Restoration",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-restoration/",
                                                "anchor_text": "Carlingford Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "At Roof Repairs Carlingford, we believe in preserving existing structures wherever possible rather than replacing them. We use the latest materials and techniques to extend the life of your roof while being mindful of its historical value and character.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roofing/",
                                                "anchor_text": "Roofing Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We offer various services for residential and commercial properties in Carlingford, ranging from minor repairs to full-scale installations. Whether it\u2019s metal or tile roofs, skylights, or solar panels \u2013 our experienced team will provide quality solutions that meet your needs and budget. We handle everything from start to finish and provide exceptional customer service throughout the entire process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Skylights Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Skylights Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/skylights/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/skylights/",
                                                "anchor_text": "Skylights Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Skylights are among the most popular features of a home, providing natural light and ventilation. Our team of qualified professionals can install residential and commercial skylights, from standard units to custom designs. We also offer repair solutions, including replacing broken seals and frames.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tilers Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tilers Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tiling is a specialized task that requires knowledge, skill, and experience \u2013 all of which our team has in abundance. We provide installation and repairs for slate, terracotta, metal, concrete tiles, and all types of roof accessories.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Repairs Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roof Repairs Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slate roofs are a popular choice for heritage homes due to their long-lasting durability and classic look. We understand the importance of preserving a building\u2019s original character and can help you with all your slate roof repair needs. Our experienced technicians use only the highest-quality materials to restore your roof to its former glory.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Carlingford Discount Roof Repair",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Are You Waiting For?",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "A reliable and secure roof is one of the most important investments in your life. That\u2019s why when it comes to repair or installation, you can count on the professionals at Roof Repairs Carlingford for quality service and workmanship. Call us now!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Links",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Us",
                                        "url": "https://roofrepairscarlingford.com.au/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/about-us/",
                                                "anchor_text": "About Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our Services",
                                        "url": "https://roofrepairscarlingford.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/",
                                                "anchor_text": "Our Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing",
                                        "url": "https://roofrepairscarlingford.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roofing Contractors",
                                        "url": "https://roofrepairscarlingford.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": "https://roofrepairscarlingford.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof and Gutter",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Roof and Gutter"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof Repairs",
                                        "url": "https://roofrepairscarlingford.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://roofrepairscarlingford.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tilers",
                                        "url": "https://roofrepairscarlingford.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slate Roof Repairs",
                                        "url": "https://roofrepairscarlingford.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Info",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "&copy 2025 Roof Repairs Carlingford",
                                "main_title": "Roof Repairs Carlingford - #1 Roofing Company in Carlingford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "&copy 2025 Roof Repairs Carlingford",
                                        "url": "https://roofrepairscarlingford.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/",
                                                "anchor_text": "Roof Repairs Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://roofrepairscarlingford.com.au/privacy-policy/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/privacy-policy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms & Conditions",
                                        "url": "https://roofrepairscarlingford.com.au/terms-and-conditions/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairscarlingford.com.au/terms-and-conditions/",
                                                "anchor_text": "Terms & Conditions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02)%206188%207382"
                            ],
                            "emails": [
                                "info@roofrepairscarlingford.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}