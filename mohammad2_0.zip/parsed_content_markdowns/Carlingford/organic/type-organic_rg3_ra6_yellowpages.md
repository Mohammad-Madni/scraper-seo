{
    "id": "01190728-1132-0216-0000-39584f12fa5a",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0275 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.yellowpages.com.au/find/roofing-construction-services/carlingford-nsw-2118",
        "target": "www.yellowpages.com.au",
        "start_url": "https://www.yellowpages.com.au/find/roofing-construction-services/carlingford-nsw-2118",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg3_ra6_yellowpages.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:46 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roofing Construction & Services Near Me",
                                    "url": "https://www.yellowpages.com.au/find/roofing-construction-services/nsw",
                                    "urls": [
                                        {
                                            "url": "https://www.yellowpages.com.au/find/roofing-construction-services/nsw",
                                            "anchor_text": "Roofing Construction & Services Near Me"
                                        }
                                    ]
                                },
                                {
                                    "text": "Carlingford NSW",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Proof Metal Roofing Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Meadowbank, NSW 2114",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: On time service",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Proof Metal Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/meadowbank/proof-metal-roofing-pty-ltd-14215379-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/meadowbank/proof-metal-roofing-pty-ltd-14215379-listing.html",
                                                "anchor_text": "Proof Metal Roofing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "106 Bowden St, Meadowbank, NSW, 2114",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=106+Bowden+St&context=undefined&directionMode=true&elat=-33.81741&elon=151.093021&ena=Proof+Metal+Roofing+Pty+Ltd&estr=106+Bowden+St&esu=Meadowbank%2C+NSW%2C+2114&productVersion=22&productId=471553776&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DProof+Metal+Roofing+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.81741%26lon%3D151.093021%26selectedViewMode%3Dlist&yellowId=14215379",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=106+Bowden+St&context=undefined&directionMode=true&elat=-33.81741&elon=151.093021&ena=Proof+Metal+Roofing+Pty+Ltd&estr=106+Bowden+St&esu=Meadowbank%2C+NSW%2C+2114&productVersion=22&productId=471553776&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DProof+Metal+Roofing+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.81741%26lon%3D151.093021%26selectedViewMode%3Dlist&yellowId=14215379",
                                                "anchor_text": "106 Bowden St, Meadowbank, NSW, 2114"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9807 3322",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Questions to ask your roofing specialist",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roofing done well will protect your house for a long time. At Yellow Pages, we want you to have the best possible experience. We\u2019ve assembled some questions for you to consider when selecting your roofing contractor.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How long have they been in business? Established roofing companies with a proven track record are more reliable and trustworthy.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do they have other homeowner referrals you can talk to? Hearing more testimonials beyond the standard testimonials in their website can give you greater insight into other families\u2019 experiences.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What sort of licensing does this business have? A roofing service should have the appropriate license for their state or province.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do they offer warranty for their service? Try to find a warranty that covers the material and the roofing service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Take your search to new heights by browsing our listings to find a roofing service near you. Request a quote today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ivy Contractors Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Seven Hills, NSW 2147",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ivy Contractors Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/seven-hills/ivy-contractors-pty-ltd-15744697-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/seven-hills/ivy-contractors-pty-ltd-15744697-listing.html",
                                                "anchor_text": "Ivy Contractors Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Unit 4/ 9A Foundry Rd, Seven Hills, NSW, 2147",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Unit+4%252F+9A+Foundry+Rd&context=undefined&directionMode=true&elat=-33.767556&elon=150.956993&ena=Ivy+Contractors+Pty+Ltd&estr=Unit+4%2F+9A+Foundry+Rd&esu=Seven+Hills%2C+NSW%2C+2147&productVersion=4&productId=999016273815&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DIvy+Contractors+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.767556%26lon%3D150.956993%26selectedViewMode%3Dlist&yellowId=15744697",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Unit+4%252F+9A+Foundry+Rd&context=undefined&directionMode=true&elat=-33.767556&elon=150.956993&ena=Ivy+Contractors+Pty+Ltd&estr=Unit+4%2F+9A+Foundry+Rd&esu=Seven+Hills%2C+NSW%2C+2147&productVersion=4&productId=999016273815&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DIvy+Contractors+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.767556%26lon%3D150.956993%26selectedViewMode%3Dlist&yellowId=15744697",
                                                "anchor_text": "Unit 4/ 9A Foundry Rd, Seven Hills, NSW, 2147"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9674 4556",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Euro Metal Roofing Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Baulkham Hills, NSW 2153",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: Special curved roofing to bullnose roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Euro Metal Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/baulkham-hills/euro-metal-roofing-pty-ltd-14187717-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/baulkham-hills/euro-metal-roofing-pty-ltd-14187717-listing.html",
                                                "anchor_text": "Euro Metal Roofing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0412 360 304",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofs Above & Beyond",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Baulkham Hills, NSW 2153",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofs Above & Beyond",
                                        "url": "https://www.yellowpages.com.au/nsw/baulkham-hills/roofs-above-beyond-14600107-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/baulkham-hills/roofs-above-beyond-14600107-listing.html",
                                                "anchor_text": "Roofs Above & Beyond"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9654 6000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Monolith Roofing - Sydney Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Castle Hill, NSW 2154",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Monolith Roofing - Sydney Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/castle-hill/monolith-roofing-sydney-roofing-1000002957685-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/castle-hill/monolith-roofing-sydney-roofing-1000002957685-listing.html",
                                                "anchor_text": "Monolith Roofing - Sydney Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "12 Clarke Pl, Castle Hill, NSW, 2154",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=12+Clarke+Pl&context=undefined&directionMode=true&elat=-33.725729&elon=151.011372&ena=Monolith+Roofing+-+Sydney+Roofing&estr=12+Clarke+Pl&esu=Castle+Hill%2C+NSW%2C+2154&productVersion=1&productId=1000002957685&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMonolith+Roofing+-+Sydney+Roofing%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.725729%26lon%3D151.011372%26selectedViewMode%3Dlist&yellowId=1000002957685",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=12+Clarke+Pl&context=undefined&directionMode=true&elat=-33.725729&elon=151.011372&ena=Monolith+Roofing+-+Sydney+Roofing&estr=12+Clarke+Pl&esu=Castle+Hill%2C+NSW%2C+2154&productVersion=1&productId=1000002957685&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMonolith+Roofing+-+Sydney+Roofing%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.725729%26lon%3D151.011372%26selectedViewMode%3Dlist&yellowId=1000002957685",
                                                "anchor_text": "12 Clarke Pl, Castle Hill, NSW, 2154"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0461 382 366",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "AGF Metal Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Seven Hills, NSW 2147",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "AGF Metal Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/seven-hills/agf-metal-roofing-14544283-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/seven-hills/agf-metal-roofing-14544283-listing.html",
                                                "anchor_text": "AGF Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "14 Bearing Rd, Seven Hills, NSW, 2147",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=14+Bearing+Rd&context=undefined&directionMode=true&elat=-33.773253&elon=150.957506&ena=AGF+Metal+Roofing&estr=14+Bearing+Rd&esu=Seven+Hills%2C+NSW%2C+2147&productVersion=7&productId=999015529564&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DAGF+Metal+Roofing%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.773253%26lon%3D150.957506%26selectedViewMode%3Dlist&yellowId=14544283",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=14+Bearing+Rd&context=undefined&directionMode=true&elat=-33.773253&elon=150.957506&ena=AGF+Metal+Roofing&estr=14+Bearing+Rd&esu=Seven+Hills%2C+NSW%2C+2147&productVersion=7&productId=999015529564&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DAGF+Metal+Roofing%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.773253%26lon%3D150.957506%26selectedViewMode%3Dlist&yellowId=14544283",
                                                "anchor_text": "14 Bearing Rd, Seven Hills, NSW, 2147"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9838 8730",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Crest Metal Roofing Pty ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Baulkham Hills, NSW 2153",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Crest Metal Roofing Pty ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/baulkham-hills/crest-metal-roofing-pty-ltd-12171518-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/baulkham-hills/crest-metal-roofing-pty-ltd-12171518-listing.html",
                                                "anchor_text": "Crest Metal Roofing Pty ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0418 678 630",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ecodomes",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Castle Hill, NSW 2154",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ecodomes",
                                        "url": "https://www.yellowpages.com.au/nsw/castle-hill/ecodomes-15194476-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/castle-hill/ecodomes-15194476-listing.html",
                                                "anchor_text": "Ecodomes"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "3 6 Gladstone Rd, Castle Hill, NSW, 2154",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=3+6+Gladstone+Rd&context=undefined&directionMode=true&elat=-33.733986&elon=150.978103&ena=Ecodomes&estr=3+6+Gladstone+Rd&esu=Castle+Hill%2C+NSW%2C+2154&productVersion=4&productId=999015915846&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DEcodomes%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.733986%26lon%3D150.978103%26selectedViewMode%3Dlist&yellowId=15194476",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=3+6+Gladstone+Rd&context=undefined&directionMode=true&elat=-33.733986&elon=150.978103&ena=Ecodomes&estr=3+6+Gladstone+Rd&esu=Castle+Hill%2C+NSW%2C+2154&productVersion=4&productId=999015915846&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DEcodomes%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.733986%26lon%3D150.978103%26selectedViewMode%3Dlist&yellowId=15194476",
                                                "anchor_text": "3 6 Gladstone Rd, Castle Hill, NSW, 2154"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1300 138 813",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Corrugation Creations Pty. Ltd.",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Seven Hills, NSW 2147",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Corrugation Creations Pty. Ltd.",
                                        "url": "https://www.yellowpages.com.au/nsw/seven-hills/corrugation-creations-pty-ltd-1000002396803-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/seven-hills/corrugation-creations-pty-ltd-1000002396803-listing.html",
                                                "anchor_text": "Corrugation Creations Pty. Ltd."
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0451 799 875",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Mattak Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Seven Hills, NSW 2147",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Family run and owned roofing business in Western Sydney",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Mattak Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/seven-hills/mattak-roofing-1000002695024-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/seven-hills/mattak-roofing-1000002695024-listing.html",
                                                "anchor_text": "Mattak Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0408 411 341",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Prestige Roofing Specialists Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Pendle Hill, NSW 2145",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Prestige Roofing Specialists Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/pendle-hill/prestige-roofing-specialists-pty-ltd-15561535-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/pendle-hill/prestige-roofing-specialists-pty-ltd-15561535-listing.html",
                                                "anchor_text": "Prestige Roofing Specialists Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Flamingo Pl, Pendle Hill, NSW, 2145",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Flamingo+Pl&context=undefined&directionMode=true&elat=-33.808236&elon=150.948068&ena=Prestige+Roofing+Specialists+Pty+Ltd&estr=Flamingo+Pl&esu=Pendle+Hill%2C+NSW%2C+2145&productVersion=4&productId=999016159837&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DPrestige+Roofing+Specialists+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.808236%26lon%3D150.948068%26selectedViewMode%3Dlist&yellowId=15561535",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Flamingo+Pl&context=undefined&directionMode=true&elat=-33.808236&elon=150.948068&ena=Prestige+Roofing+Specialists+Pty+Ltd&estr=Flamingo+Pl&esu=Pendle+Hill%2C+NSW%2C+2145&productVersion=4&productId=999016159837&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DPrestige+Roofing+Specialists+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.808236%26lon%3D150.948068%26selectedViewMode%3Dlist&yellowId=15561535",
                                                "anchor_text": "Flamingo Pl, Pendle Hill, NSW, 2145"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0420 972 072",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing365",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, South Wentworthville, NSW 2145",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing365",
                                        "url": "https://www.yellowpages.com.au/nsw/south-wentworthville/roofing365-1000002148756-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/south-wentworthville/roofing365-1000002148756-listing.html",
                                                "anchor_text": "Roofing365"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0405 270 844",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Andris Metal Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, East Ryde, NSW 2113",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Andris Metal Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/east-ryde/andris-metal-roofing-13612970-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/east-ryde/andris-metal-roofing-13612970-listing.html",
                                                "anchor_text": "Andris Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9888 9672",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Restoraroof",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Seven Hills, NSW 2147",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Restoraroof",
                                        "url": "https://www.yellowpages.com.au/nsw/seven-hills/restoraroof-15082757-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/seven-hills/restoraroof-15082757-listing.html",
                                                "anchor_text": "Restoraroof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "25 / 6 Abbott Rd, Seven Hills, NSW, 2147",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=25+%252F+6+Abbott+Rd&context=undefined&directionMode=true&elat=-33.768897&elon=150.945384&ena=Restoraroof&estr=25+%2F+6+Abbott+Rd&esu=Seven+Hills%2C+NSW%2C+2147&productVersion=6&productId=999015830165&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRestoraroof%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.768897%26lon%3D150.945384%26selectedViewMode%3Dlist&yellowId=15082757",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=25+%252F+6+Abbott+Rd&context=undefined&directionMode=true&elat=-33.768897&elon=150.945384&ena=Restoraroof&estr=25+%2F+6+Abbott+Rd&esu=Seven+Hills%2C+NSW%2C+2147&productVersion=6&productId=999015830165&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRestoraroof%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.768897%26lon%3D150.945384%26selectedViewMode%3Dlist&yellowId=15082757",
                                                "anchor_text": "25 / 6 Abbott Rd, Seven Hills, NSW, 2147"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0438 255 801",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Frames & Trusses",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Trusses & Wall Frames",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For All Your Frames & Trusses Call Us Now For Value",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(02) 8783 8022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Garage Builders & Prefabricators",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Materials",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Custombuilt Frames & Trusses",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Trusses & Wall Frames",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "H2F Termite Resistant Timber Custom And Unique Plans Owner Builders",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(02) 4871 3355",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Gutter & Roof Restoration",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Slaters & Roof Tilers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Warning, Not All Roof Companies Are The Same",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "1300 654 884",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Carport & Pergola Builders",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Regent Skylights",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Factory Direct Skylights, Energy Efficient Patented Press & Flashings",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(07) 3274 3344",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Gutter & Roof Restoration",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Warning, Not All Roof Companies Are The Same",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Guttering & Spouting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 654 884",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Telford's Building Systems",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Steel Building Solutions Built to Last in Yatala",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Rural & Industrial Sheds",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(03) 5821 4399",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Total Steel of Australia Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Profile Cutting Service. Wear Plate. Mining Industry Solutions",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Steel Supplies & Merchants",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 4648 8111",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "122 Results for Roofing Contractors & Services Near You",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "A & K Metal Roofing Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Rydalmere, NSW 2116",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A & K Metal Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/oatlands/a-k-metal-roofing-pty-ltd-12802920-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/oatlands/a-k-metal-roofing-pty-ltd-12802920-listing.html",
                                                "anchor_text": "A & K Metal Roofing Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Modern",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Baulkham Hills, NSW 2153",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Modern",
                                        "url": "https://www.yellowpages.com.au/sup/modern-14747818-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/modern-14747818-listing.html",
                                                "anchor_text": "Modern"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "GS Roofing Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Toongabbie, NSW 2146",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "GS Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/toongabbie/gs-roofing-pty-ltd-1000002976229-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/toongabbie/gs-roofing-pty-ltd-1000002976229-listing.html",
                                                "anchor_text": "GS Roofing Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "The Roofing Professionals Westside",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Homebush West, NSW 2140",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "The Roofing Professionals Westside",
                                        "url": "https://www.yellowpages.com.au/nsw/homebush-west/the-roofing-professionals-westside-1000002943473-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/homebush-west/the-roofing-professionals-westside-1000002943473-listing.html",
                                                "anchor_text": "The Roofing Professionals Westside"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "MRP Group Nsw Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Ermington, NSW 2115",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "MRP Group Nsw Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/ermington/mrp-group-nsw-pty-ltd-14895425-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ermington/mrp-group-nsw-pty-ltd-14895425-listing.html",
                                                "anchor_text": "MRP Group Nsw Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "47 Delaware Rd, Ermington, NSW, 2115",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=47+Delaware+Rd&context=undefined&directionMode=true&elat=-33.802051&elon=151.058371&ena=MRP+Group+Nsw+Pty+Ltd&estr=47+Delaware+Rd&esu=Ermington%2C+NSW%2C+2115&productVersion=10&productId=999015708929&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMRP+Group+Nsw+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.802051%26lon%3D151.058371%26selectedViewMode%3Dlist&yellowId=14895425",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=47+Delaware+Rd&context=undefined&directionMode=true&elat=-33.802051&elon=151.058371&ena=MRP+Group+Nsw+Pty+Ltd&estr=47+Delaware+Rd&esu=Ermington%2C+NSW%2C+2115&productVersion=10&productId=999015708929&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMRP+Group+Nsw+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.802051%26lon%3D151.058371%26selectedViewMode%3Dlist&yellowId=14895425",
                                                "anchor_text": "47 Delaware Rd, Ermington, NSW, 2115"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0431 555 964",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Best Metal Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Castle Hill, NSW 2154",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Best Metal Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/castle-hill/best-metal-roofing-12056456-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/castle-hill/best-metal-roofing-12056456-listing.html",
                                                "anchor_text": "Best Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open by appt",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: 14072C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9894 5137",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Featured reviews",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Handy tips",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Exclusive Metal Roofing & Construction",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Rosehill, NSW 2142",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Exclusive Metal Roofing & Construction",
                                        "url": "https://www.yellowpages.com.au/nsw/rosehill/exclusive-metal-roofing-construction-1000002609067-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/rosehill/exclusive-metal-roofing-construction-1000002609067-listing.html",
                                                "anchor_text": "Exclusive Metal Roofing & Construction"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "3 Weston St, Rosehill, NSW, 2142",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=3+Weston+St&context=undefined&directionMode=true&elat=-33.822474&elon=151.020873&ena=Exclusive+Metal+Roofing+%26+Construction&estr=3+Weston+St&esu=Rosehill%2C+NSW%2C+2142&productVersion=1&productId=1000002609067&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DExclusive+Metal+Roofing+%26+Construction%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.822474%26lon%3D151.020873%26selectedViewMode%3Dlist&yellowId=1000002609067",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=3+Weston+St&context=undefined&directionMode=true&elat=-33.822474&elon=151.020873&ena=Exclusive+Metal+Roofing+%26+Construction&estr=3+Weston+St&esu=Rosehill%2C+NSW%2C+2142&productVersion=1&productId=1000002609067&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DExclusive+Metal+Roofing+%26+Construction%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.822474%26lon%3D151.020873%26selectedViewMode%3Dlist&yellowId=1000002609067",
                                                "anchor_text": "3 Weston St, Rosehill, NSW, 2142"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0484 900 507",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restorations Sydney",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Ryde, NSW 2112",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Restorations Sydney",
                                        "url": "https://www.yellowpages.com.au/nsw/ryde/roof-restorations-sydney-1000000563907-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ryde/roof-restorations-sydney-1000000563907-listing.html",
                                                "anchor_text": "Roof Restorations Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Abaroo St, Ryde, NSW, 2112",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Abaroo+St&context=undefined&directionMode=true&elat=-33.80982895&elon=151.11736945&ena=Roof+Restorations+Sydney&estr=Abaroo+St&esu=Ryde%2C+NSW%2C+2112&productVersion=3&productId=1000000563907&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRoof+Restorations+Sydney%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.80982895%26lon%3D151.11736945%26selectedViewMode%3Dlist&yellowId=1000000563907",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Abaroo+St&context=undefined&directionMode=true&elat=-33.80982895&elon=151.11736945&ena=Roof+Restorations+Sydney&estr=Abaroo+St&esu=Ryde%2C+NSW%2C+2112&productVersion=3&productId=1000000563907&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRoof+Restorations+Sydney%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.80982895%26lon%3D151.11736945%26selectedViewMode%3Dlist&yellowId=1000000563907",
                                                "anchor_text": "Abaroo St, Ryde, NSW, 2112"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0434 747 245",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "DJ Roofing & Repairs",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Cherrybrook, NSW 2126",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "DJ Roofing & Repairs",
                                        "url": "https://www.yellowpages.com.au/nsw/cherrybrook/dj-roofing-repairs-15136980-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/cherrybrook/dj-roofing-repairs-15136980-listing.html",
                                                "anchor_text": "DJ Roofing & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "7/1 Franklin Rd, Cherrybrook, NSW, 2126",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=7%252F1+Franklin+Rd&context=undefined&directionMode=true&elat=-33.727466&elon=151.039392&ena=DJ+Roofing+%26+Repairs&estr=7%2F1+Franklin+Rd&esu=Cherrybrook%2C+NSW%2C+2126&productVersion=3&productId=999015866276&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DDJ+Roofing+%26+Repairs%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.727466%26lon%3D151.039392%26selectedViewMode%3Dlist&yellowId=15136980",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=7%252F1+Franklin+Rd&context=undefined&directionMode=true&elat=-33.727466&elon=151.039392&ena=DJ+Roofing+%26+Repairs&estr=7%2F1+Franklin+Rd&esu=Cherrybrook%2C+NSW%2C+2126&productVersion=3&productId=999015866276&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DDJ+Roofing+%26+Repairs%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.727466%26lon%3D151.039392%26selectedViewMode%3Dlist&yellowId=15136980",
                                                "anchor_text": "7/1 Franklin Rd, Cherrybrook, NSW, 2126"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0437 272 916",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Grandview Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Silverwater, NSW 2128",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Grandview Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/silverwater/grandview-pty-ltd-15582050-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/silverwater/grandview-pty-ltd-15582050-listing.html",
                                                "anchor_text": "Grandview Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Unit 3 24 Carnarvon St, Silverwater, NSW, 2128",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Unit+3+24+Carnarvon+St&context=undefined&directionMode=true&elat=-33.840227&elon=151.0463&ena=Grandview+Pty+Ltd&estr=Unit+3+24+Carnarvon+St&esu=Silverwater%2C+NSW%2C+2128&productVersion=7&productId=999902070203&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGrandview+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.840227%26lon%3D151.0463%26selectedViewMode%3Dlist&yellowId=15582050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Unit+3+24+Carnarvon+St&context=undefined&directionMode=true&elat=-33.840227&elon=151.0463&ena=Grandview+Pty+Ltd&estr=Unit+3+24+Carnarvon+St&esu=Silverwater%2C+NSW%2C+2128&productVersion=7&productId=999902070203&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGrandview+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.840227%26lon%3D151.0463%26selectedViewMode%3Dlist&yellowId=15582050",
                                                "anchor_text": "Unit 3 24 Carnarvon St, Silverwater, NSW, 2128"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1800 101 064",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Majestic Roofing Pty Ltd",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Ermington, NSW 2115",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Majestic Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/ermington/majestic-roofing-pty-ltd-15162954-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ermington/majestic-roofing-pty-ltd-15162954-listing.html",
                                                "anchor_text": "Majestic Roofing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "620 Victoria Rd, Ermington, NSW, 2115",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=620+Victoria+Rd&context=undefined&directionMode=true&elat=-33.812645&elon=151.060094&ena=Majestic+Roofing+Pty+Ltd&estr=620+Victoria+Rd&esu=Ermington%2C+NSW%2C+2115&productVersion=4&productId=999015890674&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMajestic+Roofing+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.812645%26lon%3D151.060094%26selectedViewMode%3Dlist&yellowId=15162954",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=620+Victoria+Rd&context=undefined&directionMode=true&elat=-33.812645&elon=151.060094&ena=Majestic+Roofing+Pty+Ltd&estr=620+Victoria+Rd&esu=Ermington%2C+NSW%2C+2115&productVersion=4&productId=999015890674&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMajestic+Roofing+Pty+Ltd%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.812645%26lon%3D151.060094%26selectedViewMode%3Dlist&yellowId=15162954",
                                                "anchor_text": "620 Victoria Rd, Ermington, NSW, 2115"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 8812 5243",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Kangaroof Australia",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Parramatta, NSW 2150",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Kangaroof Australia",
                                        "url": "https://www.yellowpages.com.au/nsw/parramatta/kangaroof-australia-1000002839273-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/parramatta/kangaroof-australia-1000002839273-listing.html",
                                                "anchor_text": "Kangaroof Australia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "6 Grandview St, Parramatta, NSW, 2150",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=6+Grandview+St&context=undefined&directionMode=true&elat=-33.81033&elon=151.01957&ena=Kangaroof+Australia&estr=6+Grandview+St&esu=Parramatta%2C+NSW%2C+2150&productVersion=1&productId=1000002839273&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DKangaroof+Australia%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.81033%26lon%3D151.01957%26selectedViewMode%3Dlist&yellowId=1000002839273",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=6+Grandview+St&context=undefined&directionMode=true&elat=-33.81033&elon=151.01957&ena=Kangaroof+Australia&estr=6+Grandview+St&esu=Parramatta%2C+NSW%2C+2150&productVersion=1&productId=1000002839273&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DKangaroof+Australia%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.81033%26lon%3D151.01957%26selectedViewMode%3Dlist&yellowId=1000002839273",
                                                "anchor_text": "6 Grandview St, Parramatta, NSW, 2150"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0403 944 466",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Glidevale Roofing Materials",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Silverwater, NSW 2128",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Glidevale Roofing Materials",
                                        "url": "https://www.yellowpages.com.au/nsw/silverwater/glidevale-roofing-materials-15608679-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/silverwater/glidevale-roofing-materials-15608679-listing.html",
                                                "anchor_text": "Glidevale Roofing Materials"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "38 Asquith St, Silverwater, NSW, 2128",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=38+Asquith+St&context=undefined&directionMode=true&elat=-33.83851&elon=151.04054&ena=Glidevale+Roofing+Materials&estr=38+Asquith+St&esu=Silverwater%2C+NSW%2C+2128&productVersion=3&productId=999016190581&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGlidevale+Roofing+Materials%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.83851%26lon%3D151.04054%26selectedViewMode%3Dlist&yellowId=15608679",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=38+Asquith+St&context=undefined&directionMode=true&elat=-33.83851&elon=151.04054&ena=Glidevale+Roofing+Materials&estr=38+Asquith+St&esu=Silverwater%2C+NSW%2C+2128&productVersion=3&productId=999016190581&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGlidevale+Roofing+Materials%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.83851%26lon%3D151.04054%26selectedViewMode%3Dlist&yellowId=15608679",
                                                "anchor_text": "38 Asquith St, Silverwater, NSW, 2128"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9748 4422",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "T P Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Ryde, NSW 2112",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "T P Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/ryde/t-p-roofing-13524729-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ryde/t-p-roofing-13524729-listing.html",
                                                "anchor_text": "T P Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9888 6454",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Alex Waterproofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Ryde, NSW 2112",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Alex Waterproofing",
                                        "url": "https://www.yellowpages.com.au/nsw/ryde/alex-waterproofing-15078772-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ryde/alex-waterproofing-15078772-listing.html",
                                                "anchor_text": "Alex Waterproofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9808 3685",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Glidevale Roofing Materials",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Lidcombe, NSW 2141",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Glidevale Roofing Materials",
                                        "url": "https://www.yellowpages.com.au/nsw/lidcombe/glidevale-roofing-materials-13074164-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/lidcombe/glidevale-roofing-materials-13074164-listing.html",
                                                "anchor_text": "Glidevale Roofing Materials"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "17 Wetherill St South, Lidcombe, NSW, 2141",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=17+Wetherill+St+South&context=undefined&directionMode=true&elat=-33.845042&elon=151.045449&ena=Glidevale+Roofing+Materials&estr=17+Wetherill+St+South&esu=Lidcombe%2C+NSW%2C+2141&productVersion=4&productId=999901284068&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGlidevale+Roofing+Materials%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.845042%26lon%3D151.045449%26selectedViewMode%3Dlist&yellowId=13074164",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=17+Wetherill+St+South&context=undefined&directionMode=true&elat=-33.845042&elon=151.045449&ena=Glidevale+Roofing+Materials&estr=17+Wetherill+St+South&esu=Lidcombe%2C+NSW%2C+2141&productVersion=4&productId=999901284068&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGlidevale+Roofing+Materials%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.845042%26lon%3D151.045449%26selectedViewMode%3Dlist&yellowId=13074164",
                                                "anchor_text": "17 Wetherill St South, Lidcombe, NSW, 2141"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9748 4422",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pinnacle Roofing Group",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Kellyville, NSW 2155",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pinnacle Roofing Group",
                                        "url": "https://www.yellowpages.com.au/nsw/kellyville/pinnacle-roofing-group-1000002325530-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/kellyville/pinnacle-roofing-group-1000002325530-listing.html",
                                                "anchor_text": "Pinnacle Roofing Group"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0424 509 268",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Bazz Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Berala, NSW 2141",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Bazz Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/berala/bazz-roofing-1000002874182-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/berala/bazz-roofing-1000002874182-listing.html",
                                                "anchor_text": "Bazz Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open 24 hours",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0449 988 805",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "ZD Metal Roofing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Chiswick, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "ZD Metal Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/chiswick/zd-metal-roofing-1000001778161-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/chiswick/zd-metal-roofing-1000001778161-listing.html",
                                                "anchor_text": "ZD Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open by appt",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0458 776 505",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Robert Pridmore Roofing - Repairs, Maintenance & Repointing | Hornsby",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Hornsby, NSW 2077",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Robert Pridmore Roofing - Repairs, Maintenance & Repointing | Hornsby",
                                        "url": "https://www.yellowpages.com.au/nsw/hornsby/robert-pridmore-roofing-repairs-maintenance-repointing-hornsby-1000002999673-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/hornsby/robert-pridmore-roofing-repairs-maintenance-repointing-hornsby-1000002999673-listing.html",
                                                "anchor_text": "Robert Pridmore Roofing - Repairs, Maintenance & Repointing | Hornsby"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Level 1 22-28 Edgeworth David Ave, Hornsby, NSW, 2077",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Level+1+22-28+Edgeworth+David+Ave&context=undefined&directionMode=true&elat=-33.70629&elon=151.103221&ena=Robert+Pridmore+Roofing+-+Repairs%2C+Maintenance+%26+Repointing+%7C+Hornsby&estr=Level+1+22-28+Edgeworth+David+Ave&esu=Hornsby%2C+NSW%2C+2077&productVersion=1&productId=1000002999673&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRobert+Pridmore+Roofing+-+Repairs%2C+Maintenance+%26+Repointing+%7C+Hornsby%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.70629%26lon%3D151.103221%26selectedViewMode%3Dlist&yellowId=1000002999673",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Level+1+22-28+Edgeworth+David+Ave&context=undefined&directionMode=true&elat=-33.70629&elon=151.103221&ena=Robert+Pridmore+Roofing+-+Repairs%2C+Maintenance+%26+Repointing+%7C+Hornsby&estr=Level+1+22-28+Edgeworth+David+Ave&esu=Hornsby%2C+NSW%2C+2077&productVersion=1&productId=1000002999673&ref=ypgd&referredBy=undefined&str=Carlingford%2C+NSW+2118&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRobert+Pridmore+Roofing+-+Repairs%2C+Maintenance+%26+Repointing+%7C+Hornsby%26locationClue%3DCarlingford%2C+NSW+2118%26lat%3D-33.70629%26lon%3D151.103221%26selectedViewMode%3Dlist&yellowId=1000002999673",
                                                "anchor_text": "Level 1 22-28 Edgeworth David Ave, Hornsby, NSW, 2077"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0483 228 613",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "RANDWICK METAL ROOFING",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Concord, NSW 2137",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "RANDWICK METAL ROOFING",
                                        "url": "https://www.yellowpages.com.au/sup/randwick-metal-roofing-1000002160798-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/randwick-metal-roofing-1000002160798-listing.html",
                                                "anchor_text": "RANDWICK METAL ROOFING"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0405 705 625",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Average rating for Roofing Construction & Services in Carlingford and surrounding suburbs",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Based on 730 reviews of 157 businesses on this page",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Nearby Locations for Roofing Contractors & Services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular Categories in Carlingford",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Categories in Carlingford",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tai Irwin Plumbing & Draining",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Emergency Plumbing & Gasfitting 24/7 - Northern Beaches & North Shore",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9191 8784",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "A Class Plumbing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Reliable, Professional Industrial & Commercial Specialists",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9630 4227",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Blacktown Industrial Plumbing",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Backflow Prevention Commercial Specialists",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9679 0110",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Eco Wool Insulation Services",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Insulation Installers & Contractors",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "0481 845 529",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our directory.",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Yellow Pages",
                                        "url": "https://www.yellowpages.com.au/pages/about-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/about-us",
                                                "anchor_text": "About Yellow Pages"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://www.yellowpages.com.au/pages/contact-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/contact-us",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Site Index",
                                        "url": "https://www.yellowpages.com.au/sitemap",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sitemap",
                                                "anchor_text": "Site Index"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Order or cancel your book",
                                        "url": "https://www.directoryselect.com.au/action/home",
                                        "urls": [
                                            {
                                                "url": "https://www.directoryselect.com.au/action/home",
                                                "anchor_text": "Order or cancel your book"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our advertising.",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Get a free listing",
                                        "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                                "anchor_text": "Get a free listing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Digital marketing solutions",
                                        "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                                "anchor_text": "Digital marketing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Business hub",
                                        "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                                "anchor_text": "Business hub"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "myYellow login",
                                        "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                                "anchor_text": "myYellow login"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Connect with us.",
                                "main_title": "35 BEST local Roofing Contractors & Services in Carlingford NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Thryv Australia",
                                        "url": "https://corporate.thryv.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/",
                                                "anchor_text": "About Thryv Australia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://corporate.thryv.com/privacy/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com/privacy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://corporate.thryv.com.au/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.2,
                                "max_rating_value": 5,
                                "rating_count": 730,
                                "relative_rating": 0.8400000000000001
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 8310 5101",
                                "13 1178",
                                "(02) 8015 2301",
                                "(02) 8376 1451",
                                "0431 555 964",
                                "(02) 9807 3322",
                                "(02) 9894 5137",
                                "0484 900 507",
                                "0434 747 245",
                                "(02) 9674 4556",
                                "0412 360 304",
                                "0437 272 916",
                                "(02) 9654 6000",
                                "1800 101 064",
                                "(02) 8812 5243",
                                "0403 944 466",
                                "0461 382 366",
                                "(02) 9748 4422",
                                "(02) 9888 6454",
                                "(02) 9808 3685",
                                "(02) 9838 8730",
                                "0418 678 630",
                                "1300 138 813",
                                "0424 509 268",
                                "0451 799 875",
                                "0449 988 805",
                                "0408 411 341",
                                "0420 972 072",
                                "0458 776 505",
                                "0405 270 844",
                                "(02) 9888 9672",
                                "0438 255 801",
                                "0483 228 613",
                                "0405 705 625",
                                "0431555964",
                                "0298073322",
                                "0298945137",
                                "0484900507",
                                "0434747245",
                                "0296744556",
                                "0412360304",
                                "0437272916",
                                "0296546000",
                                "1800101064",
                                "0288125243",
                                "0403944466",
                                "0461382366",
                                "0297484422",
                                "0298886454",
                                "0298083685",
                                "0298388730",
                                "0418678630",
                                "1300138813",
                                "0424509268",
                                "0451799875",
                                "0449988805",
                                "0408411341",
                                "0420972072",
                                "0458776505",
                                "0405270844",
                                "0298889672",
                                "0438255801",
                                "0483228613",
                                "0405705625",
                                "0287838022",
                                "1300556541",
                                "0248713355",
                                "1300654884",
                                "0291918784",
                                "0296304227",
                                "0732743344",
                                "0296790110",
                                "0481845529",
                                "0358214399",
                                "0246488111"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}