{
    "id": "01190728-1132-0216-0000-2375cdcb488d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0305 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.abcseamless.com.au/hills-district/carlingford-court",
        "target": "www.abcseamless.com.au",
        "start_url": "https://www.abcseamless.com.au/hills-district/carlingford-court",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg20_ra24_abcseamless.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:43 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Home +",
                                    "url": "https://www.abcseamless.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://www.abcseamless.com.au/",
                                            "anchor_text": "Home +"
                                        }
                                    ]
                                },
                                {
                                    "text": "Aluminium Guttering & Downpipes",
                                    "url": "https://www.abcseamless.com.au/hills-district/guttering_downpipes.htm",
                                    "urls": [
                                        {
                                            "url": "https://www.abcseamless.com.au/hills-district/guttering_downpipes.htm",
                                            "anchor_text": "Aluminium Guttering & Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Range",
                                    "url": "https://www.abcseamless.com.au/hills-district/gutter_range.htm",
                                    "urls": [
                                        {
                                            "url": "https://www.abcseamless.com.au/hills-district/gutter_range.htm",
                                            "anchor_text": "Gutter Range"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Gutters",
                                    "url": "https://www.abcseamless.com.au/hills-district/box.htm",
                                    "urls": [
                                        {
                                            "url": "https://www.abcseamless.com.au/hills-district/box.htm",
                                            "anchor_text": "Box Gutters"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing +",
                                    "url": "https://www.abcseamless.com.au/hills-district/roofing.htm",
                                    "urls": [
                                        {
                                            "url": "https://www.abcseamless.com.au/hills-district/roofing.htm",
                                            "anchor_text": "Metal Roofing +"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration +",
                                    "url": "https://www.abcseamless.com.au/hills-district/roof_restoration.htm",
                                    "urls": [
                                        {
                                            "url": "https://www.abcseamless.com.au/hills-district/roof_restoration.htm",
                                            "anchor_text": "Roof Restoration +"
                                        }
                                    ]
                                },
                                {
                                    "text": "Watertanks +",
                                    "url": "https://www.abcseamless.com.au/hills-district/rainwatertanks.htm",
                                    "urls": [
                                        {
                                            "url": "https://www.abcseamless.com.au/hills-district/rainwatertanks.htm",
                                            "anchor_text": "Watertanks +"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leafguard +",
                                    "url": "https://www.abcseamless.com.au/hills-district/leafguard.htm",
                                    "urls": [
                                        {
                                            "url": "https://www.abcseamless.com.au/hills-district/leafguard.htm",
                                            "anchor_text": "Leafguard +"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact +",
                                    "url": "https://www.abcseamless.com.au/hills-district/enquiries.htm",
                                    "urls": [
                                        {
                                            "url": "https://www.abcseamless.com.au/hills-district/enquiries.htm",
                                            "anchor_text": "Contact +"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Are you located in the Carlingford Court area and need your gutters and downpipes replaced, restoration completed, a new metal roof or leaf protection products (including leafguard and gutter guard).",
                                "main_title": "Service Areas - Carlingford Court",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Well, look no further! ABC Seamless is the largest supplier and installer of rainwater products servicing the Carlingford Court area.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With over 50 years operating in the gutter market, ABC Seamless offer not only a quality product at an affordable price, but also a reliable and family friendly service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ABC Seamless specialise in prepainted continuous Aluminium guttering, rolled seamlessly on site. Some of the benefits of our guttering include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No leaks at joints",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Completely rustproof and will not crack or go brittle",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Low front, high back ensure that your house is protected from overflow and blockages",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive warranties covering workmanship and material",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ABC Seamless also specialise in:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restoration \u2013 ABC Seamless are the best in the business when it comes to roof cleaning and roof painting both Tile Roofing and Terracotta Roofing. By restoring your roof we will bring your old roof back to its former glory and increase its longevity. We use a premium cleaning and painting system in all of our roof restorations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal Roofing - ABC Seamless is a distributor and recommended installer of Australia\u2019s leading roofing products. Our engineer can correctly specify the most suitable and structurally sound colorbond metal roof or zincalume metal roof to fit your house or commercial property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaf Protection Products \u2013 ABC Seamless offer all different types of leaf protection to best suit your home. We install Aluminium leafguard, gutterseal and gutter guard in a variety of colours. Our gutter guard is approved by the CSIRO and is available in high density PVC and Aluminium gutter mesh.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whirlybirds - ABC Seamless supplies and installs all types of whirlybirds (including the Turbo Ventilator which has an Aerodynamic Propellor Fan) to help cool your house in summer and remove moist and damp air in winter.",
                                        "url": "https://www.abcseamless.com.au/ventilators.htm",
                                        "urls": [
                                            {
                                                "url": "https://www.abcseamless.com.au/ventilators.htm",
                                                "anchor_text": "Whirlybirds"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Watertanks - ABC Seamless offer several types of rainwater tanks (including Slimline) to meet specific needs. All water tanks carry substantial warranties and are made from UV stabilized food grade polyethylene. ABC Seamless offer the clever Slimline Water Tank called the Brain Tank which has an internal pump and a large 2500 litre capacity.",
                                        "url": "https://www.abcseamless.com.au/rainwatertanks.htm",
                                        "urls": [
                                            {
                                                "url": "https://www.abcseamless.com.au/rainwatertanks.htm",
                                                "anchor_text": "Watertanks"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Are you located in the Carlingford Court area and need your gutters and downpipes replaced, restoration completed, a new metal roof or leaf protection products (including leafguard and gutter guard).",
                                        "url": "https://www.abcseamless.com.au/hills-district/guttering.htm",
                                        "urls": [
                                            {
                                                "url": "https://www.abcseamless.com.au/hills-district/guttering.htm",
                                                "anchor_text": "gutters and downpipes replaced"
                                            },
                                            {
                                                "url": "https://www.abcseamless.com.au/hills-district/roof_restoration.htm",
                                                "anchor_text": "restoration completed"
                                            },
                                            {
                                                "url": "https://www.abcseamless.com.au/hills-district/roofing.htm",
                                                "anchor_text": "metal roof"
                                            },
                                            {
                                                "url": "https://www.abcseamless.com.au/hills-district/leafguard.htm",
                                                "anchor_text": "leaf protection products (including leafguard and gutter guard)"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Service Areas - Carlingford Court",
                                "main_title": "Service Areas - Carlingford Court",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Product Warranty",
                                        "url": "https://www.abcseamless.com.au/hills-district/product_warranty.htm",
                                        "urls": [
                                            {
                                                "url": "https://www.abcseamless.com.au/hills-district/product_warranty.htm",
                                                "anchor_text": "Product Warranty"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Product Warranty",
                                        "url": "https://www.abcseamless.com.au/hills-district/product_warranty.htm",
                                        "urls": [
                                            {
                                                "url": "https://www.abcseamless.com.au/hills-district/product_warranty.htm",
                                                "anchor_text": "Product Warranty"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Copyright 2020. ABC Seamless. All Rights Reserved.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Carlingford Court",
                                "main_title": "Service Areas - Carlingford Court",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Request a Free Quote",
                                        "url": "https://www.abcseamless.com.au/hills-district/enquiries.htm",
                                        "urls": [
                                            {
                                                "url": "https://www.abcseamless.com.au/hills-district/enquiries.htm",
                                                "anchor_text": "Request a Free Quote"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "ABC Seamless",
                                "main_title": "Service Areas - Carlingford Court",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "The Rainwater Solution Specialists for all your residential and commercial applications.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "About Us",
                                "main_title": "Service Areas - Carlingford Court",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "ABC Seamless are the Rainwater Solution Specialists. We supply Rainwater Tanks, Guttering, Downpipes, Metal Roofing, Roof Restoration and Leafguard products for residential and commercial applications.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Quick Contact",
                                "main_title": "Service Areas - Carlingford Court",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Phone: (02) 9748 3022",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fax: (02) 9748 3687",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email: abc@abcseamless.com.au",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Services",
                                "main_title": "Service Areas - Carlingford Court",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Service Areas",
                                "main_title": "Service Areas - Carlingford Court",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61 (02) 9748 3022",
                                "0297483022"
                            ],
                            "emails": [
                                "abc@abcseamless.com.au?Subject=Website Enquiry"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}