{
    "id": "01190728-1132-0216-0000-1a4998b5727b",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0174 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-carlingford/",
        "target": "roofrestorationblacktown.com.au",
        "start_url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-carlingford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg14_ra18_roofrestorationblacktown.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:43 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Roof Restoration Blacktown",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Blacktown NSW 2148 Australia",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a92026\u00a0Roof Restoration Blacktown",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Phone: (02) 9186 3998",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Hours: 24/7 Service Available",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrestorationblacktown.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestorationblacktown.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrestorationblacktown.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestorationblacktown.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://roofrestorationblacktown.com.au/privacy/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestorationblacktown.com.au/privacy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://roofrestorationblacktown.com.au/terms/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestorationblacktown.com.au/terms/",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Professional Roofing Services in Carlingford",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roof Restoration Blacktown, we bring top-notch roofing expertise straight to Carlingford\u2019s doorsteps. From heritage terracotta tiles on Federation-style homes to sleek modern metal roofs on newer developments, our team tackles every roof type with precision and care. You\u2019ll find our spartan approach\u2014focusing on what truly matters\u2014combined with a casual, straightforward attitude that makes the process smooth and transparent.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Carlingford\u2019s climate and architecture throw a few curveballs at local roofs:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Thermal expansion in terracotta leads to cracked tiles and slipped ridges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Heavy rain and occasional hailstorms can overwhelm gutters and valleys",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Acidic run-off in some pockets causes early corrosion on metal sheeting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Understanding these common local issues means we tailor restorations, repointing and gutter maintenance to suit the suburb\u2019s specific demands, ensuring longer service life and fewer surprises down the track.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For Carlingford residents and businesses, a sound roof isn\u2019t just about shelter\u2014it\u2019s about protecting your investment and reducing energy bills in NSW\u2019s varied seasons. With years of hands-on experience, our skilled professionals stay up-to-date with City of Parramatta building standards and heritage guidelines, delivering durable, weatherproof solutions that stand the test of time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tailored Roofing Solutions for Carlingford Properties",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to Roof Restoration Blacktown working in Carlingford, we cover everything from metal roof replacements on modern townhouses to heritage tile repointing for Federation-style homes. Our offerings include: roof inspections, sarking installations, gutter guard fitting, flashing replacements and full-scale roof restorations. Familiar with Carlingford\u2019s mix of steep tiled roofs and low-pitch steel sheets, we match materials to each property\u2019s style and local climate demands.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We follow a streamlined Carlingford roofing process that ticks every box on safety, quality and local compliance:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Thorough on-site assessment against City of Parramatta standards",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Transparent quotation detailing materials, labour and timelines",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Use of premium products (Colorbond\u00ae, high-grade terracotta, marine-grade flashings)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Professional installation with certified installers and scaffolding",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Final quality check, ensuring weatherproof seals and neat finishes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Every project is backed by our commitment to premium materials and adherence to heritage guidelines where required. Whether it\u2019s a minor tile repair or a complete roof transformation, our casual, no-nonsense approach keeps you informed and your roof performing for years to come.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Carlingford\u2019s Top Pick for Rock-Solid Roofing",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With Roof Restoration Blacktown on the job, you\u2019re tapping into Blacktown\u2019s most trusted experts for complete roof restorations & replacements \u2014right here in Carlingford. Our team knows every twist of Federation terracotta, every pitch of steel sheeting, and the City of Parramatta regulations that come with them. We keep things straightforward: honest quotes, punctual crews and no hidden costs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What sets us apart from the run-of-the-mill roofers?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Deep local insight into Carlingford\u2019s weather patterns and heritage guidelines",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Use of premium materials (Colorbond\u00ae, marine-grade flashings, high-grade terracotta)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Fully insured and compliant installations, backed by safety-first protocols",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Transparent breakdowns of labour, materials and timelines\u2014no surprises",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "On top of our hands-on know-how, every project carries a comprehensive workmanship warranty alongside manufacturer guarantees. That means your roof isn\u2019t just patched up\u2014it\u2019s reinforced to handle hailstorms, heavy downpours and the full NSW seasonal cycle. When durability and peace of mind matter, Carlingford households and businesses turn to a local team that delivers on its word.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Transparent Roof Pricing for Carlingford Homes",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Investing in a roof restoration is more than an upfront figure\u2014it\u2019s about lasting value, durability and peace of mind. In Carlingford, elements like heritage tile repairs, pitch complexity and compliance with City of Parramatta guidelines all shape the final quote. Our focus is on delivering premium materials, expert workmanship and no hidden fees, so you know exactly what you\u2019re paying for.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Key factors that influence pricing include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Roof size and pitch (steep or low-sloping profiles)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Choice of materials (terracotta, Colorbond\u00ae, marine-grade flashings)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Heritage requirements or strata building controls",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Additional services (sarking, gutter guard installations, skylight fittings)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our process begins with a detailed on-site inspection to assess each roof\u2019s condition against local standards. From there, we provide a clear, itemised quote covering labour, materials and compliance costs. This level of transparency helps Carlingford homeowners budget confidently and avoid unwelcome surprises down the track.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "By opting for long-lasting solutions\u2014such as premium tile repointing or high-performance metal sheeting\u2014you not only protect your property but also optimise energy efficiency. Upfront investment in quality roofing often translates into lower maintenance outlays, reduced repair call-outs and calmer runs through NSW\u2019s seasonal swings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Commitment to Quality Roofing Services in Carlingford",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roof Restoration Blacktown, our commitment to quality shines through every step of the Carlingford roofing process. From the initial site inspection to the final ridge capping, we uphold City of Parramatta building standards and heritage guidelines, ensuring each project meets local regulations. Our spartan approach means no fluff\u2014just rigorous checks, premium materials and skilled workmanship that stands up to Carlingford\u2019s seasonal swings.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With years of experience across Blacktown and surrounds, our team brings proven expertise to every tile and sheet we install. We continually invest in training, safety protocols and the latest roofing technologies, so your home or business benefits from:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Certified installers who follow strict safety and quality protocols",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Use of premium materials like Colorbond\u00ae steel, high-grade terracotta and marine-grade flashings",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Detailed post-installation inspections to guarantee weatherproofing and neat finishes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "This blend of local insight and technical know-how has earned us a reputation for exceptional customer satisfaction in Carlingford. We stand firmly behind our work with comprehensive workmanship warranties, giving you peace of mind that your roof is built to last in NSW\u2019s varied climate.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Key Takeaways for Carlingford Roof Restorations",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Keeping a Carlingford roof in top shape means more than patching leaks\u2014it\u2019s about long-term protection against NSW\u2019s seasonal swings and preserving your home\u2019s value. With Roof Restoration Blacktown at the helm, you get a local team versed in City of Parramatta heritage guidelines and modern roofing standards. Our approach blends spartan, no-nonsense workmanship with a laid-back, clear-cut style that locals appreciate.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Here\u2019s what sets our roofing services in Carlingford apart:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Premium materials tailored to the suburb\u2019s mix of terracotta tiles and Colorbond\u00ae steel",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Skilled, certified installers who follow strict safety and compliance checks",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Comprehensive workmanship warranties alongside manufacturer guarantees",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Energy-saving outcomes that lower bills and boost thermal comfort",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "By choosing solutions built for Carlingford\u2019s roofs, you ensure dependable weatherproofing, reduced maintenance calls and lasting curb appeal. That\u2019s the kind of peace of mind every homeowner and business deserves.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Carlingford Roofing FAQs: Your Top Questions Answered",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Whether it\u2019s tile repairs on a Federation home or a full metal roof replacement, Carlingford properties bring unique challenges. Below are the most common queries about our roofing services in Carlingford, covering cost factors, timelines and compliance with local regulations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q: What drives the cost of a roof restoration in Carlingford?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Several elements shape the final quote\u2014roof size, pitch and material choice top the list. Heritage guidelines under the City of Parramatta may require specialised labour or approvals, while accessibility (steep roofs, narrow side-access) can add to labour time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Key cost factors include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Roof area and slope complexity",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Choice of materials (Colorbond\u00ae, high-grade terracotta)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Heritage or strata compliance work",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Additional services like sarking, gutter guard installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q: Can you handle heritage-tiled roofs in Carlingford?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. Our team specialises in heritage roof repairs & maintenance, from careful tile removal to expert repointing and ridge capping. All work aligns with local heritage guidelines, preserving the character of older homes while boosting durability.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q: How long does a typical restoration take?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Most single-storey homes complete a full restoration\u2014inspection to final quality check\u2014in 3\u20135 days, weather permitting. Larger or heritage-listed properties may require extra time for specialised approvals and more intricate tile work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q: Are restorations backed by a warranty?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes. Every project from Roof Restoration Blacktown includes a comprehensive workmanship warranty alongside manufacturer guarantees on materials. That means peace of mind through Carlingford\u2019s seasonal cycles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q: Which suburbs around Carlingford do you cover?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We service Carlingford and the wider Blacktown area, including Eastwood, North Rocks and Dundas. Whether it\u2019s a quick tile patch or a full-scale replacement, our Monday\u2013Saturday availability ensures minimal disruption.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Finished reviewing these FAQs? Our detailed service pages dive deeper into each topic, helping you weigh up options for tile or metal work, gutter maintenance and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get Started with Our Roofing Services in Carlingford",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Embarking on a roof restoration in Carlingford is more straightforward than you\u2019d expect. At Roof Restoration Blacktown, every step\u2014from site assessment to final inspection\u2014aligns with City of Parramatta heritage and building standards, delivering clarity and confidence from day one.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Here\u2019s how our streamlined kick-off unfolds:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Tailored on-site assessment for Carlingford\u2019s mix of heritage tiles and modern steel sheeting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Transparent, itemised quote covering materials, labour and local compliance costs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Flexible scheduling that works around seasonal weather and your daily routine",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Selection of premium Colorbond\u00ae or high-grade terracotta, backed by manufacturer guarantees",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No two roofs are the same\u2014whether you\u2019re restoring a Federation-style home or upgrading a new townhouse, our certified installers handle every detail with precision. Monday\u2013Saturday, 7 am\u20135 pm: (02) 9186 3998 | [email\u00a0protected]",
                                        "url": "https://roofrestorationblacktown.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get in Touch with Us Today",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For a comprehensive overview of our services, call us today on (02) 9186 3998. For more information about us, visit our homepage or for more information on our other areas we service, please visit our locations page.",
                                        "url": "https://roofrestorationblacktown.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/",
                                                "anchor_text": "homepage"
                                            },
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/",
                                                "anchor_text": "locations page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Services in Carlingford",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Service Locations:",
                                "main_title": "Roofing Services in Carlingford",
                                "author": "Roof Restoration Blacktown",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Acacia Gardens",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-acacia-gardens/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-acacia-gardens/",
                                                "anchor_text": "Acacia Gardens"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Arndell Park",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-arndell-park/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-arndell-park/",
                                                "anchor_text": "Arndell Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Constitution Hill",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-constitution-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-constitution-hill/",
                                                "anchor_text": "Constitution Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dean Park",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-dean-park/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-dean-park/",
                                                "anchor_text": "Dean Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dundas Valley",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-dundas-valley/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-dundas-valley/",
                                                "anchor_text": "Dundas Valley"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Guildford West",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-guildford-west/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-guildford-west/",
                                                "anchor_text": "Guildford West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Harris Park",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-harris-park/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-harris-park/",
                                                "anchor_text": "Harris Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hassall Grove",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-hassall-grove/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-hassall-grove/",
                                                "anchor_text": "Hassall Grove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kellyville Ridge",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-kellyville-ridge/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-kellyville-ridge/",
                                                "anchor_text": "Kellyville Ridge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kings Langley",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-kings-langley/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-kings-langley/",
                                                "anchor_text": "Kings Langley"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kings Park",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-kings-park/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-kings-park/",
                                                "anchor_text": "Kings Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lalor Park",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-lalor-park/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-lalor-park/",
                                                "anchor_text": "Lalor Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lethbridge Park",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-lethbridge-park/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-lethbridge-park/",
                                                "anchor_text": "Lethbridge Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Marsden Park",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-marsden-park/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-marsden-park/",
                                                "anchor_text": "Marsden Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mays Hill",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-mays-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-mays-hill/",
                                                "anchor_text": "Mays Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Merrylands West",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-merrylands-west/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-merrylands-west/",
                                                "anchor_text": "Merrylands West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Druitt",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-mount-druitt/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-mount-druitt/",
                                                "anchor_text": "Mount Druitt"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Parramatta",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-north-parramatta/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-north-parramatta/",
                                                "anchor_text": "North Parramatta"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Rocks",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-north-rocks/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-north-rocks/",
                                                "anchor_text": "North Rocks"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Old Guildford",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-old-guildford/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-old-guildford/",
                                                "anchor_text": "Old Guildford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pendle Hill",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-pendle-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-pendle-hill/",
                                                "anchor_text": "Pendle Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Quakers Hill",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-quakers-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-quakers-hill/",
                                                "anchor_text": "Quakers Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rooty Hill",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-rooty-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-rooty-hill/",
                                                "anchor_text": "Rooty Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Ropes Crossing",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-ropes-crossing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-ropes-crossing/",
                                                "anchor_text": "Ropes Crossing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Seven Hills",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-seven-hills/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-seven-hills/",
                                                "anchor_text": "Seven Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "South Granville",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-south-granville/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-south-granville/",
                                                "anchor_text": "South Granville"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "South Wentworthville",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-south-wentworthville/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-south-wentworthville/",
                                                "anchor_text": "South Wentworthville"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Stanhope Gardens",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-stanhope-gardens/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-stanhope-gardens/",
                                                "anchor_text": "Stanhope Gardens"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Ponds",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-the-ponds/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-the-ponds/",
                                                "anchor_text": "The Ponds"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wentworth Point",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-wentworth-point/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-wentworth-point/",
                                                "anchor_text": "Wentworth Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Winston Hills",
                                        "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-winston-hills/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestorationblacktown.com.au/locations/roofing-services-in-winston-hills/",
                                                "anchor_text": "Winston Hills"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 9186 3998",
                                "+61291863998"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}