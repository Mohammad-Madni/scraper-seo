{
    "id": "01190728-1132-0216-0000-11571f722758",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0341 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://duravex.com.au/roofing-services-carlingford/",
        "target": "duravex.com.au",
        "start_url": "https://duravex.com.au/roofing-services-carlingford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg18_ra22_duravex.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:29 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "NSW Fair Trading License 466515C",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://duravex.com.au/service/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Tile Roof Restoration",
                                    "url": "https://duravex.com.au/service/terracotta-tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/terracotta-tile-roof-restoration/",
                                            "anchor_text": "Terracotta Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Condition Report",
                                    "url": "https://duravex.com.au/service/roof-condition-report/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/roof-condition-report/",
                                            "anchor_text": "Roof Condition Report"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://duravex.com.au/service/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heat Reflective Roof Paint Coatings",
                                    "url": "https://duravex.com.au/service/heat-reflective-roof-paint-coatings/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/heat-reflective-roof-paint-coatings/",
                                            "anchor_text": "Heat Reflective Roof Paint Coatings"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cement Tile Roof Restoration",
                                    "url": "https://duravex.com.au/service/cement-tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/cement-tile-roof-restoration/",
                                            "anchor_text": "Cement Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://duravex.com.au/service/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Sealing Services Sydney",
                                    "url": "https://duravex.com.au/services/roof-sealing-services-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/roof-sealing-services-sydney/",
                                            "anchor_text": "Roof Sealing Services Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "High Pressure Cleaning Services",
                                    "url": "https://duravex.com.au/services/high-pressure-cleaning-services/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/high-pressure-cleaning-services/",
                                            "anchor_text": "High Pressure Cleaning Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "COLORBOND Steel Gutters, Fascias & Downpipes Replacement & Installations Services",
                                    "url": "https://duravex.com.au/service/colorbond-steel-gutters-fascias-downpipes-replacement-installations-services/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/colorbond-steel-gutters-fascias-downpipes-replacement-installations-services/",
                                            "anchor_text": "COLORBOND Steel Gutters, Fascias & Downpipes Replacement & Installations Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration Sydney \u2013 Industrial and Commercial Metal Roofing Installation",
                                    "url": "https://duravex.com.au/service/metal-roofing-sydney-industrial-and-commercial-metal-roofing-installation/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/metal-roofing-sydney-industrial-and-commercial-metal-roofing-installation/",
                                            "anchor_text": "Metal Roof Restoration Sydney \u2013 Industrial and Commercial Metal Roofing Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Monier Roofing, Roof Restoration Specialist",
                                    "url": "https://duravex.com.au/service/monier-roofing-roof-restoration-maintenance-specialist-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/monier-roofing-roof-restoration-maintenance-specialist-sydney/",
                                            "anchor_text": "Monier Roofing, Roof Restoration Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration & Repairs",
                                    "url": "https://duravex.com.au/services/roof-restoration-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/roof-restoration-repairs/",
                                            "anchor_text": "Roof Restoration & Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement & Installation",
                                    "url": "https://duravex.com.au/services/roof-replacement-installation/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/roof-replacement-installation/",
                                            "anchor_text": "Roof Replacement & Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Restoration",
                                    "url": "https://duravex.com.au/services/commercial-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/commercial-roof-restoration/",
                                            "anchor_text": "Commercial Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Installation",
                                    "url": "https://duravex.com.au/services/commercial-roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/commercial-roof-installation/",
                                            "anchor_text": "Commercial Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney\u2019s Commercial and Industrial Roofing",
                                    "url": "https://duravex.com.au/services/sydneys-commercial-and-industrial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/sydneys-commercial-and-industrial-roofing/",
                                            "anchor_text": "Sydney\u2019s Commercial and Industrial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://duravex.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "New and Re-roofing",
                                    "url": "https://duravex.com.au/new-and-re-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/new-and-re-roofing/",
                                            "anchor_text": "New and Re-roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Gutter Repair",
                                    "url": "https://duravex.com.au/box-gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/box-gutter-repair/",
                                            "anchor_text": "Box Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fibreglass Roof Replacment",
                                    "url": "https://duravex.com.au/fibreglass-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/fibreglass-roof-replacement/",
                                            "anchor_text": "Fibreglass Roof Replacment"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://duravex.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heat Reflective Roof Coatings",
                                    "url": "https://duravex.com.au/heat-reflective-roof-coatings/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/heat-reflective-roof-coatings/",
                                            "anchor_text": "Heat Reflective Roof Coatings"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://duravex.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing Coatings",
                                    "url": "https://duravex.com.au/roofing-coatings/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/roofing-coatings/",
                                            "anchor_text": "Roofing Coatings"
                                        }
                                    ]
                                },
                                {
                                    "text": "Warehouse Roofing",
                                    "url": "https://duravex.com.au/warehouse-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/warehouse-roofing/",
                                            "anchor_text": "Warehouse Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repair",
                                    "url": "https://duravex.com.au/leaking-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/leaking-roof-repair/",
                                            "anchor_text": "Leaking Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulux Acratex\u00ae Colour Chart",
                                    "url": "https://duravex.com.au/dulux-acratex-roof-paint-colour-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/dulux-acratex-roof-paint-colour-chart/",
                                            "anchor_text": "Dulux Acratex\u00ae Colour Chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "COLORBOND\u00ae steel Colour Chart",
                                    "url": "https://duravex.com.au/colorbond-steel-color-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/colorbond-steel-color-chart/",
                                            "anchor_text": "COLORBOND\u00ae steel Colour Chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "InfraCOOL\u00ae Pastel Range",
                                    "url": "https://duravex.com.au/infracool-pastel-range/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/infracool-pastel-range/",
                                            "anchor_text": "InfraCOOL\u00ae Pastel Range"
                                        }
                                    ]
                                },
                                {
                                    "text": "InfraCOOL\u00ae Traditional Range",
                                    "url": "https://duravex.com.au/infracool-traditional-range/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/infracool-traditional-range/",
                                            "anchor_text": "InfraCOOL\u00ae Traditional Range"
                                        }
                                    ]
                                },
                                {
                                    "text": "COLORBOND\u00ae Colour Chart",
                                    "url": "https://duravex.com.au/colorbond-colour-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/colorbond-colour-chart/",
                                            "anchor_text": "COLORBOND\u00ae Colour Chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulux Avista Sealer Colours",
                                    "url": "https://duravex.com.au/dulux-avista-sealer-colours/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/dulux-avista-sealer-colours/",
                                            "anchor_text": "Dulux Avista Sealer Colours"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tilemaster colour chart",
                                    "url": "https://duravex.com.au/tilemaster-colour-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/tilemaster-colour-chart/",
                                            "anchor_text": "Tilemaster colour chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Globalcote Colour chart",
                                    "url": "https://duravex.com.au/globalcote-color-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/globalcote-color-chart/",
                                            "anchor_text": "Globalcote Colour chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Nutech Paint Colour Chart",
                                    "url": "https://duravex.com.au/nutech-paint-colour-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/nutech-paint-colour-chart/",
                                            "anchor_text": "Nutech Paint Colour Chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Shield coat Colour chart",
                                    "url": "https://duravex.com.au/shield-coat-color-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/shield-coat-color-chart/",
                                            "anchor_text": "Shield coat Colour chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulux Acratex\u00ae Cool Roof Commercial Colour Card",
                                    "url": "https://duravex.com.au/dulux-acratex-cool-roof-commercial-colour-card/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/dulux-acratex-cool-roof-commercial-colour-card/",
                                            "anchor_text": "Dulux Acratex\u00ae Cool Roof Commercial Colour Card"
                                        }
                                    ]
                                },
                                {
                                    "text": "Selleys Pointworks Roof Pointing Color Chart",
                                    "url": "https://duravex.com.au/selleys-pointworks-roof-pointing-color-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/selleys-pointworks-roof-pointing-color-chart/",
                                            "anchor_text": "Selleys Pointworks Roof Pointing Color Chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulux Acratex 962",
                                    "url": "https://duravex.com.au/dulux-acratex-962/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/dulux-acratex-962/",
                                            "anchor_text": "Dulux Acratex 962"
                                        }
                                    ]
                                },
                                {
                                    "text": "Duravex Roofing Group Maintenance",
                                    "url": "https://duravex.com.au/duravex-roofing-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/duravex-roofing-maintenance/",
                                            "anchor_text": "Duravex Roofing Group Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Duravex Roofing Group Solution",
                                    "url": "https://duravex.com.au/roofing-solution/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/roofing-solution/",
                                            "anchor_text": "Duravex Roofing Group Solution"
                                        }
                                    ]
                                },
                                {
                                    "text": "Duravex Re Roofing",
                                    "url": "https://duravex.com.au/duravex-re-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/duravex-re-roofing/",
                                            "anchor_text": "Duravex Re Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulux Acratex\u00ae Roofing",
                                    "url": "https://duravex.com.au/product-category/dulux/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/dulux/",
                                            "anchor_text": "Dulux Acratex\u00ae Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Nutech Paint",
                                    "url": "https://duravex.com.au/product-category/nutech-paint/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/nutech-paint/",
                                            "anchor_text": "Nutech Paint"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bailey Fall Protection Range",
                                    "url": "https://duravex.com.au/bailey-fall-protection-range/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/bailey-fall-protection-range/",
                                            "anchor_text": "Bailey Fall Protection Range"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashing Range",
                                    "url": "https://duravex.com.au/product-category/flashing-range/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/flashing-range/",
                                            "anchor_text": "Flashing Range"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repair",
                                    "url": "https://duravex.com.au/product-category/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing and Wall Cladding",
                                    "url": "https://duravex.com.au/product-category/roofing-and-wall-cladding/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/roofing-and-wall-cladding/",
                                            "anchor_text": "Roofing and Wall Cladding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Architectural Cladding",
                                    "url": "https://duravex.com.au/product-category/architectural-cladding/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/architectural-cladding/",
                                            "anchor_text": "Architectural Cladding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashings & Rainwater",
                                    "url": "https://duravex.com.au/product-category/flashings-rainwater/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/flashings-rainwater/",
                                            "anchor_text": "Flashings & Rainwater"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colour Visualizer",
                                    "url": "https://duravex.com.au/colour-visualizer/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/colour-visualizer/",
                                            "anchor_text": "Colour Visualizer"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://duravex.com.au/service/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Tile Roof Restoration",
                                    "url": "https://duravex.com.au/service/terracotta-tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/terracotta-tile-roof-restoration/",
                                            "anchor_text": "Terracotta Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Condition Report",
                                    "url": "https://duravex.com.au/service/roof-condition-report/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/roof-condition-report/",
                                            "anchor_text": "Roof Condition Report"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://duravex.com.au/service/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heat Reflective Roof Paint Coatings",
                                    "url": "https://duravex.com.au/service/heat-reflective-roof-paint-coatings/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/heat-reflective-roof-paint-coatings/",
                                            "anchor_text": "Heat Reflective Roof Paint Coatings"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cement Tile Roof Restoration",
                                    "url": "https://duravex.com.au/service/cement-tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/cement-tile-roof-restoration/",
                                            "anchor_text": "Cement Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://duravex.com.au/service/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Sealing Services Sydney",
                                    "url": "https://duravex.com.au/services/roof-sealing-services-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/roof-sealing-services-sydney/",
                                            "anchor_text": "Roof Sealing Services Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "High Pressure Cleaning Services",
                                    "url": "https://duravex.com.au/services/high-pressure-cleaning-services/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/high-pressure-cleaning-services/",
                                            "anchor_text": "High Pressure Cleaning Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "COLORBOND Steel Gutters, Fascias & Downpipes Replacement & Installations Services",
                                    "url": "https://duravex.com.au/service/colorbond-steel-gutters-fascias-downpipes-replacement-installations-services/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/colorbond-steel-gutters-fascias-downpipes-replacement-installations-services/",
                                            "anchor_text": "COLORBOND Steel Gutters, Fascias & Downpipes Replacement & Installations Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration Sydney \u2013 Industrial and Commercial Metal Roofing Installation",
                                    "url": "https://duravex.com.au/service/metal-roofing-sydney-industrial-and-commercial-metal-roofing-installation/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/metal-roofing-sydney-industrial-and-commercial-metal-roofing-installation/",
                                            "anchor_text": "Metal Roof Restoration Sydney \u2013 Industrial and Commercial Metal Roofing Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Monier Roofing, Roof Restoration Specialist",
                                    "url": "https://duravex.com.au/service/monier-roofing-roof-restoration-maintenance-specialist-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/service/monier-roofing-roof-restoration-maintenance-specialist-sydney/",
                                            "anchor_text": "Monier Roofing, Roof Restoration Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration & Repairs",
                                    "url": "https://duravex.com.au/services/roof-restoration-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/roof-restoration-repairs/",
                                            "anchor_text": "Roof Restoration & Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement & Installation",
                                    "url": "https://duravex.com.au/services/roof-replacement-installation/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/roof-replacement-installation/",
                                            "anchor_text": "Roof Replacement & Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Restoration",
                                    "url": "https://duravex.com.au/services/commercial-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/commercial-roof-restoration/",
                                            "anchor_text": "Commercial Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roof Installation",
                                    "url": "https://duravex.com.au/services/commercial-roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/commercial-roof-installation/",
                                            "anchor_text": "Commercial Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney\u2019s Commercial and Industrial Roofing",
                                    "url": "https://duravex.com.au/services/sydneys-commercial-and-industrial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/services/sydneys-commercial-and-industrial-roofing/",
                                            "anchor_text": "Sydney\u2019s Commercial and Industrial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://duravex.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "New and Re-roofing",
                                    "url": "https://duravex.com.au/new-and-re-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/new-and-re-roofing/",
                                            "anchor_text": "New and Re-roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Gutter Repair",
                                    "url": "https://duravex.com.au/box-gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/box-gutter-repair/",
                                            "anchor_text": "Box Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fibreglass Roof Replacment",
                                    "url": "https://duravex.com.au/fibreglass-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/fibreglass-roof-replacement/",
                                            "anchor_text": "Fibreglass Roof Replacment"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://duravex.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heat Reflective Roof Coatings",
                                    "url": "https://duravex.com.au/heat-reflective-roof-coatings/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/heat-reflective-roof-coatings/",
                                            "anchor_text": "Heat Reflective Roof Coatings"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://duravex.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing Coatings",
                                    "url": "https://duravex.com.au/roofing-coatings/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/roofing-coatings/",
                                            "anchor_text": "Roofing Coatings"
                                        }
                                    ]
                                },
                                {
                                    "text": "Warehouse Roofing",
                                    "url": "https://duravex.com.au/warehouse-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/warehouse-roofing/",
                                            "anchor_text": "Warehouse Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repair",
                                    "url": "https://duravex.com.au/leaking-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/leaking-roof-repair/",
                                            "anchor_text": "Leaking Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulux Acratex\u00ae Colour Chart",
                                    "url": "https://duravex.com.au/dulux-acratex-roof-paint-colour-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/dulux-acratex-roof-paint-colour-chart/",
                                            "anchor_text": "Dulux Acratex\u00ae Colour Chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "COLORBOND\u00ae steel Colour Chart",
                                    "url": "https://duravex.com.au/colorbond-steel-color-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/colorbond-steel-color-chart/",
                                            "anchor_text": "COLORBOND\u00ae steel Colour Chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "InfraCOOL\u00ae Pastel Range",
                                    "url": "https://duravex.com.au/infracool-pastel-range/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/infracool-pastel-range/",
                                            "anchor_text": "InfraCOOL\u00ae Pastel Range"
                                        }
                                    ]
                                },
                                {
                                    "text": "InfraCOOL\u00ae Traditional Range",
                                    "url": "https://duravex.com.au/infracool-traditional-range/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/infracool-traditional-range/",
                                            "anchor_text": "InfraCOOL\u00ae Traditional Range"
                                        }
                                    ]
                                },
                                {
                                    "text": "COLORBOND\u00ae Colour Chart",
                                    "url": "https://duravex.com.au/colorbond-colour-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/colorbond-colour-chart/",
                                            "anchor_text": "COLORBOND\u00ae Colour Chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulux Avista Sealer Colours",
                                    "url": "https://duravex.com.au/dulux-avista-sealer-colours/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/dulux-avista-sealer-colours/",
                                            "anchor_text": "Dulux Avista Sealer Colours"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tilemaster colour chart",
                                    "url": "https://duravex.com.au/tilemaster-colour-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/tilemaster-colour-chart/",
                                            "anchor_text": "Tilemaster colour chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Globalcote Colour chart",
                                    "url": "https://duravex.com.au/globalcote-color-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/globalcote-color-chart/",
                                            "anchor_text": "Globalcote Colour chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Nutech Paint Colour Chart",
                                    "url": "https://duravex.com.au/nutech-paint-colour-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/nutech-paint-colour-chart/",
                                            "anchor_text": "Nutech Paint Colour Chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Shield coat Colour chart",
                                    "url": "https://duravex.com.au/shield-coat-color-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/shield-coat-color-chart/",
                                            "anchor_text": "Shield coat Colour chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulux Acratex\u00ae Cool Roof Commercial Colour Card",
                                    "url": "https://duravex.com.au/dulux-acratex-cool-roof-commercial-colour-card/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/dulux-acratex-cool-roof-commercial-colour-card/",
                                            "anchor_text": "Dulux Acratex\u00ae Cool Roof Commercial Colour Card"
                                        }
                                    ]
                                },
                                {
                                    "text": "Selleys Pointworks Roof Pointing Color Chart",
                                    "url": "https://duravex.com.au/selleys-pointworks-roof-pointing-color-chart/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/selleys-pointworks-roof-pointing-color-chart/",
                                            "anchor_text": "Selleys Pointworks Roof Pointing Color Chart"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulux Acratex 962",
                                    "url": "https://duravex.com.au/dulux-acratex-962/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/dulux-acratex-962/",
                                            "anchor_text": "Dulux Acratex 962"
                                        }
                                    ]
                                },
                                {
                                    "text": "Duravex Roofing Group Maintenance",
                                    "url": "https://duravex.com.au/duravex-roofing-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/duravex-roofing-maintenance/",
                                            "anchor_text": "Duravex Roofing Group Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Duravex Roofing Group Solution",
                                    "url": "https://duravex.com.au/roofing-solution/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/roofing-solution/",
                                            "anchor_text": "Duravex Roofing Group Solution"
                                        }
                                    ]
                                },
                                {
                                    "text": "Duravex Re Roofing",
                                    "url": "https://duravex.com.au/duravex-re-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/duravex-re-roofing/",
                                            "anchor_text": "Duravex Re Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dulux Acratex\u00ae Roofing",
                                    "url": "https://duravex.com.au/product-category/dulux/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/dulux/",
                                            "anchor_text": "Dulux Acratex\u00ae Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Nutech Paint",
                                    "url": "https://duravex.com.au/product-category/nutech-paint/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/nutech-paint/",
                                            "anchor_text": "Nutech Paint"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bailey Fall Protection Range",
                                    "url": "https://duravex.com.au/bailey-fall-protection-range/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/bailey-fall-protection-range/",
                                            "anchor_text": "Bailey Fall Protection Range"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashing Range",
                                    "url": "https://duravex.com.au/product-category/flashing-range/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/flashing-range/",
                                            "anchor_text": "Flashing Range"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repair",
                                    "url": "https://duravex.com.au/product-category/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofing and Wall Cladding",
                                    "url": "https://duravex.com.au/product-category/roofing-and-wall-cladding/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/roofing-and-wall-cladding/",
                                            "anchor_text": "Roofing and Wall Cladding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Architectural Cladding",
                                    "url": "https://duravex.com.au/product-category/architectural-cladding/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/architectural-cladding/",
                                            "anchor_text": "Architectural Cladding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashings & Rainwater",
                                    "url": "https://duravex.com.au/product-category/flashings-rainwater/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/product-category/flashings-rainwater/",
                                            "anchor_text": "Flashings & Rainwater"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colour Visualizer",
                                    "url": "https://duravex.com.au/colour-visualizer/",
                                    "urls": [
                                        {
                                            "url": "https://duravex.com.au/colour-visualizer/",
                                            "anchor_text": "Colour Visualizer"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": null,
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Carlingford",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Best Active Experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "years experience working",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "happy clients",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "projects done",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our Skills",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://duravex.com.au/service/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terracotta Tile Roof Restoration",
                                        "url": "https://duravex.com.au/service/terracotta-tile-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/terracotta-tile-roof-restoration/",
                                                "anchor_text": "Terracotta Tile Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Condition Report",
                                        "url": "https://duravex.com.au/service/roof-condition-report/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/roof-condition-report/",
                                                "anchor_text": "Roof Condition Report"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roof Restoration",
                                        "url": "https://duravex.com.au/service/metal-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/metal-roof-restoration/",
                                                "anchor_text": "Metal Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Heat Reflective Roof Paint Coatings",
                                        "url": "https://duravex.com.au/service/heat-reflective-roof-paint-coatings/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/heat-reflective-roof-paint-coatings/",
                                                "anchor_text": "Heat Reflective Roof Paint Coatings"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cement Tile Roof Restoration",
                                        "url": "https://duravex.com.au/service/cement-tile-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/cement-tile-roof-restoration/",
                                                "anchor_text": "Cement Tile Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://duravex.com.au/service/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/roof-painting/",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Sealing Services Sydney",
                                        "url": "https://duravex.com.au/services/roof-sealing-services-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/services/roof-sealing-services-sydney/",
                                                "anchor_text": "Roof Sealing Services Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "High Pressure Cleaning Services",
                                        "url": "https://duravex.com.au/services/high-pressure-cleaning-services/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/services/high-pressure-cleaning-services/",
                                                "anchor_text": "High Pressure Cleaning Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "COLORBOND Steel Gutters, Fascias & Downpipes Replacement & Installations Services",
                                        "url": "https://duravex.com.au/service/colorbond-steel-gutters-fascias-downpipes-replacement-installations-services/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/colorbond-steel-gutters-fascias-downpipes-replacement-installations-services/",
                                                "anchor_text": "COLORBOND Steel Gutters, Fascias & Downpipes Replacement & Installations Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roof Restoration Sydney \u2013 Industrial and Commercial Metal Roofing Installation",
                                        "url": "https://duravex.com.au/service/metal-roofing-sydney-industrial-and-commercial-metal-roofing-installation/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/metal-roofing-sydney-industrial-and-commercial-metal-roofing-installation/",
                                                "anchor_text": "Metal Roof Restoration Sydney \u2013 Industrial and Commercial Metal Roofing Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Monier Roofing, Roof Restoration Specialist",
                                        "url": "https://duravex.com.au/service/monier-roofing-roof-restoration-maintenance-specialist-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/monier-roofing-roof-restoration-maintenance-specialist-sydney/",
                                                "anchor_text": "Monier Roofing, Roof Restoration Specialist"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://duravex.com.au/services/roof-restoration-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/services/roof-restoration-repairs/",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement & Installation",
                                        "url": "https://duravex.com.au/services/roof-replacement-installation/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/services/roof-replacement-installation/",
                                                "anchor_text": "Roof Replacement & Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roof Restoration",
                                        "url": "https://duravex.com.au/services/commercial-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/services/commercial-roof-restoration/",
                                                "anchor_text": "Commercial Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roof Installation",
                                        "url": "https://duravex.com.au/services/commercial-roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/services/commercial-roof-installation/",
                                                "anchor_text": "Commercial Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney\u2019s Commercial and Industrial Roofing",
                                        "url": "https://duravex.com.au/services/sydneys-commercial-and-industrial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/services/sydneys-commercial-and-industrial-roofing/",
                                                "anchor_text": "Sydney\u2019s Commercial and Industrial Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://duravex.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roof-repairs/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "New and Re-roofing",
                                        "url": "https://duravex.com.au/new-and-re-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/new-and-re-roofing/",
                                                "anchor_text": "New and Re-roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Box Gutter Repair",
                                        "url": "https://duravex.com.au/box-gutter-repair/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/box-gutter-repair/",
                                                "anchor_text": "Box Gutter Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Fibreglass Roof Replacment",
                                        "url": "https://duravex.com.au/fibreglass-roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/fibreglass-roof-replacement/",
                                                "anchor_text": "Fibreglass Roof Replacment"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://duravex.com.au/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Heat Reflective Roof Coatings",
                                        "url": "https://duravex.com.au/heat-reflective-roof-coatings/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/heat-reflective-roof-coatings/",
                                                "anchor_text": "Heat Reflective Roof Coatings"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://duravex.com.au/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Coatings",
                                        "url": "https://duravex.com.au/roofing-coatings/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roofing-coatings/",
                                                "anchor_text": "Roofing Coatings"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Warehouse Roofing",
                                        "url": "https://duravex.com.au/warehouse-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/warehouse-roofing/",
                                                "anchor_text": "Warehouse Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof Repair",
                                        "url": "https://duravex.com.au/leaking-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/leaking-roof-repair/",
                                                "anchor_text": "Leaking Roof Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulux Acratex\u00ae Colour Chart",
                                        "url": "https://duravex.com.au/dulux-acratex-roof-paint-colour-chart/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/dulux-acratex-roof-paint-colour-chart/",
                                                "anchor_text": "Dulux Acratex\u00ae Colour Chart"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "COLORBOND\u00ae steel Colour Chart",
                                        "url": "https://duravex.com.au/colorbond-steel-color-chart/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/colorbond-steel-color-chart/",
                                                "anchor_text": "COLORBOND\u00ae steel Colour Chart"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "InfraCOOL\u00ae Pastel Range",
                                        "url": "https://duravex.com.au/infracool-pastel-range/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/infracool-pastel-range/",
                                                "anchor_text": "InfraCOOL\u00ae Pastel Range"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "InfraCOOL\u00ae Traditional Range",
                                        "url": "https://duravex.com.au/infracool-traditional-range/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/infracool-traditional-range/",
                                                "anchor_text": "InfraCOOL\u00ae Traditional Range"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "COLORBOND\u00ae Colour Chart",
                                        "url": "https://duravex.com.au/colorbond-colour-chart/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/colorbond-colour-chart/",
                                                "anchor_text": "COLORBOND\u00ae Colour Chart"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulux Avista Sealer Colours",
                                        "url": "https://duravex.com.au/dulux-avista-sealer-colours/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/dulux-avista-sealer-colours/",
                                                "anchor_text": "Dulux Avista Sealer Colours"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tilemaster colour chart",
                                        "url": "https://duravex.com.au/tilemaster-colour-chart/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/tilemaster-colour-chart/",
                                                "anchor_text": "Tilemaster colour chart"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Globalcote Colour chart",
                                        "url": "https://duravex.com.au/globalcote-color-chart/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/globalcote-color-chart/",
                                                "anchor_text": "Globalcote Colour chart"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Nutech Paint Colour Chart",
                                        "url": "https://duravex.com.au/nutech-paint-colour-chart/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/nutech-paint-colour-chart/",
                                                "anchor_text": "Nutech Paint Colour Chart"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Shield coat Colour chart",
                                        "url": "https://duravex.com.au/shield-coat-color-chart/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/shield-coat-color-chart/",
                                                "anchor_text": "Shield coat Colour chart"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulux Acratex\u00ae Cool Roof Commercial Colour Card",
                                        "url": "https://duravex.com.au/dulux-acratex-cool-roof-commercial-colour-card/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/dulux-acratex-cool-roof-commercial-colour-card/",
                                                "anchor_text": "Dulux Acratex\u00ae Cool Roof Commercial Colour Card"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Selleys Pointworks Roof Pointing Color Chart",
                                        "url": "https://duravex.com.au/selleys-pointworks-roof-pointing-color-chart/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/selleys-pointworks-roof-pointing-color-chart/",
                                                "anchor_text": "Selleys Pointworks Roof Pointing Color Chart"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulux Acratex 962",
                                        "url": "https://duravex.com.au/dulux-acratex-962/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/dulux-acratex-962/",
                                                "anchor_text": "Dulux Acratex 962"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Duravex Roofing Group Maintenance",
                                        "url": "https://duravex.com.au/duravex-roofing-maintenance/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/duravex-roofing-maintenance/",
                                                "anchor_text": "Duravex Roofing Group Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Duravex Roofing Group Solution",
                                        "url": "https://duravex.com.au/roofing-solution/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roofing-solution/",
                                                "anchor_text": "Duravex Roofing Group Solution"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Duravex Re Roofing",
                                        "url": "https://duravex.com.au/duravex-re-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/duravex-re-roofing/",
                                                "anchor_text": "Duravex Re Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulux Acratex\u00ae Roofing",
                                        "url": "https://duravex.com.au/product-category/dulux/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/product-category/dulux/",
                                                "anchor_text": "Dulux Acratex\u00ae Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Nutech Paint",
                                        "url": "https://duravex.com.au/product-category/nutech-paint/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/product-category/nutech-paint/",
                                                "anchor_text": "Nutech Paint"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bailey Fall Protection Range",
                                        "url": "https://duravex.com.au/bailey-fall-protection-range/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/bailey-fall-protection-range/",
                                                "anchor_text": "Bailey Fall Protection Range"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Flashing Range",
                                        "url": "https://duravex.com.au/product-category/flashing-range/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/product-category/flashing-range/",
                                                "anchor_text": "Flashing Range"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://duravex.com.au/product-category/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/product-category/roof-repair/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing and Wall Cladding",
                                        "url": "https://duravex.com.au/product-category/roofing-and-wall-cladding/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/product-category/roofing-and-wall-cladding/",
                                                "anchor_text": "Roofing and Wall Cladding"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Architectural Cladding",
                                        "url": "https://duravex.com.au/product-category/architectural-cladding/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/product-category/architectural-cladding/",
                                                "anchor_text": "Architectural Cladding"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Flashings & Rainwater",
                                        "url": "https://duravex.com.au/product-category/flashings-rainwater/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/product-category/flashings-rainwater/",
                                                "anchor_text": "Flashings & Rainwater"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Colour Visualizer",
                                        "url": "https://duravex.com.au/colour-visualizer/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/colour-visualizer/",
                                                "anchor_text": "Colour Visualizer"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Carlingford Roofing Services",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professional and Reasonably-Priced Carlingford Roofing Services",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "With over 20 years of experience, Duravex Roofing Group offers dependable and affordable roofing services in Carlingford. We work closely with clients to provide high-quality, cost-effective, and durable solutions tailored to their needs.",
                                        "url": "https://duravex.com.au/roofing-services-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roofing-services-sydney/",
                                                "anchor_text": "Duravex Roofing Group offers dependable and affordable roofing services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "If you\u2019ve noticed a roof problem and searched for \u201croofing Carlingford\u201d or \u201clocal roofers in Ryde,\u201d end your search with Duravex Roofing Group. We offer a wide variety of roofing solutions.",
                                        "url": "https://duravex.com.au/video/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/video/",
                                                "anchor_text": "roof"
                                            },
                                            {
                                                "url": "https://duravex.com.au/roofing-solution/",
                                                "anchor_text": "roofing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator Are The Carlingford Roofing Professionals. For over 20 Years, we have provided exceptional Roofing Carlingford services to residential and commercial properties.",
                                        "url": "https://duravex.com.au/duravex-roofing-approved-dulux-acratex-applicator/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/duravex-roofing-approved-dulux-acratex-applicator/",
                                                "anchor_text": "Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator"
                                            },
                                            {
                                                "url": "https://duravex.com.au/roof-painting-services-carlingford/",
                                                "anchor_text": "Roofing Carlingford services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "For reliable, professional, and affordable roofing contractors in Carlingford, choose us. We pride ourselves on outstanding customer service, expert roofing, and timely, budget-friendly project delivery.",
                                        "url": "https://duravex.com.au/roofing-services-gladesville/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roofing-services-gladesville/",
                                                "anchor_text": "affordable roofing contractors"
                                            },
                                            {
                                                "url": "https://duravex.com.au/service/monier-roofing-roof-restoration-maintenance-specialist-sydney/",
                                                "anchor_text": "expert roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Duravex Roofing Group, a Dulux Acratex Accredited Applicator, ensures top-quality work on your home or building. From basic maintenance to full replacements and restorations, our skilled craftsmen provide the finest roofing services in Carlingford.",
                                        "url": "https://duravex.com.au/roof-valley-replacement-know-when-its-time/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roof-valley-replacement-know-when-its-time/",
                                                "anchor_text": "Duravex Roofing Group"
                                            },
                                            {
                                                "url": "https://duravex.com.au/roofing-services-leetsvale-2/",
                                                "anchor_text": "roofing services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Select Us?",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "If you\u2019re looking for a professional roofing contractor who can provide roofing services in Carlingford at the best price, you\u2019ve come to the right location.",
                                        "url": "https://duravex.com.au/roofing-services-dunmore-2/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roofing-services-dunmore-2/",
                                                "anchor_text": "roofing services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We have over 20 years of experience in the roofing industry in Carlingford.",
                                        "url": "https://duravex.com.au/service/heat-reflective-roof-paint-coatings/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/heat-reflective-roof-paint-coatings/",
                                                "anchor_text": "roofing industry"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We possess all necessary credentials, licences, and insurance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All of our services utilise only the highest-quality materials.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We do the task correctly the first time. We take pride in the calibre of our services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Provide cost-effective services at reasonable rates.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Have more than 5-star Google reviews!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Is Your Roof So Important?",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Your roof is one of the most vital components of your home. It must be maintained properly to protect the entire property from natural hazards such as the sun, rain, wind, and water. While the structure\u2019s boundaries provide physical security, the roof protects the structure and its inhabitants from a broad spectrum of external factors.",
                                        "url": "https://duravex.com.au/product/roof-workers-kit-professional-fs13660/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/product/roof-workers-kit-professional-fs13660/",
                                                "anchor_text": "roof protects"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Like other building components, the roof undergoes wear and tear over time. Identify and maintain deterioration to prevent extensive damage. Remedy minor issues with roof repairs, address significant problems with roof restoration, and replace the roof if it sustains extensive damage.",
                                        "url": "https://duravex.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roof-repairs/",
                                                "anchor_text": "roof repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Looking For A Reliable And Cost-Effective Roofing Contractor in Carlingford?",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "For affordable, high-quality roofing services in Carlingford, choose Duravex Roofing Group, an Accredited Dulux Acratex Applicator. With over two decades of experience, we prioritize meeting customers\u2019 needs.",
                                        "url": "https://duravex.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/",
                                                "anchor_text": "Dulux Acratex"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Companies in Carlingford",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator has many years of experience providing residential roofing services in Carlingford. We have repaired and restored all Australian roof types. You can rely on Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator regardless of the work you wish to have done on your roof. We can do it much more efficiently and effectively than our competitors.",
                                        "url": "https://duravex.com.au/what-is-the-expected-lifespan-of-a-dulux-acratex-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/what-is-the-expected-lifespan-of-a-dulux-acratex-roof-restoration/",
                                                "anchor_text": "Roofing Group \u2013 Dulux Acratex"
                                            },
                                            {
                                                "url": "https://duravex.com.au/product/edge-type-roof-anchor-fs13776/",
                                                "anchor_text": "roof types"
                                            },
                                            {
                                                "url": "https://duravex.com.au/step-by-step-guide-for-dulux-acratex-terracotta-roof-restoration/",
                                                "anchor_text": "Roofing Group \u2013 Dulux Acratex"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "If you are searching for a roofing company that can provide you with a comprehensive selection of roofing solutions in Carlingford at the most competitive price, then we are the team for you. At Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator, we offer cost-effective services that consistently deliver quality and thorough work for all of our clients. We understand both roofs and consumers, and that\u2019s why we are the most affordable company in the industry.",
                                        "url": "https://duravex.com.au/skillion-roof-designs-a-comprehensive-guide-with-definition-examples-and-more/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/skillion-roof-designs-a-comprehensive-guide-with-definition-examples-and-more/",
                                                "anchor_text": "roofing company that can provide you with a comprehensive"
                                            },
                                            {
                                                "url": "https://duravex.com.au/roofing-services-dee-why-beach/",
                                                "anchor_text": "Duravex Roofing Group \u2013 Dulux"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "We Are Your Local Roofers in Carlingford.",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Along with the structural foundations, every roofer will tell you that a secure and impermeable roof is the single most essential part of your property, as it will keep you dry and safe regardless of what mother nature may bring. To obtain this peace of mind, it is imperative that all roofing work in Carlingford be performed by qualified and experienced roofers.",
                                        "url": "https://duravex.com.au/restoring-and-painting-steep-pitch-roofs-working-on-roofs-with-a-high-pitch/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/restoring-and-painting-steep-pitch-roofs-working-on-roofs-with-a-high-pitch/",
                                                "anchor_text": "roofing work"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Local Carlingford Roofers",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "As local roofers in Carlingford, we strive to provide the finest personalised services that no other competitor can match. This is how we have withstood the passage of time and remained at the forefront of Carlingford roofing. If you require additional information, our channels of communication are open. We will contact you as quickly as feasible to discuss the project and provide free inspections and estimates.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Select Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator for Your Roofing Requirements in Carlingford?",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator comprised of a team of experts and industry professionals who are here to protect your property with reliable, affordable, and high-quality roofing services in Carlingford. In Carlingford, we specialise in roofing services, including repairs, restorations, and replacements. Residents of Carlingford can rely on our team of roofing contractors to keep them dry, protected, and safe from the elements throughout the year. Our services range from fundamental advice and guidance to leaking roof repairs.",
                                        "url": "https://duravex.com.au/step-by-step-dulux-acratex-cement-tile-roof-restoration-guide/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/step-by-step-dulux-acratex-cement-tile-roof-restoration-guide/",
                                                "anchor_text": "Roofing Group \u2013 Dulux Acratex Accredited Applicator"
                                            },
                                            {
                                                "url": "https://duravex.com.au/roofing-services-berkshire-park/",
                                                "anchor_text": "roofing services"
                                            },
                                            {
                                                "url": "https://duravex.com.au/service/roof-painting/",
                                                "anchor_text": "roofing contractors"
                                            },
                                            {
                                                "url": "https://duravex.com.au/how-to-stop-leaking-roof-during-heavy-rain-tips-tricks-2/",
                                                "anchor_text": "leaking roof repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "At Duravex Roofing Group \u2013 Accredited Dulux Acratex Applicator. We strive to offer our consumers competitive services that are both adaptable and all-encompassing. Residents of Carlingford can place their trust in our dedicated and experienced team, driven by our passion and comprehensive expertise across all aspects of roofing. Our team consists of diligent industry veterans with years of experience. We are known for our professionalism, quality services, and punctuality when completing projects.",
                                        "url": "https://duravex.com.au/dulux-acratex-roof-membrane-a-complete-restoration-guide/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/dulux-acratex-roof-membrane-a-complete-restoration-guide/",
                                                "anchor_text": "Duravex Roofing Group \u2013 Accredited Dulux Acratex Applicator"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "When you contact Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator, you will speak directly with a roofing specialist in Carlingford who will take the time to understand your needs and provide you with expert guidance from the very first phone call. Dealing directly with the roofing specialist enables you to discuss the specifics of your project with the individual who will be carrying it out.",
                                        "url": "https://duravex.com.au/energy-efficient-commercial-roofing-what-you-need-to-know/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/energy-efficient-commercial-roofing-what-you-need-to-know/",
                                                "anchor_text": "Roofing Group \u2013 Dulux Acratex Accredited Applicator, you will speak directly with a roofing specialist in Carlingford"
                                            },
                                            {
                                                "url": "https://duravex.com.au/commercial-roofing-projects-case-studies-sydney/",
                                                "anchor_text": "project"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "This also results in a substantially lower price for you, as we do not carry the excessive overhead costs of operating sales and customer service departments, which are typically passed on to the customer. Therefore, we are able to offer the most competitive prices without sacrificing quality when it comes to Carlingford roofing services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us Right Now!",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "At Duravex Roofing Group \u2013 Accredited Dulux Acratex Applicator. We are proud of our track record of excellence, which demonstrates that we are the finest team for roofing services in Carlingford. Nothing makes us happier than when our customers are pleased with our commitment to superior service and customer satisfaction. If you require additional information, our channels of communication are open.",
                                        "url": "https://duravex.com.au/barge-boards-repair-or-replace-sydneys-experts/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/barge-boards-repair-or-replace-sydneys-experts/",
                                                "anchor_text": "Duravex Roofing Group"
                                            },
                                            {
                                                "url": "https://duravex.com.au/roofing-service-bilpin/",
                                                "anchor_text": "roofing services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our team consists of skilled roofers. We have the abilities necessary to restore and maintain your roof\u2019s optimal condition. We have experience with all forms of roofing and guttering for both commercial and residential properties. Our team is equiped to handle tasks of any magnitude, without underestimating the value of even the smallest endeavors.",
                                        "url": "https://duravex.com.au/roof-restoration-services-ashfield/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roof-restoration-services-ashfield/",
                                                "anchor_text": "restore and maintain your roof\u2019s"
                                            },
                                            {
                                                "url": "https://duravex.com.au/project/broughton-anglican-dulux-acratex-roof-restoration-project-case-study-and-report/",
                                                "anchor_text": "roofing and guttering for both commercial"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "If you are interested in an inspection and estimate for Carlingford roofing services, or if you simply have enquiries, please contact our experts today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Services",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professional and Reasonably-Priced Carlingford Roofing Services",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "With over 20 years of experience, Duravex Roofing Group offers dependable and affordable roofing services in Carlingford. We work closely with clients to provide high-quality, cost-effective, and durable solutions tailored to their needs.",
                                        "url": "https://duravex.com.au/roofing-services-pymble/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roofing-services-pymble/",
                                                "anchor_text": "Duravex Roofing Group"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "If you\u2019ve noticed a roof problem and searched for \u201croofing Carlingford\u201d or \u201clocal roofers in Ryde,\u201d end your search with Duravex Roofing Group. We offer a wide variety of roofing solutions.",
                                        "url": "https://duravex.com.au/testimonials/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/testimonials/",
                                                "anchor_text": "roof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator Are The Carlingford Roofing Professionals. For over 20 Years, we have provided exceptional Roofing Carlingford services to residential and commercial properties.",
                                        "url": "https://duravex.com.au/warranty-care/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/warranty-care/",
                                                "anchor_text": "Dulux Acratex"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "For reliable, professional, and affordable roofing contractors in Carlingford, choose us. We pride ourselves on outstanding customer service, expert roofing, and timely, budget-friendly project delivery.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Duravex Roofing Group, a Dulux Acratex Accredited Applicator, ensures top-quality work on your home or building. From basic maintenance to full replacements and restorations, our skilled craftsmen provide the finest roofing services in Carlingford.",
                                        "url": "https://duravex.com.au/roof-restoration-vs-roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roof-restoration-vs-roof-replacement/",
                                                "anchor_text": "maintenance to full replacements and restorations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Select Us?",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "If you\u2019re looking for a professional roofing contractor who can provide roofing services in Carlingford at the best price, you\u2019ve come to the right location.",
                                        "url": "https://duravex.com.au/roofing-services-clontarf/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roofing-services-clontarf/",
                                                "anchor_text": "roofing services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We have over 20 years of experience in the roofing industry in Carlingford.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We possess all necessary credentials, licences, and insurance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All of our services utilise only the highest-quality materials.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We do the task correctly the first time. We take pride in the calibre of our services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Provide cost-effective services at reasonable rates.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Have more than 5-star Google reviews!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Is Your Roof So Important?",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Your roof is one of the most vital components of your home. It must be maintained properly to protect the entire property from natural hazards such as the sun, rain, wind, and water. While the structure\u2019s boundaries provide physical security, the roof protects the structure and its inhabitants from a broad spectrum of external factors.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Like other building components, the roof undergoes wear and tear over time. Identify and maintain deterioration to prevent extensive damage. Remedy minor issues with roof repairs, address significant problems with roof restoration, and replace the roof if it sustains extensive damage.",
                                        "url": "https://duravex.com.au/roof-restoration-services-haberfield-2/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roof-restoration-services-haberfield-2/",
                                                "anchor_text": "roof restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Looking For A Reliable And Cost-Effective Roofing Contractor in Carlingford?",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "If you are looking for affordable roofing companies in Carlingford that provide high-quality services, you have come to the correct place. At Duravex Roofing Group \u2013 Accredited Dulux Acratex Applicator. We have been providing superior Carlingford roofing services for over two decades, and throughout the years we have prioritised providing customers with a service that genuinely meets their needs.",
                                        "url": "https://duravex.com.au/roofing-services-west-wollongong/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/roofing-services-west-wollongong/",
                                                "anchor_text": "roofing companies in Carlingford that provide high-quality services"
                                            },
                                            {
                                                "url": "https://duravex.com.au/roofing-services-westmead/",
                                                "anchor_text": "Duravex Roofing Group"
                                            },
                                            {
                                                "url": "https://duravex.com.au/roof-cleaning-services-in-carlingford-2/",
                                                "anchor_text": "Carlingford roofing services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Companies in Carlingford",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator has many years of experience providing residential roofing services in Carlingford. We have repaired and restored all Australian roof types. You can rely on Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator regardless of the work you wish to have done on your roof. We can do it much more efficiently and effectively than our competitors.",
                                        "url": "https://duravex.com.au/sydneys-terracotta-roof-tiles-repair-installation-and-restoration-services/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/sydneys-terracotta-roof-tiles-repair-installation-and-restoration-services/",
                                                "anchor_text": "repaired and restored all Australian roof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "If you are searching for a roofing company that can provide you with a comprehensive selection of roofing solutions in Carlingford at the most competitive price, then we are the team for you. At Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator, we offer cost-effective services that consistently deliver quality and thorough work for all of our clients. We understand both roofs and consumers, and that\u2019s why we are the most affordable company in the industry.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "We Are Your Local Roofers in Carlingford.",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Along with the structural foundations, every roofer will tell you that a secure and impermeable roof is the single most essential part of your property, as it will keep you dry and safe regardless of what mother nature may bring. To obtain this peace of mind, it is imperative that all roofing work in Carlingford be performed by qualified and experienced roofers.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Local Carlingford Roofers",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "As local roofers in Carlingford, we strive to provide the finest personalised services that no other competitor can match. This is how we have withstood the passage of time and remained at the forefront of Carlingford roofing. If you require additional information, our channels of communication are open. We will contact you as quickly as feasible to discuss the project and provide free inspections and estimates.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Select Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator for Your Roofing Requirements in Carlingford?",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator comprised of a team of experts and industry professionals who are here to protect your property with reliable, affordable, and high-quality roofing services in Carlingford. In Carlingford, we specialise in roofing services, including repairs, restorations, and replacements. Residents of Carlingford can rely on our team of roofing contractors to keep them dry, protected, and safe from the elements throughout the year. Our services range from fundamental advice and guidance to leaking roof repairs.",
                                        "url": "https://duravex.com.au/expert-colourbond-gutter-installation-guide-2/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/expert-colourbond-gutter-installation-guide-2/",
                                                "anchor_text": "Duravex Roofing Group"
                                            },
                                            {
                                                "url": "https://duravex.com.au/how-to-stop-leaking-roof-during-heavy-rain/",
                                                "anchor_text": "leaking roof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "At Duravex Roofing Group \u2013 Accredited Dulux Acratex Applicator. We strive to offer our consumers competitive services that are both adaptable and all-encompassing. Residents of Carlingford can place their trust in our dedicated and experienced team, driven by our passion and comprehensive expertise across all aspects of roofing. Our team consists of diligent industry veterans with years of experience. We are known for our professionalism, quality services, and punctuality when completing projects.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "When you contact Duravex Roofing Group \u2013 Dulux Acratex Accredited Applicator, you will speak directly with a roofing specialist in Carlingford who will take the time to understand your needs and provide you with expert guidance from the very first phone call. Dealing directly with the roofing specialist enables you to discuss the specifics of your project with the individual who will be carrying it out.",
                                        "url": "https://duravex.com.au/energy-efficient-commercial-roofing-what-you-need-to-know/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/energy-efficient-commercial-roofing-what-you-need-to-know/",
                                                "anchor_text": "Roofing Group \u2013 Dulux Acratex Accredited Applicator, you will speak directly with a roofing specialist in Carlingford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "This also results in a substantially lower price for you, as we do not carry the excessive overhead costs of operating sales and customer service departments, which are typically passed on to the customer. Therefore, we are able to offer the most competitive prices without sacrificing quality when it comes to Carlingford roofing services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us Right Now!",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "At Duravex Roofing Group \u2013 Accredited Dulux Acratex Applicator. We are proud of our track record of excellence, which demonstrates that we are the finest team for roofing services in Carlingford. Nothing makes us happier than when our customers are pleased with our commitment to superior service and customer satisfaction. If you require additional information, our channels of communication are open.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team consists of skilled roofers. We have the abilities necessary to restore and maintain your roof\u2019s optimal condition. We have experience with all forms of roofing and guttering for both commercial and residential properties. Our team is equiped to handle tasks of any magnitude, without underestimating the value of even the smallest endeavors.",
                                        "url": "https://duravex.com.au/service/roof-condition-report/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/service/roof-condition-report/",
                                                "anchor_text": "roof\u2019s optimal condition"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "If you are interested in an inspection and estimate for Carlingford roofing services, or if you simply have enquiries, please contact our experts today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Expert & Professionals",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We have 20+ Year of Experience in this field.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "High Quality Work",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We Deliver high quality work to our client",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "High Quality Work",
                                        "url": "https://demo.wpthemego.com/themes/sw_kontruk/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://demo.wpthemego.com/themes/sw_kontruk/about-us/",
                                                "anchor_text": "High Quality Work"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ontime Finishing",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We finish the work within given limited time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ontime Finishing",
                                        "url": "https://demo.wpthemego.com/themes/sw_kontruk/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://demo.wpthemego.com/themes/sw_kontruk/about-us/",
                                                "anchor_text": "Ontime Finishing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "24x7 Emergency",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our team are always available to hear from you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "24x7 Emergency",
                                        "url": "https://demo.wpthemego.com/themes/sw_kontruk/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://demo.wpthemego.com/themes/sw_kontruk/about-us/",
                                                "anchor_text": "24x7 Emergency"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Flexible Solutions",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide flexible solution for your unique requirements",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Flexible Solutions",
                                        "url": "https://demo.wpthemego.com/themes/sw_kontruk/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://demo.wpthemego.com/themes/sw_kontruk/about-us/",
                                                "anchor_text": "Flexible Solutions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted Brands",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Trusted Brands",
                                        "url": "https://demo.wpthemego.com/themes/sw_kontruk/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://demo.wpthemego.com/themes/sw_kontruk/about-us/",
                                                "anchor_text": "Trusted Brands"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are Trusted roofing services provider since 20+ year.",
                                        "url": "https://duravex.com.au/trusted-roof-painting-services-in-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://duravex.com.au/trusted-roof-painting-services-in-sydney/",
                                                "anchor_text": "Trusted roofing services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "With Our Skills We Guarantee Project Success!",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Let's Talk About Your Upcoming Project",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We are always in waiting to hear from you and we will be happy only if you will be happy from our service",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "NEW HERE?",
                                "main_title": "Roofing Carlingford",
                                "author": "https://www.facebook.com/duravex",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Registration is free and easy!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Faster checkout",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Save multiple shipping addresses",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "View and track orders and more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 45,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": [
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-07-16 21:00:00 +00:00",
                                "author": "John Chant",
                                "primary_content": [
                                    {
                                        "text": "Having made the decision to paint my roof the decision to use this company was quickly justified. From the beginning the quotation, accreditations, insurance, warranty, licensing documentation they provided was superior to the other quotation I received, and this was only the beginning. Their workmanship was everything I expected from them and there was no damage/mess to my property and my neighbours adjoining properties.\r\n\r\nIf you don\u2019t include them when you are looking for quotes you may well be disappointed",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-09-08 21:00:00 +00:00",
                                "author": "Stephen Chang",
                                "primary_content": [
                                    {
                                        "text": "The team at Duravex Roofing provided exceptional service. I have never had a better experience with a trade contractor. We recently engaged Duravex Roofing Group to replace our old tiled roof with a new Colorbond steel roof. They had previously worked with our neighbours on their metal roof. Installing a new Colorbond roof is an excellent way to improve street attractiveness, weather resistance, and house longevity. The Duravex team was professional, arrived on schedule, and kept the workspace neat throughout. Tile-to-tin roof conversions for homes are their specialty. I will use their services again and highly recommend them. Pam, Daniel, and the entire staff at Duravex Roofing, thank you!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-07-03 21:00:00 +00:00",
                                "author": "Tram M",
                                "primary_content": [
                                    {
                                        "text": "Excellent communication by roofing team \u2013 The excellent communication and meticulous planning immediately established a standard for professionalism and quality of the project",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-04-09 21:00:00 +00:00",
                                "author": "Jonathan",
                                "primary_content": [
                                    {
                                        "text": "Duravex Roofing crew performed the most comprehensive roof inspection and the Adam was the most knowledgeable roofer I have ever met .",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-04-09 21:00:00 +00:00",
                                "author": "Brendon lee",
                                "primary_content": [
                                    {
                                        "text": "The skilled roofing professionals at Duravex Roofing Group are highly recommended. The crew kept me informed throughout the process and were a pleasure to work with. Their Colorbond design and colour visualiser tips were helpful, and the roofing team replaced rusty guttering and installed a new Colorbond roof and guttering system that blended in well with the rest of the property. The work was finished promptly and without leaving any debris on the site. I have no complaints about the work that has been done and would gladly recommend it to my friends and relatives.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-02-29 22:00:00 +00:00",
                                "author": "Mathew Flare",
                                "primary_content": [
                                    {
                                        "text": "The Duravex Metal Roofing team completed a roof remediation project with a new Colorbond roof and guttering on my property. The Project methodology was well-communicated and implemented throughout the project, and the team was professional. We are delighted with the final product and grateful for the entire crew&#039;s efforts and delivered high-end detailed work. Duravex Metal Roofing is highly recommended for any future metal roofing projects. Their work speaks for itself in terms of quality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-08-10 21:00:00 +00:00",
                                "author": "John",
                                "primary_content": [
                                    {
                                        "text": "I hired Duravex roofing to make a new roof. They did a great job at a much lower cost than other companies projected. They are honest and thorough. I recommend the duravex highly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2019-09-03 21:00:00 +00:00",
                                "author": "Timeless Strata Group",
                                "primary_content": [
                                    {
                                        "text": "Duravex Roofing has been assisting us with Dulux Roof Restoration services across Greater Sydney Region \u2013 Duravex Roofing has been assisting us with Dulux Roof Restoration services and Roof &amp; Gutter repair services, and Roof Cleaning services for our client\u2019s investment properties for several years. The Roofing crew is reliable, competent, and professional, which is most crucial. In our opinion, Outstanding outcomes are delivered along with great services at a fair price. We could not possibly suggest a better business for any roofing jobs. With Regards, ( Timeless Strata Group )",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-02-07 22:00:00 +00:00",
                                "author": "Victor S",
                                "primary_content": [
                                    {
                                        "text": "Delighted to endorse a professional roofing company in sydney \u2013 Duravex Roofing Group is distinguished from competitors as the company allows you to communicate directly with professional roofers. The project manager or roofing professional will listen to your requirements and provide professional advice. Liaising with the roofing crew will permit you to review your project&#039;s details with the skilled roofer.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-02-29 22:00:00 +00:00",
                                "author": "Peter J",
                                "primary_content": [
                                    {
                                        "text": "I approached Duravex Roofing as well other companies to arrange a Dulux Acratex Roof Restoration for our house roof. I received several quotes from other companies. However, Duravex Roofing quote was drafted professionally, all key items mentioned and well drafted work methodology. Duravex Roofing crew were very professional to deal with from arranging the inspection and quote. The Project Manager Rob did final defect walk through and overseeing the works. The roofing crew was diligent, polite, and professional. Rob at the office deserves special recognition because he manages scheduling through challenging weather conditions and always kept me informed of the schedule. I choose Duravex Roofing because of the accredited Dulux Acratex applicator and high level of communication&amp; Professionalism. Highly recommended them as a top provider for Dulux Roofing in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-04-09 21:00:00 +00:00",
                                "author": "ALFRED DELLO",
                                "primary_content": [
                                    {
                                        "text": "Dulux AcraTex\u00ae Roof Membrane is the latest and most revolutionary roof covering from Dulux, with a 100 percent acrylic coating. This product facilitates application, improves gloss, and reduces chalking, ensuring that your paint colour remains vibrant, and your finish lasts longer. It is critical to choose an Accredited/licensed Applicator to apply this product since licenced companies have been schooled on typical roofing issues and their practical, real-world remedies in a hands-on environment.\r\nHere are a few reasons why hiring a licenced contractor to put Dulux AcraTex\u00ae Roof Membrane to your home is a good idea:\r\n\u2022 The application of Dulux AcraTex\u00ae Roof Membrane is simple.\r\n\u2022 The improved technology of Dulux AcraTex\u00ae Roof Membrane ensures greater outcomes.\r\n\u2022 You can customise the finish to fit your preferences.\r\n\r\nYour home\u2019s roof is continually exposed to harsh weather, from summer\u2019s searing UV rays to winter\u2019s torrential downpours. Dulux collaborated with applicators to optimise the product\u2019s application properties, resulting in a protective membrane that looks great on both tile and metal roofs and applies like regular paint.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-11-10 22:00:00 +00:00",
                                "author": "Helen N",
                                "primary_content": [
                                    {
                                        "text": "The communication and service were good, and the workmanship met our expectations. We find this company reliable, professional, and knowledgeable. We plan to use Duravex Roofing Services for future annual roof maintenance works. Thank you",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-07-03 21:00:00 +00:00",
                                "author": "Catherine Fitzpatrick",
                                "primary_content": [
                                    {
                                        "text": "Firstly, if I could award more stars then I would without any hesitation. I am so grateful I came across this Business whilst conducting my Google search. Romy goes above and beyond for his customers. I found him to be very friendly, professional, knowledgeable and with fantastic customer service skills, both in person and via the phone. I look forward to utilising Romy and his team again in the future.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-01-26 22:00:00 +00:00",
                                "author": "Krystine Pike",
                                "primary_content": [
                                    {
                                        "text": "Our strata manager recommended this company when we needed urgent Colorbond Roof, Gutter Box Repair, and Installation works for our commercial property roof. I must admit that their professionalism and situation-handling expertise astonished me. The staff arrived promptly, evaluated the issue, and gave me a comprehensive estimate. They were open and honest regarding the project cost and time needed to finish the repair and installation work. The team members worked quickly and courteously, taking all precautions to safely relocate the outdoor furniture and other vulnerable items. I was pleased with their work&#039;s calibre and effort to guarantee the roof repair and gutters work was done correctly. I recommend their services to anyone needing a trustworthy and knowledgeable roofing business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-10-21 21:00:00 +00:00",
                                "author": "Brendon Brown",
                                "primary_content": [
                                    {
                                        "text": "Duravex Roofing Group&#039;s attention to detail made them stand out in the home improvement industry. They offer a complete end-to-end Dulux Acratex Total Roof Restoration system. The team restored our house roof to like-new condition with Dulux Acratex Roof Restoration Service. Giving the roof a superb gloss and long-lasting protection. The roofing crew also cared for even the most minor details, like painting and repairing the eaves, whirlybirds, and fascia boards. In addition, the crew replaced forty to fifty roof tiles with remarkable expertise and devotion, protecting the integrity and longevity of our roof. They demonstrated their vision and dedication to perfection by painting fifteen spare replacement tiles. The outcomes clearly illustrate the situation. Our roof has never looked better, and the calibre of their work has completely changed how our house roof looks\u2014thanks to the Duravex Roofing Group crew.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2022-07-13 21:00:00 +00:00",
                                "author": "Tim Wilson",
                                "primary_content": [
                                    {
                                        "text": "The Duravex Roofing Team completed a full Dulux Acratex Roof Restoration service on our terracotta tile roof. The dedicated team of Approved roofing applicators replaced all the broken or cracked terracotta roof tiles and treated the roof with anti-mould, moss, fungal, and lichen removal concentrate. Hi-pressure roof cleaning using 4,000 psi of water pressure, repointing the roof ridges, sealing, priming, and finishing coat of Dulux Acratex Roof Membrane. We are incredibly happy with the roof transformation, and the crew\u2019s professionalism and workmanship are top-notch. Duravex Roofing comes highly recommended by us to anyone seeking a Dulux Roof Restoration service in the Greater Sydney region.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-07-07 21:00:00 +00:00",
                                "author": "Jerry lyn",
                                "primary_content": [
                                    {
                                        "text": "The staff at Duravex Roofing \u2013 Dulux Acratex accredited applicator is outstanding. we engaged them for Dulux Acratex Roof Membrane coating system project, and I must say that everything went quite smoothly. Duravex Roofing have experienced roofers. The crew aware of your preferences and offer excellent customer service. Duravex Roofing offered us with Roof Care &amp; Maintenance guide tips for our roof to help extend its life and assist in maintaining its optimal appearance, and everything is carried out in accordance with manufactures specifications.\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-10-19 21:00:00 +00:00",
                                "author": "Peter James",
                                "primary_content": [
                                    {
                                        "text": "I approached Duravex Roofing as well other companies to arrange a Dulux Acratex Roof Restoration for our house roof. I received several quotes from other companies. However, Duravex Roofing quote was drafted professionally, all key items mentioned and well drafted work methodology.\r\nDuravex Roofing crew were very professional to deal with from arranging the inspection and quote. The Project Manager Rob did final defect walk through and overseeing the works. The roofing crew was diligent, polite, and professional. Rob at the office deserves special recognition because he manages scheduling through challenging weather conditions and always kept me informed of the schedule. I choose Duravex Roofing because of the accredited Dulux Acratex applicator and high level of communication&amp; Professionalism.\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-06-08 21:00:00 +00:00",
                                "author": "GEORGE",
                                "primary_content": [
                                    {
                                        "text": "I can highly recommend the team at Duravex Roofing for their professional attitude and excellent workmanship in restoring our roof prior to a Solar Panel Installation. Duravex Roofing crew clearly explained the process up front and replied promptly when I had any questions. The friendly team maintained their professional attitude throughout the project, making sure the surrounding community was informed of the work and showcasing their superior skill and workmanship. WHAT\u2019S NOT TO LOVE! ... Looking for a Dulux Acratex Roof Membrane coating colour range to go with the exterior house colours you already have? Make Duravex Roofing your first choice for tile and metal Roof restoration, Roof renovation, Roof repairs, Roof cleaning, Roof sealing, Roof ridge pointing and roof painting.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-10-27 21:00:00 +00:00",
                                "author": "Si Moon",
                                "primary_content": [
                                    {
                                        "text": "We had a Dulux Acratex Roof Restoration Service carried out on our property by Duravex Roofing, and we couldn&#039;t be happier with the results. Because there is no rating higher than 5, we awarded Duravex Roofing a 5-star review. The roof looks brand new, and we have already received many compliments on it. DULUX Acratex 962 Roof Membrane is the best roof paint on the market. If you require a Dulux Acratex Roof Restoration service in Sydney, we recommend using Duravex Roofing. We researched a lot of other businesses that provided comparable services, but none of them could compare to Duravex Roofing. The best way to sum up our relationship with Duravex Roofing is to say that they are exceptional, honest, reliable, and respectful. a business that exhibits professionalism on every level. We would recommend Duravex Roofing for all your roofing needs!\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-09-09 21:00:00 +00:00",
                                "author": "Richard Potrick",
                                "primary_content": [
                                    {
                                        "text": "High-quality service for Dulux Acratex Roof Restoration in Sydney.\r\nProfessional, meticulous, and smooth transition between the various stages of the task. The first quotation was excellent. We were able to say &quot;yes or nay&quot; before meeting anyone because it saved time and provided us an estimate of the cost.\r\nThe physical examination went quite well. This is incredibly sophisticated drone use. acceptable quotation an accurate evaluation at a fair price. We had hoped for more since we have a steep or high pitch roof.\r\nThe estimated job time was precise and reasonable. The Duravex Roofing team was open and honest about their services. Installation and removal of the railing went off without a hitch.\r\nFriendly and diligent roofing workers, even amid light rain and wind. These men take great pride in their profession and love what they do. very effective and affable.\r\nInspection of the final product was outstanding. Additionally provided useful guidance on roof maintenance and care. We had a wonderful experience overall, and the finished Dulux Acratex Roof Membrane looks fantastic. I recommend Duravex Roofing for Dulux Acratex Roof Restoration services in Sydney without hesitation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-06-17 21:00:00 +00:00",
                                "author": "Stephanie Graham",
                                "primary_content": [
                                    {
                                        "text": "We requested the Duravex roofing for Colorbond Roof, and guttering quote and we received the quote next day, we were amazed to see how detailed quote was drafted. The delivery and installation dates were effectively and kindly conveyed by the office employees. Despite being warned that there would be a wait because of all the rain, it only took a little under two weeks. The delivery person was accommodating and moved the guttering out of the way, and the two installers were knowledgeable, courteous, and competent. The company is beyond exceptional. I will highly recommend Duravex Roofing for your roofing and guttering requirements.\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2022-02-02 22:00:00 +00:00",
                                "author": "STRM Management",
                                "primary_content": [
                                    {
                                        "text": "Colorbond Roof &amp; Gutter Restoration We are overjoyed with the transformation of our Colorbond\u00ae steel roof and gutters. Duravex Roofing&#039;s staff members delighted us with their professionalism, friendliness, and depth of expertise, which made us feel very confident in our decision to hire them. Thanks to Andrew, our project manager, who thoroughly examined the work and made sure everything was completed to the highest standard, and to the tireless, affable team who worked on the roof and answered all our questions at the time of the quote. We heartily endorse this business to anyone seeking a reasonable price, excellent service, and top quality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-06-02 21:00:00 +00:00",
                                "author": "PC",
                                "primary_content": [
                                    {
                                        "text": "From the time of the original quote for Dulux Acratex Colorbond Roof Restoration/Commercial Metal roof restoration until the works was completed, Duravex Roofing Crew was excellent\u2014responsive, adaptable, communicative, and friendly. They were diligent in keeping everything clean both during and after the work was completed. We are incredibly pleased with Duravex Roofing works and have no hesitation in referring them to anyone who require commercial roof restoration or Metal roof repairs works done. Duravex Roofing crew, thank you for the fantastic service!\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-05-12 21:00:00 +00:00",
                                "author": "Craig Sparks",
                                "primary_content": [
                                    {
                                        "text": "Our commercial Colorbond metal roof was recently restored by Duravex Roofing Services. the service was exceptional and price was fair. All our inquiries were promptly addressed, and the site staff shown courtesy and friendliness. I was grateful that the Duravex roofing provided me a deadline for the task and kept to it (weather allowing). If you&#039;re searching for commercial roof repairs or Dulux Acratex commercial cool roof restoration, I wouldn&#039;t think twice about recommending Duravex Roofing - Dulux Acratex Accredited company.\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2022-03-01 22:00:00 +00:00",
                                "author": "Milan Kokovaci",
                                "primary_content": [
                                    {
                                        "text": "we recently purchased our wonderful retirement house. MONIER concrete roof tiles were installed 20 years ago at the property and roof tiles had grown overrun with moss, lichen, and dirt. Moss had grown on the gutters and the screen guard. Water would spill from the roof corners and over most gutters whenever it rained.\r\n\r\nWe hired Duravex Roofing to restore, repair and refurbish our house roof with new DULUX Acratex Cool Roof Membrane. We chose them because of their competitive pricing, their expertise, and our concerns about climate change and growing energy expenses. In response, Duravex Roofing Team presented us with a revolutionary product DULUX Acratex Cool Roof Membrane with Infracool technology\r\n\r\nDuravex Roofing crew completely renovated our house with Heat Reflective coating in just two days. The roof appears to be completely new and much cooler. Acratex\u00ae Cool Roof Commercial is a high-build acrylic heat-reflective roof coating that maximises sun reflection. Removes solar heat before it enters the building while also removing surplus heat. As a result, your structure will have better insulation\r\n\r\nOur next-door neighbours are so impressed that they&#039;ve decided to hire them as well. You should as well.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2022-11-08 22:00:00 +00:00",
                                "author": "Mr Gorian",
                                "primary_content": [
                                    {
                                        "text": "The boys at Duravex helped me out greatly, their expertise and experience really show, and the workmanship is top-notch notch",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-03-05 22:00:00 +00:00",
                                "author": "Roseanne",
                                "primary_content": [
                                    {
                                        "text": "Romy is professional, reliable, approachable and an absolute asset to Duravex Roofing! Many thanks to Romy and his team. We couldn&#039;t be happier with the results of our roof restoration. 5 stars plus more!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-10-02 21:00:00 +00:00",
                                "author": "David Scerri",
                                "primary_content": [
                                    {
                                        "text": "Romy and his team did an amazing job on my roof restoration going above and beyond to replace and repair broken tiles and paint all surfaces professionally. I highly recommend DURAVEX Roofing to anyone that needs this type of job done right the first time.\r\nGreat job guys. Well done!!!!!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2016-11-02 22:00:00 +00:00",
                                "author": "Peter James",
                                "primary_content": [
                                    {
                                        "text": "I approached Duravex Roofing as well other companies to arrange a Dulux Acratex Roof Restoration for our house roof. I received several quotes from other companies. However, Duravex Roofing quote was drafted professionally, all key items mentioned and well drafted work methodology. Duravex Roofing crew were very professional to deal with from arranging the inspection and quote. The Project Manager Rob did final defect walk through and overseeing the works. The roofing crew was diligent, polite, and professional. Rob at the office deserves special recognition because he manages scheduling through challenging weather conditions and always kept me informed of the schedule. I choose Duravex Roofing because of the accredited Dulux Acratex applicator and high level of communication&amp; Professionalism. Highly recommended them as a top provider for Dulux Roofing in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-10-15 21:00:00 +00:00",
                                "author": "Jenna C",
                                "primary_content": [
                                    {
                                        "text": "The company used high end technology like DJI Drones for roof Inspection \u2013 Although I&#039;ve had two additional roofers to &quot;repair&quot; my roof, the work was sadly never done correctly, and the roof leaks continued. I called Duravex Roofing, and their friendly customer care representative set up a roof inspection for the following day. The Duravex roofing crew did a thorough roof inspection and used high end technology like DJI Drones for roof Inspection. Roofing inspector identified cracked/broken roof tiles under the solar panels and misalignment of roof tiles were causing the water leaks in roof cavity. The problem was quickly fixed thanks to the roofing inspector&#039;s professional advice. Incredibly knowledgeable and took the time to talk with us about our roof condition report. Very satisfied!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2018-02-14 22:00:00 +00:00",
                                "author": "Racheal W",
                                "primary_content": [
                                    {
                                        "text": "We found Duravex Roofing - Dulux Accredited Applicator through Google. Not only is a highly competitive price provided by Duravex Roofing, but the company also offers dedicated, qualified guidance and Roofing services across Sydney area like Roof ridge capping, High pressure Roof and Gutters cleaning, Roof Re-pointing/Re-bedding, Roof Repairs, Dulux Roof Restoration are areas of expertise. In addition to being fully insured, Duravex Roofing is a Dulux Approved Roof Coating Company. An assessment and price from a roofing crew were provided to us. The Roofing crew carefully examined every aspect of our roof. Since Project Manager is the one signing off our certificate, so they routinely checked in from delivery till the finish. To restore your roof and enhance the beauty of your home, use the Dulux Acratex Roof Restoration System with Next Generation Technology. We were extremely lucky to have them work on our roof. I would have given them a perfect score of ten stars. Dulux Roof Restoration Service is highly recommended!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2018-06-04 21:00:00 +00:00",
                                "author": "Peter J",
                                "primary_content": [
                                    {
                                        "text": "Highly recommended them as a top provider for Dulux Roofing in Sydney \u2013 I approached Duravex Roofing as well other companies to arrange a Dulux Acratex Roof Restoration for our house roof. I received several quotes from other companies. However, Duravex Roofing quote was drafted professionally, all key items mentioned and well drafted work methodology. Duravex Roofing crew were very professional to deal with from arranging the inspection and quote. The Project Manager Rob did final defect walk through and overseeing the works. The roofing crew was diligent, polite, and professional. Rob at the office deserves special recognition because he manages scheduling through challenging weather conditions and always kept me informed of the schedule. I choose Duravex Roofing because of the accredited Dulux Acratex applicator and high level of communication&amp; Professionalism. Highly recommended them as a top provider for Dulux Roofing in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-04-02 21:00:00 +00:00",
                                "author": "Si M",
                                "primary_content": [
                                    {
                                        "text": "There is no rating higher than 5, we awarded Duravex Roofing a 5-star review \u2013 We had a Dulux Acratex Roof Restoration Service carried out on our property by Duravex Roofing, and we couldn&#039;t be happier with the results. Because there is no rating higher than 5, we awarded Duravex Roofing a 5-star review. The roof looks brand new, and we have already received many compliments on it. DULUX Acratex 962 Roof Membrane is the best roof paint on the market. If you require a Dulux Acratex Roof Restoration service in Sydney, we recommend using Duravex Roofing. We researched a lot of other businesses that provided comparable services, but none of them could compare to Duravex Roofing. The best way to sum up our relationship with Duravex Roofing is to say that they are exceptional, honest, reliable, and respectful. a business that exhibits professionalism on every level. We would recommend Duravex Roofing for all your roofing needs!\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2022-01-05 22:00:00 +00:00",
                                "author": "Richard P",
                                "primary_content": [
                                    {
                                        "text": "High-quality service for Dulux Acratex Roof Restoration in Sydney \u2013 High-quality service for Dulux Acratex Roof Restoration in Sydney. Professional, meticulous, and smooth transition between the various stages of the task. The first quotation was excellent. We were able to say &quot;yes or nay&quot; before meeting anyone because it saved time and provided us an estimate of the cost.\r\n\r\nThe physical examination went quite well. This is incredibly sophisticated drone use. acceptable quotation an accurate evaluation at a fair price. We had hoped for more since we have a steep or high pitch roof. The estimated job time was precise and reasonable. The Duravex Roofing team was open and honest about their services. Installation and removal of the railing went off without a hitch.\r\n\r\nFriendly and diligent roofing workers, even amid light rain and wind. These men take great pride in their profession and love what they do. very effective and affable.\r\n\r\nInspection of the final product was outstanding. Additionally provided useful guidance on roof maintenance and care. We had a wonderful experience overall, and the finished Dulux Acratex Roof Membrane looks fantastic. I recommend Duravex Roofing for Dulux Acratex Roof Restoration services in Sydney without hesitation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-02-09 22:00:00 +00:00",
                                "author": "Stephanie G",
                                "primary_content": [
                                    {
                                        "text": "Colourbond Roof and Guttering Installation \u2013 We requested the Duravex roofing for Colorbond Roof, and guttering quote and we received the quote next day, we were amazed to see how detailed quote was drafted. The delivery and installation dates were effectively and kindly conveyed by the office employees. Despite being warned that there would be a wait because of all the rain, it only took a little under two weeks. The delivery person was accommodating and moved the guttering out of the way, and the two installers were knowledgeable, courteous, and competent. The company is beyond exceptional. I will highly recommend Duravex Roofing for your roofing and guttering requirements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-05-04 21:00:00 +00:00",
                                "author": "ACM Group",
                                "primary_content": [
                                    {
                                        "text": "We discovered Duravex Roofing through Google reviews!! \u2013 We discovered Duravex Roofing through Google reviews, and the results were authentic! Duravex Roofing crew impressed me with their professionalism. We had a wonderful time working with Duravex Roofing team to replace our Colorbond Metal roof. The quote provided was higher at first, but we chose to go with Duravex Roofing nevertheless because of the positive ratings. Before and after images were taken in abundance, communication was excellent, and a 10 Years of workmanship warranty. I would strongly recommend Duravex Roofing for any roofing requirements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2018-06-05 21:00:00 +00:00",
                                "author": "Cassidy S",
                                "primary_content": [
                                    {
                                        "text": "Although not the cheapest, the work they completed more than justified their fees 10/10 \u2013 Although not the cheapest, the work they completed more than justified their fees 10/10. Duravex team did an excellent job and visited my house the same day for a roof inspection and thoroughly explained the entire roof restoration process to me. My roof was 30 years old and in urgent need of repairs. These folks completed the repairs and restoration, and my roof now looks brand new and is painted in a Colorbond Monument color.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-02-10 22:00:00 +00:00",
                                "author": "Samantha",
                                "primary_content": [
                                    {
                                        "text": "The service was exceptional. Transitioning from one part of the task to the next is professional, precise, and seamless. The initial quote received via the internet was excellent. We were able to save time and get a price estimate. The physical examination went exceptionally well. Using a drone, it&#039;s quite a high tech and the Quote was reasonable too. Highly recommended for the Sydney area.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-06-12 21:00:00 +00:00",
                                "author": "Tim L",
                                "primary_content": [
                                    {
                                        "text": "We are delighted with the roof maintenance and restoration work completed by Duravex Roofing Group on my mother&#039;s house. We&#039;ve had terrible experiences in the past with dishonest roofers, but this company streamlined the site assessment and quote procedure. Even the solar installation crew specifically mentioned the excellent roof restoration work they had seen recently. I highly recommend this business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-04-24 21:00:00 +00:00",
                                "author": "Vinny Araouzou",
                                "primary_content": [
                                    {
                                        "text": "The team at Duravex Roofing provided exceptional service. I have never had a better experience with a trade contractor. We recently engaged Duravex Roofing Group to replace our old tiled roof with a new Colorbond steel roof. They had previously worked with our neighbours on their metal roof. Installing a new Colorbond roof is an excellent way to improve street attractiveness, weather resistance, and house longevity. The Duravex team was professional, arrived on schedule, and kept the workspace neat throughout. Tile-to-tin roof conversions for homes are their specialty. I will use their services again and highly recommend them. Pam, Daniel, and the entire staff at Duravex Roofing, thank you!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-02-05 22:00:00 +00:00",
                                "author": "Ross Tim Smyth",
                                "primary_content": [
                                    {
                                        "text": "The team at Duravex Roofing Group exceeded my expectations with their work. They provided a detailed written quote and kept me updated with follow-up calls. The project manager maintained excellent communication throughout the entire process. The materials were delivered promptly, and skilled local tradesmen completed the job efficiently. I highly recommend their services for any roofing needs you may have.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-11-02 22:00:00 +00:00",
                                "author": "Benjamin M",
                                "primary_content": [
                                    {
                                        "text": "This business exhibited a high degree of professionalism. Once scheduled, the team arrived punctually and executed the task with attention to detail, including the thorough replacement of broken tiles, ridge capping, repointing, and painting the roof. They completed the work promptly and ensured the site was cleaned up upon completion. The existing solar panels on the roof were handled with care. The roof restoration results were satisfactory and met the standards suitable for recommendation. We extend our appreciation to the Duravex Roofing team.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-04-30 21:00:00 +00:00",
                                "author": "Donna Tam",
                                "primary_content": [
                                    {
                                        "text": "Before our solar panel installation, the Duravex Roofing Group team carried out a complete restoration of our 30-year-old concrete tiled roof using the Dulux Acratex Roof Restoration System. Their professionalism and exceptional craftsmanship are the reasons I wholeheartedly recommend them. 3 Coats of Dulux roof membrane, replaced damaged tiles, cleaned the roof with high pressure, and fully repointed it. Now, our roof looks as good as new! The team promptly addressed all my questions and provided a comprehensive explanation of the entire procedure from the beginning. They ensured that our neighbours were informed about the work while maintaining a friendly and professional approach. Throughout the project, they demonstrated exceptional expertise and skill, which included installing sediment barriers. The crew cleaned up after themselves every day, not just at the end of the project, and they did so in a very professional manner.\r\nI want to extend my gratitude for a job well done!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-04-09 21:00:00 +00:00",
                                "author": "Pierre",
                                "primary_content": [
                                    {
                                        "text": "The Duravex Roofing Group provides an array of Premium Roofing Products designed to meet your unique requirements, whether you have concrete, terracotta roof tiles, or metal roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-07-16 21:00:00 +00:00",
                                "author": "John Chant",
                                "primary_content": [
                                    {
                                        "text": "Having made the decision to paint my roof the decision to use this company was quickly justified. From the beginning the quotation, accreditations, insurance, warranty, licensing documentation they provided was superior to the other quotation I received, and this was only the beginning. Their workmanship was everything I expected from them and there was no damage/mess to my property and my neighbours adjoining properties.\r\n\r\nIf you don\u2019t include them when you are looking for quotes you may well be disappointed",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-09-08 21:00:00 +00:00",
                                "author": "Stephen Chang",
                                "primary_content": [
                                    {
                                        "text": "The team at Duravex Roofing provided exceptional service. I have never had a better experience with a trade contractor. We recently engaged Duravex Roofing Group to replace our old tiled roof with a new Colorbond steel roof. They had previously worked with our neighbours on their metal roof. Installing a new Colorbond roof is an excellent way to improve street attractiveness, weather resistance, and house longevity. The Duravex team was professional, arrived on schedule, and kept the workspace neat throughout. Tile-to-tin roof conversions for homes are their specialty. I will use their services again and highly recommend them. Pam, Daniel, and the entire staff at Duravex Roofing, thank you!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-07-03 21:00:00 +00:00",
                                "author": "Tram M",
                                "primary_content": [
                                    {
                                        "text": "Excellent communication by roofing team \u2013 The excellent communication and meticulous planning immediately established a standard for professionalism and quality of the project",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-04-09 21:00:00 +00:00",
                                "author": "Jonathan",
                                "primary_content": [
                                    {
                                        "text": "Duravex Roofing crew performed the most comprehensive roof inspection and the Adam was the most knowledgeable roofer I have ever met .",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-04-09 21:00:00 +00:00",
                                "author": "Brendon lee",
                                "primary_content": [
                                    {
                                        "text": "The skilled roofing professionals at Duravex Roofing Group are highly recommended. The crew kept me informed throughout the process and were a pleasure to work with. Their Colorbond design and colour visualiser tips were helpful, and the roofing team replaced rusty guttering and installed a new Colorbond roof and guttering system that blended in well with the rest of the property. The work was finished promptly and without leaving any debris on the site. I have no complaints about the work that has been done and would gladly recommend it to my friends and relatives.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-08-10 21:00:00 +00:00",
                                "author": "John",
                                "primary_content": [
                                    {
                                        "text": "I hired Duravex roofing to make a new roof. They did a great job at a much lower cost than other companies projected. They are honest and thorough. I recommend the duravex highly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-02-29 22:00:00 +00:00",
                                "author": "Mathew Flare",
                                "primary_content": [
                                    {
                                        "text": "The Duravex Metal Roofing team completed a roof remediation project with a new Colorbond roof and guttering on my property. The Project methodology was well-communicated and implemented throughout the project, and the team was professional. We are delighted with the final product and grateful for the entire crew&#039;s efforts and delivered high-end detailed work. Duravex Metal Roofing is highly recommended for any future metal roofing projects. Their work speaks for itself in terms of quality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-02-10 22:00:00 +00:00",
                                "author": "Samantha",
                                "primary_content": [
                                    {
                                        "text": "The service was exceptional. Transitioning from one part of the task to the next is professional, precise, and seamless. The initial quote received via the internet was excellent. We were able to save time and get a price estimate. The physical examination went exceptionally well. Using a drone, it&#039;s quite a high tech and the Quote was reasonable too. Highly recommended for the Sydney area.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-06-12 21:00:00 +00:00",
                                "author": "Tim L",
                                "primary_content": [
                                    {
                                        "text": "We are delighted with the roof maintenance and restoration work completed by Duravex Roofing Group on my mother&#039;s house. We&#039;ve had terrible experiences in the past with dishonest roofers, but this company streamlined the site assessment and quote procedure. Even the solar installation crew specifically mentioned the excellent roof restoration work they had seen recently. I highly recommend this business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-04-24 21:00:00 +00:00",
                                "author": "Vinny Araouzou",
                                "primary_content": [
                                    {
                                        "text": "The team at Duravex Roofing provided exceptional service. I have never had a better experience with a trade contractor. We recently engaged Duravex Roofing Group to replace our old tiled roof with a new Colorbond steel roof. They had previously worked with our neighbours on their metal roof. Installing a new Colorbond roof is an excellent way to improve street attractiveness, weather resistance, and house longevity. The Duravex team was professional, arrived on schedule, and kept the workspace neat throughout. Tile-to-tin roof conversions for homes are their specialty. I will use their services again and highly recommend them. Pam, Daniel, and the entire staff at Duravex Roofing, thank you!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-02-05 22:00:00 +00:00",
                                "author": "Ross Tim Smyth",
                                "primary_content": [
                                    {
                                        "text": "The team at Duravex Roofing Group exceeded my expectations with their work. They provided a detailed written quote and kept me updated with follow-up calls. The project manager maintained excellent communication throughout the entire process. The materials were delivered promptly, and skilled local tradesmen completed the job efficiently. I highly recommend their services for any roofing needs you may have.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-11-02 22:00:00 +00:00",
                                "author": "Benjamin M",
                                "primary_content": [
                                    {
                                        "text": "This business exhibited a high degree of professionalism. Once scheduled, the team arrived punctually and executed the task with attention to detail, including the thorough replacement of broken tiles, ridge capping, repointing, and painting the roof. They completed the work promptly and ensured the site was cleaned up upon completion. The existing solar panels on the roof were handled with care. The roof restoration results were satisfactory and met the standards suitable for recommendation. We extend our appreciation to the Duravex Roofing team.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-04-30 21:00:00 +00:00",
                                "author": "Donna Tam",
                                "primary_content": [
                                    {
                                        "text": "Before our solar panel installation, the Duravex Roofing Group team carried out a complete restoration of our 30-year-old concrete tiled roof using the Dulux Acratex Roof Restoration System. Their professionalism and exceptional craftsmanship are the reasons I wholeheartedly recommend them. 3 Coats of Dulux roof membrane, replaced damaged tiles, cleaned the roof with high pressure, and fully repointed it. Now, our roof looks as good as new! The team promptly addressed all my questions and provided a comprehensive explanation of the entire procedure from the beginning. They ensured that our neighbours were informed about the work while maintaining a friendly and professional approach. Throughout the project, they demonstrated exceptional expertise and skill, which included installing sediment barriers. The crew cleaned up after themselves every day, not just at the end of the project, and they did so in a very professional manner.\r\nI want to extend my gratitude for a job well done!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-04-09 21:00:00 +00:00",
                                "author": "Pierre",
                                "primary_content": [
                                    {
                                        "text": "The Duravex Roofing Group provides an array of Premium Roofing Products designed to meet your unique requirements, whether you have concrete, terracotta roof tiles, or metal roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-01-26 22:00:00 +00:00",
                                "author": "Krystine Pike",
                                "primary_content": [
                                    {
                                        "text": "Our strata manager recommended this company when we needed urgent Colorbond Roof, Gutter Box Repair, and Installation works for our commercial property roof. I must admit that their professionalism and situation-handling expertise astonished me. The staff arrived promptly, evaluated the issue, and gave me a comprehensive estimate. They were open and honest regarding the project cost and time needed to finish the repair and installation work. The team members worked quickly and courteously, taking all precautions to safely relocate the outdoor furniture and other vulnerable items. I was pleased with their work&#039;s calibre and effort to guarantee the roof repair and gutters work was done correctly. I recommend their services to anyone needing a trustworthy and knowledgeable roofing business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-10-21 21:00:00 +00:00",
                                "author": "Brendon Brown",
                                "primary_content": [
                                    {
                                        "text": "Duravex Roofing Group&#039;s attention to detail made them stand out in the home improvement industry. They offer a complete end-to-end Dulux Acratex Total Roof Restoration system. The team restored our house roof to like-new condition with Dulux Acratex Roof Restoration Service. Giving the roof a superb gloss and long-lasting protection. The roofing crew also cared for even the most minor details, like painting and repairing the eaves, whirlybirds, and fascia boards. In addition, the crew replaced forty to fifty roof tiles with remarkable expertise and devotion, protecting the integrity and longevity of our roof. They demonstrated their vision and dedication to perfection by painting fifteen spare replacement tiles. The outcomes clearly illustrate the situation. Our roof has never looked better, and the calibre of their work has completely changed how our house roof looks\u2014thanks to the Duravex Roofing Group crew.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2022-07-13 21:00:00 +00:00",
                                "author": "Tim Wilson",
                                "primary_content": [
                                    {
                                        "text": "The Duravex Roofing Team completed a full Dulux Acratex Roof Restoration service on our terracotta tile roof. The dedicated team of Approved roofing applicators replaced all the broken or cracked terracotta roof tiles and treated the roof with anti-mould, moss, fungal, and lichen removal concentrate. Hi-pressure roof cleaning using 4,000 psi of water pressure, repointing the roof ridges, sealing, priming, and finishing coat of Dulux Acratex Roof Membrane. We are incredibly happy with the roof transformation, and the crew\u2019s professionalism and workmanship are top-notch. Duravex Roofing comes highly recommended by us to anyone seeking a Dulux Roof Restoration service in the Greater Sydney region.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-07-07 21:00:00 +00:00",
                                "author": "Jerry lyn",
                                "primary_content": [
                                    {
                                        "text": "The staff at Duravex Roofing \u2013 Dulux Acratex accredited applicator is outstanding. we engaged them for Dulux Acratex Roof Membrane coating system project, and I must say that everything went quite smoothly. Duravex Roofing have experienced roofers. The crew aware of your preferences and offer excellent customer service. Duravex Roofing offered us with Roof Care &amp; Maintenance guide tips for our roof to help extend its life and assist in maintaining its optimal appearance, and everything is carried out in accordance with manufactures specifications.\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-10-19 21:00:00 +00:00",
                                "author": "Peter James",
                                "primary_content": [
                                    {
                                        "text": "I approached Duravex Roofing as well other companies to arrange a Dulux Acratex Roof Restoration for our house roof. I received several quotes from other companies. However, Duravex Roofing quote was drafted professionally, all key items mentioned and well drafted work methodology.\r\nDuravex Roofing crew were very professional to deal with from arranging the inspection and quote. The Project Manager Rob did final defect walk through and overseeing the works. The roofing crew was diligent, polite, and professional. Rob at the office deserves special recognition because he manages scheduling through challenging weather conditions and always kept me informed of the schedule. I choose Duravex Roofing because of the accredited Dulux Acratex applicator and high level of communication&amp; Professionalism.\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-06-08 21:00:00 +00:00",
                                "author": "GEORGE",
                                "primary_content": [
                                    {
                                        "text": "I can highly recommend the team at Duravex Roofing for their professional attitude and excellent workmanship in restoring our roof prior to a Solar Panel Installation. Duravex Roofing crew clearly explained the process up front and replied promptly when I had any questions. The friendly team maintained their professional attitude throughout the project, making sure the surrounding community was informed of the work and showcasing their superior skill and workmanship. WHAT\u2019S NOT TO LOVE! ... Looking for a Dulux Acratex Roof Membrane coating colour range to go with the exterior house colours you already have? Make Duravex Roofing your first choice for tile and metal Roof restoration, Roof renovation, Roof repairs, Roof cleaning, Roof sealing, Roof ridge pointing and roof painting.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-10-27 21:00:00 +00:00",
                                "author": "Si Moon",
                                "primary_content": [
                                    {
                                        "text": "We had a Dulux Acratex Roof Restoration Service carried out on our property by Duravex Roofing, and we couldn&#039;t be happier with the results. Because there is no rating higher than 5, we awarded Duravex Roofing a 5-star review. The roof looks brand new, and we have already received many compliments on it. DULUX Acratex 962 Roof Membrane is the best roof paint on the market. If you require a Dulux Acratex Roof Restoration service in Sydney, we recommend using Duravex Roofing. We researched a lot of other businesses that provided comparable services, but none of them could compare to Duravex Roofing. The best way to sum up our relationship with Duravex Roofing is to say that they are exceptional, honest, reliable, and respectful. a business that exhibits professionalism on every level. We would recommend Duravex Roofing for all your roofing needs!\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-09-09 21:00:00 +00:00",
                                "author": "Richard Potrick",
                                "primary_content": [
                                    {
                                        "text": "High-quality service for Dulux Acratex Roof Restoration in Sydney.\r\nProfessional, meticulous, and smooth transition between the various stages of the task. The first quotation was excellent. We were able to say &quot;yes or nay&quot; before meeting anyone because it saved time and provided us an estimate of the cost.\r\nThe physical examination went quite well. This is incredibly sophisticated drone use. acceptable quotation an accurate evaluation at a fair price. We had hoped for more since we have a steep or high pitch roof.\r\nThe estimated job time was precise and reasonable. The Duravex Roofing team was open and honest about their services. Installation and removal of the railing went off without a hitch.\r\nFriendly and diligent roofing workers, even amid light rain and wind. These men take great pride in their profession and love what they do. very effective and affable.\r\nInspection of the final product was outstanding. Additionally provided useful guidance on roof maintenance and care. We had a wonderful experience overall, and the finished Dulux Acratex Roof Membrane looks fantastic. I recommend Duravex Roofing for Dulux Acratex Roof Restoration services in Sydney without hesitation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-06-17 21:00:00 +00:00",
                                "author": "Stephanie Graham",
                                "primary_content": [
                                    {
                                        "text": "We requested the Duravex roofing for Colorbond Roof, and guttering quote and we received the quote next day, we were amazed to see how detailed quote was drafted. The delivery and installation dates were effectively and kindly conveyed by the office employees. Despite being warned that there would be a wait because of all the rain, it only took a little under two weeks. The delivery person was accommodating and moved the guttering out of the way, and the two installers were knowledgeable, courteous, and competent. The company is beyond exceptional. I will highly recommend Duravex Roofing for your roofing and guttering requirements.\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2022-02-02 22:00:00 +00:00",
                                "author": "STRM Management",
                                "primary_content": [
                                    {
                                        "text": "Colorbond Roof &amp; Gutter Restoration We are overjoyed with the transformation of our Colorbond\u00ae steel roof and gutters. Duravex Roofing&#039;s staff members delighted us with their professionalism, friendliness, and depth of expertise, which made us feel very confident in our decision to hire them. Thanks to Andrew, our project manager, who thoroughly examined the work and made sure everything was completed to the highest standard, and to the tireless, affable team who worked on the roof and answered all our questions at the time of the quote. We heartily endorse this business to anyone seeking a reasonable price, excellent service, and top quality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-06-02 21:00:00 +00:00",
                                "author": "PC",
                                "primary_content": [
                                    {
                                        "text": "From the time of the original quote for Dulux Acratex Colorbond Roof Restoration/Commercial Metal roof restoration until the works was completed, Duravex Roofing Crew was excellent\u2014responsive, adaptable, communicative, and friendly. They were diligent in keeping everything clean both during and after the work was completed. We are incredibly pleased with Duravex Roofing works and have no hesitation in referring them to anyone who require commercial roof restoration or Metal roof repairs works done. Duravex Roofing crew, thank you for the fantastic service!\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-05-12 21:00:00 +00:00",
                                "author": "Craig Sparks",
                                "primary_content": [
                                    {
                                        "text": "Our commercial Colorbond metal roof was recently restored by Duravex Roofing Services. the service was exceptional and price was fair. All our inquiries were promptly addressed, and the site staff shown courtesy and friendliness. I was grateful that the Duravex roofing provided me a deadline for the task and kept to it (weather allowing). If you&#039;re searching for commercial roof repairs or Dulux Acratex commercial cool roof restoration, I wouldn&#039;t think twice about recommending Duravex Roofing - Dulux Acratex Accredited company.\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2022-03-01 22:00:00 +00:00",
                                "author": "Milan Kokovaci",
                                "primary_content": [
                                    {
                                        "text": "we recently purchased our wonderful retirement house. MONIER concrete roof tiles were installed 20 years ago at the property and roof tiles had grown overrun with moss, lichen, and dirt. Moss had grown on the gutters and the screen guard. Water would spill from the roof corners and over most gutters whenever it rained.\r\n\r\nWe hired Duravex Roofing to restore, repair and refurbish our house roof with new DULUX Acratex Cool Roof Membrane. We chose them because of their competitive pricing, their expertise, and our concerns about climate change and growing energy expenses. In response, Duravex Roofing Team presented us with a revolutionary product DULUX Acratex Cool Roof Membrane with Infracool technology\r\n\r\nDuravex Roofing crew completely renovated our house with Heat Reflective coating in just two days. The roof appears to be completely new and much cooler. Acratex\u00ae Cool Roof Commercial is a high-build acrylic heat-reflective roof coating that maximises sun reflection. Removes solar heat before it enters the building while also removing surplus heat. As a result, your structure will have better insulation\r\n\r\nOur next-door neighbours are so impressed that they&#039;ve decided to hire them as well. You should as well.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2022-11-08 22:00:00 +00:00",
                                "author": "Mr Gorian",
                                "primary_content": [
                                    {
                                        "text": "The boys at Duravex helped me out greatly, their expertise and experience really show, and the workmanship is top-notch notch",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-03-05 22:00:00 +00:00",
                                "author": "Roseanne",
                                "primary_content": [
                                    {
                                        "text": "Romy is professional, reliable, approachable and an absolute asset to Duravex Roofing! Many thanks to Romy and his team. We couldn&#039;t be happier with the results of our roof restoration. 5 stars plus more!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2025-10-02 21:00:00 +00:00",
                                "author": "David Scerri",
                                "primary_content": [
                                    {
                                        "text": "Romy and his team did an amazing job on my roof restoration going above and beyond to replace and repair broken tiles and paint all surfaces professionally. I highly recommend DURAVEX Roofing to anyone that needs this type of job done right the first time.\r\nGreat job guys. Well done!!!!!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2016-11-02 22:00:00 +00:00",
                                "author": "Peter James",
                                "primary_content": [
                                    {
                                        "text": "I approached Duravex Roofing as well other companies to arrange a Dulux Acratex Roof Restoration for our house roof. I received several quotes from other companies. However, Duravex Roofing quote was drafted professionally, all key items mentioned and well drafted work methodology. Duravex Roofing crew were very professional to deal with from arranging the inspection and quote. The Project Manager Rob did final defect walk through and overseeing the works. The roofing crew was diligent, polite, and professional. Rob at the office deserves special recognition because he manages scheduling through challenging weather conditions and always kept me informed of the schedule. I choose Duravex Roofing because of the accredited Dulux Acratex applicator and high level of communication&amp; Professionalism. Highly recommended them as a top provider for Dulux Roofing in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-10-15 21:00:00 +00:00",
                                "author": "Jenna C",
                                "primary_content": [
                                    {
                                        "text": "The company used high end technology like DJI Drones for roof Inspection \u2013 Although I&#039;ve had two additional roofers to &quot;repair&quot; my roof, the work was sadly never done correctly, and the roof leaks continued. I called Duravex Roofing, and their friendly customer care representative set up a roof inspection for the following day. The Duravex roofing crew did a thorough roof inspection and used high end technology like DJI Drones for roof Inspection. Roofing inspector identified cracked/broken roof tiles under the solar panels and misalignment of roof tiles were causing the water leaks in roof cavity. The problem was quickly fixed thanks to the roofing inspector&#039;s professional advice. Incredibly knowledgeable and took the time to talk with us about our roof condition report. Very satisfied!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2018-02-14 22:00:00 +00:00",
                                "author": "Racheal W",
                                "primary_content": [
                                    {
                                        "text": "We found Duravex Roofing - Dulux Accredited Applicator through Google. Not only is a highly competitive price provided by Duravex Roofing, but the company also offers dedicated, qualified guidance and Roofing services across Sydney area like Roof ridge capping, High pressure Roof and Gutters cleaning, Roof Re-pointing/Re-bedding, Roof Repairs, Dulux Roof Restoration are areas of expertise. In addition to being fully insured, Duravex Roofing is a Dulux Approved Roof Coating Company. An assessment and price from a roofing crew were provided to us. The Roofing crew carefully examined every aspect of our roof. Since Project Manager is the one signing off our certificate, so they routinely checked in from delivery till the finish. To restore your roof and enhance the beauty of your home, use the Dulux Acratex Roof Restoration System with Next Generation Technology. We were extremely lucky to have them work on our roof. I would have given them a perfect score of ten stars. Dulux Roof Restoration Service is highly recommended!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2018-06-04 21:00:00 +00:00",
                                "author": "Peter J",
                                "primary_content": [
                                    {
                                        "text": "Highly recommended them as a top provider for Dulux Roofing in Sydney \u2013 I approached Duravex Roofing as well other companies to arrange a Dulux Acratex Roof Restoration for our house roof. I received several quotes from other companies. However, Duravex Roofing quote was drafted professionally, all key items mentioned and well drafted work methodology. Duravex Roofing crew were very professional to deal with from arranging the inspection and quote. The Project Manager Rob did final defect walk through and overseeing the works. The roofing crew was diligent, polite, and professional. Rob at the office deserves special recognition because he manages scheduling through challenging weather conditions and always kept me informed of the schedule. I choose Duravex Roofing because of the accredited Dulux Acratex applicator and high level of communication&amp; Professionalism. Highly recommended them as a top provider for Dulux Roofing in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-04-02 21:00:00 +00:00",
                                "author": "Si M",
                                "primary_content": [
                                    {
                                        "text": "There is no rating higher than 5, we awarded Duravex Roofing a 5-star review \u2013 We had a Dulux Acratex Roof Restoration Service carried out on our property by Duravex Roofing, and we couldn&#039;t be happier with the results. Because there is no rating higher than 5, we awarded Duravex Roofing a 5-star review. The roof looks brand new, and we have already received many compliments on it. DULUX Acratex 962 Roof Membrane is the best roof paint on the market. If you require a Dulux Acratex Roof Restoration service in Sydney, we recommend using Duravex Roofing. We researched a lot of other businesses that provided comparable services, but none of them could compare to Duravex Roofing. The best way to sum up our relationship with Duravex Roofing is to say that they are exceptional, honest, reliable, and respectful. a business that exhibits professionalism on every level. We would recommend Duravex Roofing for all your roofing needs!\r\n\r\n",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2022-01-05 22:00:00 +00:00",
                                "author": "Richard P",
                                "primary_content": [
                                    {
                                        "text": "High-quality service for Dulux Acratex Roof Restoration in Sydney \u2013 High-quality service for Dulux Acratex Roof Restoration in Sydney. Professional, meticulous, and smooth transition between the various stages of the task. The first quotation was excellent. We were able to say &quot;yes or nay&quot; before meeting anyone because it saved time and provided us an estimate of the cost.\r\n\r\nThe physical examination went quite well. This is incredibly sophisticated drone use. acceptable quotation an accurate evaluation at a fair price. We had hoped for more since we have a steep or high pitch roof. The estimated job time was precise and reasonable. The Duravex Roofing team was open and honest about their services. Installation and removal of the railing went off without a hitch.\r\n\r\nFriendly and diligent roofing workers, even amid light rain and wind. These men take great pride in their profession and love what they do. very effective and affable.\r\n\r\nInspection of the final product was outstanding. Additionally provided useful guidance on roof maintenance and care. We had a wonderful experience overall, and the finished Dulux Acratex Roof Membrane looks fantastic. I recommend Duravex Roofing for Dulux Acratex Roof Restoration services in Sydney without hesitation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-02-09 22:00:00 +00:00",
                                "author": "Stephanie G",
                                "primary_content": [
                                    {
                                        "text": "Colourbond Roof and Guttering Installation \u2013 We requested the Duravex roofing for Colorbond Roof, and guttering quote and we received the quote next day, we were amazed to see how detailed quote was drafted. The delivery and installation dates were effectively and kindly conveyed by the office employees. Despite being warned that there would be a wait because of all the rain, it only took a little under two weeks. The delivery person was accommodating and moved the guttering out of the way, and the two installers were knowledgeable, courteous, and competent. The company is beyond exceptional. I will highly recommend Duravex Roofing for your roofing and guttering requirements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2020-05-04 21:00:00 +00:00",
                                "author": "ACM Group",
                                "primary_content": [
                                    {
                                        "text": "We discovered Duravex Roofing through Google reviews!! \u2013 We discovered Duravex Roofing through Google reviews, and the results were authentic! Duravex Roofing crew impressed me with their professionalism. We had a wonderful time working with Duravex Roofing team to replace our Colorbond Metal roof. The quote provided was higher at first, but we chose to go with Duravex Roofing nevertheless because of the positive ratings. Before and after images were taken in abundance, communication was excellent, and a 10 Years of workmanship warranty. I would strongly recommend Duravex Roofing for any roofing requirements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2018-06-05 21:00:00 +00:00",
                                "author": "Cassidy S",
                                "primary_content": [
                                    {
                                        "text": "Although not the cheapest, the work they completed more than justified their fees 10/10 \u2013 Although not the cheapest, the work they completed more than justified their fees 10/10. Duravex team did an excellent job and visited my house the same day for a roof inspection and thoroughly explained the entire roof restoration process to me. My roof was 30 years old and in urgent need of repairs. These folks completed the repairs and restoration, and my roof now looks brand new and is painted in a Colorbond Monument color.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2019-09-03 21:00:00 +00:00",
                                "author": "Timeless Strata Group",
                                "primary_content": [
                                    {
                                        "text": "Duravex Roofing has been assisting us with Dulux Roof Restoration services across Greater Sydney Region \u2013 Duravex Roofing has been assisting us with Dulux Roof Restoration services and Roof &amp; Gutter repair services, and Roof Cleaning services for our client\u2019s investment properties for several years. The Roofing crew is reliable, competent, and professional, which is most crucial. In our opinion, Outstanding outcomes are delivered along with great services at a fair price. We could not possibly suggest a better business for any roofing jobs. With Regards, ( Timeless Strata Group )",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-02-07 22:00:00 +00:00",
                                "author": "Victor S",
                                "primary_content": [
                                    {
                                        "text": "Delighted to endorse a professional roofing company in sydney \u2013 Duravex Roofing Group is distinguished from competitors as the company allows you to communicate directly with professional roofers. The project manager or roofing professional will listen to your requirements and provide professional advice. Liaising with the roofing crew will permit you to review your project&#039;s details with the skilled roofer.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-02-29 22:00:00 +00:00",
                                "author": "Peter J",
                                "primary_content": [
                                    {
                                        "text": "I approached Duravex Roofing as well other companies to arrange a Dulux Acratex Roof Restoration for our house roof. I received several quotes from other companies. However, Duravex Roofing quote was drafted professionally, all key items mentioned and well drafted work methodology. Duravex Roofing crew were very professional to deal with from arranging the inspection and quote. The Project Manager Rob did final defect walk through and overseeing the works. The roofing crew was diligent, polite, and professional. Rob at the office deserves special recognition because he manages scheduling through challenging weather conditions and always kept me informed of the schedule. I choose Duravex Roofing because of the accredited Dulux Acratex applicator and high level of communication&amp; Professionalism. Highly recommended them as a top provider for Dulux Roofing in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2023-04-09 21:00:00 +00:00",
                                "author": "ALFRED DELLO",
                                "primary_content": [
                                    {
                                        "text": "Dulux AcraTex\u00ae Roof Membrane is the latest and most revolutionary roof covering from Dulux, with a 100 percent acrylic coating. This product facilitates application, improves gloss, and reduces chalking, ensuring that your paint colour remains vibrant, and your finish lasts longer. It is critical to choose an Accredited/licensed Applicator to apply this product since licenced companies have been schooled on typical roofing issues and their practical, real-world remedies in a hands-on environment.\r\nHere are a few reasons why hiring a licenced contractor to put Dulux AcraTex\u00ae Roof Membrane to your home is a good idea:\r\n\u2022 The application of Dulux AcraTex\u00ae Roof Membrane is simple.\r\n\u2022 The improved technology of Dulux AcraTex\u00ae Roof Membrane ensures greater outcomes.\r\n\u2022 You can customise the finish to fit your preferences.\r\n\r\nYour home\u2019s roof is continually exposed to harsh weather, from summer\u2019s searing UV rays to winter\u2019s torrential downpours. Dulux collaborated with applicators to optimise the product\u2019s application properties, resulting in a protective membrane that looks great on both tile and metal roofs and applies like regular paint.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2021-11-10 22:00:00 +00:00",
                                "author": "Helen N",
                                "primary_content": [
                                    {
                                        "text": "The communication and service were good, and the workmanship met our expectations. We find this company reliable, professional, and knowledgeable. We plan to use Duravex Roofing Services for future annual roof maintenance works. Thank you",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-07-03 21:00:00 +00:00",
                                "author": "Catherine Fitzpatrick",
                                "primary_content": [
                                    {
                                        "text": "Firstly, if I could award more stars then I would without any hesitation. I am so grateful I came across this Business whilst conducting my Google search. Romy goes above and beyond for his customers. I found him to be very friendly, professional, knowledgeable and with fantastic customer service skills, both in person and via the phone. I look forward to utilising Romy and his team again in the future.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            }
                        ],
                        "contacts": {
                            "telephones": [
                                "1300 492 880"
                            ],
                            "emails": [
                                "sales@duravex.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}