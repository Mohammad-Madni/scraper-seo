{
    "id": "01190728-1132-0216-0000-bbfa3e3a1dc8",
    "status_code": 40602,
    "status_message": "Task In Queue.",
    "time": "0.0080 sec.",
    "cost": 0,
    "result_count": 0,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://adkoroofing.com.au/locations/western-sydney/roof-repairs-carlingford/",
        "target": "adkoroofing.com.au",
        "start_url": "https://adkoroofing.com.au/locations/western-sydney/roof-repairs-carlingford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg11_ra15_adkoroofing.md"
    },
    "result": null
}