{
    "id": "01190728-1132-0216-0000-648441239e3d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0185 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofranger.com.au/locations/hills-district/roof-restoration-carlingford/",
        "target": "roofranger.com.au",
        "start_url": "https://roofranger.com.au/locations/hills-district/roof-restoration-carlingford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Carlingford\\organic\\type-organic_rg5_ra8_roofranger.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:42 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "0401 374 203",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Terracotta Roof Restoration",
                                    "url": "https://roofranger.com.au/roof-restoration/terracotta/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/roof-restoration/terracotta/",
                                            "anchor_text": "Terracotta Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cement Roof Restoration",
                                    "url": "https://roofranger.com.au/roof-restoration/cement/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/roof-restoration/cement/",
                                            "anchor_text": "Cement Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://roofranger.com.au/roof-restoration/metal/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/roof-restoration/metal/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://roofranger.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bedding & Pointing",
                                    "url": "https://roofranger.com.au/bedding-pointing/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/bedding-pointing/",
                                            "anchor_text": "Bedding & Pointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirly Bird Installation",
                                    "url": "https://roofranger.com.au/whirly-bird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/whirly-bird-installation/",
                                            "anchor_text": "Whirly Bird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://roofranger.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof",
                                    "url": "https://roofranger.com.au/leaking-roof/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/leaking-roof/",
                                            "anchor_text": "Leaking Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofranger.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Western Sydney",
                                    "url": "https://roofranger.com.au/locations/roof-restoration-western-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/locations/roof-restoration-western-sydney/",
                                            "anchor_text": "Western Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hills District",
                                    "url": "https://roofranger.com.au/locations/hills-district/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/locations/hills-district/",
                                            "anchor_text": "Hills District"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blue Mountains",
                                    "url": "https://roofranger.com.au/locations/roof-restoration-blue-mountains/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/locations/roof-restoration-blue-mountains/",
                                            "anchor_text": "Blue Mountains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Image Gallery",
                                    "url": "https://roofranger.com.au/image-gallery/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/image-gallery/",
                                            "anchor_text": "Image Gallery"
                                        }
                                    ]
                                },
                                {
                                    "text": "Video Gallery",
                                    "url": "https://roofranger.com.au/video-gallery/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/video-gallery/",
                                            "anchor_text": "Video Gallery"
                                        }
                                    ]
                                },
                                {
                                    "text": "NXT Cool Zone",
                                    "url": "https://roofranger.com.au/nutech-paints/nxt-cool-zone/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/nutech-paints/nxt-cool-zone/",
                                            "anchor_text": "NXT Cool Zone"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofranger.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofranger.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Extensive range of roofing services to Carlingford",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roof Ranger, we provide an extensive range of roofing services to Carlingford. We believe that the roof is one of the most important parts of your home, which is why you should only choose a reliable and certified roof restoration specialist.\u00a0From Terracotta Roof Restoration to Gutter Cleaning, our professionals in Carlingford will come straight to your door and complete our roofing service in a timely manner.",
                                        "url": "https://roofranger.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/",
                                                "anchor_text": "roof restoration"
                                            },
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/terracotta/",
                                                "anchor_text": "Terracotta Roof Restoration"
                                            },
                                            {
                                                "url": "https://roofranger.com.au/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Carlingford Roof Repairs",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our Services are of the highest quality with the latest technology and skilled roofing experts.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our service includes:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Terracotta Roof Restoration \u2013 Our step-by-step process is strictly followed when cleaning terracotta tiles to ensure they receive quality treatment. Terracotta Roof Restoration is one of our most popular services throughout Sydney.",
                                        "url": "https://roofranger.com.au/roof-restoration/terracotta/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/terracotta/",
                                                "anchor_text": "Terracotta Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cement Roof Restoration \u2013 This process is designed to increase the functionality of your tiles and roof, as well as give them a renewed appearance. We use environmentally friendly Nutech Roof paint so your roof will withstand the harsh Australian weather conditions.",
                                        "url": "https://roofranger.com.au/roof-restoration/cement/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/cement/",
                                                "anchor_text": "Cement Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roof Restoration \u2013 Metal roof restoration is a great way to restore the exterior of sheet metal\u00a0roofs like galvanised iron or colorbond to a good-as-new state.\u00a0Quality metal roof restoration will leave your house waterproof.",
                                        "url": "https://roofranger.com.au/roof-restoration/metal/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/metal/",
                                                "anchor_text": "Metal Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whirly Bird Installation \u2013 Implementing a whirly bird on your roof is ideal during those summer months where temperatures reach high levels. Our wind driven turbine ventilator will exhaust heat & vapour from your home minus the use of electrical energy. Pick from 28 colours.",
                                        "url": "https://roofranger.com.au/whirly-bird-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/whirly-bird-installation/",
                                                "anchor_text": "Whirly Bird Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bedding & Pointing \u2013 Our quality bedding and pointing installation will ensure your roof looks better for longer. This works well for normal roof movement without any cracking.",
                                        "url": "https://roofranger.com.au/bedding-pointing/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/bedding-pointing/",
                                                "anchor_text": "Bedding & Pointing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Cleaning \u2013 Our roofing experts will clean out your gutters and downpipes to decrease the risk of fire damage during summer seasons. We also check that your roof has appropriate plumbing to avoid pressure build up and leakage.",
                                        "url": "https://roofranger.com.au/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement \u2013 It is imperative to ensure your roof is performing at its optimum level to ensure you and your family is protected from outside elements. A roof replacement service will replace any damaged or broken tiles your roof may have and provide you with a functioning roof.",
                                        "url": "https://roofranger.com.au/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting \u2013 Roof painting is a great way to increase the value of your home and ensure your property is looking its best. Roof painting can also reduce any mould or algae that can grow on your roof.",
                                        "url": "https://roofranger.com.au/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-painting/",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Leaks \u2013 Roof leaks are a nuisance and can damage the internal and external structure of your home. It is important to have any roof leak fixed immediately to ensure your property is healthy and well maintained.",
                                        "url": "https://roofranger.com.au/leaking-roof/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/leaking-roof/",
                                                "anchor_text": "Roof Leaks"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Ranger also specialise in roof painting, high pressure roof cleaning, roof leak detection, roof tile replacement, roof valley iron replacement, roof flashing replacement and roof sparking and insulation.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The cost of each service depends on an array of factors such as size, height, terrain, and the number of repairs needed. At Roof Ranger we aim to give you the best price. If you\u2019re looking for roofing services in your area contact us today and one of our friendly staff members will be happy to help.",
                                        "url": "https://roofranger.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/contact-us/",
                                                "anchor_text": "contact us"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Your Local Carlingford Roofer",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our roofing contractors have over 30 years experience in all facets of roofing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We offer an obligation free, honest, maintenance inspection of your roof and give genuine, easy to understand advice. We also provide guaranteed workmanship on all services. Are you worried about mess? Our tradesmen go to great lengths to ensure your home and surroundings are left good as new. Experience our personal service with high-quality materials as our focus. We know the Carlingford area and its roofing needs precisely.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All work completed by Roof Ranger comes with a 10 year warranty guarantee, that\u2019s how much we believe in the work we do. When you work with us, you receive only the best when it comes to our service and our workmanship. Read what our clients have said themselves!",
                                        "url": "https://roofranger.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/",
                                                "anchor_text": "Roof Ranger"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Ranger will travel to your location to meet your roofing requirements. If you live in the Carlingford area contact Roof Ranger on 0401 374 203 to receive an obligation free quote, or email daniel@roofranger.com.au to book a service today.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\ufeff \ufeff",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Carlingford Roof Restoration",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Terracotta Roof Restoration",
                                        "url": "https://roofranger.com.au/roof-restoration/terracotta/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/terracotta/",
                                                "anchor_text": "Terracotta Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cement Roof Restoration",
                                        "url": "https://roofranger.com.au/roof-restoration/cement/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/cement/",
                                                "anchor_text": "Cement Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roof Restoration",
                                        "url": "https://roofranger.com.au/roof-restoration/metal/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/metal/",
                                                "anchor_text": "Metal Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://roofranger.com.au/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-painting/",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bedding & Pointing",
                                        "url": "https://roofranger.com.au/bedding-pointing/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/bedding-pointing/",
                                                "anchor_text": "Bedding & Pointing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whirly Bird Installation",
                                        "url": "https://roofranger.com.au/whirly-bird-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/whirly-bird-installation/",
                                                "anchor_text": "Whirly Bird Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://roofranger.com.au/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof",
                                        "url": "https://roofranger.com.au/leaking-roof/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/leaking-roof/",
                                                "anchor_text": "Leaking Roof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://roofranger.com.au/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Western Sydney",
                                        "url": "https://roofranger.com.au/locations/roof-restoration-western-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/locations/roof-restoration-western-sydney/",
                                                "anchor_text": "Western Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hills District",
                                        "url": "https://roofranger.com.au/locations/hills-district/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/locations/hills-district/",
                                                "anchor_text": "Hills District"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Blue Mountains",
                                        "url": "https://roofranger.com.au/locations/roof-restoration-blue-mountains/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/locations/roof-restoration-blue-mountains/",
                                                "anchor_text": "Blue Mountains"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Image Gallery",
                                        "url": "https://roofranger.com.au/image-gallery/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/image-gallery/",
                                                "anchor_text": "Image Gallery"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Video Gallery",
                                        "url": "https://roofranger.com.au/video-gallery/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/video-gallery/",
                                                "anchor_text": "Video Gallery"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NXT Cool Zone",
                                        "url": "https://roofranger.com.au/nutech-paints/nxt-cool-zone/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/nutech-paints/nxt-cool-zone/",
                                                "anchor_text": "NXT Cool Zone"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact Us",
                                        "url": "https://roofranger.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/contact-us/",
                                                "anchor_text": "Contact Us"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Are You Living In Carlingford and Looking For Roofing Services?",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do You Need Your Roof Restored?",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Ranger can help.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We know your area and will reach you swiftly.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Contact Us",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Detail",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "licenses",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "lic: NO 244547c",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ABN: 75 615 464 465",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Detail",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Email: daniel@roofranger.com.au",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Phone: 0401 374 203",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Licenses",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Lic: NO 244547c",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ABN: 75 615 464 465",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Carlingford Roof Restoration",
                                "author": "daniel",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Terracotta Roof Restoration",
                                        "url": "https://roofranger.com.au/roof-restoration/terracotta/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/terracotta/",
                                                "anchor_text": "Terracotta Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cement Roof Restoration",
                                        "url": "https://roofranger.com.au/roof-restoration/cement/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/cement/",
                                                "anchor_text": "Cement Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roof Restoration",
                                        "url": "https://roofranger.com.au/roof-restoration/metal/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-restoration/metal/",
                                                "anchor_text": "Metal Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bedding & Pointing",
                                        "url": "https://roofranger.com.au/bedding-pointing/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/bedding-pointing/",
                                                "anchor_text": "Bedding & Pointing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whirly Bird Installation",
                                        "url": "https://roofranger.com.au/whirly-bird-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/whirly-bird-installation/",
                                                "anchor_text": "Whirly Bird Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://roofranger.com.au/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://roofranger.com.au/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/roof-painting/",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof",
                                        "url": "https://roofranger.com.au/leaking-roof/",
                                        "urls": [
                                            {
                                                "url": "https://roofranger.com.au/leaking-roof/",
                                                "anchor_text": "Leaking Roof"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61 0401 374 203",
                                "0401 374 203",
                                "0401374203"
                            ],
                            "emails": [
                                "daniel@roofranger.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}