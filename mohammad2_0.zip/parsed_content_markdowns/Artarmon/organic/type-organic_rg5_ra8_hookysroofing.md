{
    "id": "01190727-1132-0216-0000-124b0bda4b2d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0291 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://hookysroofing.sydney/artarmon/",
        "target": "hookysroofing.sydney",
        "start_url": "https://hookysroofing.sydney/artarmon/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Artarmon\\organic\\type-organic_rg5_ra8_hookysroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:51 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "NOW OFFERING Certified roof inspection for commercial and residential buildings Find Out More",
                                    "url": "https://www.hookysroofing.sydney/service/roof-inspections",
                                    "urls": [
                                        {
                                            "url": "https://www.hookysroofing.sydney/service/roof-inspections",
                                            "anchor_text": "Find Out More"
                                        }
                                    ]
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://hookysroofing.sydney/service/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://hookysroofing.sydney/service/colorbond-roofing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/colorbond-roofing-sydney/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Replacement",
                                    "url": "https://hookysroofing.sydney/service/metal-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/metal-roof-replacement/",
                                            "anchor_text": "Metal Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://hookysroofing.sydney/service/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Extensions",
                                    "url": "https://hookysroofing.sydney/service/roof-extensions/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/roof-extensions/",
                                            "anchor_text": "Roof Extensions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://hookysroofing.sydney/service/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Re-Roofing",
                                    "url": "https://hookysroofing.sydney/service/tile-re-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/tile-re-roofing/",
                                            "anchor_text": "Tile Re-Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Velux Skylights",
                                    "url": "https://hookysroofing.sydney/service/velux-skylights/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/velux-skylights/",
                                            "anchor_text": "Velux Skylights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Standing Seam Zinc Cladding",
                                    "url": "https://hookysroofing.sydney/service/standing-seam-roofing-and-cladding/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/standing-seam-roofing-and-cladding/",
                                            "anchor_text": "Standing Seam Zinc Cladding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://hookysroofing.sydney/services/roof-inspections",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/services/roof-inspections",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://hookysroofing.sydney/service/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://hookysroofing.sydney/service/colorbond-roofing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/colorbond-roofing-sydney/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Replacement",
                                    "url": "https://hookysroofing.sydney/service/metal-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/metal-roof-replacement/",
                                            "anchor_text": "Metal Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://hookysroofing.sydney/service/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Extensions",
                                    "url": "https://hookysroofing.sydney/service/roof-extensions/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/roof-extensions/",
                                            "anchor_text": "Roof Extensions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://hookysroofing.sydney/service/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Re-Roofing",
                                    "url": "https://hookysroofing.sydney/service/tile-re-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/tile-re-roofing/",
                                            "anchor_text": "Tile Re-Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Velux Skylights",
                                    "url": "https://hookysroofing.sydney/service/velux-skylights/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/velux-skylights/",
                                            "anchor_text": "Velux Skylights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Standing Seam Zinc Cladding",
                                    "url": "https://hookysroofing.sydney/service/standing-seam-roofing-and-cladding/",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/service/standing-seam-roofing-and-cladding/",
                                            "anchor_text": "Standing Seam Zinc Cladding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://hookysroofing.sydney/services/roof-inspections",
                                    "urls": [
                                        {
                                            "url": "https://hookysroofing.sydney/services/roof-inspections",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Providing Experienced Artarmon Roofing Services",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "At Hooky\u2019s Roofing, we\u2019re proud to be the specialists for roof replacement, extensions and more! For over 15 years, we\u2019ve provided the residents of Sydney\u2019s Northern beaches with expert service and advice on all their roofing needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We offer a comprehensive range of services to address your specific roofing requirements, including:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof replacements and extensions",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Other metal roofing services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team is qualified, experienced, and adept at working with a variety of roofing materials, from traditional options to highly engineered solutions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether you\u2019re aiming for a classic heritage finish or exploring the benefits of metal roofing, we\u2019ll ensure you get exactly what you\u2019re looking for.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As Artarmon\u2019s leading re-roofing company, we\u2019re here to assist you. No matter where you\u2019re located in Artarmon, we have the expertise and services to meet your needs. It\u2019s safe to say that Hooky\u2019s Roofing stands out as second to none.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "New roofs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Colorbond roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof tiling",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Commercial re-roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "COLORBOND Roofing Installation & Replacement",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "COLORBOND Roofing Installation & Replacement No metal roofing is more flexible, striking, or thermally efficient as COLORBOND! It is the brainchild of BlueScope Steel, which has drawn on the very best...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "COLORBOND Roofing Installation & Replacement",
                                        "url": "https://hookysroofing.sydney/service/colorbond-roofing-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/colorbond-roofing-sydney/",
                                                "anchor_text": "COLORBOND Roofing Installation & Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roof Replacement",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal Roof Replacement If you are in need of a roofing specialist in North Sydney, we are here to help. When it comes to quality metal and tile re-roofing or maintenance,...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roof Replacement",
                                        "url": "https://hookysroofing.sydney/service/metal-roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/metal-roof-replacement/",
                                                "anchor_text": "Metal Roof Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiles",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Quality Roof Tile Replacement in Sydney If your roof is well past its use-by date, perhaps you should contact Hookys. We offer the roof tile replacement Sydney locals trust to last....",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiles",
                                        "url": "https://hookysroofing.sydney/service/roof-tiles/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/roof-tiles/",
                                                "anchor_text": "Roof Tiles"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Inspections with Comprehensive Professional Roof Condition Reports We specialise in providing the most comprehensive roof inspections and roof inspection reports for residents and businesses across Sydney. With decades of...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://hookysroofing.sydney/service/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/roof-inspections/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal Roofing and KLIP-LOK roofing for Sydney Homes Hooky\u2019s Roofing only uses the highest quality metal roofing accessories and anti-condensation insulation products, including COLORBOND, KLIP-LOK roofing and CUSTOM BLUE ORB, for...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://hookysroofing.sydney/service/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "New Roofs",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If you have a proposed new house or project that requires a Colorbond metal roof or standing seam zinc roof we have a highly skilled team of certified tradesman to deliver a...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "New Roofs",
                                        "url": "https://hookysroofing.sydney/service/new-roofs/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/new-roofs/",
                                                "anchor_text": "New Roofs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Replacement, Maintenance & Restoration North Sydney If you have a renovation, roof replacement, restoration or maintenance or project that requires a Colorbond metal roof or standing seam zinc roof we...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://hookysroofing.sydney/service/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond and Zinc Standing Seam",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Standing Seam and architectural roofing and cladding systems are versatile options for feature roofs and walls that offer your build a unique finish. Each panel laps each other which are then...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Colorbond and Zinc Standing Seam",
                                        "url": "https://hookysroofing.sydney/service/standing-seam-roofing-and-cladding/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/standing-seam-roofing-and-cladding/",
                                                "anchor_text": "Colorbond and Zinc Standing Seam"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Extensions",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Hooky\u2019s roofing has high level of expertise with metal and Colorbond roof extensions, and can help guide you, your builder or foreman to the correct Colorbond metal roofing profile and finish to...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Extensions",
                                        "url": "https://hookysroofing.sydney/service/roof-extensions/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/roof-extensions/",
                                                "anchor_text": "Roof Extensions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With the minimal amount of inconvenience to your business we can replace your metal roof with a new CLIP Lock (klip lok)Colorbond roof. These concealed clip Colorbond roofing profiles are perfect for...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing",
                                        "url": "https://hookysroofing.sydney/service/commercial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/commercial-roofing/",
                                                "anchor_text": "Commercial Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Cladding",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Highly regarded in architectural design, VM Zinc, Aluminium & Matt Colorbond cladding has fast become desiredmaterial for modern facade and roofing applications to improve the appearance of the building. The composition is...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Cladding",
                                        "url": "https://hookysroofing.sydney/service/facade-and-cladding/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/facade-and-cladding/",
                                                "anchor_text": "Cladding"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Velux Skylights",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Hookys roofing has vast experience in installing Velux skylights on metal colorbond roofs through Sydney\u2019s north shore and northern beaches. All our Velux installations are installed high metal roofing standards. We also...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Velux Skylights",
                                        "url": "https://hookysroofing.sydney/service/velux-skylights/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/velux-skylights/",
                                                "anchor_text": "Velux Skylights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Re-roofing",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If your roof is past it\u2019s use-by date, perhaps you should contact Hookys. We offer the roof tile replacement Sydney locals trust to last. We work with the full Monier Cement and...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tile Re-roofing",
                                        "url": "https://hookysroofing.sydney/service/tile-re-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/tile-re-roofing/",
                                                "anchor_text": "Tile Re-roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Insulation",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Insulation comes in many different thicknesses with a range different tolerances and R values. It can be very confusing to select the correct product without being misled and directed into a product...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Insulation",
                                        "url": "https://hookysroofing.sydney/service/insulation/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/insulation/",
                                                "anchor_text": "Insulation"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Rainwater Goods",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Colorbond gutters and rainwater goods come in a large range of different profiles, from quad high front slotted gutters to architectural 150mm half round gutters to name a few, the selection is...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutters & Rainwater Goods",
                                        "url": "https://hookysroofing.sydney/service/rainwater-goods/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/service/rainwater-goods/",
                                                "anchor_text": "Gutters & Rainwater Goods"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "The Artarmon Roofers with a Difference",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Hooky\u2019s Roofing, we provide a written guarantee on all work that we carry out and a fully insured service, including home warranty access and a 50-year warranty on all new terracotta tiles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team is dedicated to achieving customer satisfaction. We\u2019re highly trained and qualified, with the experience and attention to detail to complete your projects to the highest standard.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are committed to delivering superior customer service on all Artarmon roofing jobs. For quality roof replacement, roof tiling, and much more, simply contact the team at Hooky\u2019s Roofing for a quick quote today. If you\u2019d like to discuss your specific roofing needs in Artarmon or any other metropolitan suburb, you can give us a call on 0408 026 601. Alternatively, you can also use the Quick Quote form to the right of the screen to get in touch, and our team will get back to you as soon as possible.",
                                        "url": "https://hookysroofing.sydney/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/contact-us/",
                                                "anchor_text": "Quick Quote form"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Providing Experienced Artarmon Roofing Services",
                                "main_title": "Providing Experienced Artarmon Roofing Services",
                                "author": "Hookys Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We Provide Services in these areas:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Copyright \u00a9 2023 Hookys Roofing Pty Ltd - All Rights Reserved.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Neutral Bay",
                                        "url": "https://hookysroofing.sydney/neutral-bay/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/neutral-bay/",
                                                "anchor_text": "Neutral Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Crows Nest",
                                        "url": "https://hookysroofing.sydney/crows-nest-metal-roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/crows-nest-metal-roof-replacement/",
                                                "anchor_text": "Crows Nest"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dee Why",
                                        "url": "https://hookysroofing.sydney/dee-why/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/dee-why/",
                                                "anchor_text": "Dee Why"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mona Vale",
                                        "url": "https://hookysroofing.sydney/mona-vale/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/mona-vale/",
                                                "anchor_text": "Mona Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Northern Beaches",
                                        "url": "https://hookysroofing.sydney/northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://hookysroofing.sydney/northern-beaches/",
                                                "anchor_text": "Northern Beaches"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whale beach",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Avalon and beyond",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quick Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Name *",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Phone Number *",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Postcode *",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email *",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.9,
                                "max_rating_value": 5,
                                "rating_count": null,
                                "relative_rating": 0.9800000000000001
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0408 026 601",
                                "0408026601"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}