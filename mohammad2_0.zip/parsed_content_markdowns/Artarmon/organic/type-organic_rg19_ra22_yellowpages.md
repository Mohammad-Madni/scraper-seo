{
    "id": "01190727-1132-0216-0000-fb0083e4e317",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0164 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/artarmon-nsw-2064",
        "target": "www.yellowpages.com.au",
        "start_url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/artarmon-nsw-2064",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Artarmon\\organic\\type-organic_rg19_ra22_yellowpages.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:30:53 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration & Repairs Near Me",
                                    "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/nsw",
                                    "urls": [
                                        {
                                            "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/nsw",
                                            "anchor_text": "Roof Restoration & Repairs Near Me"
                                        }
                                    ]
                                },
                                {
                                    "text": "Artarmon NSW",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "What are the benefits of a roof restoration?",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The benefits from a roof restoration will depend on the type of roof you have. Some of the benefits of a metal roof restoration or roof repair include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Weatherproofing your home, making it safe in a storm and more secure in high winds",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Giving your home an updated and refreshed look",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of any sheets that are rusted beyond repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of rusty or lose nails",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Professional treatment of light rust",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Benefits of tile roof restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tiles are recoated, preventing them from becoming waterlogged in rainy seasons",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ridges are re-pointed which makes them safe in violent weather and high winds, dramatically reducing storm damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The quality of run-off water from your roof is improved. Here, the improved water quality in tank water is cleaner for other uses and applications.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Yellow, we\u2019re here to help. If you would like roof replacement services, get a quote by checking out our listings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Piper's Plumbing Pty Ltd",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters, Artarmon, NSW 2064",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Piper's Plumbing provide repairs and maintenance for commercial and residential. 24/7 service. Contact us",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Piper's Plumbing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/willoughby/pipers-plumbing-pty-ltd-12981862-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/willoughby/pipers-plumbing-pty-ltd-12981862-listing.html",
                                                "anchor_text": "Piper's Plumbing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9901 4866",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutterscreen",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Guttering & Spouting, North Ryde, NSW 2113",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: Qualified and experienced professional team",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutterscreen",
                                        "url": "https://www.yellowpages.com.au/nsw/north-ryde/gutterscreen-13221525-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/north-ryde/gutterscreen-13221525-listing.html",
                                                "anchor_text": "Gutterscreen"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:30pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0417 659 915",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "26 Results for Roof Restorations Near You",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Artarmon, NSW 2064",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aussie Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/artarmon/aussie-roofing-services-1000002965114-listing.html?isTopOfList=true&premiumProductId=400009942718",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/artarmon/aussie-roofing-services-1000002965114-listing.html?isTopOfList=true&premiumProductId=400009942718",
                                                "anchor_text": "Aussie Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, servicing Artarmon",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aussie Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/artarmon/aussie-roofing-services-1000002965114-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/artarmon/aussie-roofing-services-1000002965114-listing.html",
                                                "anchor_text": "Aussie Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aussie Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/aussie-roofing-services-1000002964917-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/aussie-roofing-services-1000002964917-listing.html",
                                                "anchor_text": "Aussie Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Andris Metal Roofing",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, East Ryde, NSW 2113",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Andris Metal Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/east-ryde/andris-metal-roofing-13784649-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/east-ryde/andris-metal-roofing-13784649-listing.html",
                                                "anchor_text": "Andris Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "John R. Dean Constructions Pty Ltd",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Builders & Building Contractors, Lane Cove, NSW 2066",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "John R. Dean Constructions Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/lane-cove/john-r-dean-constructions-pty-ltd-15457618-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/lane-cove/john-r-dean-constructions-pty-ltd-15457618-listing.html",
                                                "anchor_text": "John R. Dean Constructions Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pro Blast Services",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Pressure & Steam Cleaning Contractors, Drummoyne, NSW 2047",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pro Blast Services",
                                        "url": "https://www.yellowpages.com.au/nsw/drummoyne/pro-blast-services-1000002995315-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/drummoyne/pro-blast-services-1000002995315-listing.html",
                                                "anchor_text": "Pro Blast Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pro Blast Services",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Pressure & Steam Cleaning Contractors, Seaforth, NSW 2092",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pro Blast Services",
                                        "url": "https://www.yellowpages.com.au/nsw/seaforth/pro-blast-services-1000002995316-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/seaforth/pro-blast-services-1000002995316-listing.html",
                                                "anchor_text": "Pro Blast Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "The Roofing Professionals Northside",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Artarmon, NSW 2064",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "The Roofing Professionals Northside",
                                        "url": "https://www.yellowpages.com.au/nsw/artarmon/the-roofing-professionals-northside-1000002154140-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/artarmon/the-roofing-professionals-northside-1000002154140-listing.html",
                                                "anchor_text": "The Roofing Professionals Northside"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 7:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0432 286 448",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Handy tips",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Reliance Roof Restoration North Shore Pty",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Lane Cove, NSW 2066",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Reliance Roof Restoration North Shore Pty",
                                        "url": "https://www.yellowpages.com.au/nsw/lane-cove/reliance-roof-restoration-north-shore-pty-15230349-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/lane-cove/reliance-roof-restoration-north-shore-pty-15230349-listing.html",
                                                "anchor_text": "Reliance Roof Restoration North Shore Pty"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Legal ID: 245249C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 300 748",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "ASAP Roofing",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Lane Cove, NSW 2066",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "ASAP Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/lane-cove/asap-roofing-14548401-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/lane-cove/asap-roofing-14548401-listing.html",
                                                "anchor_text": "ASAP Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0415 389 673",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "The Roofing Professionals",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Artarmon, NSW 2064",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "The Roofing Professionals",
                                        "url": "https://www.yellowpages.com.au/nsw/artarmon/the-roofing-professionals-13338298-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/artarmon/the-roofing-professionals-13338298-listing.html",
                                                "anchor_text": "The Roofing Professionals"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "4/ 80 Reserve Rd, Artarmon, NSW, 2064",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=4%252F+80+Reserve+Rd&context=undefined&directionMode=true&elat=-33.81791&elon=151.1875&ena=The+Roofing+Professionals&estr=4%2F+80+Reserve+Rd&esu=Artarmon%2C+NSW%2C+2064&productVersion=5&productId=473730571&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DThe+Roofing+Professionals%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.81791%26lon%3D151.1875%26selectedViewMode%3Dlist&yellowId=13338298",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=4%252F+80+Reserve+Rd&context=undefined&directionMode=true&elat=-33.81791&elon=151.1875&ena=The+Roofing+Professionals&estr=4%2F+80+Reserve+Rd&esu=Artarmon%2C+NSW%2C+2064&productVersion=5&productId=473730571&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DThe+Roofing+Professionals%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.81791%26lon%3D151.1875%26selectedViewMode%3Dlist&yellowId=13338298",
                                                "anchor_text": "4/ 80 Reserve Rd, Artarmon, NSW, 2064"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9439 6888",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Fix Restorations",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Chatswood, NSW 2067",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Fix Restorations",
                                        "url": "https://www.yellowpages.com.au/nsw/chatswood/roof-fix-restorations-1000002953701-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/chatswood/roof-fix-restorations-1000002953701-listing.html",
                                                "anchor_text": "Roof Fix Restorations"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "465 Victoria Ave, Chatswood, NSW, 2067",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=465+Victoria+Ave&context=undefined&directionMode=true&elat=-33.796785&elon=151.179947&ena=Roof+Fix+Restorations&estr=465+Victoria+Ave&esu=Chatswood%2C+NSW%2C+2067&productVersion=1&productId=1000002953701&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRoof+Fix+Restorations%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.796785%26lon%3D151.179947%26selectedViewMode%3Dlist&yellowId=1000002953701",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=465+Victoria+Ave&context=undefined&directionMode=true&elat=-33.796785&elon=151.179947&ena=Roof+Fix+Restorations&estr=465+Victoria+Ave&esu=Chatswood%2C+NSW%2C+2067&productVersion=1&productId=1000002953701&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRoof+Fix+Restorations%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.796785%26lon%3D151.179947%26selectedViewMode%3Dlist&yellowId=1000002953701",
                                                "anchor_text": "465 Victoria Ave, Chatswood, NSW, 2067"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9994 8962",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "T P Roofing",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Lane Cove, NSW 2066",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "T P Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/lane-cove/t-p-roofing-13073369-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/lane-cove/t-p-roofing-13073369-listing.html",
                                                "anchor_text": "T P Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9888 6454",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "B.P. Roofing and Gutter Cleaning",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Crows Nest, NSW 2065",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "B.P. Roofing and Gutter Cleaning",
                                        "url": "https://www.yellowpages.com.au/nsw/crows-nest/bp-roofing-and-gutter-cleaning-12672502-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/crows-nest/bp-roofing-and-gutter-cleaning-12672502-listing.html",
                                                "anchor_text": "B.P. Roofing and Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0415 389 673",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Quick Roof Service",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Chatswood, NSW 2067",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Quick Roof Service",
                                        "url": "https://www.yellowpages.com.au/nsw/chatswood/quick-roof-service-14204124-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/chatswood/quick-roof-service-14204124-listing.html",
                                                "anchor_text": "Quick Roof Service"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1 Pacific Hwy, Chatswood, NSW, 2057",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=1+Pacific+Hwy&context=undefined&directionMode=true&elat=-33.797595&elon=151.178306&ena=Quick+Roof+Service&estr=1+Pacific+Hwy&esu=Chatswood%2C+NSW%2C+2057&productVersion=3&productId=999015404273&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DQuick+Roof+Service%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.797595%26lon%3D151.178306%26selectedViewMode%3Dlist&yellowId=14204124",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=1+Pacific+Hwy&context=undefined&directionMode=true&elat=-33.797595&elon=151.178306&ena=Quick+Roof+Service&estr=1+Pacific+Hwy&esu=Chatswood%2C+NSW%2C+2057&productVersion=3&productId=999015404273&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DQuick+Roof+Service%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.797595%26lon%3D151.178306%26selectedViewMode%3Dlist&yellowId=14204124",
                                                "anchor_text": "1 Pacific Hwy, Chatswood, NSW, 2057"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0450 146 980",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Roof Repairs",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Lindfield, NSW 2070",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney Roof Repairs",
                                        "url": "https://www.yellowpages.com.au/sup/sydney-roof-repairs-15393251-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/sydney-roof-repairs-15393251-listing.html",
                                                "anchor_text": "Sydney Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open by appt",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 764 456",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Paramount Roof Restoration",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Hunters Hill, NSW 2110",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Paramount Roof Restoration",
                                        "url": "https://www.yellowpages.com.au/sup/paramount-roof-restoration-15367892-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/paramount-roof-restoration-15367892-listing.html",
                                                "anchor_text": "Paramount Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0418 204 042",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "CPR Roofing Pty Ltd",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Gladesville, NSW 2111",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: License. No.132359C",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "CPR Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/gladesville/cpr-roofing-pty-ltd-1000002337370-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/gladesville/cpr-roofing-pty-ltd-1000002337370-listing.html",
                                                "anchor_text": "CPR Roofing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0418 677 188",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Factor 1 Roofing And Guttering",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Abbotsford, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Factor 1 Roofing And Guttering",
                                        "url": "https://www.yellowpages.com.au/nsw/abbotsford/factor-1-roofing-and-guttering-15258391-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/abbotsford/factor-1-roofing-and-guttering-15258391-listing.html",
                                                "anchor_text": "Factor 1 Roofing And Guttering"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0424 495 172",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "C.M.S. Roofing Pty Ltd",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Rozelle, NSW 2039",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "C.M.S. Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/rozelle/cms-roofing-pty-ltd-12190702-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/rozelle/cms-roofing-pty-ltd-12190702-listing.html",
                                                "anchor_text": "C.M.S. Roofing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "26C Mansfield St, Rozelle, NSW, 2039",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=26C+Mansfield+St&context=undefined&directionMode=true&elat=-33.864499&elon=151.178715&ena=C.M.S.+Roofing+Pty+Ltd&estr=26C+Mansfield+St&esu=Rozelle%2C+NSW%2C+2039&productVersion=4&productId=999999075911&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DC.M.S.+Roofing+Pty+Ltd%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.864499%26lon%3D151.178715%26selectedViewMode%3Dlist&yellowId=12190702",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=26C+Mansfield+St&context=undefined&directionMode=true&elat=-33.864499&elon=151.178715&ena=C.M.S.+Roofing+Pty+Ltd&estr=26C+Mansfield+St&esu=Rozelle%2C+NSW%2C+2039&productVersion=4&productId=999999075911&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DC.M.S.+Roofing+Pty+Ltd%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.864499%26lon%3D151.178715%26selectedViewMode%3Dlist&yellowId=12190702",
                                                "anchor_text": "26C Mansfield St, Rozelle, NSW, 2039"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9555 8944",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Budget Roof Painting",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Budget Roof Painting",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/budget-roof-painting-1000002839977-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/budget-roof-painting-1000002839977-listing.html",
                                                "anchor_text": "Budget Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "31 Alfred St, Sydney, NSW, 2000",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=31+Alfred+St&context=undefined&directionMode=true&elat=-33.862199&elon=151.210859&ena=Budget+Roof+Painting&estr=31+Alfred+St&esu=Sydney%2C+NSW%2C+2000&productVersion=1&productId=1000002839977&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DBudget+Roof+Painting%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.862199%26lon%3D151.210859%26selectedViewMode%3Dlist&yellowId=1000002839977",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=31+Alfred+St&context=undefined&directionMode=true&elat=-33.862199&elon=151.210859&ena=Budget+Roof+Painting&estr=31+Alfred+St&esu=Sydney%2C+NSW%2C+2000&productVersion=1&productId=1000002839977&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DBudget+Roof+Painting%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.862199%26lon%3D151.210859%26selectedViewMode%3Dlist&yellowId=1000002839977",
                                                "anchor_text": "31 Alfred St, Sydney, NSW, 2000"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0491 727 077",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "T P Roofing",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, East Ryde, NSW 2113",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "T P Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/east-ryde/t-p-roofing-12330807-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/east-ryde/t-p-roofing-12330807-listing.html",
                                                "anchor_text": "T P Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "3 Bluett Ave, East Ryde, NSW, 2113",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=3+Bluett+Ave&context=undefined&directionMode=true&elat=-33.80925&elon=151.12823&ena=T+P+Roofing&estr=3+Bluett+Ave&esu=East+Ryde%2C+NSW%2C+2113&productVersion=3&productId=473772411&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DT+P+Roofing%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.80925%26lon%3D151.12823%26selectedViewMode%3Dlist&yellowId=12330807",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=3+Bluett+Ave&context=undefined&directionMode=true&elat=-33.80925&elon=151.12823&ena=T+P+Roofing&estr=3+Bluett+Ave&esu=East+Ryde%2C+NSW%2C+2113&productVersion=3&productId=473772411&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DT+P+Roofing%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.80925%26lon%3D151.12823%26selectedViewMode%3Dlist&yellowId=12330807",
                                                "anchor_text": "3 Bluett Ave, East Ryde, NSW, 2113"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9888 6454",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "OMG Maintenance",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Home Maintenance & Handymen, Lane Cove, NSW 2066",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "OMG Maintenance",
                                        "url": "https://www.yellowpages.com.au/nsw/lane-cove/omg-maintenance-1000002100177-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/lane-cove/omg-maintenance-1000002100177-listing.html",
                                                "anchor_text": "OMG Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 6:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0478 493 151",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Freeflow Guttering",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Guttering & Spouting, Seaforth, NSW 2092",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Freeflow Guttering",
                                        "url": "https://www.yellowpages.com.au/nsw/brookvale/freeflow-guttering-15470311-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/brookvale/freeflow-guttering-15470311-listing.html",
                                                "anchor_text": "Freeflow Guttering"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open by appt",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "31 Manly Rd, Brookvale, NSW, 2100",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=31+Manly+Rd&context=undefined&directionMode=true&elat=-33.798519&elon=151.251508&ena=Freeflow+Guttering&estr=31+Manly+Rd&esu=Brookvale%2C+NSW%2C+2100&productVersion=17&productId=479096941&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DFreeflow+Guttering%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.798519%26lon%3D151.251508%26selectedViewMode%3Dlist&yellowId=15470311",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=31+Manly+Rd&context=undefined&directionMode=true&elat=-33.798519&elon=151.251508&ena=Freeflow+Guttering&estr=31+Manly+Rd&esu=Brookvale%2C+NSW%2C+2100&productVersion=17&productId=479096941&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DFreeflow+Guttering%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.798519%26lon%3D151.251508%26selectedViewMode%3Dlist&yellowId=15470311",
                                                "anchor_text": "31 Manly Rd, Brookvale, NSW, 2100"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Legal ID: Quality",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0414 955 855",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restorations Sydney",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Ryde, NSW 2112",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Restorations Sydney",
                                        "url": "https://www.yellowpages.com.au/nsw/ryde/roof-restorations-sydney-1000000563907-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ryde/roof-restorations-sydney-1000000563907-listing.html",
                                                "anchor_text": "Roof Restorations Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Abaroo St, Ryde, NSW, 2112",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Abaroo+St&context=undefined&directionMode=true&elat=-33.80982895&elon=151.11736945&ena=Roof+Restorations+Sydney&estr=Abaroo+St&esu=Ryde%2C+NSW%2C+2112&productVersion=3&productId=1000000563907&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRoof+Restorations+Sydney%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.80982895%26lon%3D151.11736945%26selectedViewMode%3Dlist&yellowId=1000000563907",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Abaroo+St&context=undefined&directionMode=true&elat=-33.80982895&elon=151.11736945&ena=Roof+Restorations+Sydney&estr=Abaroo+St&esu=Ryde%2C+NSW%2C+2112&productVersion=3&productId=1000000563907&ref=ypgd&referredBy=undefined&str=Artarmon%2C+NSW+2064&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRoof+Restorations+Sydney%26locationClue%3DArtarmon%2C+NSW+2064%26lat%3D-33.80982895%26lon%3D151.11736945%26selectedViewMode%3Dlist&yellowId=1000000563907",
                                                "anchor_text": "Abaroo St, Ryde, NSW, 2112"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0434 747 245",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Average rating for Roof Restoration & Repairs in Artarmon and surrounding suburbs",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Based on 767 reviews of 160 businesses on this page",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Articles",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Nearby Locations for Roof Restorations",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular Categories in Artarmon",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Categories in Artarmon",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Gutter & Roof Restoration",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Warning, Not All Roof Companies Are The Same",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Slaters & Roof Tilers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 654 884",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Guttering & Spouting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Regent Skylights",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Factory Direct Skylights, Energy Efficient Patented Press & Flashings",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(07) 3274 3344",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Eco Wool Insulation Services",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Insulation Installers & Contractors",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0481 845 529",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tai Irwin Plumbing & Draining",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Emergency Plumbing & Gasfitting 24/7 - Northern Beaches & North Shore",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9191 8784",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Gutter & Roof Restoration",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Warning, Not All Roof Companies Are The Same",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Guttering & Spouting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 654 884",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "A Class Plumbing",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Reliable, Professional Industrial & Commercial Specialists",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9630 4227",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Related Articles",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our directory.",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Yellow Pages",
                                        "url": "https://www.yellowpages.com.au/pages/about-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/about-us",
                                                "anchor_text": "About Yellow Pages"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://www.yellowpages.com.au/pages/contact-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/contact-us",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Site Index",
                                        "url": "https://www.yellowpages.com.au/sitemap",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sitemap",
                                                "anchor_text": "Site Index"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Order or cancel your book",
                                        "url": "https://www.directoryselect.com.au/action/home",
                                        "urls": [
                                            {
                                                "url": "https://www.directoryselect.com.au/action/home",
                                                "anchor_text": "Order or cancel your book"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our advertising.",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Get a free listing",
                                        "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                                "anchor_text": "Get a free listing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Digital marketing solutions",
                                        "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                                "anchor_text": "Digital marketing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Business hub",
                                        "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                                "anchor_text": "Business hub"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "myYellow login",
                                        "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                                "anchor_text": "myYellow login"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Connect with us.",
                                "main_title": "26 BEST local Roof Restorations in Artarmon NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Thryv Australia",
                                        "url": "https://corporate.thryv.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/",
                                                "anchor_text": "About Thryv Australia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://corporate.thryv.com/privacy/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com/privacy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://corporate.thryv.com.au/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.2,
                                "max_rating_value": 5,
                                "rating_count": 767,
                                "relative_rating": 0.8400000000000001
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0485 800 063",
                                "(02) 9888 9672",
                                "(02) 9630 8811",
                                "0481 941 941",
                                "0432 286 448",
                                "1300 300 748",
                                "0415 389 673",
                                "(02) 9439 6888",
                                "(02) 9994 8962",
                                "(02) 9888 6454",
                                "0450 146 980",
                                "1300 764 456",
                                "0418 204 042",
                                "0418 677 188",
                                "0424 495 172",
                                "(02) 9555 8944",
                                "0491 727 077",
                                "0478 493 151",
                                "(02) 9901 4866",
                                "0414 955 855",
                                "0417 659 915",
                                "0434 747 245",
                                "0432286448",
                                "1300300748",
                                "0415389673",
                                "0294396888",
                                "0299948962",
                                "0298886454",
                                "0450146980",
                                "1300764456",
                                "0418204042",
                                "0418677188",
                                "0424495172",
                                "0295558944",
                                "0491727077",
                                "0478493151",
                                "0299014866",
                                "0414955855",
                                "0417659915",
                                "0434747245",
                                "1300654884",
                                "1300556541",
                                "0732743344",
                                "0481845529",
                                "0291918784",
                                "0296304227"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}