{
    "id": "01190727-1132-0216-0000-76c2d034d13a",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0202 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.newtechroofing.com.au/artarmon/",
        "target": "www.newtechroofing.com.au",
        "start_url": "https://www.newtechroofing.com.au/artarmon/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Artarmon\\organic\\type-organic_rg15_ra18_newtechroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:49 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "2/9B Babbage Rd, Roseville Chase NSW 2069",
                                    "url": "https://goo.gl/maps/Q5HwSxjAV56zk9V89",
                                    "urls": [
                                        {
                                            "url": "https://goo.gl/maps/Q5HwSxjAV56zk9V89",
                                            "anchor_text": "2/9B Babbage Rd, Roseville Chase NSW 2069"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://www.newtechroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roofing",
                                    "url": "https://www.newtechroofing.com.au/emergency-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/emergency-roofing/",
                                            "anchor_text": "Emergency Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Maintenance",
                                    "url": "https://www.newtechroofing.com.au/gutter-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/gutter-maintenance/",
                                            "anchor_text": "Gutter Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://www.newtechroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roofs",
                                    "url": "https://www.newtechroofing.com.au/leaking-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/leaking-roofs/",
                                            "anchor_text": "Leaking Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.newtechroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://www.newtechroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://www.newtechroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance and Cleaning",
                                    "url": "https://www.newtechroofing.com.au/roof-maintenance-and-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-maintenance-and-cleaning/",
                                            "anchor_text": "Roof Maintenance and Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.newtechroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "About us",
                                    "url": "https://www.newtechroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/about-us/",
                                            "anchor_text": "About us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.newtechroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://www.newtechroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roofing",
                                    "url": "https://www.newtechroofing.com.au/emergency-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/emergency-roofing/",
                                            "anchor_text": "Emergency Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Maintenance",
                                    "url": "https://www.newtechroofing.com.au/gutter-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/gutter-maintenance/",
                                            "anchor_text": "Gutter Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair",
                                    "url": "https://www.newtechroofing.com.au/gutter-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/gutter-repair/",
                                            "anchor_text": "Gutter Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roofs",
                                    "url": "https://www.newtechroofing.com.au/leaking-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/leaking-roofs/",
                                            "anchor_text": "Leaking Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.newtechroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://www.newtechroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://www.newtechroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance and Cleaning",
                                    "url": "https://www.newtechroofing.com.au/roof-maintenance-and-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-maintenance-and-cleaning/",
                                            "anchor_text": "Roof Maintenance and Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.newtechroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "About us",
                                    "url": "https://www.newtechroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/about-us/",
                                            "anchor_text": "About us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.newtechroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "2/9B Babbage Rd, Roseville Chase NSW 2069",
                                    "url": "https://goo.gl/maps/Q5HwSxjAV56zk9V89",
                                    "urls": [
                                        {
                                            "url": "https://goo.gl/maps/Q5HwSxjAV56zk9V89",
                                            "anchor_text": "2/9B Babbage Rd, Roseville Chase NSW 2069"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://www.newtechroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Areas We Serve",
                                    "url": "https://www.newtechroofing.com.au/locations/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/locations/",
                                            "anchor_text": "Areas We Serve"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.newtechroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Maintenance",
                                    "url": "https://www.newtechroofing.com.au/gutter-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/gutter-maintenance/",
                                            "anchor_text": "Gutter Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.newtechroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://www.newtechroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roofing",
                                    "url": "https://www.newtechroofing.com.au/emergency-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/emergency-roofing/",
                                            "anchor_text": "Emergency Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://www.newtechroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://www.newtechroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.newtechroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance and Cleaning",
                                    "url": "https://www.newtechroofing.com.au/roof-maintenance-and-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-maintenance-and-cleaning/",
                                            "anchor_text": "Roof Maintenance and Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roofs",
                                    "url": "https://www.newtechroofing.com.au/leaking-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/leaking-roofs/",
                                            "anchor_text": "Leaking Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "\u00a9 2025 All rights reserved",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.newtechroofing.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms of Use",
                                    "url": "https://www.newtechroofing.com.au/terms-of-use/",
                                    "urls": [
                                        {
                                            "url": "https://www.newtechroofing.com.au/terms-of-use/",
                                            "anchor_text": "Terms of Use"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roofing Contractor in Artarmon",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Artarmon\u2019s mix of commercial buildings, industrial facilities, and strata-managed apartments demands roofing services that are precise, documented, and compliant. Whether it\u2019s a leaking warehouse roof, a strata-approved repair, or a full restoration project, New Tech Roofing delivers technical excellence backed by full transparency.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Our licensed team works across Sydney\u2019s Lower North Shore, providing same-day emergency leak response, detailed photographic reporting, and warranty-backed workmanship. From small tile replacements to large-scale metal re-roofing projects, we offer the reliability, documentation, and safety compliance expected by professionals, strata committees, and homeowners alike.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Artarmon Clients Trust New Tech Roofing",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "What It Means for You",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Same-day triage for residential and commercial properties, with photographic reports.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Distinguish between storm damage and maintenance for faster claim processing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clear breakdowns of materials, safety setups, and warranty inclusions \u2014 no \u201cdodgy\u201d surprises.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Full SWMS, rope access, and compliance for multi-storey and industrial sites.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Every stage documented for client, insurer, and compliance records.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "What We Offer",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast Leak Response",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Insurance-Ready Documentation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent, Itemised Quotes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Strata & Commercial Expertise",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Photo Proof & Warranties",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": [
                                    {
                                        "header": null,
                                        "body": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "What We Offer",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "What It Means for You",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Fast Leak Response",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Same-day triage for residential and commercial properties, with photographic reports.",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Insurance-Ready Documentation",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Distinguish between storm damage and maintenance for faster claim processing.",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Transparent, Itemised Quotes",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Clear breakdowns of materials, safety setups, and warranty inclusions \u2014 no \u201cdodgy\u201d surprises.",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Strata & Commercial Expertise",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Full SWMS, rope access, and compliance for multi-storey and industrial sites.",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Photo Proof & Warranties",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Every stage documented for client, insurer, and compliance records.",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            }
                                        ],
                                        "footer": null
                                    }
                                ]
                            },
                            {
                                "h_title": "Roofing Services in Artarmon",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We handle every aspect of roof repair, restoration, and replacement, using premium Australian materials and industry best practices.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak Repairs",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Blocked gutters, failed flashing, or aging sealants can cause leaks that return after every downpour. We use thermal imaging and moisture tracing to locate the true cause, not just the symptom. Our repairs include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flashing replacement and proper waterproof sealing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repointing ridge caps with flexible mortar",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tile and panel replacements (like-for-like)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Weep hole cleaning and roof drainage optimisation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We don\u2019t patch with silicone \u2014 we fix the underlying issue permanently.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restorations",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If your roof is structurally sound but cosmetically worn, restoration is the most cost-effective way to extend its lifespan. Our process includes:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "High-pressure cleaning and debris removal",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Full re-bedding and pointing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Application of primer, sealer, and UV-resistant coatings",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Optional heat-reflective Colorbond finishes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "This approach restores durability, improves insulation, and enhances curb appeal \u2014 ideal for both residential and commercial sites.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Strata Roofing & Reports",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For strata buildings and multi-unit complexes, we provide formal inspection reports and compliant repair scopes with photo evidence, quotes, and warranty details. Our team handles:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leak investigation and access planning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "SWMS and safety documentation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Liaison with strata committees and property managers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We understand strata timelines and approval processes, helping managers make informed, evidence-based decisions quickly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Rope access coordination",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial & Industrial Roofing",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Artarmon\u2019s light industrial and logistics facilities need durable roofing that withstands both weather and wear. We provide:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Colorbond re-roofing and sheet replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter system upgrades and box gutter redesign",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Skylight and fa\u00e7ade flashing installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Preventative maintenance programs for high-traffic sites",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All work is delivered with minimal operational disruption and full safety compliance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter & Drainage Maintenance",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Blocked gutters are one of Artarmon\u2019s most frequent leak sources \u2014 especially in mixed commercial zones. We provide:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter cleaning and high-flow downpipe optimisation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guard installation for long-term maintenance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Scheduled cleaning programs for strata and industrial facilities",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Proper gutter care prevents costly ceiling damage and ensures insurance compliance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roofing Services",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "When leaks appear mid-storm, fast action matters. Our emergency callout service offers same-day waterproofing, damage control, and insurer-ready documentation. We return post-weather for permanent repairs and issue a full photographic completion report.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose New Tech Roofing in Artarmon",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Documented Transparency: We photograph everything \u2014 no hidden work or vague invoices.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Compliance Confidence: SWMS, insurance, and licensing documentation provided for every project.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Experience Across Sectors: Residential, strata, and commercial roofing specialists.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium Australian Materials: Using BlueScope, Boral, and Monier for warranty-backed durability.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local Knowledge: Servicing Artarmon and Sydney\u2019s North Shore for over 10 years.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roofing Process",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Inspection & Diagnostics \u2013 Using moisture tracking and high-resolution photography, we identify real causes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Itemised Quotation \u2013 Full breakdowns covering safety setup, materials, and warranties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Scheduling & Safety Setup \u2013 SWMS-compliant setup, scaffolding or rope access as required.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repair or Restoration Work \u2013 Performed by licensed roofers with full manufacturer compliance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Completion & Reporting \u2013 Before/after photo logs, warranty documents, and insurer-friendly summaries.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "This process provides clarity from first inspection to final proof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Challenges Unique to Turramurra",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Blocked gutters causing ceiling leaks",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rusted valley irons due to standing debris",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Failed silicone patchwork on flashing points",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Faded Colorbond surfaces from UV exposure",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Overflow from unmaintained gutter guards",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our local experience means we know what to expect \u2014 and how to prevent it. We educate clients about what to monitor seasonally, so small maintenance stays small.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Turramurra\u2019s environment brings both beauty and maintenance pressure. The combination of tall gums, steep slopes, and heavy downpours creates recurring roofing issues:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Clients Say",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u201cOur strata roof leak kept returning until New Tech Roofing diagnosed the real issue. Their report was so detailed it made approval easy.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cThey fixed what two other roofers missed. Photos and updates were sent throughout \u2014 professional, reliable, and honest.\u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "\ue934 \ue934 \ue934 \ue934 \ue934 5/5",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\ue934 \ue934 \ue934 \ue934 \ue934 5/5",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Yes. We prepare insurer- and committee-ready reports with all supporting images and access notes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. We offer same-day service for active leaks and temporary waterproofing during storms.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, including logistics facilities and warehouses requiring SWMS and access plans.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All materials are Australian-made and warranty-backed, including BlueScope Colorbond and Monier tiles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes \u2014 all inspections include a free, no-obligation quote with supporting photos.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Book a Roof Inspection in Artarmon",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When your roof protects both property and productivity, quality matters. New Tech Roofing delivers transparent, compliant, and verifiable roofing services for homes, strata, and businesses across Artarmon.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Call (02) 8403 0126 or book online for a no-obligation roof inspection today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Driving Directions: Artarmon \u2192 Roofing Today of Roseville",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Take Artarmon Road to Sydney Street",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Turn left onto Sydney Street and go through one roundabout",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Follow Penshurst Street and A38 to Ormonde Road in Roseville Chase, then take the exit from A38",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Drive to Babbage Road",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Contractor in Artarmon",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Today of Roseville",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Today of Roseville",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Location",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "106-2, 29 Smith St, Roseville NSW 2150",
                                        "url": "https://goo.gl/maps/oPJxzsJdXoK4cuHh7",
                                        "urls": [
                                            {
                                                "url": "https://goo.gl/maps/oPJxzsJdXoK4cuHh7",
                                                "anchor_text": "106-2, 29 Smith St, Roseville NSW 2150"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Phone",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hours of Operation",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Monday - Sunday: Open 24 hours",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Areas We Serve",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "North Shore",
                                        "url": "https://www.newtechroofing.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/",
                                                "anchor_text": "North Shore"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Cherrybrook",
                                        "url": "https://www.newtechroofing.com.au/north-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/north-sydney/",
                                                "anchor_text": "North Cherrybrook"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove",
                                        "url": "https://www.newtechroofing.com.au/lane-cove/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/lane-cove/",
                                                "anchor_text": "Lane Cove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Ives",
                                        "url": "https://www.newtechroofing.com.au/st-ives/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/st-ives/",
                                                "anchor_text": "St Ives"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Other Services We Offer",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter Maintenance",
                                        "url": "https://www.newtechroofing.com.au/gutter-maintenance/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/gutter-maintenance/",
                                                "anchor_text": "Gutter Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://www.newtechroofing.com.au/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://www.newtechroofing.com.au/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roofing",
                                        "url": "https://www.newtechroofing.com.au/emergency-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/emergency-roofing/",
                                                "anchor_text": "Emergency Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roofing",
                                        "url": "https://www.newtechroofing.com.au/commercial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/commercial-roofing/",
                                                "anchor_text": "Commercial Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Residential Roofing",
                                        "url": "https://www.newtechroofing.com.au/residential-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/residential-roofing/",
                                                "anchor_text": "Residential Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://www.newtechroofing.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Maintenance and Cleaning",
                                        "url": "https://www.newtechroofing.com.au/roof-maintenance-and-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/roof-maintenance-and-cleaning/",
                                                "anchor_text": "Roof Maintenance and Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roofs",
                                        "url": "https://www.newtechroofing.com.au/leaking-roofs/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/leaking-roofs/",
                                                "anchor_text": "Leaking Roofs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Repairs",
                                        "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://www.newtechroofing.com.au/roof-repairs/",
                                                "anchor_text": "Gutter Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "From Artarmon",
                                "main_title": "Roofing Contractor in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02)%208403%200126",
                                "(02) 8403 0126"
                            ],
                            "emails": [
                                "info@newtechroofing.com.au",
                                "info@roofingtoday.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}