{
    "id": "01190727-1132-0216-0000-18ed7c0de742",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0780 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://northshoreroofrepairs.com.au/roof-repair-artarmon/",
        "target": "northshoreroofrepairs.com.au",
        "start_url": "https://northshoreroofrepairs.com.au/roof-repair-artarmon/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Artarmon\\organic\\type-organic_rg3_ra6_northshoreroofrepairs.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:52 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Roofing expert servicing the North Shore, Northern Beaches, Hornsby and the Inner West.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": null,
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "North Shore Roof Repairs",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "NSW licence number: 118020C",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Quick Links",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Tile Roof Repair",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                            "anchor_text": "Tile Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Rebedding and Pointing",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/bedding-and-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/bedding-and-repointing/",
                                            "anchor_text": "Rebedding and Pointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leak Repair",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/leak-repair/",
                                            "anchor_text": "Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sarking Repair",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/sarking-repair/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/sarking-repair/",
                                            "anchor_text": "Sarking Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard Installation",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-guard-installation/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-guard-installation/",
                                            "anchor_text": "Gutter Guard Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Valley Replacement",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/valley-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/valley-replacement/",
                                            "anchor_text": "Valley Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Replacement",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/tile-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/tile-replacement/",
                                            "anchor_text": "Tile Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repair",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Batten Replacement",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/batten-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/batten-replacement/",
                                            "anchor_text": "Batten Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flashing Repair and Replacement",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/flashing-repair-and-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/flashing-repair-and-replacement/",
                                            "anchor_text": "Flashing Repair and Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspection",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-inspection/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-inspection/",
                                            "anchor_text": "Roof Inspection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter and Downpipe Replacement",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-downpipe-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-downpipe-replacement/",
                                            "anchor_text": "Gutter and Downpipe Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Roof Vent Installation",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/solar-roof-vent-installation/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/solar-roof-vent-installation/",
                                            "anchor_text": "Solar Roof Vent Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm and Wind Damage Repair",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/storm-and-wind-damage-repair/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/storm-and-wind-damage-repair/",
                                            "anchor_text": "Storm and Wind Damage Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roof Repair",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/terracotta-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/terracotta-roof-repair/",
                                            "anchor_text": "Terracotta Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repair",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Cement Roof Tiles",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Ridge Recementing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Ridge Capping Repair",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Recementing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Colorbond Roof Screw Replacement",
                                    "url": "https://northshoreroofrepairs.com.au/roofing-services/colorbond-full-roof-screw-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/roofing-services/colorbond-full-roof-screw-replacement/",
                                            "anchor_text": "Colorbond Roof Screw Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "PO Box 711",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Lindfield NSW 2070",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "1300 764 456 or 0425 248 704",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN: 21 914 134 529",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2020 North Shore Roof Repairs. Privacy Policy. Website by Futurised",
                                    "url": "https://northshoreroofrepairs.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://northshoreroofrepairs.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        },
                                        {
                                            "url": "https://futurised.au/",
                                            "anchor_text": "Website by Futurised"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repair Services in Artarmon",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "North Shore Roof Repairs has over 32 years of roofing experience in Artarmon.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We deliver personalised, efficient service to ensure your roof remains strong, functional, and weather-ready in Artarmon.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tile and Metal Roof Repairs: Whether it's a loose flashing, a damaged gutter, or a minor leak, we can handle the repair with expertise and attention to detail.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "For trusted roof repair, leak solutions, whirlybird installations, and valley replacements, contact us today!",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                                "anchor_text": "roof repair"
                                            },
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/leak-repair/",
                                                "anchor_text": "leak solutions"
                                            },
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/whirlybird-installation/",
                                                "anchor_text": "whirlybird installations"
                                            },
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/valley-replacement/",
                                                "anchor_text": "valley replacements"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tile and metal roof repairs",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof repair costs depend on the type of repair, the condition of the roof and if it is a single or double story. Get a FREE quote.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Cost of rebedding and pointing",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Pointing roof ridge tiles costs $20 to $25 per lineal metre. For an average-sized roof, the total cost can be around $1,500 to $2,500.",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/bedding-and-repointing/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/bedding-and-repointing/",
                                                "anchor_text": "Pointing roof ridge tiles"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Cost of to replace Valley Irons?",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The cost of valley iron replacement can vary depending on the size of your roof, the number of valleys, and the type of material used (Colorbond or zinc).",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Valleys cost from $1,200 to $1,500 to replace per valley.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Licensed Contractor in Artarmon",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With over 32 years in the industry and our NSW licence (118020C), North Shore Roof Repairs is dedicated to delivering lasting quality in Artarmon.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Led by Steve Moore, an experienced roofer and North Shore local is committed to resolving roofing issues with precision.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Flexible Scheduling",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Offering free, no-obligation quotes for all services, from valley replacements to general repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019re available every day of the week, from 7AM to 8PM. We tailor our service times to align with your schedule.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose North Shore Roof Repairs?",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Expertise: Backed by over 30 years of industry experience in Artarmon, we provide reliable solutions for all roofing concerns.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Detailed: Our comprehensive inspections uncover both visible and hidden issues, ensuring thorough and lasting repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Proactive Repairs: We address minor problems before they escalate, saving you from costly future repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Peace of Mind: With our licensed and insured services, you can trust that your roof is in expert hands.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Artarmon Roofing Services",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal Roof Repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cement Roof Tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ridge Recementing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ridge Capping Repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Recementing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tile Roof Repair",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                                "anchor_text": "Tile Roof Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rebedding and Pointing",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/bedding-and-repointing/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/bedding-and-repointing/",
                                                "anchor_text": "Rebedding and Pointing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leak Repair",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/leak-repair/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/leak-repair/",
                                                "anchor_text": "Leak Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whirlybird Installation",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/whirlybird-installation/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/whirlybird-installation/",
                                                "anchor_text": "Whirlybird Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sarking Repair",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/sarking-repair/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/sarking-repair/",
                                                "anchor_text": "Sarking Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Guard Installation",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-guard-installation/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-guard-installation/",
                                                "anchor_text": "Gutter Guard Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Valley Replacement",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/valley-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/valley-replacement/",
                                                "anchor_text": "Valley Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tile Replacement",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/tile-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/tile-replacement/",
                                                "anchor_text": "Tile Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Batten Replacement",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/batten-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/batten-replacement/",
                                                "anchor_text": "Batten Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Flashing Repair and Replacement",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/flashing-repair-and-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/flashing-repair-and-replacement/",
                                                "anchor_text": "Flashing Repair and Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspection",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-inspection/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-inspection/",
                                                "anchor_text": "Roof Inspection"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter and Downpipe Replacement",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-downpipe-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-downpipe-replacement/",
                                                "anchor_text": "Gutter and Downpipe Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Solar Roof Vent Installation",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/solar-roof-vent-installation/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/solar-roof-vent-installation/",
                                                "anchor_text": "Solar Roof Vent Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Storm and Wind Damage Repair",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/storm-and-wind-damage-repair/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/storm-and-wind-damage-repair/",
                                                "anchor_text": "Storm and Wind Damage Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terracotta Roof Repair",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/terracotta-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/terracotta-roof-repair/",
                                                "anchor_text": "Terracotta Roof Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Colorbond Roof Screw Replacement",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/colorbond-full-roof-screw-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/colorbond-full-roof-screw-replacement/",
                                                "anchor_text": "Colorbond Roof Screw Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Quality and Reliabile Roof Repairs",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With fully insured services in Artarmon, a NSW licence (number: 118020C), and a direct line to our tradespeople, we guarantee satisfaction without the hassle of dealing with salespeople.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flexible scheduling 7AM to 8PM, we work around your life, not the other way around.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Engage With Local Experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For Artarmon residents seeking reliable roof repair and maintenance, North Shore Roof Repairs is ready to exceed expectations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Discover the difference of a local specialist dedicated to your home\u2019s integrity and aesthetic.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Local Insight:\nArtarmon",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Artarmon\u2019s dense residential character combines Federation-era homes and post-war cottages, often on compact blocks near major transport corridors.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The significant stock of ageing terracotta and slate roofs demands consistent upkeep, with cracked tiles and deteriorating ridge capping being common failure points.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Extensions often create complex junctions between old and new roofing, increasing the risk of water ingress if flashings are not expertly installed.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mature street trees contribute significant leaf debris that can obstruct gutters, compounding drainage issues, particularly on the suburb\u2019s varied and complex rooflines.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We practice work-safe procedures and meet all requirements, ensuring the safest possible conditions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, professional repairs to your roof can enhance the curb appeal and overall value of your home, making it more attractive to potential buyers.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "In Artarmon, we specialise in tile roof repair, leak repair, valley replacement and whirlybird installation in Artarmon. Visit our full lists of services.",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/",
                                                "anchor_text": "full lists of services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We offer free quotes for all types of roofing work, including leak repairs, bedding and repointing, and cracked tile repair and replacement. On-site inspections are available to provide you with an accurate cost assessment.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We offer flexible working hours Monday to Sunday from 7 AM to 8 PM to accommodate your schedule, ensuring that finding a convenient time for roof repairs is never an issue.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Locations We Service",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We service Sydney's Lower North Shore, Upper North Shore, Northern Beaches, Ryde area, Hornsby district, and the Inner West.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Over 32 years of experience",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to roof repair, gutters and ventilation, we've got you covered",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repair in Artarmon",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Call 1300 764 456",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Protected by reCAPTCHA Privacy and Terms.",
                                        "url": "https://policies.google.com/privacy",
                                        "urls": [
                                            {
                                                "url": "https://policies.google.com/privacy",
                                                "anchor_text": "Privacy"
                                            },
                                            {
                                                "url": "https://policies.google.com/terms",
                                                "anchor_text": "Terms"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tile Roof Repair",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/roof-repair/",
                                                "anchor_text": "Tile Roof Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rebedding and Pointing",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/bedding-and-repointing/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/bedding-and-repointing/",
                                                "anchor_text": "Rebedding and Pointing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leak Repair in Artarmon",
                                        "url": "https://northshoreroofrepairs.com.au/leak-repair-artarmon/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/leak-repair-artarmon/",
                                                "anchor_text": "Leak Repair in Artarmon"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whirlybird Installation in Artarmon",
                                        "url": "https://northshoreroofrepairs.com.au/whirlybird-installation-artarmon/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/whirlybird-installation-artarmon/",
                                                "anchor_text": "Whirlybird Installation in Artarmon"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sarking Repair",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/sarking-repair/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/sarking-repair/",
                                                "anchor_text": "Sarking Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Guard Installation",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-guard-installation/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/gutter-guard-installation/",
                                                "anchor_text": "Gutter Guard Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Valley Replacement",
                                        "url": "https://northshoreroofrepairs.com.au/roofing-services/valley-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://northshoreroofrepairs.com.au/roofing-services/valley-replacement/",
                                                "anchor_text": "Valley Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof repair cost?",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Common Roof Repair Problems",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Cracked or broken tiles can lead to leaks and moisture penetration, requiring tile replacement or roof repairs.",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Rust and corrosion due to salty sea air. This is particularly relevant for metal flashings, valleys, or gutters.",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leaves, twigs, and debris can accumulate in gutters and downpipes causing blockages.",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "NSW licence number: 118020C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ABN: 21 914 134 529",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hours",
                                "main_title": "Roof Repair in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "7AM to 8PM",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "1300764456",
                                "0425248704"
                            ],
                            "emails": [
                                "info@northshoreroofrepairs.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}