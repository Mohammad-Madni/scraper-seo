{
    "id": "01190727-1132-0216-0000-acb4688a3f13",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0340 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://tomkatroofing.com.au/artarmon/",
        "target": "tomkatroofing.com.au",
        "start_url": "https://tomkatroofing.com.au/artarmon/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Artarmon\\organic\\type-organic_rg4_ra7_tomkatroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:36:12 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Unit 4, 16 Bernera Road Prestons NSW 2170",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "\ud83c\udf84 Christmas Close-Out: Closed from 23 December \u2013 Back on 12 January \ud83c\udf81 | Wishing you a Merry Christmas & Happy New Year! \ud83c\udf85\u2728",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\ud83c\udf84 Christmas Close-Out: Closed from 23 December \u2013 Back on 12 January \ud83c\udf81 | Wishing you a Merry Christmas & Happy New Year! \ud83c\udf85\u2728",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Project",
                                    "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                            "anchor_text": "New Roof Project"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters & Downpipes",
                                    "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                            "anchor_text": "Gutters & Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports & Inspections",
                                    "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                            "anchor_text": "Roof Reports & Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://tomkatroofing.com.au/service-area/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/service-area/",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://tomkatroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Project",
                                    "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                            "anchor_text": "New Roof Project"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters & Downpipes",
                                    "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                            "anchor_text": "Gutters & Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports & Inspections",
                                    "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                            "anchor_text": "Roof Reports & Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://tomkatroofing.com.au/service-area/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/service-area/",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://tomkatroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "1300 866 528",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Call Us Today!",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A stitch in time saves nine. Pick our roof repair service in Auburn, and experience the difference in resolving your issue with expert roofing plumbers. Whether you witness cracked tiles, leaks and water stains, a rusted roof, deteriorated roof sheets, or a faulty whirlybird, we are here to help.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If the condition worsens and the lifespan of your roof is going to end, you need to replace your shelter with a new and functional one. Don\u2019t worry; we provide multiple personalised rate offers and incredible assistance at each stage of roof replacement in Auburn to help you quickly replace the entire roof, gutters, downpipes, and skylights.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "New Roof Projects",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If you plan to install a brand-new roof over your residential or commercial property in Auburn, we have covered you with our new roof projects. Our experts will understand your needs and preferences concerning the installation of the new shelter and will quickly set the new roof in place in accordance with your plans.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter and Downpipes",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roofing plumbers specialise in handling all the issues concerning your gutters and downpipes. If you are looking to repair your faulty gutters or planning a gutter replacement in Auburn, our competent team can assist you in addressing all the issues associated with your guttering system.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Inspections & Preventative Maintenance",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Regular roof check-ups can save you from expensive repairs down the line. We\u2019ll inspect your roof, spot potential issues, and fix them before they get worse.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leak Repairs & Storm Damage Fixes",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Leaky roofs and storm damage can\u2019t wait. We offer fast, reliable roof repair in Artarmon to prevent further damage and keep your home safe.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter, Flashing & Structural Repairs",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Your roof is more than just tiles; it\u2019s a system that works together. We repair and replace gutters, flashing, ridge capping, and more to ensure everything is in top shape.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Full Roof Restorations & Replacements",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If your roof is beyond patch-up jobs, we offer complete restorations and replacements using top-quality materials for long-lasting results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Step-by-Step Roof Repair Proces",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We believe in doing things right the first time. Our roof repair process is thorough, ensuring every job is completed to the highest standard.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roofing Repair Services in Artarmon Include",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Leak detection and repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof tile and sheet repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Total roof replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rebedding and pointing of ridge capping",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter and downpipe repair and replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fascia and eave repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Skylight repair, replacement and installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Pressure cleaning and restoration",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "From quick fixes to full replacements, here\u2019s what we offer:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Storm damage repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Pergola repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flashing repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaf screen installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whirly birds replacement",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Happy Clients Are Saying",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I have had a fantastic experience with this business from start to finish. They are professional experienced, very fair and reasonable. We needed to replace the roof on our outdoor deck which was slightly tricky. Their advice and suggestions regarding product to use was sage. After a downpour there was a bit of a leak between the main building and the deck roof which they came out to fix which resolved the issue. There have been plenty of downpours since and everything is fine. I would highly recommend this company without hesitation. They are excellent.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tomkat did a great job and they were very pleasant to deal with.\nI\u2019d definitely preference them for any similar work in the future!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thankyou to TomKat Roofing and particulary Scott who did an excellent job repairing my roof.\nI had a water stain on the ceiling in one of my rooms, I called TomKat Roofing.\nThey sent out a technician (Tim I think his name was) to have a look at the roof and that was followed by a very clear & comprehensive quote with what work needed to be done. The quote was supported by photos of the roof showing the problem areas. Tim was very polite & knowledgeable. He explained to me what needed to be done as a matter of urgency and what would need to be done for maintenance purpose and he showed me the photos.\nThe price was very reasonable for the work that needed to be done.\nScott carried out the repair work. Scott is very pleasant to deal and he knew exactly what he was doing. He worked just about all day to finish the job for me and I was very happy with the results and my roof problems have now been solved.\nI was very impressed with everyone I dealt with, from the ladies in the office who prepared my quote to Scott who completed the job , they are all very friendly and most of all they know their stuff. I think they're an asset to TomKat.\nI highly recommend TomKat Roofing and I would definitely use them again.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tomkat Roofing was a great place to do business with from the initial phone call, to Gary who came out to give me a quote arrived on time and was very helpfull in his advise.The job was completed in a highly professional manner. I will have no problems using this company for any future roofing work. Great work to the whole team at Tomkat",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I contacted the team at TomKat roofing as I noticed a small leak in my daughters room during the recent storms and I was pleasantly greeted over the phone by the admin team who took down all my details and soon after I had the scheduling team call and arrange a suitable time to come out and review my concerns.\nThe team promptly identified what the issue was and fixed it promptly.\nI can\u2019t thank the team enough and whilst I hope I never need to call them again due to a roof issue, I would gladly recommend them to anyone looking for professional workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I highly recommend Tomkat Roofing for an efficient, well priced and solid quality roof replacement. My old, droopy and leaking terracotta tile roof is now straight and strong with a reinforced structure, new corrugated colorbond roof, gutters, facias, downpipes and leaf guard.\nSome of the key positive experiences I had with Tomkat Roofing are:\nThe efficient and friendly office staff always responded quickly and kept me informed of the progress and when the tradesmen would be onsite.\nAt the start of the job, within a single work day, they had a team of roofers and carpenters to get the old tiles off, the roof structure repaired/reinforced and the colorbond sheets with insulation secured so that my home was protected from the weather. Fortunately the weather was clear for a few days, but it was reassuring to know that they were prepared to work incredibly fast in the summer sun to keep my home safe.\nThe site supervisors were always friendly and took the time to explain everything to me and respond to any concerns or questions I had about the job. Being an older build home, I had a few items that needed particular attention and everything was completed to my satisfaction.\nA word of advice for home owners looking to get a roof replaced with Tomkat Roofing: Raise as many of your objectives and concerns as you can as early as possible. I found the Tomkat team very responsive to my overthinking mind and everything I wanted to get done was outlined in the quote and addressed during the job.\nAlso, they do tidy up and take away all the waste building material during and at the end of the job, which is great. But be prepared each evening to clean up smaller items that take time to find, like random screws or nails that were dropped, if you have children or pets accessing the area around your home in the evenings. It is unreasonable to expect the workers to find every dropped item each day if you also want the job done quickly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Helen O'Connor",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ali Bugeja",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lisa Anthony",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Christine Puckering",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Peter Thomas",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sully 71",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mike Cohen",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How do I know if my roof needs repairs?",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Look for signs like leaks, sagging areas, missing tiles, or mould growth. If you\u2019re unsure, we can inspect it and let you know what\u2019s needed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long do roof repairs take?",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "It depends on the job, but most minor repairs are done in a day. Bigger projects, like restorations, can take a few days. We\u2019ll always give you a clear timeframe upfront.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you offer emergency roof repairs?",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Yes! If your roof is damaged by storms or sudden leaks, we provide fast, emergency roofing repairs in Artarmon to keep your home protected.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Can you work with all roof types?",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "It depends on your policy and the cause of the damage. We can assess your roof and provide a detailed report to help with insurance claims if needed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much do roof repairs cost?",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The cost depends on the damage and the work needed. We offer free quotes and transparent pricing, so you know exactly what to expect.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Keeping Artarmon\u2019s Roofs Strong, Secure, And Weatherproof",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get Your Free Roofing Quote Today!",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Roof Repairs in Artarmon: We\u2019ve Got You Covered",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "If your roof is giving you trouble, you\u2019re in the right place. Have a leak that won\u2019t quit? No worries! Dealing with cracked tiles or storm damage? Say no more because we\u2019re here to help. At Tomkat Roofing, we specialise in roof repairs in Artarmon, bringing years of experience and top-quality workmanship to every job.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We know roof issues can be frustrating (and sometimes downright stressful), but fixing them doesn\u2019t have to be. Our team makes the process easy, from the first inspection to the final fix. We take care of everything so you don\u2019t have to worry about a thing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Need a small repair? No problem. Looking at a full roof replacement? We\u2019ve got that covered, too. Whatever your roofing issue, we handle it with skill and care, ensuring your home stays protected for years to come. And the best part? We do it all with honest pricing, friendly service, and a commitment to quality that sets us apart.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you\u2019re searching for roofing repairs in Artarmon, give us a call. We\u2019ll get it sorted quickly, properly, and without any hassle.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repair and Maintenance Services in Annandale",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Don\u2019t Wait Until it\u2019s Too Late: Contact Us Today",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "The next time you witness water stains, damaged flashing, clogged gutters, moss growth, or any other signs that indicate damage, don\u2019t hesitate to reach out to us immediately. At Tomkat Roofing, we provide you with a practical and quick solution to bring out the best potential of your space.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Comprehensive Roofing Services in Artarmon",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Taking care of your roof isn\u2019t just about fixing problems when they happen; it\u2019s about making sure they don\u2019t happen again. That\u2019s why we offer a full range of roof services in Artarmon, from small repairs to major renovations.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Regular Roof Maintenance Saves You Time and Money",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Your roof works hard every day, protecting your home from rain, wind, and the harsh Australian sun. But over time, even the toughest roofs wear down. Small cracks, loose tiles, or clogged gutters might not seem like a big deal until they turn into costly repairs. That\u2019s why regular maintenance is essential.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Catching issues early can save you thousands in unexpected repairs and extend the lifespan of your roof. A well-maintained roof also keeps your home energy efficient, preventing heat loss in winter and excessive heat absorption in summer. Plus, it helps avoid water damage that can lead to mould and structural issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Tomkat Roofing, we offer thorough inspections and maintenance to keep your roof in top shape. Whether it\u2019s a quick patch-up or a full restoration, investing in your roof now means fewer headaches (and expenses) down the track.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "01",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Inspection & Assessment",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We start with a detailed roof inspection to identify any damage, leaks, or weak spots.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "02",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Clear, Honest Quote",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "We provide a transparent quote, explaining exactly what needs to be done; no hidden fees, no surprises.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "03",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Preparation & Safety Measures",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Before we begin, we set up safety equipment and prepare the area to protect your home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "04",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Repairs & Restoration",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Whether it\u2019s replacing tiles, resealing leaks, or fixing gutters, we carry out all repairs with precision and care.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Locals Trust Tomkat Roofing for Roofing Repairs in Artarmon",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Homeowners in Artarmon trust Tomkat Roofing for our commitment to quality and reliable service. Here\u2019s why:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fast, Responsive Service",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We don\u2019t keep you waiting for days.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Clear, Upfront Quotes",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "No hidden fees or surprises.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "High-Quality Materials",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Only durable materials for lasting repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Respect and Care",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We treat your home like our own, ensuring top-notch work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Years of Experience",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We know roofing inside and out.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FAQs",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get Finance In A Few Minutes",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "No Impact On Your Credit Score",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fast Pre-approval",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fortified Data Protection",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quick Links",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Services",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacements",
                                        "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                                "anchor_text": "Roof Replacements"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "New Roof Projects",
                                        "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                                "anchor_text": "New Roof Projects"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspection & Reports",
                                        "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                                "anchor_text": "Roof Inspection & Reports"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Details",
                                "main_title": "Tomkat Roofing: Reliable Roof Repairs in Artarmon",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Unit 4, 16 Bernera Road Prestons NSW 2170",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Terms of Use | Privacy Policy",
                                        "url": "https://www.thryv.com/client-terms-of-use/",
                                        "urls": [
                                            {
                                                "url": "https://www.thryv.com/client-terms-of-use/",
                                                "anchor_text": "Terms of Use"
                                            },
                                            {
                                                "url": "https://www.thryv.com/client-privacy-policy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "\u00a9 2025 Tomkat Roofing. All Rights Reserved.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "1300866528"
                            ],
                            "emails": [
                                "%20info@tomkatroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}