{
    "id": "01191151-1132-0216-0000-653d964a7bdd",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0136 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://yourlocalroofers.com.au/locations/artarmon/",
        "target": "yourlocalroofers.com.au",
        "start_url": "https://yourlocalroofers.com.au/locations/artarmon/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": false,
        "load_resources": false,
        "enable_browser_rendering": false,
        "enable_xhr": false,
        "disable_cookie_popup": false,
        "browser_preset": "desktop",
        "tag": "parsed_content_markdowns\\Artarmon\\organic\\type-organic_rg7_ra10_yourlocalroofers.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 07:51:23 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Australia's trusted roofing specialists. We provide comprehensive roofing solutions with professional excellence.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Rain warranty coverage is provided on eligible leak repairs following acceptance of our quote and commencement of works.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2026 YourLocalRoofers.com.au. All rights reserved.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Licensed \u2022 Insured \u2022 Bonded | NSW Builder Licence No. 393687C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Get a Quote Get a Quote",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email Us Email Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Call Us Now Call Us Now",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Professional Roofing Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://yourlocalroofers.com.au/services/roof-replacement",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/roof-replacement",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://yourlocalroofers.com.au/services/roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/roof-restoration",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Repairs",
                                    "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                            "anchor_text": "Emergency Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://yourlocalroofers.com.au/about-us",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/about-us",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://yourlocalroofers.com.au/terms-and-conditions",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/terms-and-conditions",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://yourlocalroofers.com.au/privacy-policy",
                                    "urls": [
                                        {
                                            "url": "https://yourlocalroofers.com.au/privacy-policy",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "24/7 Emergency Service",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email inquiries",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "NSW & ACT",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Licence No. 393687C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday to Sunday",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "24 hour service",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roofers in Artarmon",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Professional roofing services for Artarmon's family-oriented railway suburb near quality schools. Servicing established family homes, units and commercial properties with expert roof repairs, restorations and maintenance across the Lower North Shore.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "+16 years of experience",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Your Local Roofers in Artarmon?",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We are a trusted roofing team serving Artarmon's family-oriented commuter community with reliable workmanship. From roof restorations for established homes to modern repairs and preventative maintenance near schools and station, we deliver quality solutions for Lower North Shore families.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Family Home Specialists",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We understand Artarmon's established family homes, mixed property types near railway, good schools area and Lower North Shore expectations.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Family-Focused Service",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Quality workmanship with minimal disruption, transparent pricing and clear communication for Artarmon commuter families.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Licensed & Reliable",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Fully licensed team delivering Australian Standards compliance with comprehensive warranties for Artarmon family homes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted Roofers Throughout Artarmon",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From established family homes near quality schools to units near Artarmon Station and commercial strip properties, our roofing team delivers dependable solutions across Artarmon's commuter-friendly suburb. We understand the mix of established houses and modern units requiring quality maintenance and repairs in this family-oriented Lower North Shore railway suburb.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our Artarmon roofing services include roof restorations for established homes, tile and metal roofing repairs, leak detection for family properties, gutter cleaning and maintenance, ridge repointing, valley repairs, unit building work, insurance repairs and complete re-roofing. Every project features transparent pricing, quality materials and comprehensive warranties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Choose Artarmon's trusted family-focused roofers for prompt service, professional workmanship and roofing solutions built to protect your Lower North Shore family home investment near schools and transport.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Roofing for Artarmon Family Homes",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our Artarmon roofing specialists combine extensive Lower North Shore family suburb experience with proven techniques and quality materials. From established family homes requiring roof restoration to modern units needing efficient maintenance, we deliver tailored roofing services across this commuter-friendly railway suburb popular with families seeking good schools and transport connections.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether you need emergency leak repairs for family homes, roof restoration for established properties near schools, routine maintenance for commuter-area units, or complete roof replacement, our certified team provides comprehensive solutions with transparent pricing and industry-leading warranties protecting your Artarmon family property investment.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Trust our Lower North Shore family suburb expertise to deliver Artarmon roofing solutions that withstand Sydney's demanding climate while exceeding Australian building standards and protecting your family home near quality schools.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "+500 projects completed",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roofing Services",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Expert roofing craftsmanship meets superior construction quality. Every roofing project is custom-designed to protect your property and enhance its value and functionality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Not Sure Which Option is Right for You?",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roofing specialists will assess your property and recommend the perfect roofing solution that matches your style preferences, budget, and functional requirements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Services Across Lower North Shore",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Professional roofing services throughout the Lower North Shore. From emergency leak response to planned maintenance and restorations, we keep roofs watertight in this prestigious harbourside region.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Neutral Bay & Cremorne",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing services for residential and commercial properties in harbourside suburbs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Neutral Bay, Cremorne, Mosman, Cammeray",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Key Suburbs:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "North Sydney & Kirribilli",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Professional roofing solutions for business districts and waterfront properties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "North Sydney, Kirribilli, Milsons Point, Lavender Bay",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Key Suburbs:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Crows Nest & Waverton",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Experienced team handling roof repairs and restorations in established inner suburbs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Crows Nest, Waverton, Wollstonecraft, McMahons Point",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Key Suburbs:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Northbridge & Lane Cove",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Reliable roofing services for family homes and residential precincts in the Lower North Shore.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Northbridge, Lane Cove, Artarmon",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Key Suburbs:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get a Free Quote in Your Area",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "No matter where you are in the Lower North Shore, our team is ready to repair and protect your roof. Contact us today for a free consultation and local quote.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Loved by +1000 home and business owners",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Discover why our clients trust us for their roofing projects.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fantastic job and really professional experience from the first enquiry. Rapan the leader on site was amazing. Wouldn't hesitate to recommend this company! Awesome.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I found your local roofers to be fantastic. They demolished the old roof and put the new roof up 2 days before Xmas. I now have a roof that does not leak onto my deck. We are so happy with their service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are very glad we chose Your Local Roofers for the reroofing of our home. It was a huge thing for us and they kept us in the loop all the way. A great experience from start to finish. Would recommend them to anyone.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thankyou to Your Local Roofers for your excellence of service in repairing our roof & solving our water problem. Shout out to your professional staff skilled & experienced roofer Lachlan & Admin Alex who were helpful & courteous.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If we could give Luke Durazza more than a five star rating we would!!! Such a professional, courteous and thoughtful person. Luke's knowledge and workmanship are top notch and so greatly appreciated.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We had water cascading from the gutter onto our deck when it rained. We would like to thank the team at Your Local Roofers for doing a very good job in replacing the roof and fixing the guttering.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Adam and his roofing team absolutely astounded me with the quality of service, speed and professional finish of our complete roof replacement. The quoted price was competitive and they were packed up, cleaned up with some long days to complete 2 days prior to their scheduled finish.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We had a great experience with this roofing company. Their team was friendly, efficient and professional. We love the results of the newly painted roof and feel secure with all of the repair work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What a great a team, they have completed my workshop roof in 1 week and the difference is mind blowing. The team are on point from start to finish. A job well done \ud83d\udc4d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Julian Barton",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "12 May 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bruce Dunlop",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 February 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "John Hardaker",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24 May 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Julian Barton",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "12 May 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bruce Dunlop",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 February 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "John Hardaker",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24 May 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ange L",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "9 August 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Susie Molloy",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "12 July 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mark Read",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "11 May 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ange L",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "9 August 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Susie Molloy",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "12 July 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mark Read",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "11 May 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Richard Aurisch",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 November 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lesley Paredes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "15 January 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mark Dyball",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "15 April 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Richard Aurisch",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 November 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lesley Paredes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "15 January 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mark Dyball",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "15 April 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Need Reliable Roofers? Get a Free Quote Today",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From urgent make-safes to scheduled remedial works, we deliver clear scopes, photo documentation and workmanship warranties, keeping your operations safe and minimising downtime.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Our Focus:",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Mixed houses and units",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lower North Shore standards",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Family home expertise",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Established area specialists",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Commercial strip experience",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Focus:",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Minimal home disruption",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent pricing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Family communication",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Photo progress reports",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flexible scheduling",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Focus:",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Fully licensed roofers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Australian Standards",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive warranties",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Safety compliance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Insurance protection",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "24/7 Emergency Repairs & Make Safes",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "24/7 Emergency Repairs & Make Safes",
                                        "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                                "anchor_text": "24/7 Emergency Repairs & Make Safes"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "24/7 emergency roofing services when you need them most. Our rapid response team provides immediate repairs and make-safe solutions to protect your property from further damage.",
                                        "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/24-7-emergency-repairs-make-safes",
                                                "anchor_text": "24/7 emergency roofing services when you need them most. Our rapid response team provides immediate repairs and make-safe solutions to protect your property from further damage."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Professional roof repair services for all types of roofing materials. From minor fixes to major structural repairs, we ensure your roof is restored to optimal condition.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-repairs",
                                                "anchor_text": "Professional roof repair services for all types of roofing materials. From minor fixes to major structural repairs, we ensure your roof is restored to optimal condition."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://yourlocalroofers.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Complete roof restoration services to extend your roof's lifespan. Our comprehensive approach includes cleaning, repairs, and protective treatments for lasting results.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-restoration/",
                                                "anchor_text": "Complete roof restoration services to extend your roof's lifespan. Our comprehensive approach includes cleaning, repairs, and protective treatments for lasting results."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://yourlocalroofers.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Complete roof replacement services for when repairs aren't enough. We install brand new roofing systems with premium materials and expert craftsmanship for long-term protection.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-replacement/",
                                                "anchor_text": "Complete roof replacement services for when repairs aren't enough. We install brand new roofing systems with premium materials and expert craftsmanship for long-term protection."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing & Flashings",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing & Flashings",
                                        "url": "https://yourlocalroofers.com.au/services/metal-roofing-flashings/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/metal-roofing-flashings/",
                                                "anchor_text": "Metal Roofing & Flashings"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Expert installation and repair of metal roofing systems and flashings. Durable, weather-resistant solutions that provide long-lasting protection for your property.",
                                        "url": "https://yourlocalroofers.com.au/services/metal-roofing-flashings/",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/metal-roofing-flashings/",
                                                "anchor_text": "Expert installation and repair of metal roofing systems and flashings. Durable, weather-resistant solutions that provide long-lasting protection for your property."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://yourlocalroofers.com.au/services/roof-painting",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-painting",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Professional roof painting services to transform and protect your roof. High-quality paints and expert application techniques ensure lasting beauty and weather protection.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-painting",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-painting",
                                                "anchor_text": "Professional roof painting services to transform and protect your roof. High-quality paints and expert application techniques ensure lasting beauty and weather protection."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Cleaning",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Scheduled gutter cleaning to prevent blockages, water ingress and foundation damage. Includes debris removal and flow testing.",
                                        "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/gutter-cleaning",
                                                "anchor_text": "Scheduled gutter cleaning to prevent blockages, water ingress and foundation damage. Includes debris removal and flow testing."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Pergolas & Patios",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Pergolas & Patios",
                                        "url": "https://yourlocalroofers.com.au/services/metal-pergolas-patios",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/metal-pergolas-patios",
                                                "anchor_text": "Metal Pergolas & Patios"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Custom-designed metal pergolas and patios that integrate with your roofing system for shade, durability and style.",
                                        "url": "https://yourlocalroofers.com.au/services/metal-pergolas-patios",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/metal-pergolas-patios",
                                                "anchor_text": "Custom-designed metal pergolas and patios that integrate with your roofing system for shade, durability and style."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Restoration & Remediation",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Restoration & Remediation",
                                        "url": "https://yourlocalroofers.com.au/services/restoration-remediation",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/restoration-remediation",
                                                "anchor_text": "Restoration & Remediation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Holistic restoration and remediation to address underlying roof issues, structural defects and water ingress long-term.",
                                        "url": "https://yourlocalroofers.com.au/services/restoration-remediation",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/restoration-remediation",
                                                "anchor_text": "Holistic restoration and remediation to address underlying roof issues, structural defects and water ingress long-term."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ridge Capping Restoration",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Ridge Capping Restoration",
                                        "url": "https://yourlocalroofers.com.au/services/ridge-capping-restoration",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/ridge-capping-restoration",
                                                "anchor_text": "Ridge Capping Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Re-bedding and re-pointing ridge caps with flexible compounds to seal joints, prevent leaks and improve appearance.",
                                        "url": "https://yourlocalroofers.com.au/services/ridge-capping-restoration",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/ridge-capping-restoration",
                                                "anchor_text": "Re-bedding and re-pointing ridge caps with flexible compounds to seal joints, prevent leaks and improve appearance."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak Detection & Repair",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leak Detection & Repair",
                                        "url": "https://yourlocalroofers.com.au/services/roof-leak",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-leak",
                                                "anchor_text": "Roof Leak Detection & Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rapid roof leak detection and permanent repairs using diagnostics, moisture tracing and targeted remediation.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-leak",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-leak",
                                                "anchor_text": "Rapid roof leak detection and permanent repairs using diagnostics, moisture tracing and targeted remediation."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Maintenance",
                                        "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                                "anchor_text": "Roof Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Proactive maintenance programs with scheduled inspections, cleaning and minor repairs to extend roof life and reduce costs.",
                                        "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/roof-maintenance",
                                                "anchor_text": "Proactive maintenance programs with scheduled inspections, cleaning and minor repairs to extend roof life and reduce costs."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Safety Roof Anchors",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Safety Roof Anchors",
                                        "url": "https://yourlocalroofers.com.au/services/safety-roof-anchors",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/safety-roof-anchors",
                                                "anchor_text": "Safety Roof Anchors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Design and installation of compliant roof anchor systems and fall-arrest points for safe rooftop access.",
                                        "url": "https://yourlocalroofers.com.au/services/safety-roof-anchors",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/safety-roof-anchors",
                                                "anchor_text": "Design and installation of compliant roof anchor systems and fall-arrest points for safe rooftop access."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Repointing",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Repointing",
                                        "url": "https://yourlocalroofers.com.au/services/what-is-the-point-of-repointing",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/what-is-the-point-of-repointing",
                                                "anchor_text": "Repointing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Flexible repointing compounds applied to ridge and hip cappings to reseal joints and prevent water ingress.",
                                        "url": "https://yourlocalroofers.com.au/services/what-is-the-point-of-repointing",
                                        "urls": [
                                            {
                                                "url": "https://yourlocalroofers.com.au/services/what-is-the-point-of-repointing",
                                                "anchor_text": "Flexible repointing compounds applied to ridge and hip cappings to reseal joints and prevent water ingress."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted by over +1000 happy clients",
                                "main_title": "Roofers in Artarmon",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61-2-5300-4047",
                                "0253004047",
                                "(02) 5300 4047"
                            ],
                            "emails": [
                                "customersupport@yourlocalroofers.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}