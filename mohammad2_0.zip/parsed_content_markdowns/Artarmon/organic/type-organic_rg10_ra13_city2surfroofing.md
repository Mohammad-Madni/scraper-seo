{
    "id": "01190727-1132-0216-0000-604c5d74fb5c",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0207 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://city2surfroofing.com.au/areas-serviced-roofing/roof-repairs-artarmon/",
        "target": "city2surfroofing.com.au",
        "start_url": "https://city2surfroofing.com.au/areas-serviced-roofing/roof-repairs-artarmon/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Artarmon\\organic\\type-organic_rg10_ra13_city2surfroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:52 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "COLORBOND ROOFING",
                                    "url": "https://city2surfroofing.com.au/colorbond-roofing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://city2surfroofing.com.au/colorbond-roofing-sydney/",
                                            "anchor_text": "COLORBOND ROOFING"
                                        }
                                    ]
                                },
                                {
                                    "text": "TERRACOTTA ROOF TILES",
                                    "url": "https://city2surfroofing.com.au/terracotta-roof-tiles/",
                                    "urls": [
                                        {
                                            "url": "https://city2surfroofing.com.au/terracotta-roof-tiles/",
                                            "anchor_text": "TERRACOTTA ROOF TILES"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF INSTALLATION",
                                    "url": "https://city2surfroofing.com.au/roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://city2surfroofing.com.au/roof-installation-sydney/",
                                            "anchor_text": "ROOF INSTALLATION"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF REPAIRS",
                                    "url": "https://city2surfroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://city2surfroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "ROOF REPAIRS"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF REPLACEMENT",
                                    "url": "https://city2surfroofing.com.au/roof-replacement-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://city2surfroofing.com.au/roof-replacement-sydney/",
                                            "anchor_text": "ROOF REPLACEMENT"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF RESTORATION",
                                    "url": "https://city2surfroofing.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://city2surfroofing.com.au/roof-restoration-sydney/",
                                            "anchor_text": "ROOF RESTORATION"
                                        }
                                    ]
                                },
                                {
                                    "text": "RE ROOFING",
                                    "url": "https://city2surfroofing.com.au/re-roofing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://city2surfroofing.com.au/re-roofing-sydney/",
                                            "anchor_text": "RE ROOFING"
                                        }
                                    ]
                                },
                                {
                                    "text": "METAL ROOFING",
                                    "url": "https://city2surfroofing.com.au/metal-roofing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://city2surfroofing.com.au/metal-roofing-sydney/",
                                            "anchor_text": "METAL ROOFING"
                                        }
                                    ]
                                },
                                {
                                    "text": "CONCRETE ROOFING",
                                    "url": "https://city2surfroofing.com.au/concrete-tile-roofing-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://city2surfroofing.com.au/concrete-tile-roofing-sydney/",
                                            "anchor_text": "CONCRETE ROOFING"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Privacy Policy \u00a9 City2Surf Roofing | Sitemap | ACN: 64 919 151 | ABN: 71 624 919 151 | LICENCE NO: 326 467 C",
                                    "url": "https://city2surfroofing.com.au/privacy-policy",
                                    "urls": [
                                        {
                                            "url": "https://city2surfroofing.com.au/privacy-policy",
                                            "anchor_text": "Privacy Policy"
                                        },
                                        {
                                            "url": "https://city2surfroofing.com.au/sitemap/",
                                            "anchor_text": "Sitemap"
                                        }
                                    ]
                                }
                            ],
                            "secondary_content": null,
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "ROOF REPAIRS ARTARMON",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "City2Surf Roofing have over 15 years of experience in providing quality roof repairs and services to Artarmon. We\u2019ve repaired, restored, and replaced roofs for hundreds of satisfied customers throughout the Artarmon region.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A leaking or old roof is a ticking time bomb. If you ignore a tired, old roof, you could severely damage your home and decrease its value. Roofs with missing tiles, worn shingles, or corroded metal can scare off prospective buyers and make your home stand out like a sore thumb in the neighbourhood.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "ROOFING SERVICES ARTARMON",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We offer a range of roofing services from installations to replacement. We work with a wide range of different roofing materials. Your roof material, size, and condition don\u2019t matter to us. We\u2019ve seen it all and can guarantee an affordable, durable roofing repair job regardless of the circumstances.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our roofing services in Artarmon include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "residential roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "commercial roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "re roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "gutter repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Types of materials we use in roofing projects in Artarmon:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "asphalt shingles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "copper roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "concrete roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our roofer tilers are licensed, insured, and some of the most experienced in the roofing repair industry. We can repair missing siding, flashing, and missing shingles and tiles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For Colorbond metal roof and tile roof repairs, we know a uniform look is important to you. When you work with us for your Artarmon roof repair, we will do our absolute best to match your new Colorbond or tiles to your existing roof\u2019s appearance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "roof installations",
                                        "url": "https://city2surfroofing.com.au/roof-installation-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://city2surfroofing.com.au/roof-installation-sydney/",
                                                "anchor_text": "roof installations"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "roof repairs",
                                        "url": "https://city2surfroofing.com.au/roof-repairs-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://city2surfroofing.com.au/roof-repairs-sydney/",
                                                "anchor_text": "roof repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "roof replacement",
                                        "url": "https://city2surfroofing.com.au/roof-replacement-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://city2surfroofing.com.au/roof-replacement-sydney/",
                                                "anchor_text": "roof replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "metal roofing",
                                        "url": "https://city2surfroofing.com.au/metal-roofing-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://city2surfroofing.com.au/metal-roofing-sydney/",
                                                "anchor_text": "metal roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Colorbond roofing",
                                        "url": "https://city2surfroofing.com.au/colorbond-roofing-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://city2surfroofing.com.au/colorbond-roofing-sydney/",
                                                "anchor_text": "Colorbond roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "terracotta roof tiles",
                                        "url": "https://city2surfroofing.com.au/roof-tiles-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://city2surfroofing.com.au/roof-tiles-sydney/",
                                                "anchor_text": "terracotta roof tiles"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "If you have a Slate Roof needing repair, contact our sister company: NSW Slate Roofing Sydney.",
                                        "url": "https://nswslateroofing.com.au/slate-roofing-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://nswslateroofing.com.au/slate-roofing-sydney/",
                                                "anchor_text": "NSW Slate Roofing Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "PROFESSIONAL ROOF REPAIRS ARTARMON COMPANY",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With years of experience in the roofing industry, City2Surf Roofing has been providing quality services to all our Artarmon roof repairs clients.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our extensive knowledge of the industry. We have more than a decade of experience in roofing repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We can work with a variety of roofing materials. And we can work with commercial and residential properties alike.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guaranteed customer satisfaction. We treat our customer\u2019s roofs like they are our own. When you work with our licensed and experienced roofers, we\u2019ll make sure that you are satisfied from start to finish with your roof repair project.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Prices are transparent and affordable. When you call us, we will thoroughly inspect your roof before giving you a free, no-obligation quote. Our quotes are detailed and tailored for your specific roof repair job. We know that roofing repair can be stressful for most home owners, and we want to make it easy for you to make the right choice for your home. Each of our quotes is customised for the individual property. We\u2019ll work with you so that you\u2019ll get the most affordable price for your roofing repair needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our prices are some of the most competitive in the Artarmon area.",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "And when you work with us, we will guarantee your satisfaction. We treat each job with care and pay close attention to detail. Are you ready to restore your home\u2019s value and give it some curb appeal?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Then contact us today at City2Surf Roofing for your free, no-obligation quote.",
                                        "url": "https://city2surfroofing.com.au/areas-serviced/metal-roofing-northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://city2surfroofing.com.au/areas-serviced/metal-roofing-northern-beaches/",
                                                "anchor_text": "contact us today"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Give us a call today on 1300 296 842 or fill out the enquiry form below and we will get back to you shortly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Request a Free Quote",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Type of Roof Required*",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "* Denotes required field",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "TERRACOTTA TILES",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "The quality, integrity, and color of terracotta roof tiles hold up well over time. Plus, the material is naturally fire and frost resistant. Thus making it an ideal building material for brush fire-prone areas and places that experience harsh, cold weather.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "TERRACOTTA TILES",
                                        "url": "https://city2surfroofing.com.au/roof-tilers-sydney",
                                        "urls": [
                                            {
                                                "url": "https://city2surfroofing.com.au/roof-tilers-sydney",
                                                "anchor_text": "TERRACOTTA TILES"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "ROOF REPLACEMENT",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "With over 20 years of experience in the local roofing business. We specialise in all kinds of roof replacement techniques. Materials including Colorbond, copper, terracotta and metal roofing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "ROOF INSTALLATION",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "City2Surf Roofing are the leading roofing installation specialists in the Sydney area. Expert roof tilers and Metal Roofing Installers with more than 20 years of experience.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "COLORBOND ROOFING",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Colorbond Roofing sheets are pre-painted and treated to resist the Australian climate. Furthermore, their high quality design ensures that they will last for decades to come.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "ARTARMON ROOFING SERVICES",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "VIEW OUR GALLERY",
                                "main_title": "ROOF REPAIRS ARTARMON",
                                "author": "City2surf Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "1300 296 842"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}