{
    "id": "01190728-1132-0216-0000-bb40c05732e3",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0181 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneywideroofingco.com.au/inner-west/canada-bay/",
        "target": "sydneywideroofingco.com.au",
        "start_url": "https://sydneywideroofingco.com.au/inner-west/canada-bay/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Canada-Bay\\featured_snippet\\type-featured_snippet_rg1_ra1_sydneywideroofingco.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:38:11 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipes",
                                    "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                            "anchor_text": "Gutters and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tile Pointing and Bedding",
                                    "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                            "anchor_text": "Roof Tile Pointing and Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Roofing",
                                    "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                            "anchor_text": "Zinc Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs in Randwick NSW",
                                    "url": "https://sydneywideroofingco.com.au/randwick/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/randwick/",
                                            "anchor_text": "Roof Repairs in Randwick NSW"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Georges River",
                                    "url": "https://sydneywideroofingco.com.au/georges-river/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/georges-river/",
                                            "anchor_text": "Georges River"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Inner West Roof Repairs",
                                    "url": "https://sydneywideroofingco.com.au/inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/inner-west/",
                                            "anchor_text": "Sydney Inner West Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "City of Sydney",
                                    "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                            "anchor_text": "City of Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "GET QUOTE",
                                    "url": "https://sydneywideroofingco.com.au/get-quote/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/get-quote/",
                                            "anchor_text": "GET QUOTE"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "95 Bellingara Rd, Miranda NSW 2228.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "(02) 8294 4654",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Safeguarding Your Canada Bay Property with Sydney Wide Roofing Co",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For those in Canada Bay who are looking to protect their homes or commercial properties from the diverse Australian climate, the importance of quality roofing cannot be overstated. Sydney Wide Roofing Co emerges as the benchmark in the area, epitomizing a dedication to unparalleled standards. We, at Sydney Wide Roofing Co, believe a robust roof is not just a protective layer but an emblem of your commitment to longevity and safety. With an illustrious history, we have mastered roofing to ensure every venture stands as a reflection of our work ethic and dependability. From minor repairs to large-scale installations, we are your trusted ally in offering the pinnacle of roofing Canada Bay solutions, ensuring stability and tranquillity.",
                                        "url": "https://maps.app.goo.gl/5D98d7TwYVXUKnKz6",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/5D98d7TwYVXUKnKz6",
                                                "anchor_text": "Canada Bay"
                                            },
                                            {
                                                "url": "https://sydneywideroofingco.com.au/",
                                                "anchor_text": "Sydney Wide Roofing Co"
                                            },
                                            {
                                                "url": "https://www.canadabay.nsw.gov.au/",
                                                "anchor_text": "Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Diving Deeper into Our Roofing Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney Wide Roofing Co is more than equipped to handle any roofing challenge, irrespective of its magnitude or intricacy. Our Canada Bay roofing professionals are dedicated to ensuring resilience, longevity, and client contentment. Here\u2019s a snapshot of what we offer:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Canada Bay",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A roof that\u2019s aged or severely damaged calls for the expert intervention of our seasoned team. Not just about protection, we guarantee your new roof amplifies your property\u2019s visual appeal. With three decades of industry involvement, Sydney Wide Roofing Co is your go-to for flawless roof replacements in Canada Bay. Our expertise extends to tile, metal, corrugated iron, colorbond, and skylight replacements, making us the preferred choice for both residential and commercial spaces.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                                "anchor_text": "Roof Replacement Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation Canada Bay",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If you\u2019re erecting a new establishment or extending an existing one, our adept Canada Bay roofing experts can manage installations of every scale and variety. Our commitment to top-tier materials and industry benchmarks ensures your roof\u2019s longevity.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Installation Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                                "anchor_text": "Roof Installation Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Canada Bay",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Prompt and effective roof repairs in Canada Bay are pivotal to thwart exacerbation and secure your roof\u2019s foundational integrity. Our team excels in pinpointing and rectifying a spectrum of roofing ailments, from leakage issues to structural compromises.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                                "anchor_text": "Roof Repairs Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Roof Repairs Canada Bay",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our tenure in the field has endowed us with the skills to not merely rectify roof leakages but also counsel on proactive measures and the optimal selection of guttering systems. At Sydney Wide Roofing Co, our methodical approach to leak repairs ensures identification, rectification, and prevention.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Leaking Roof Repairs Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                                "anchor_text": "Leaking Roof Repairs Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Canada Bay",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofs showing signs of wear but not warranting a complete overhaul can be revitalised with our restoration services. From intensive cleaning to resealing, our solutions enhance your roof\u2019s longevity and aesthetic charm.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tile Rebedding and Repointing Canada Bay",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Weather and time can erode roof tiles. Our professionals engage in meticulous tile rebedding and repointing to strengthen your roof\u2019s defense against the elements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Tile Rebedding and Repointing Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                                "anchor_text": "Roof Tile Rebedding and Repointing Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Sydney Wide Roofing Co in Canada Bay?",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "A Wealth of Experience Our longstanding presence has endowed us with insights and expertise, making us the premier choice for many in Canada Bay.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rooted in Canada Bay Our ties to Canada Bay are profound. Our insights into the locale\u2019s dynamics enable us to craft solutions tailored for its residents.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Unwavering Dedication to Clients We don\u2019t merely execute tasks; we cultivate relationships. Our commitment to transparent communication and adaptability sets us apart.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Meticulous Craftsmanship Every project, regardless of scale, is approached with precision and dedication, ensuring impeccable outcomes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For unparalleled roofing solutions in Leichhardt, reach out to Sydney Wide Roofing Co:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing in Canada Bay: Local Insights",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Canada Bay, a jewel in Sydney\u2019s inner-west, is distinguished by its rich history and serene waterfronts. The suburb is enveloped by areas like Concord, Five Dock, and Drummoyne. Attractions such as the Canada Bay foreshores draw residents and tourists alike.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local Roofing Regulations Roofing endeavors in Canada Bay must align with the guidelines of the City of Canada Bay Council. Adherence to design standards, bushfire safety norms, stormwater management practices, and eco-friendly methodologies are paramount. Also, acknowledging local architectural nuances enriches the suburb\u2019s character.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Sydney Wide Roofing Co, we\u2019re poised to address all your roofing needs in Canada Bay. Entrust us with your projects, and witness our unwavering commitment to quality and client satisfaction.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Contact Us Today",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Phone \u2013 (02) 8503 4416",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email \u2013 [email\u00a0protected]",
                                        "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Website \u2013 https://sydneywideroofingco.com.au/",
                                        "url": "https://sydneywideroofingco.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/",
                                                "anchor_text": "https://sydneywideroofingco.com.au/"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Canada Bay",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair Canada Bay \u2013 Sydney Wide Roofing Co",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Services Canada Bay",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ensuring effective water flow away from your structure, our gutter services encompass installations, periodic maintenance, and prompt repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter Services Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                                "anchor_text": "Gutter Services Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Highly Rated Roofing Company servicing Canada Bay, Inner West",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For all your roofing needs, reach out to us today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Contact Information",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You can contact Sydney Wide Roofing Co \u2013 Leichhardt at the following:",
                                        "url": "https://maps.app.goo.gl/GZKPfLyAtY3H1Afn9",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/GZKPfLyAtY3H1Afn9",
                                                "anchor_text": "Sydney Wide Roofing Co \u2013 Leichhardt"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Phone \u2013 (02) 8503 4416",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email \u2013 [email\u00a0protected]",
                                        "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Website \u2013 https://sydneywideroofingco.com.au/",
                                        "url": "https://sydneywideroofingco.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/",
                                                "anchor_text": "https://sydneywideroofingco.com.au/"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Portfolio",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burraneer Bay Residential",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Burraneer Bay Residential",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                                "anchor_text": "Burraneer Bay Residential"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing Project Sydney",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing Project Sydney",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                                "anchor_text": "Slate Roofing Project Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Project Eastern Suburbs",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Project Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                                "anchor_text": "Metal Roofing Project Eastern Suburbs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Handy Tips About Roofing",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leaks",
                                        "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                                "anchor_text": "Roof Leaks"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-roofing",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Re-roofing",
                                        "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                                "anchor_text": "Re-roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Downpipes",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                                "anchor_text": "Roof Tiling"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations We Service",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sutherland Shire",
                                        "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                                "anchor_text": "Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                                "anchor_text": "Eastern Suburbs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georges River",
                                        "url": "https://sydneywideroofingco.com.au/georges-river/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/georges-river/",
                                                "anchor_text": "Georges River"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Inner West",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/",
                                                "anchor_text": "Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Northern Beaches",
                                        "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                                "anchor_text": "Northern Beaches"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "North Sydney",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                                "anchor_text": "North Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Roofing",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heritage Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/heritage-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/heritage-roofing/",
                                                "anchor_text": "Heritage Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Copper Roofing",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Copper Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/copper-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/copper-roofing/",
                                                "anchor_text": "Copper Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/slate-roofing/",
                                                "anchor_text": "Slate Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Zinc Roofing",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Zinc Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/zinc-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/zinc-roofing/",
                                                "anchor_text": "Zinc Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations in the Inner West Council We Service",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Russell Lea",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/russell-lea/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/russell-lea/",
                                                "anchor_text": "Russell Lea"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/five-dock/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/five-dock/",
                                                "anchor_text": "Five Dock"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rodd Point",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/rodd-point/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/rodd-point/",
                                                "anchor_text": "Rodd Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/summer-hill/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/summer-hill/",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/canada-bay/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/canada-bay/",
                                                "anchor_text": "Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Building Inspiring Roofs",
                                "main_title": "Roofing Canada Bay",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Only takes a few seconds!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "61282944654",
                                "+61282944654",
                                "+61285034416"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}