{
    "id": "01190728-1132-0216-0000-2b22248b835c",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0226 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofingcorp.net.au/roof-leak-detection-and-repairs/canada-bay",
        "target": "roofingcorp.net.au",
        "start_url": "https://roofingcorp.net.au/roof-leak-detection-and-repairs/canada-bay",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Canada-Bay\\organic\\type-organic_rg10_ra15_roofingcorp.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:30:45 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Sydney's trusted roofing specialists with over 30 years of experience. Expert roof leak detection, repairs, restoration, and painting services throughout Sydney.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2025 RoofingCorp Pty Ltd",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://roofingcorp.net.au/about",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/about",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://roofingcorp.net.au/services/roof-leak-detection-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-leak-detection-sydney",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports",
                                    "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                            "anchor_text": "Roof Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://roofingcorp.net.au/services/roof-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-cleaning-sydney",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofingcorp.net.au/services/roof-restoration-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-restoration-sydney",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://roofingcorp.net.au/services/roof-painting-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-painting-sydney",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asbestos Roof Removal",
                                    "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                            "anchor_text": "Asbestos Roof Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fascia Replacement",
                                    "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                            "anchor_text": "Fascia Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofingcorp.net.au/contact",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/contact",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call us now",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofingcorp.net.au/about",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/about",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Services",
                                    "url": "https://roofingcorp.net.au/services",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services",
                                            "anchor_text": "Our Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofingcorp.net.au/contact",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/contact",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://roofingcorp.net.au/service-areas",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/service-areas",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://roofingcorp.net.au/services/roof-leak-detection-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-leak-detection-sydney",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports",
                                    "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                            "anchor_text": "Roof Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://roofingcorp.net.au/services/roof-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-cleaning-sydney",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofingcorp.net.au/services/roof-restoration-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-restoration-sydney",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://roofingcorp.net.au/services/roof-painting-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/roof-painting-sydney",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asbestos Roof Removal",
                                    "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                            "anchor_text": "Asbestos Roof Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fascia Replacement",
                                    "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                    "urls": [
                                        {
                                            "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                            "anchor_text": "Fascia Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "14 Stamford Avenue",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Ermington, NSW 2115",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Business Hours",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mon-Sat: 7:00 AM - 4:00 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Sunday: Closed",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN: 30 600 295 323",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Roof Leak Detection & Repairs Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Professional roof leak detection & repairs services in Canada Bay. We find leaks that others can't\u2014guaranteed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leak Detection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Or you don't pay",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We Find It",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Based on 239 reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney's Trusted Leak Detection Specialists",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With over 30 years of experience, RoofingCorp has become Sydney's go-to experts for finding and fixing roof leaks. We use proven techniques and decades of knowledge to locate even the most elusive leaks that other roofers miss.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Canada Bay residents trust RoofingCorp for professional roof leak detection & repairs services. With over 30 years of experience working throughout Inner West, we understand the specific roofing needs of homes and businesses in Canada Bay and surrounding suburbs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "$99 Guaranteed Detection",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For just $99, we guarantee to find the source of your leak. If we can't find it, you don't pay.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Money-Back Guarantee",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If we can't fix your leak by our 3rd attempt, we'll refund your money in full. That's our promise.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Cost Deducted from Repairs",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "When you proceed with our repair service, your $99 detection fee is deducted from the repair quote.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Same-Day Service Available",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Leaking roof? We offer same-day leak detection services throughout Sydney when you call early.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Leak Detection Process",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our systematic approach ensures we find every leak, every time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Thorough Inspection",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We inspect your entire roof, inside and out, checking all potential entry points including tiles, flashing, valleys, and penetrations.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leak Source Identification",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Using our 30+ years of experience, we trace water paths and identify the exact source of your leak\u2014not just where water appears.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Detailed Assessment",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We document the leak source with photos and explain exactly what's causing the problem and how we'll fix it.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fixed-Price Quote",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You receive a clear, itemised quote for repairs. No hidden fees, no surprises\u2014just honest pricing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professional Repair",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our experienced roofers complete the repair using quality materials, backed by our workmanship warranty.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Common Leak Problems We Solve",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From minor drips to major water damage, we've seen and fixed it all.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Cracked or Broken Tiles",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Damaged tiles allow water to penetrate during rain, causing ceiling stains and structural damage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Failed Flashing",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Deteriorated flashing around chimneys, skylights, and vents is a major source of leaks.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Valley Leaks",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Valleys collect large amounts of water and are prone to leaks when damaged or poorly installed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ridge Cap Issues",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Cracked bedding or failed pointing on ridge caps allows water into the roof space.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Storm Damage",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Hail, wind, and fallen debris can cause immediate leaks requiring urgent attention.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Blocked Gutters",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Overflowing gutters can force water under tiles and into roof cavities.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Common Leak Problems We Solve",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Noticed any of these signs on your Canada Bay property? Don't wait until a small problem becomes expensive water damage. Our team regularly works in Canada Bay and can usually inspect your roof within days.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Your Local Leak Detection Experts",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Here's why homeowners and businesses across Canada Bay choose RoofingCorp for their roofing needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We Find Hidden Leaks",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our 30+ years of experience means we find leaks that other roofers miss. We trace water paths to the true source.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Money-Back Guarantee",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We're so confident in our ability that if we can't fix your leak by our 3rd attempt, you get a full refund.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "No Middlemen",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Deal directly with the roofer who will complete your work\u2014no sales departments or subcontractors.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Honest Advice",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We tell you exactly what needs fixing. We won't upsell unnecessary work or recommend repairs you don't need.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Years Experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "5-Star Reviews",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Licensed & Insured",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Support Available",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Common Questions About Roof Leak Detection & Repairs",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Everything you need to know about our roof leak detection & repairs services for Canada Bay homes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Customers Say",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Don't just take our word for it. Here's what our customers say about our roofing services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201c We had a persistent leak that two other roofers couldn't find. RoofingCorp came out, found the source within an hour, and fixed it the same day. Their leak detection service is worth every cent. The $99 detection fee was deducted from the repair cost too. Highly recommend for anyone with a leaking roof in Sydney. \u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201c Had a mystery leak that appeared every time it rained heavily. Called RoofingCorp and they found it was coming from deteriorated flashing around the chimney. Fixed it on the spot and we've had no leaks since. Their money-back guarantee gave us confidence to try them. \u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Customers Say",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u201c We had water stains appearing on our ceiling but couldn't work out where the leak was coming from. RoofingCorp's leak detection service was thorough and professional. They found a hairline crack in a valley that was letting water in. Problem solved! \u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201c Multiple leaks during heavy rain had us stressed. RoofingCorp systematically found every problem area - worn flashing, cracked tiles, and failed pointing. They fixed it all in one visit. No leaks since, even in the heaviest storms. \u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Customers Say",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u201c A leak that appeared only during certain wind-driven rain conditions had us baffled. RoofingCorp's thorough inspection found the culprit - failed flashing around a skylight. Problem solved and leak-free ever since! \u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201c Internal leak causing ceiling damage. RoofingCorp's systematic approach found multiple problem areas that had been missed before. All fixed now and no more water damage. \u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak Detection & Repairs Near Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We also service these suburbs near Canada Bay in the Inner West region",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Explore Our Roofing Services in Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "In addition to roof leak detection & repairs, we offer a comprehensive range of roofing solutions in Canada Bay and throughout Inner West.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Need Roof Leak Detection & Repairs in Canada Bay?",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Contact RoofingCorp today for professional roof leak detection & repairs services. We're just a phone call away.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Request a Leak Detection Quote",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We'll get back to you as soon as possible",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Click to upload or drag and drop",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "By submitting this form, you agree to our Privacy Policy. Your information is secure.",
                                        "url": "https://roofingcorp.net.au/privacy-policy",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/privacy-policy",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "0 /5 images \u2022 Optional",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof leak detection cost in Canada Bay?",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How quickly can you respond to a leaking roof in Canada Bay?",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What if you can't find my roof leak in Canada Bay?",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you repair all types of roofs in Canada Bay?",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Are you licensed to work in Canada Bay?",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Still have questions? Our friendly team is here to help.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Michael Thompson",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Peter Nguyen",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Rebecca White",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Elizabeth Moore",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Diana Murphy",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fiona James",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Reports Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Reports Canada Bay",
                                        "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                                "anchor_text": "Roof Reports Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are able to deliver an honest and thorough assessment on the current condition of your roof. Detailed reports for $299.",
                                        "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-reports-sydney",
                                                "anchor_text": "We are able to deliver an honest and thorough assessment on the current condition of your roof. Detailed reports for $299."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs Canada Bay",
                                        "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                                "anchor_text": "Roof Repairs Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canada Bay residents can trust us to find the source and address any roof issues quickly and efficiently. Quality repairs with a money-back guarantee.",
                                        "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-repairs-sydney",
                                                "anchor_text": "Canada Bay residents can trust us to find the source and address any roof issues quickly and efficiently. Quality repairs with a money-back guarantee."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Maintenance Canada Bay",
                                        "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                                "anchor_text": "Roof Maintenance Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are able to service your roof maintenance and complete all repairs that will last you into the future.",
                                        "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/roof-maintenance-sydney",
                                                "anchor_text": "We are able to service your roof maintenance and complete all repairs that will last you into the future."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Cleaning Canada Bay",
                                        "url": "https://roofingcorp.net.au/roof-cleaning/canada-bay",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-cleaning/canada-bay",
                                                "anchor_text": "Roof Cleaning Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof cleaning is a great, affordable way to restore pride to your weary and untidy looking roof.",
                                        "url": "https://roofingcorp.net.au/roof-cleaning/canada-bay",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-cleaning/canada-bay",
                                                "anchor_text": "Roof cleaning is a great, affordable way to restore pride to your weary and untidy looking roof."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration Canada Bay",
                                        "url": "https://roofingcorp.net.au/roof-restoration/canada-bay",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-restoration/canada-bay",
                                                "anchor_text": "Roof Restoration Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are able to return your roof back to its premium condition, ensuring you decades of style and security.",
                                        "url": "https://roofingcorp.net.au/roof-restoration/canada-bay",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-restoration/canada-bay",
                                                "anchor_text": "We are able to return your roof back to its premium condition, ensuring you decades of style and security."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Painting Canada Bay",
                                        "url": "https://roofingcorp.net.au/roof-painting/canada-bay",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-painting/canada-bay",
                                                "anchor_text": "Roof Painting Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rejuvenate your roof, ensuring it continues to protect your family whilst adding value to your home's appeal.",
                                        "url": "https://roofingcorp.net.au/roof-painting/canada-bay",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/roof-painting/canada-bay",
                                                "anchor_text": "Rejuvenate your roof, ensuring it continues to protect your family whilst adding value to your home's appeal."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Canada Bay",
                                        "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                                "anchor_text": "Metal Roofing Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We provide all flat metal roofing tasks, whether you need repairs, maintenance or a new flat metal roof.",
                                        "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/metal-roofing-sydney",
                                                "anchor_text": "We provide all flat metal roofing tasks, whether you need repairs, maintenance or a new flat metal roof."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Asbestos Roof Removal Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Asbestos Roof Removal Canada Bay",
                                        "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                                "anchor_text": "Asbestos Roof Removal Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are the specialists in the safe removal of asbestos roofs, and we make sure to comply with all regulations.",
                                        "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/asbestos-roof-removal-sydney",
                                                "anchor_text": "We are the specialists in the safe removal of asbestos roofs, and we make sure to comply with all regulations."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Replacement Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter Replacement Canada Bay",
                                        "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                                "anchor_text": "Gutter Replacement Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are your go-to experts for efficient gutter replacement services in Canada Bay, ensuring top-quality materials and workmanship.",
                                        "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/gutter-replacement-sydney",
                                                "anchor_text": "We are your go-to experts for efficient gutter replacement services in Canada Bay, ensuring top-quality materials and workmanship."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fascia Replacement Canada Bay",
                                "main_title": "Roof Leak Detection & Repairs Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Fascia Replacement Canada Bay",
                                        "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                                "anchor_text": "Fascia Replacement Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Specialising in fascia replacement, we provide durable and aesthetically pleasing solutions that stand the test of time.",
                                        "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                        "urls": [
                                            {
                                                "url": "https://roofingcorp.net.au/services/fascia-replacement-sydney",
                                                "anchor_text": "Specialising in fascia replacement, we provide durable and aesthetically pleasing solutions that stand the test of time."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 69,
                                "relative_rating": 1
                            },
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 69,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": [
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-14 22:00:00 +00:00",
                                "author": "Eva Shui",
                                "primary_content": [
                                    {
                                        "text": "Cannot speak highly enough of RoofingCorp. They did high pressure clean and fungal treatment for us recently on an extremely hot weather nearly 45c outside, no reschedule, show up on time and the roof look like brand new after the wash. Asked them to come back to do repointing, replace broken tiles and fix leaking roof due to storm damage. Fast and efficient service at competitive price. Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-27 22:00:00 +00:00",
                                "author": "Kate Merrick",
                                "primary_content": [
                                    {
                                        "text": "Had some fibreglass panels on the roof changed out for sheet metal and while they were here I asked them to have a look at re-pointing the roof caps on the tile part of our roof. They went above and beyond, even finding and swapping out some severely broken tiles. The re-pointing and new roof panels look amazing! They were fast, friendly and professional. Have already recommended them to a few friends and will be keeping their details for future roofing needs. Thanks guys!!!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-14 21:00:00 +00:00",
                                "author": "Ian Stokes",
                                "primary_content": [
                                    {
                                        "text": "I hired the guys from RoofingCorp to clean and repaint our steel roof. They were by far the most responsive, helpful, and value for money of all the companies I contacted in regards to the work I wanted done. Quick and efficient, well mannered, no fuss and the quality of the work was excellent. I would highly recommend them.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-09-29 21:00:00 +00:00",
                                "author": "Dennis Kalkandis",
                                "primary_content": [
                                    {
                                        "text": "Yesser and the team at Roofing Corp came out to my property and replaced my old tile roof to Colorbond. They did a great job. My new roof looks amazing, the job was completed within a few days and the boys removed and disposed of all the rubbish and excess materials from the site. They replaced all my batons to the correct spacing required for a metal roof and provided new insulation underneath. Great work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-19 22:00:00 +00:00",
                                "author": "Michael Thompson",
                                "primary_content": [
                                    {
                                        "text": "We had a persistent leak that two other roofers couldn't find. RoofingCorp came out, found the source within an hour, and fixed it the same day. Their leak detection service is worth every cent. The $99 detection fee was deducted from the repair cost too. Highly recommend for anyone with a leaking roof in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-17 22:00:00 +00:00",
                                "author": "Sarah Chen",
                                "primary_content": [
                                    {
                                        "text": "Just had our entire roof restored by RoofingCorp using the Dulux Acratex system. The transformation is incredible - our 30-year-old tile roof looks brand new. The team was professional from the quote right through to completion. Very happy with the quality and the price was competitive.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-11 22:00:00 +00:00",
                                "author": "David Williams",
                                "primary_content": [
                                    {
                                        "text": "Had all our gutters replaced with Colorbond gutters by RoofingCorp. The old gutters were rusted and leaking everywhere. The new ones look fantastic and the water flows perfectly now. The team cleaned up after themselves and were very professional throughout.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-07 22:00:00 +00:00",
                                "author": "Jennifer Brown",
                                "primary_content": [
                                    {
                                        "text": "Needed a roof condition report for insurance purposes after the recent storms. RoofingCorp provided a detailed, professional report with photos and recommendations. The report helped us claim the repair costs from our insurance. Well worth the $299.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-04 22:00:00 +00:00",
                                "author": "Robert Anderson",
                                "primary_content": [
                                    {
                                        "text": "Our tile roof was leaking in multiple spots after the heavy rains. RoofingCorp came out promptly, identified all the problem areas, and fixed everything in one visit. They even fixed some ridge capping issues we didn't know about. Fair price and excellent work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-29 22:00:00 +00:00",
                                "author": "Michelle Lee",
                                "primary_content": [
                                    {
                                        "text": "The spray and wait cleaning method they use is amazing! No harsh chemicals or high pressure damage to our tiles. The moss and lichen are completely gone and the roof looks years younger. Will definitely use them again for regular maintenance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-14 22:00:00 +00:00",
                                "author": "Eva Shui",
                                "primary_content": [
                                    {
                                        "text": "Cannot speak highly enough of RoofingCorp. They did high pressure clean and fungal treatment for us recently on an extremely hot weather nearly 45c outside, no reschedule, show up on time and the roof look like brand new after the wash. Asked them to come back to do repointing, replace broken tiles and fix leaking roof due to storm damage. Fast and efficient service at competitive price. Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-27 22:00:00 +00:00",
                                "author": "Kate Merrick",
                                "primary_content": [
                                    {
                                        "text": "Had some fibreglass panels on the roof changed out for sheet metal and while they were here I asked them to have a look at re-pointing the roof caps on the tile part of our roof. They went above and beyond, even finding and swapping out some severely broken tiles. The re-pointing and new roof panels look amazing! They were fast, friendly and professional. Have already recommended them to a few friends and will be keeping their details for future roofing needs. Thanks guys!!!",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-14 21:00:00 +00:00",
                                "author": "Ian Stokes",
                                "primary_content": [
                                    {
                                        "text": "I hired the guys from RoofingCorp to clean and repaint our steel roof. They were by far the most responsive, helpful, and value for money of all the companies I contacted in regards to the work I wanted done. Quick and efficient, well mannered, no fuss and the quality of the work was excellent. I would highly recommend them.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-09-29 21:00:00 +00:00",
                                "author": "Dennis Kalkandis",
                                "primary_content": [
                                    {
                                        "text": "Yesser and the team at Roofing Corp came out to my property and replaced my old tile roof to Colorbond. They did a great job. My new roof looks amazing, the job was completed within a few days and the boys removed and disposed of all the rubbish and excess materials from the site. They replaced all my batons to the correct spacing required for a metal roof and provided new insulation underneath. Great work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-19 22:00:00 +00:00",
                                "author": "Michael Thompson",
                                "primary_content": [
                                    {
                                        "text": "We had a persistent leak that two other roofers couldn't find. RoofingCorp came out, found the source within an hour, and fixed it the same day. Their leak detection service is worth every cent. The $99 detection fee was deducted from the repair cost too. Highly recommend for anyone with a leaking roof in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-17 22:00:00 +00:00",
                                "author": "Sarah Chen",
                                "primary_content": [
                                    {
                                        "text": "Just had our entire roof restored by RoofingCorp using the Dulux Acratex system. The transformation is incredible - our 30-year-old tile roof looks brand new. The team was professional from the quote right through to completion. Very happy with the quality and the price was competitive.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-11 22:00:00 +00:00",
                                "author": "David Williams",
                                "primary_content": [
                                    {
                                        "text": "Had all our gutters replaced with Colorbond gutters by RoofingCorp. The old gutters were rusted and leaking everywhere. The new ones look fantastic and the water flows perfectly now. The team cleaned up after themselves and were very professional throughout.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-07 22:00:00 +00:00",
                                "author": "Jennifer Brown",
                                "primary_content": [
                                    {
                                        "text": "Needed a roof condition report for insurance purposes after the recent storms. RoofingCorp provided a detailed, professional report with photos and recommendations. The report helped us claim the repair costs from our insurance. Well worth the $299.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-11-04 22:00:00 +00:00",
                                "author": "Robert Anderson",
                                "primary_content": [
                                    {
                                        "text": "Our tile roof was leaking in multiple spots after the heavy rains. RoofingCorp came out promptly, identified all the problem areas, and fixed everything in one visit. They even fixed some ridge capping issues we didn't know about. Fair price and excellent work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            },
                            {
                                "rating": {
                                    "name": null,
                                    "rating_value": 5,
                                    "max_rating_value": 5,
                                    "rating_count": null,
                                    "relative_rating": 1
                                },
                                "title": null,
                                "publish_date": "2024-10-29 22:00:00 +00:00",
                                "author": "Michelle Lee",
                                "primary_content": [
                                    {
                                        "text": "The spray and wait cleaning method they use is amazing! No harsh chemicals or high pressure damage to our tiles. The moss and lichen are completely gone and the roof looks years younger. Will definitely use them again for regular maintenance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            }
                        ],
                        "contacts": {
                            "telephones": [
                                "0414424878",
                                "0414 424 878"
                            ],
                            "emails": [
                                "sales@roofingcorp.net.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}