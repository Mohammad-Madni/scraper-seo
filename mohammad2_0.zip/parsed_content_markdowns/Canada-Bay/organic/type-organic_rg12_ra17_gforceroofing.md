{
    "id": "01190728-1132-0216-0000-f797c0a5b659",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0444 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://gforceroofing.au/roofing/",
        "target": "gforceroofing.au",
        "start_url": "https://gforceroofing.au/roofing/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Canada-Bay\\organic\\type-organic_rg12_ra17_gforceroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:42 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "G-Force Roofing",
                                    "url": "https://gforceroofing.au/roofing",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing",
                                            "anchor_text": "G-Force Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://gforceroofing.au/roofing/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emer-Clad Waterproof Membrane Balmain",
                                    "url": "https://gforceroofing.au/roofing/emer-clad-waterproof-membrane-balmain/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/emer-clad-waterproof-membrane-balmain/",
                                            "anchor_text": "Emer-Clad Waterproof Membrane Balmain"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Lilyfield",
                                    "url": "https://gforceroofing.au/roofing/roof-repairs-lilyfield/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/roof-repairs-lilyfield/",
                                            "anchor_text": "Roof Repairs Lilyfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Weatherproof Roof Alexandria",
                                    "url": "https://gforceroofing.au/roofing/weatherproof-roof-alexandria/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/weatherproof-roof-alexandria/",
                                            "anchor_text": "Weatherproof Roof Alexandria"
                                        }
                                    ]
                                },
                                {
                                    "text": "Repoint Ridge Capping Balmain",
                                    "url": "https://gforceroofing.au/roofing/repoint-ridge-capping-balmain/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/repoint-ridge-capping-balmain/",
                                            "anchor_text": "Repoint Ridge Capping Balmain"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof and Gutters Ashbury",
                                    "url": "https://gforceroofing.au/roofing/roof-and-gutters-ashbury/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/roof-and-gutters-ashbury/",
                                            "anchor_text": "Roof and Gutters Ashbury"
                                        }
                                    ]
                                },
                                {
                                    "text": "Re Roof Rozelle",
                                    "url": "https://gforceroofing.au/roofing/re-roof-rozelle/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/re-roof-rozelle/",
                                            "anchor_text": "Re Roof Rozelle"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashings Russell Lea",
                                    "url": "https://gforceroofing.au/roofing/roof-flashings-russell-lea/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/roof-flashings-russell-lea/",
                                            "anchor_text": "Roof Flashings Russell Lea"
                                        }
                                    ]
                                },
                                {
                                    "text": "New guttering and downpipes Drummoyne",
                                    "url": "https://gforceroofing.au/roofing/new-guttering-and-downpipes-drummoyne/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/new-guttering-and-downpipes-drummoyne/",
                                            "anchor_text": "New guttering and downpipes Drummoyne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof and Gutter Annandale",
                                    "url": "https://gforceroofing.au/roofing/roof-and-gutter-annandale/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/roof-and-gutter-annandale/",
                                            "anchor_text": "Roof and Gutter Annandale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Chimney Flashing Replacement",
                                    "url": "https://gforceroofing.au/roofing/chimney-flashing-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/chimney-flashing-replacement/",
                                            "anchor_text": "Chimney Flashing Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://gforceroofing.au/roofing/contact-g-force-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/contact-g-force-roofing/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://gforceroofing.au/roofing/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emer-Clad Waterproof Membrane Balmain",
                                    "url": "https://gforceroofing.au/roofing/emer-clad-waterproof-membrane-balmain/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/emer-clad-waterproof-membrane-balmain/",
                                            "anchor_text": "Emer-Clad Waterproof Membrane Balmain"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Lilyfield",
                                    "url": "https://gforceroofing.au/roofing/roof-repairs-lilyfield/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/roof-repairs-lilyfield/",
                                            "anchor_text": "Roof Repairs Lilyfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Weatherproof Roof Alexandria",
                                    "url": "https://gforceroofing.au/roofing/weatherproof-roof-alexandria/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/weatherproof-roof-alexandria/",
                                            "anchor_text": "Weatherproof Roof Alexandria"
                                        }
                                    ]
                                },
                                {
                                    "text": "Repoint Ridge Capping Balmain",
                                    "url": "https://gforceroofing.au/roofing/repoint-ridge-capping-balmain/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/repoint-ridge-capping-balmain/",
                                            "anchor_text": "Repoint Ridge Capping Balmain"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof and Gutters Ashbury",
                                    "url": "https://gforceroofing.au/roofing/roof-and-gutters-ashbury/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/roof-and-gutters-ashbury/",
                                            "anchor_text": "Roof and Gutters Ashbury"
                                        }
                                    ]
                                },
                                {
                                    "text": "Re Roof Rozelle",
                                    "url": "https://gforceroofing.au/roofing/re-roof-rozelle/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/re-roof-rozelle/",
                                            "anchor_text": "Re Roof Rozelle"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashings Russell Lea",
                                    "url": "https://gforceroofing.au/roofing/roof-flashings-russell-lea/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/roof-flashings-russell-lea/",
                                            "anchor_text": "Roof Flashings Russell Lea"
                                        }
                                    ]
                                },
                                {
                                    "text": "New guttering and downpipes Drummoyne",
                                    "url": "https://gforceroofing.au/roofing/new-guttering-and-downpipes-drummoyne/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/new-guttering-and-downpipes-drummoyne/",
                                            "anchor_text": "New guttering and downpipes Drummoyne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof and Gutter Annandale",
                                    "url": "https://gforceroofing.au/roofing/roof-and-gutter-annandale/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/roof-and-gutter-annandale/",
                                            "anchor_text": "Roof and Gutter Annandale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Chimney Flashing Replacement",
                                    "url": "https://gforceroofing.au/roofing/chimney-flashing-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/chimney-flashing-replacement/",
                                            "anchor_text": "Chimney Flashing Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://gforceroofing.au/roofing/contact-g-force-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://gforceroofing.au/roofing/contact-g-force-roofing/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Abbotsford, Annandale, Ashbury, Ashfield, Balmain, Balmain East, Belfield, Birchgrove, Breakfast Point, Burwood, Burwood Heights, Cabarita, Camperdown, Canada Bay, Chiswick, Concord, Concord West, Croydon, Croydon Park, Drummoyne, Dulwich Hill, Earlwood, Enfield, Enmore, Erskineville, Five Dock, Forest Lodge, Gladesville, Glebe, Haberfield, Homebush, Homebush West, Leichhardt, Lewisham, Liberty Grove, Lilyfield, Marrickville, Mortlake, Newtown, North Strathfield, Petersham, Rhodes, Rodd Point, Rozelle, Russell Lea, St Peters, Stanmore, Strathfield, Strathfield South, Summer Hill, Sydenham, Tempe, Wareemba.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright \u00a9 2026 G-Force Roofing",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Mobile: 0414 992 306",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Balmain Web Design",
                                    "url": "http://balmainwebdesign.com.au/",
                                    "urls": [
                                        {
                                            "url": "http://balmainwebdesign.com.au/",
                                            "anchor_text": "Balmain Web Design"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs Inner West Sydney",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "It doesn\u2019t matter what kind of home or building you have, or what style of roof, G-Force Roofing Services will be able to help you take care of your roofing needs. Roof Repairs Sydney Inner West. We work on tile roofs, metal roofs and slate roofs and work with Terracotta tiles, Concrete tiles, Colorbond and Zincalume roofing and Galvanised roofing and associated flashings, capping and guttering etc.Roof Repairs Inner West Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "G-Force Roofing",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We specialise in all types of slate roofing products, lead flashing and lead flashing substitutes. We also fit timber fascias, barge boards, rafters and battens. We do skylights of all makes and sizes and can help you with your insulation and ventilation requirements. Roof Repairs Inner West Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "G-Force Roofing - Inner West Sydney",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofs",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Birchgrove",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofs",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Balmain",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Roofs",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Haberfield",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "re-bedding & re-pointing",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Camperdown",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "flashings, capping and guttering",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "skylights",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Rozelle",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "G-Force Roofing",
                                "main_title": "Roof Repairs & Re-Roofs | Sydney Inner West",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.8,
                                "max_rating_value": 5,
                                "rating_count": 121,
                                "relative_rating": 0.96
                            }
                        ],
                        "offers": [
                            {
                                "name": null,
                                "price": 2000,
                                "price_currency": "AUD",
                                "price_valid_until": null
                            }
                        ],
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0414992306"
                            ],
                            "emails": [
                                "anna@gforceroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}