{
    "id": "01190728-1132-0216-0000-0582c3c184f6",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0136 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrepairsstrathfield.com.au/in/canada-bay/",
        "target": "roofrepairsstrathfield.com.au",
        "start_url": "https://roofrepairsstrathfield.com.au/in/canada-bay/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Canada-Bay\\organic\\type-organic_rg9_ra14_roofrepairsstrathfield.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:42 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsstrathfield.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsstrathfield.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "We Take Care Of Your Roof",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Canada Bay is a lovely city, and you should have the best roof for your house or business. Nevertheless, severe climate condition can be harsh on your roof and cause it to deteriorate gradually. Whether you require a brand-new roof or repairs for an existing one, Roof Repairs Canada Bay is here to assist you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With years of experience in repair and installation, our team of certified professionals are specialists in doing the job right the first time. We provide a large range of services to ensure your roof is safe and secure. From minor repairs, such as replacing tiles or fixing leakages, to more involved projects, like complete replacements or re-roofing, our specialists will work with you to assist identify the best remedy for your residential or commercial property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We understand the significance of having a trusted and secure roof over your head, which is why we make every effort to provide quality craftsmanship and remarkable customer care. Our team of experienced professionals takes pride in their work and utilizes only the first-rate products for all our projects. We are also pleased to discuss any unique requests or concerns you might have and provide useful recommendations throughout the process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter what type of roofing needs you have, Roof Repairs Canada Bay is here to assist. Contact our team today, and let us be the ones to repair your roof!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Colorbond roofing is a popular option for both residential and industrial properties. Our group of experienced professionals is trained in the installation of colorbond roofing and uses the first-rate products to ensure your roof looks its best.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing Contractors Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Whether you require a complete replacement or repairs for an existing roof, our team of certified professionals can assist. We understand that a slight disturbance in company can be costly. We work around your schedule to lessen downtime, which includes weekends and/or evenings if required.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing Contractors Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We understand that emergencies can take place anytime and require quick action to lessen damage. Our team of experienced professionals is available 24/7 to provide fast and trusted emergency roof repair services. From minor repairs to more comprehensive work, we can be depended on to do the job right.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Emergency Roof Repairs Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Canada Bay Roof and Gutter",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Routine maintenance of your roof and gutter is vital in making sure that it stays in good condition. Our team of experienced professionals offers numerous services, such as cleaning and repairs, to keep your gutters working properly and assist extend the life of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Canada Bay Roof and Gutter",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Canada Bay Roof and Gutter"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Let our team of certified professionals assist you evaluate the condition of your roof. We\u2019ll provide an extensive inspection to identify roof issues and precisely recommend affordable remedies. We provide a in-depth report of our findings, which can then be used to plan any required repairs or replacements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Inspections Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Roof Repairs Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Do not let a small leak develop into a bigger problem. We utilize the latest leak detection techniques to identify and repair any issues precisely. They consist of water tests, thermal imaging, and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Leaking Roof Repairs Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of qualified professionals is can install all roofing materials, including metal roofs, slate roofs, solar roofs, tile roofs, and more. we believe in quality craftsmanship and use only the first-rate products to ensure your roof is strong and secure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Installation Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal roofs are becoming considerably popular due to their resilience, low maintenance, and energy effectiveness. We handle various type of metal roofing, from corrugated to standing seam, and several color choices. In addition, we can set up soaker panels and other add-ons for a more custom-made look.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of experienced professionals can provide a complete roof replacement service if your roof is beyond repair. We\u2019ll assist you choose the best material, size, and shape to match your property and budget plan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Canada Bay Roof Restoration",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roof Repairs Canada Bay, we believe in protecting existing structures wherever possible rather than replacing them. We utilize the latest products and techniques to extend the life of your roof while being mindful of its historical worth and character.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Canada Bay Roof Restoration",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                                "anchor_text": "Canada Bay Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We provide numerous services for residential and industrial properties in Canada Bay, ranging from minor repairs to full-scale installations. Whether it\u2019s metal or tile roofs, skylights, or solar panels\u2013 our experienced team will provide quality services that fulfill your needs and budget plan. We manage everything from start to finish and provide remarkable customer care throughout the whole process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roofing/",
                                                "anchor_text": "Roofing Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Skylights Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Skylights are amongst the most popular elements of a house, providing natural light and ventilation. Our team of certified professionals can set up residential and commercial skylights, from basic units to custom-made designs. We also provide repair options, including replacing damaged seals and frames.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Skylights Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/skylights/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/skylights/",
                                                "anchor_text": "Skylights Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tilers Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Tiling is a specialized task that needs knowledge, skill, and experience\u2013 all of which our team has in abundance. We provide installation and repairs for slate, terracotta, metal, concrete tiles, and all kinds of roof devices.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Tilers Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Repairs Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Slate roofs are a popular option for heritage homes due to their lasting resilience and traditional look. We comprehend the significance of protecting a structure\u2019s initial character and can assist you with all your slate roof repair needs. Our experienced specialists utilize only the first-rate products to restore your roof to its previous magnificence.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Slate Roof Repairs Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We understand that some Canada Bay residents might not be able to afford a roof repair or installation. Considering that our desire is to assist everybody, we provide a unique discount program for qualified Canada Bay residents. With our Canada Bay Discount Roof Repair program, you can get the repairs or installations you require at a lower expense.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019re proud to be part of the Canada Bay community and do all we can to assist our neighbors. It doesn\u2019t matter if you require a simple repair or a complete roof replacement; our experienced professionals are here to assist.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our 100% satisfaction guarantee backs every task we do. We back up all of our work and will not rest until you\u2019re totally pleased with the end results. From when you first call us to when we finish the task, you can rely on our team for remarkable service and craftsmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A trusted and secure roof is one of the most essential investments in your life. That\u2019s why when it comes to repair or installation, you can rely on the professionals at Roof Repairs Canada Bay for quality service and craftsmanship.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We proudly serve: Five Dock, Concord, Wareemba, Cabarita, Abbotsford, Burwood, Croydon, Chiswick, Russell Lea, Breakfast Point and Canada Bay",
                                        "url": "https://roofrepairsstrathfield.com.au/in/five-dock/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/five-dock/",
                                                "anchor_text": "Five Dock"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/concord/",
                                                "anchor_text": "Concord"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/wareemba/",
                                                "anchor_text": "Wareemba"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/cabarita/",
                                                "anchor_text": "Cabarita"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/abbotsford/",
                                                "anchor_text": "Abbotsford"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/burwood/",
                                                "anchor_text": "Burwood"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/croydon/",
                                                "anchor_text": "Croydon"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/chiswick/",
                                                "anchor_text": "Chiswick"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/russell-lea/",
                                                "anchor_text": "Russell Lea"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/breakfast-point/",
                                                "anchor_text": "Breakfast Point"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Our website connects you with skilled local roofing contractors servicing most Strathfield suburb, including Rookwood, Burwood, and Belfield. With extensive experience in the industry, our roofers are experts in maintaining and enhancing both tile and metal roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Are You Waiting For?",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A reliable and secure roof is one of the most important investments in your life. That\u2019s why when it comes to repair or installation, you can count on the professionals at Roof Repairs Canada Bay for quality service and workmanship. Call us now!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Talk to us today about roofing services for your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "GET IN TOUCH",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repairs Canada Bay Services",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What we offer",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We provide a large range of services, consisting of:",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Canada Bay Discount Roof Repair",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Canada Bay, New South Wales",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "For more information about Canada Bay, New South Wales",
                                        "url": "https://en.wikipedia.org/wiki/Canada%20Bay,_New%20South%20Wales",
                                        "urls": [
                                            {
                                                "url": "https://en.wikipedia.org/wiki/Canada%20Bay,_New%20South%20Wales",
                                                "anchor_text": "For more information about Canada Bay, New South Wales"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Google News:",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Latest Canada Bay News",
                                        "url": "https://news.google.com/search?q=Canada%20Bay,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                        "urls": [
                                            {
                                                "url": "https://news.google.com/search?q=Canada%20Bay,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                                "anchor_text": "Latest Canada Bay News"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Links",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Us",
                                        "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                                "anchor_text": "About Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our Services",
                                        "url": "https://roofrepairsstrathfield.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/",
                                                "anchor_text": "Our Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Info",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing",
                                        "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roofing Contractors",
                                        "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof and Gutter",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Roof and Gutter"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof Repairs",
                                        "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tilers",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slate Roof Repairs",
                                        "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "&copy 2025 Roof Repairs Strathfield",
                                "main_title": "Roof Repairs Canada Bay - #1 Roofing Company in Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "&copy 2025 Roof Repairs Strathfield",
                                        "url": "https://roofrepairsstrathfield.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/",
                                                "anchor_text": "Roof Repairs Strathfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "http://roofrepairsstrathfield.com.au/privacy-policy/",
                                        "urls": [
                                            {
                                                "url": "http://roofrepairsstrathfield.com.au/privacy-policy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms & Conditions",
                                        "url": "http://roofrepairsstrathfield.com.au/terms-and-conditions/",
                                        "urls": [
                                            {
                                                "url": "http://roofrepairsstrathfield.com.au/terms-and-conditions/",
                                                "anchor_text": "Terms & Conditions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 8403 0759",
                                "(02)%208403%200759"
                            ],
                            "emails": [
                                "info@roofrepairsstrathfield.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}