{
    "id": "01190728-1132-0216-0000-84cf7d565afa",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0362 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.jrburnsplumbing.com.au/areas-served/plumber-canada-bay/",
        "target": "www.jrburnsplumbing.com.au",
        "start_url": "https://www.jrburnsplumbing.com.au/areas-served/plumber-canada-bay/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Canada-Bay\\organic\\type-organic_rg18_ra23_jrburnsplumbing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:40 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "We are proud to bring quality plumbing services as the #1 trusted plumber in Croydon, the Inner West and Sydney CBD, NSW",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Burns Plumbing",
                                    "url": "https://www.google.com/maps?cid=11842565150125169112",
                                    "urls": [
                                        {
                                            "url": "https://www.google.com/maps?cid=11842565150125169112",
                                            "anchor_text": "Burns Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "76 Bay St, Croydon NSW 2132, Australia",
                                    "url": "https://www.google.com/maps?cid=11842565150125169112",
                                    "urls": [
                                        {
                                            "url": "https://www.google.com/maps?cid=11842565150125169112",
                                            "anchor_text": "76 Bay St, Croydon NSW 2132, Australia"
                                        }
                                    ]
                                },
                                {
                                    "text": "ABN: 59627044526",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Licence: 123357C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Sydney CBD",
                                    "url": "https://jrburnsplumbing.com.au/areas-served/plumber-sydney-cbd/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/areas-served/plumber-sydney-cbd/",
                                            "anchor_text": "Sydney CBD"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inner West",
                                    "url": "https://jrburnsplumbing.com.au/areas-served/plumber-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/areas-served/plumber-inner-west/",
                                            "anchor_text": "Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "Five Dock",
                                    "url": "https://jrburnsplumbing.com.au/areas-served/plumber-five-dock/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/areas-served/plumber-five-dock/",
                                            "anchor_text": "Five Dock"
                                        }
                                    ]
                                },
                                {
                                    "text": "View All",
                                    "url": "https://jrburnsplumbing.com.au/areas-we-service/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/areas-we-service/",
                                            "anchor_text": "View All"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Plumbing",
                                    "url": "https://jrburnsplumbing.com.au/commercial-plumbing-inner-west-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/commercial-plumbing-inner-west-sydney/",
                                            "anchor_text": "Commercial Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Plumbing",
                                    "url": "https://jrburnsplumbing.com.au/residential-plumbing-services-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/residential-plumbing-services-inner-west/",
                                            "anchor_text": "Residential Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gas Plumbing",
                                    "url": "https://jrburnsplumbing.com.au/gas-plumbing-services-inner-west-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/gas-plumbing-services-inner-west-sydney/",
                                            "anchor_text": "Gas Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bathroom Plumbing",
                                    "url": "https://jrburnsplumbing.com.au/bathroom-plumbing-inner-west-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/bathroom-plumbing-inner-west-sydney/",
                                            "anchor_text": "Bathroom Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Plumbing",
                                    "url": "https://jrburnsplumbing.com.au/emergency-plumbers-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/emergency-plumbers-inner-west/",
                                            "anchor_text": "Emergency Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blocked Drains Plumbing",
                                    "url": "https://jrburnsplumbing.com.au/blocked-drains-plumber-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/blocked-drains-plumber-inner-west/",
                                            "anchor_text": "Blocked Drains Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Kitchen Plumbing",
                                    "url": "https://jrburnsplumbing.com.au/kitchen-plumbing-inner-west-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/kitchen-plumbing-inner-west-sydney/",
                                            "anchor_text": "Kitchen Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hot Water System Repairs",
                                    "url": "https://jrburnsplumbing.com.au/hot-water-plumber-inner-west-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/hot-water-plumber-inner-west-sydney/",
                                            "anchor_text": "Hot Water System Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Burst Water Pipe Repairs",
                                    "url": "https://jrburnsplumbing.com.au/burst-water-pipe-repair-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/burst-water-pipe-repair-inner-west/",
                                            "anchor_text": "Burst Water Pipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Tap And Toilet Repairs",
                                    "url": "https://jrburnsplumbing.com.au/leaking-tap-repair-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/leaking-tap-repair-inner-west/",
                                            "anchor_text": "Leaking Tap And Toilet Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pipe Relining Services",
                                    "url": "https://jrburnsplumbing.com.au/pipe-relining-services-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/pipe-relining-services-inner-west/",
                                            "anchor_text": "Pipe Relining Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs And Installation",
                                    "url": "https://jrburnsplumbing.com.au/leaking-roof-repair-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/leaking-roof-repair-inner-west/",
                                            "anchor_text": "Roof Repairs And Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Water Leak Detection",
                                    "url": "https://jrburnsplumbing.com.au/water-leak-detection-services-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://jrburnsplumbing.com.au/water-leak-detection-services-inner-west/",
                                            "anchor_text": "Water Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Google Rating",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Expert Canada Bay Plumbing Services: Fast, Reliable Solutions for Your Plumbing Needs",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Dealing with a plumbing issue on your own can be incredibly frustrating. That\u2019s why, with over 20 years of experience providing plumbing services, JR Burns is here to help. We are committed to delivering effective plumbing solutions to homeowners, businesses, and strata properties alike. Whether you\u2019re in need of leak detection, water system repairs, roof installations, or pipe relining services, we have you covered.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team of experienced and certified plumbers in Canada Bay use the latest equipment and techniques to diagnose and fix any plumbing issue quickly.",
                                        "url": "https://jrburnsplumbing.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/",
                                                "anchor_text": "plumbers in Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us now and let us take care of your plumbing needs!",
                                        "url": "https://www.jrburnsplumbing.com.au/contact/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/contact/",
                                                "anchor_text": "Contact us now"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hot Water System Repairs In Canada Bay",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A hot water system is essential to any home, business or strata property, providing comfort and convenience to its users. However, like any other appliance, it can encounter problems over time, such as leaks, insufficient hot water, or no hot water. Hot water system in Canada Bay needs to be repaired to keep your hot water running smoothly and efficiently. Our professional local plumbers in Canada Bay can identify the root cause of the problem and provide effective solutions, such as replacing faulty components or fixing leaks.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Not only do our hot water system repairs ensure that you have hot water when needed, but they can also save you money on energy bills by improving the system\u2019s efficiency. Don\u2019t put up with cold showers or low water pressure \u2013 get in touch with our professional plumbers in Canada Bay NSW today to get your hot water system back in working order.",
                                        "url": "https://jrburnsplumbing.com.au/hot-water-plumber-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/hot-water-plumber-inner-west-sydney/",
                                                "anchor_text": "hot water system"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Hot Water System Repairs In Canada Bay",
                                        "url": "https://jrburnsplumbing.com.au/hot-water-plumber-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/hot-water-plumber-inner-west-sydney/",
                                                "anchor_text": "Hot Water System Repairs In Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Plumbing Services In Canada Bay",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From emergency plumbing to routine maintenance, our professional plumbers are equipped to handle any plumbing service. Our emergency plumbers in Canada Bay promptly reacts to plumbing crisis such as burst pipe or an overflowing toilet. We are equipped with specialized tools that can also effectively solve the common issue of blocked drains in Canada Bay.",
                                        "url": "https://jrburnsplumbing.com.au/general-plumbing-services-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/general-plumbing-services-inner-west-sydney/",
                                                "anchor_text": "plumbing service"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Beside this, JR Burns professional plumbers in Canada Bay provide plumbing services for bathrooms and kitchens. Our experts will install new fixtures, repair leaks, and clear clogs, ensuring that the essential areas of your property work properly. Relying on our local plumber in Canada Bay for your general plumbing requirements can prevent expensive repairs and guarantee that your space stays fully operational and efficient.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Danny was great really helpful and sorted the issue really quickly",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repeat customer at Burns Plumbing. Friendly team with good advice, discussed options including ways to save money on approach. Clear communication and quotes. Like that it\u2019s a smaller business. Recommend!!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jack from Burns Plumbing replaced a kitchen pullout hose under warranty. He was efficient, friendly and polite. I would happily call him again.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Grant and the team were great, very professional and friendly. The team worked efficaciously to produce the intended result, and their work was completed in a skilful manner. I would have no hesitation using Burns Plumbing again.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Exceptional service. Danny is a very knowledgeable plumber, arrived on time and did a perfect job. Can't ask for more. Strongly recommend.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "great service and very responsive",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Danny did a great job fixing our Kitchen faucet after the cartridge had failed. He also discovered corrosion inside the faucet head and cleaned and polished it out so that it worked smoothly again. Danny was on time, professional and pleasant to talk to as well.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "My emergency was a broken tap which was spraying water onto the footpath & onto all those passing by. Not entirely ideal. Burns Plumbing sent Jack almost immediately. That saved litres of precious water & reduced my anxiety levels &##x1f609;. Jack was professional, warm & friendly. He replaced the tap efficiently & quickly whilst explaining what new part of the also broken hose attachment I needed to purchase. I cannot thank Jack & the J R Burns team enough. As an aside, I phoned Plumbwell initially but they could not assist me - however they recommended J R Burns, which to me says a lot! Again thank you &##x1f64f;",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Danny did a very good job and was very personable to me and my mother. We were very satisfied with his work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Grant dropped over to quote a job (On time which is a great start). He took time to make sure he understood the job, thought about it and was then able to come back with options on how to sort out the issue. Great to have a plan A and B explained with pros and cons. Professional, down to earth bloke. Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Called these guys out short notice to assist on bathroom renovation. They arrived promptly and were able to provide very professional advice and service. Nice guys too! Will use them again.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Danny did a great job in installing our Franke pull out spray (warranty job). He also repositioned the weight for the spray and tighten the washer. He left the work area clean. Also called in advance to let me know that he was running late. Won\u2019t hesitate to use him again.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Plumbing Services In Canada Bay",
                                        "url": "https://jrburnsplumbing.com.au/general-plumbing-services-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/general-plumbing-services-inner-west-sydney/",
                                                "anchor_text": "Plumbing Services In Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Based on 101 reviews",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "review us on",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gas Leak Detection Services In Canada Bay",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Gas leaks are a serious safety hazard that requires immediate attention. Even a small gas leak can pose a significant risk to the health and safety of the occupants of a home or business. Gas leak detection services are essential to identify and locate any gas leaks in your property.",
                                        "url": "https://jrburnsplumbing.com.au/gas-leak-detection-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/gas-leak-detection-sydney/",
                                                "anchor_text": "Gas leak detection"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our professional gas plumbers in Canada Bay use high-tech leak detection equipments to pinpoint the location of gas leaks. No matter if you\u2019re dealing with a broken or burst pipe, deteriorating piping, or a faulty valve or connection, we can fix it quickly and efficiently, ensuring that it\u2019s functioning properly once again.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Water Leak Detection In Canada Bay",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Water leaks can be a major inconvenience, causing damage to your property and potentially leading to more serious issues such as mold growth or structural damage. Water leak detection services are essential to quickly identify the source of a leak and minimize the damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our professional Canada Bay plumbers detect water leaks in walls, floors, and ceilings. We repair the leak and address related issues, such as restoration of water damage. Prompt detection and repair of water leaks can save you money on your water bills and prevent further damage to your property. Contacting our plumbers in Canada Bay for water leak detection services can ensure the safety and integrity of your property.",
                                        "url": "https://jrburnsplumbing.com.au/water-leak-detection-services-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/water-leak-detection-services-inner-west/",
                                                "anchor_text": "water leak detection services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Pipe Relining Services In Canada Bay",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Pipe relining in Canada Bay is a non-invasive and cost-effective method of repairing damaged or broken pipes without the need for excavation. To investigate the state of pipes, detect blockages, and identify the root cause of persistent plumbing problems, we employ CCTV drain cameras. After locating the issue, we provide a comprehensive report of the pipe\u2019s condition, complete with recorded footage and images. Our upfront quotes provide an accurate diagnosis and the expected duration of the drain pipe relining process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our pipe relining services can repair pipes with cracks, holes, or corrosion, providing a long-term solution that is less disruptive than traditional pipe repair methods. The process is quick and efficient, and it can extend the life of your pipes for many years. Contact our professional residential and commercial plumbers in Canada Bay for pipe relining services to restore your damaged pipes to full functionality.",
                                        "url": "https://jrburnsplumbing.com.au/pipe-relining-services-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/pipe-relining-services-inner-west/",
                                                "anchor_text": "pipe relining services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs and Installation In Canada Bay",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A through roof repair and a roof installation in Canada Bay can be essential in maintaining the integrity of your home or business\u2019s roofing system. A damaged or leaking roof can lead to water damage, mold growth, and other serious problems that can be expensive to fix. Our professional roof repair services can address issues such as cracked or missing tiles, leaks, and damage caused by weather events.",
                                        "url": "https://jrburnsplumbing.com.au/leaking-roof-repair-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/leaking-roof-repair-inner-west/",
                                                "anchor_text": "roof repair services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Here at Burns Plumbing, we also offer new roof installation in Canada Bay. From traditional tile and slate roofs to modern metal roofing, our roofers are equipped to handle a range of roofing materials and styles.",
                                        "url": "https://jrburnsplumbing.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/",
                                                "anchor_text": "Burns Plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Rodd Point",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Canada Bay is a local government area located in the inner-western suburbs of Sydney, Australia. It is named after the bay on the Parramatta River, which forms the northern boundary of the area. Canada Bay is a predominantly residential area, with a mix of older-style houses and newer apartment buildings.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "It has a population of approximately 96,000 people, and the area is known for its cultural diversity, with a significant proportion of residents being of Asian descent. Canada Bay is also home to a number of parks and recreational areas, including the popular Bay Run, a 7km walking and cycling track that follows the foreshore of the bay. Overall, Canada Bay is a vibrant and diverse community, offering residents a comfortable and convenient lifestyle close to the heart of Sydney.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Burns Plumbing understand the importance of a functioning plumbing system, which is why we provide comprehensive plumbing services to our customers. Our team of expert emergency plumbers in Canada Bay are available to handle any and all plumbing needs. We pride ourselves on delivering high-quality services with a focus on customer satisfaction. Don\u2019t let plumbing issues cause stress or inconvenience to you anymore \u2013 contact us today to schedule a service or request a quote. Trust us to take care of all your plumbing needs and keep your property running smoothly!",
                                        "url": "https://jrburnsplumbing.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/",
                                                "anchor_text": "Burns Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avoid unnecessary stress and inconvenience caused by plumbing problems. Contact our plumbers in Canada Bay today for prompt and reliable services!",
                                        "url": "https://www.jrburnsplumbing.com.au/contact/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/contact/",
                                                "anchor_text": "Contact our plumbers"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burns Plumbing is Just Around the Corner",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Starting from Burns Plumbing at 76 Bay St, Croydon NSW 2132, here is a set of written driving directions to get to Canada Bay:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaving Burns Plumbing : Begin by exiting the parking lot onto Blackwall Point Road, heading northwest.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Driving on Blackwall Point Road : Follow Blackwall Point Road for approximately 700 meters. You\u2019ll see the Croydon Community Centre on your left after about 400 meters.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Approaching the Intersection : When you arrive at the intersection with Burns Crescent, you\u2019ll notice St Andrew\u2019s Anglican Church Croydon on your right. Continue straight.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Turning onto Bortfield Drive : After approximately 200 meters, turn right onto Bortfield Drive.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Driving on Bortfield Drive : Continue straight on Bortfield Drive for about 1 kilometre. You\u2019ll pass by Lysaght Park on your right after about 800 meters.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Turning onto Lyons Road : At the roundabout, take the 2nd exit and stay on Bortfield Drive, then after 200 meters, turn right onto Lyons Road. You should see the Croydon Public School on your right.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Driving on Lyons Road : Follow Lyons Road for approximately 1.5 kilometres. You will pass Five Dock Leisure Centre along this route on your left.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Arriving at Canada Bay : Continue on Lyons Road until you reach Canada Bay. You\u2019ll notice the Canada Bay Club on your right as you enter the area.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Emergency Plumber Canada Bay",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Areas We Service",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Commercial Plumbing",
                                        "url": "https://www.jrburnsplumbing.com.au/commercial-plumbing-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/commercial-plumbing-inner-west-sydney/",
                                                "anchor_text": "Commercial Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Residential Plumbing",
                                        "url": "https://www.jrburnsplumbing.com.au/residential-plumbing-services-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/residential-plumbing-services-inner-west/",
                                                "anchor_text": "Residential Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gas Plumbing",
                                        "url": "https://www.jrburnsplumbing.com.au/gas-plumbing-services-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/gas-plumbing-services-inner-west-sydney/",
                                                "anchor_text": "Gas Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "General Plumbing Services",
                                        "url": "https://www.jrburnsplumbing.com.au/general-plumbing-services-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/general-plumbing-services-inner-west-sydney/",
                                                "anchor_text": "General Plumbing Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gas Leak Detection",
                                        "url": "https://www.jrburnsplumbing.com.au/gas-leak-detection-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/gas-leak-detection-sydney/",
                                                "anchor_text": "Gas Leak Detection"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bathroom Plumbing",
                                        "url": "https://www.jrburnsplumbing.com.au/bathroom-plumbing-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/bathroom-plumbing-inner-west-sydney/",
                                                "anchor_text": "Bathroom Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Blocked Drains Plumbing",
                                        "url": "https://www.jrburnsplumbing.com.au/blocked-drains-plumber-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/blocked-drains-plumber-inner-west/",
                                                "anchor_text": "Blocked Drains Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Burst Water Pipe Repairs",
                                        "url": "https://www.jrburnsplumbing.com.au/burst-water-pipe-repair-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/burst-water-pipe-repair-inner-west/",
                                                "anchor_text": "Burst Water Pipe Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hot Water System Repairs",
                                        "url": "https://www.jrburnsplumbing.com.au/hot-water-plumber-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/hot-water-plumber-inner-west-sydney/",
                                                "anchor_text": "Hot Water System Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Tap And Toilet Repairs",
                                        "url": "https://www.jrburnsplumbing.com.au/leaking-tap-repair-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/leaking-tap-repair-inner-west/",
                                                "anchor_text": "Leaking Tap And Toilet Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pipe Relining Services",
                                        "url": "https://www.jrburnsplumbing.com.au/pipe-relining-services-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/pipe-relining-services-inner-west/",
                                                "anchor_text": "Pipe Relining Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs And Installation",
                                        "url": "https://www.jrburnsplumbing.com.au/leaking-roof-repair-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/leaking-roof-repair-inner-west/",
                                                "anchor_text": "Roof Repairs And Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Water Leak Detection",
                                        "url": "https://www.jrburnsplumbing.com.au/water-leak-detection-services-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/water-leak-detection-services-inner-west/",
                                                "anchor_text": "Water Leak Detection"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strata Plumber",
                                        "url": "https://www.jrburnsplumbing.com.au/strata-plumber-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/strata-plumber-sydney/",
                                                "anchor_text": "Strata Plumber"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gas Hot Water",
                                        "url": "https://www.jrburnsplumbing.com.au/gas-hot-water-installation-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/gas-hot-water-installation-inner-west-sydney/",
                                                "anchor_text": "Gas Hot Water"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electric Hot Water",
                                        "url": "https://www.jrburnsplumbing.com.au/electric-hot-water-system-installation-and-repair-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/electric-hot-water-system-installation-and-repair-inner-west-sydney/",
                                                "anchor_text": "Electric Hot Water"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Plumbing",
                                        "url": "https://www.jrburnsplumbing.com.au/commercial-plumbing-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/commercial-plumbing-inner-west-sydney/",
                                                "anchor_text": "Commercial Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Residential Plumbing",
                                        "url": "https://www.jrburnsplumbing.com.au/residential-plumbing-services-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/residential-plumbing-services-inner-west/",
                                                "anchor_text": "Residential Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gas Plumbing",
                                        "url": "https://www.jrburnsplumbing.com.au/gas-plumbing-services-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/gas-plumbing-services-inner-west-sydney/",
                                                "anchor_text": "Gas Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "General Plumbing Services",
                                        "url": "https://www.jrburnsplumbing.com.au/general-plumbing-services-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/general-plumbing-services-inner-west-sydney/",
                                                "anchor_text": "General Plumbing Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gas Leak Detection",
                                        "url": "https://www.jrburnsplumbing.com.au/gas-leak-detection-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/gas-leak-detection-sydney/",
                                                "anchor_text": "Gas Leak Detection"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bathroom Plumbing",
                                        "url": "https://www.jrburnsplumbing.com.au/bathroom-plumbing-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/bathroom-plumbing-inner-west-sydney/",
                                                "anchor_text": "Bathroom Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Blocked Drains Plumbing",
                                        "url": "https://www.jrburnsplumbing.com.au/blocked-drains-plumber-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/blocked-drains-plumber-inner-west/",
                                                "anchor_text": "Blocked Drains Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Burst Water Pipe Repairs",
                                        "url": "https://www.jrburnsplumbing.com.au/burst-water-pipe-repair-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/burst-water-pipe-repair-inner-west/",
                                                "anchor_text": "Burst Water Pipe Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hot Water System Repairs",
                                        "url": "https://www.jrburnsplumbing.com.au/hot-water-plumber-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/hot-water-plumber-inner-west-sydney/",
                                                "anchor_text": "Hot Water System Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Tap And Toilet Repairs",
                                        "url": "https://www.jrburnsplumbing.com.au/leaking-tap-repair-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/leaking-tap-repair-inner-west/",
                                                "anchor_text": "Leaking Tap And Toilet Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pipe Relining Services",
                                        "url": "https://www.jrburnsplumbing.com.au/pipe-relining-services-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/pipe-relining-services-inner-west/",
                                                "anchor_text": "Pipe Relining Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs And Installation",
                                        "url": "https://www.jrburnsplumbing.com.au/leaking-roof-repair-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/leaking-roof-repair-inner-west/",
                                                "anchor_text": "Roof Repairs And Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Water Leak Detection",
                                        "url": "https://www.jrburnsplumbing.com.au/water-leak-detection-services-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/water-leak-detection-services-inner-west/",
                                                "anchor_text": "Water Leak Detection"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strata Plumber",
                                        "url": "https://www.jrburnsplumbing.com.au/strata-plumber-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/strata-plumber-sydney/",
                                                "anchor_text": "Strata Plumber"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gas Hot Water",
                                        "url": "https://www.jrburnsplumbing.com.au/gas-hot-water-installation-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/gas-hot-water-installation-inner-west-sydney/",
                                                "anchor_text": "Gas Hot Water"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electric Hot Water",
                                        "url": "https://www.jrburnsplumbing.com.au/electric-hot-water-system-installation-and-repair-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.jrburnsplumbing.com.au/electric-hot-water-system-installation-and-repair-inner-west-sydney/",
                                                "anchor_text": "Electric Hot Water"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Request A Free Quote",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Request A Free Quote",
                                        "url": "https://jrburnsplumbing.com.au/contact/",
                                        "urls": [
                                            {
                                                "url": "https://jrburnsplumbing.com.au/contact/",
                                                "anchor_text": "Request A Free Quote"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "We Are The Local Plumbers Near You",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Request A Free Consultation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Best Plumber Near Me In Canada Bay, Sydney NSW 2132 | With Over 20 Years of Experience in Providing Plumbing Services",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Your Local Emergency Plumber in Emergency Plumber Canada Bay",
                                "main_title": "Emergency Plumber Canada Bay",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Give us a call today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 18,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61297440964",
                                "+61290721165",
                                "%2002%209744%200964"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}