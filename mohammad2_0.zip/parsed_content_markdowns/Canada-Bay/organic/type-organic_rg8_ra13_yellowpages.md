{
    "id": "01190728-1132-0216-0000-dc7f04c67847",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0260 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/canada-bay-nsw-2046",
        "target": "www.yellowpages.com.au",
        "start_url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/canada-bay-nsw-2046",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Canada-Bay\\organic\\type-organic_rg8_ra13_yellowpages.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:31:49 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Canada Bay NSW",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration & Repairs Near Me",
                                    "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/nsw",
                                    "urls": [
                                        {
                                            "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/nsw",
                                            "anchor_text": "Roof Restoration & Repairs Near Me"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Slate Restoration Australia",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Concord, NSW 2137",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "WE STOP LEAKS, We guarantee our work\nFREE No-Obligation Quotes Metal/Slate/Tile/Glass/Slate/Stone\nRepair/Renewal/Cleaning/Restoration 30 Years Experience",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Slate Restoration Australia",
                                        "url": "https://www.yellowpages.com.au/nsw/concord/slate-restoration-australia-1000001937227-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/concord/slate-restoration-australia-1000001937227-listing.html",
                                                "anchor_text": "Slate Restoration Australia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open 24 hours",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0421 951 272",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What are the benefits of a roof restoration?",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The benefits from a roof restoration will depend on the type of roof you have. Some of the benefits of a metal roof restoration or roof repair include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Weatherproofing your home, making it safe in a storm and more secure in high winds",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Giving your home an updated and refreshed look",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of any sheets that are rusted beyond repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of rusty or lose nails",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Professional treatment of light rust",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Benefits of tile roof restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tiles are recoated, preventing them from becoming waterlogged in rainy seasons",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ridges are re-pointed which makes them safe in violent weather and high winds, dramatically reducing storm damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The quality of run-off water from your roof is improved. Here, the improved water quality in tank water is cleaner for other uses and applications.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Yellow, we\u2019re here to help. If you would like roof replacement services, get a quote by checking out our listings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "A Aadworkin' Roofer",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Marrickville, NSW 2204",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have been in business for over 30 years specializing in replacement of old roofs with Color bond.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: Roof Services",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A Aadworkin' Roofer",
                                        "url": "https://www.yellowpages.com.au/nsw/marrickville/a-aadworkin-roofer-14019955-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/marrickville/a-aadworkin-roofer-14019955-listing.html",
                                                "anchor_text": "A Aadworkin' Roofer"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9559 1616",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "106 Results for Roof Restorations Near You",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Five Dock, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aussie Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/five-dock/aussie-roofing-services-1000002965074-listing.html?isTopOfList=true&premiumProductId=400009942718",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/five-dock/aussie-roofing-services-1000002965074-listing.html?isTopOfList=true&premiumProductId=400009942718",
                                                "anchor_text": "Aussie Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Five Dock, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aussie Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/five-dock/aussie-roofing-services-1000002965074-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/five-dock/aussie-roofing-services-1000002965074-listing.html",
                                                "anchor_text": "Aussie Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Duravex Roofing Group - Dulux Acratex Registered roof Applicator",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Ryde, NSW 2112",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Duravex Roofing Group - Dulux Acratex Registered roof Applicator",
                                        "url": "https://www.yellowpages.com.au/nsw/ryde/duravex-roofing-group-dulux-acratex-registered-roof-applicator-1000002844390-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ryde/duravex-roofing-group-dulux-acratex-registered-roof-applicator-1000002844390-listing.html",
                                                "anchor_text": "Duravex Roofing Group - Dulux Acratex  Registered roof Applicator"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "DJ Daisley & Sons",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Marrickville, NSW 2204",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "DJ Daisley & Sons",
                                        "url": "https://www.yellowpages.com.au/nsw/marrickville/dj-daisley-sons-12815220-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/marrickville/dj-daisley-sons-12815220-listing.html",
                                                "anchor_text": "DJ Daisley & Sons"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Sydney, NSW 2000",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aussie Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/sydney/aussie-roofing-services-1000002964917-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/sydney/aussie-roofing-services-1000002964917-listing.html",
                                                "anchor_text": "Aussie Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Andris Metal Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, East Ryde, NSW 2113",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Andris Metal Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/east-ryde/andris-metal-roofing-13784649-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/east-ryde/andris-metal-roofing-13784649-listing.html",
                                                "anchor_text": "Andris Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Plumbing Expert",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Homebush, NSW 2140",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Plumbing Expert",
                                        "url": "https://www.yellowpages.com.au/nsw/homebush/roof-plumbing-expert-1000002286583-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/homebush/roof-plumbing-expert-1000002286583-listing.html",
                                                "anchor_text": "Roof Plumbing Expert"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "89 Parramatta Rd, Homebush, NSW, 2140",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=89+Parramatta+Rd&context=undefined&directionMode=true&elat=-33.864424&elon=151.08425&ena=Roof+Plumbing+Expert&estr=89+Parramatta+Rd&esu=Homebush%2C+NSW%2C+2140&productVersion=1&productId=1000002286583&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRoof+Plumbing+Expert%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.864424%26lon%3D151.08425%26selectedViewMode%3Dlist&yellowId=1000002286583",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=89+Parramatta+Rd&context=undefined&directionMode=true&elat=-33.864424&elon=151.08425&ena=Roof+Plumbing+Expert&estr=89+Parramatta+Rd&esu=Homebush%2C+NSW%2C+2140&productVersion=1&productId=1000002286583&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DRoof+Plumbing+Expert%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.864424%26lon%3D151.08425%26selectedViewMode%3Dlist&yellowId=1000002286583",
                                                "anchor_text": "89 Parramatta Rd, Homebush, NSW, 2140"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0416 224 505",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Featured reviews",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Handy tips",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "A-Grade Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Ashfield, NSW 2131",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A-Grade Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/ashfield/a-grade-roofing-12820683-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ashfield/a-grade-roofing-12820683-listing.html",
                                                "anchor_text": "A-Grade Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 7:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0430 070 149",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Roofing Services",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Croydon, NSW 2132",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Roofing Services",
                                        "url": "https://www.yellowpages.com.au/sup/all-roofing-services-1000002286940-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/all-roofing-services-1000002286940-listing.html",
                                                "anchor_text": "All Roofing Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 8086 2059",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Newtown Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Cabarita, NSW 2137",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Newtown Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/cabarita/newtown-roofing-15609661-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/cabarita/newtown-roofing-15609661-listing.html",
                                                "anchor_text": "Newtown Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open by appt",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0427 121 800",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Elite Metal Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Canada Bay, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Elite Metal Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/canada-bay/elite-metal-roofing-14051122-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/canada-bay/elite-metal-roofing-14051122-listing.html",
                                                "anchor_text": "Elite Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0415 580 507",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Metal P/L",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Five Dock, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Metal P/L",
                                        "url": "https://www.yellowpages.com.au/nsw/five-dock/all-metal-p-l-12043144-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/five-dock/all-metal-p-l-12043144-listing.html",
                                                "anchor_text": "All Metal P/L"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0407 153 504",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Factor 1 Roofing And Guttering",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Abbotsford, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Factor 1 Roofing And Guttering",
                                        "url": "https://www.yellowpages.com.au/nsw/abbotsford/factor-1-roofing-and-guttering-15258391-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/abbotsford/factor-1-roofing-and-guttering-15258391-listing.html",
                                                "anchor_text": "Factor 1 Roofing And Guttering"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0424 495 172",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Roofing Services",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Cabarita, NSW 2137",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/cabarita/all-roofing-services-12980108-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/cabarita/all-roofing-services-12980108-listing.html",
                                                "anchor_text": "All Roofing Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 8086 2059",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "MBS Roof Pty Ltd",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Strathfield, NSW 2135",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "MBS Roof Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/strathfield/mbs-roof-pty-ltd-14206277-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/strathfield/mbs-roof-pty-ltd-14206277-listing.html",
                                                "anchor_text": "MBS Roof Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open by appt",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Unit 9 43-45 Mosely St, Strathfield, NSW, 2135",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Unit+9+43-45+Mosely+St&context=undefined&directionMode=true&elat=-33.869757&elon=151.094959&ena=MBS+Roof+Pty+Ltd&estr=Unit+9+43-45+Mosely+St&esu=Strathfield%2C+NSW%2C+2135&productVersion=6&productId=999015405373&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMBS+Roof+Pty+Ltd%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.869757%26lon%3D151.094959%26selectedViewMode%3Dlist&yellowId=14206277",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=Unit+9+43-45+Mosely+St&context=undefined&directionMode=true&elat=-33.869757&elon=151.094959&ena=MBS+Roof+Pty+Ltd&estr=Unit+9+43-45+Mosely+St&esu=Strathfield%2C+NSW%2C+2135&productVersion=6&productId=999015405373&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMBS+Roof+Pty+Ltd%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.869757%26lon%3D151.094959%26selectedViewMode%3Dlist&yellowId=14206277",
                                                "anchor_text": "Unit 9 43-45 Mosely St, Strathfield, NSW, 2135"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 8005 5871",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Auscity Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Five Dock, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Auscity Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/five-dock/auscity-roofing-1000002862535-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/five-dock/auscity-roofing-1000002862535-listing.html",
                                                "anchor_text": "Auscity Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "10 Kings Park Cct, Five Dock, NSW, 2046",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=10+Kings+Park+Cct&context=undefined&directionMode=true&elat=-33.867202&elon=151.120087&ena=Auscity+Roofing&estr=10+Kings+Park+Cct&esu=Five+Dock%2C+NSW%2C+2046&productVersion=1&productId=1000002862535&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DAuscity+Roofing%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.867202%26lon%3D151.120087%26selectedViewMode%3Dlist&yellowId=1000002862535",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=10+Kings+Park+Cct&context=undefined&directionMode=true&elat=-33.867202&elon=151.120087&ena=Auscity+Roofing&estr=10+Kings+Park+Cct&esu=Five+Dock%2C+NSW%2C+2046&productVersion=1&productId=1000002862535&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DAuscity+Roofing%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.867202%26lon%3D151.120087%26selectedViewMode%3Dlist&yellowId=1000002862535",
                                                "anchor_text": "10 Kings Park Cct, Five Dock, NSW, 2046"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0432 466 466",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "R R B Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Five Dock, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "R R B Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/five-dock/r-r-b-roofing-12462072-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/five-dock/r-r-b-roofing-12462072-listing.html",
                                                "anchor_text": "R R B Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0412 962 526",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Daisley D J &amp Sons Pty Ltd",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Ashfield, NSW 2131",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Daisley D J &amp Sons Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/ashfield/daisley-d-j-amp-sons-pty-ltd-1000001762464-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ashfield/daisley-d-j-amp-sons-pty-ltd-1000001762464-listing.html",
                                                "anchor_text": "Daisley D J &amp Sons Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "162 Parramatta Rd, Ashfield, NSW, 2131",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=162+Parramatta+Rd&context=undefined&directionMode=true&elat=-33.883498&elon=151.133667&ena=Daisley+D+J+%26amp+Sons+Pty+Ltd&estr=162+Parramatta+Rd&esu=Ashfield%2C+NSW%2C+2131&productVersion=1&productId=1000001762464&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DDaisley+D+J+%26amp+Sons+Pty+Ltd%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.883498%26lon%3D151.133667%26selectedViewMode%3Dlist&yellowId=1000001762464",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=162+Parramatta+Rd&context=undefined&directionMode=true&elat=-33.883498&elon=151.133667&ena=Daisley+D+J+%26amp+Sons+Pty+Ltd&estr=162+Parramatta+Rd&esu=Ashfield%2C+NSW%2C+2131&productVersion=1&productId=1000001762464&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DDaisley+D+J+%26amp+Sons+Pty+Ltd%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.883498%26lon%3D151.133667%26selectedViewMode%3Dlist&yellowId=1000001762464",
                                                "anchor_text": "162 Parramatta Rd, Ashfield, NSW, 2131"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9799 2158",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Nep Star Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Strathfield, NSW 2135",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Nep Star Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/strathfield/nep-star-roofing-1000002938278-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/strathfield/nep-star-roofing-1000002938278-listing.html",
                                                "anchor_text": "Nep Star Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "11 Beresford Rd, Strathfield, NSW, 2135",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=11+Beresford+Rd&context=undefined&directionMode=true&elat=-33.869697&elon=151.088759&ena=Nep+Star+Roofing&estr=11+Beresford+Rd&esu=Strathfield%2C+NSW%2C+2135&productVersion=1&productId=1000002938278&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DNep+Star+Roofing%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.869697%26lon%3D151.088759%26selectedViewMode%3Dlist&yellowId=1000002938278",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=11+Beresford+Rd&context=undefined&directionMode=true&elat=-33.869697&elon=151.088759&ena=Nep+Star+Roofing&estr=11+Beresford+Rd&esu=Strathfield%2C+NSW%2C+2135&productVersion=1&productId=1000002938278&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DNep+Star+Roofing%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.869697%26lon%3D151.088759%26selectedViewMode%3Dlist&yellowId=1000002938278",
                                                "anchor_text": "11 Beresford Rd, Strathfield, NSW, 2135"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0450 076 923",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Deck Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Lidcombe, NSW 2141",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Deck Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/lidcombe/metal-deck-roofing-13192031-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/lidcombe/metal-deck-roofing-13192031-listing.html",
                                                "anchor_text": "Metal Deck Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 4:30pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "2/ 9 Parramatta Rd, Lidcombe, NSW, 2141",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=2%252F+9+Parramatta+Rd&context=undefined&directionMode=true&elat=-33.84973&elon=151.05265&ena=Metal+Deck+Roofing&estr=2%2F+9+Parramatta+Rd&esu=Lidcombe%2C+NSW%2C+2141&productVersion=5&productId=474053220&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMetal+Deck+Roofing%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.84973%26lon%3D151.05265%26selectedViewMode%3Dlist&yellowId=13192031",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=2%252F+9+Parramatta+Rd&context=undefined&directionMode=true&elat=-33.84973&elon=151.05265&ena=Metal+Deck+Roofing&estr=2%2F+9+Parramatta+Rd&esu=Lidcombe%2C+NSW%2C+2141&productVersion=5&productId=474053220&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DMetal+Deck+Roofing%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.84973%26lon%3D151.05265%26selectedViewMode%3Dlist&yellowId=13192031",
                                                "anchor_text": "2/ 9 Parramatta Rd, Lidcombe, NSW, 2141"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9648 4811",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "G-Force Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Stanmore, NSW 2048",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: Excellent workmanship",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "G-Force Roofing",
                                        "url": "https://www.yellowpages.com.au/sup/g-force-roofing-12957820-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/g-force-roofing-12957820-listing.html",
                                                "anchor_text": "G-Force Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 4:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9799 0065",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "A & A Dynamic Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Ryde, NSW 2112",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A & A Dynamic Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/ryde/a-a-dynamic-roofing-14099176-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ryde/a-a-dynamic-roofing-14099176-listing.html",
                                                "anchor_text": "A & A Dynamic Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open by appt",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: 161215C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0414 707 561",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "CPR Roofing Pty Ltd",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Gladesville, NSW 2111",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: License. No.132359C",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "CPR Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/gladesville/cpr-roofing-pty-ltd-1000002337370-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/gladesville/cpr-roofing-pty-ltd-1000002337370-listing.html",
                                                "anchor_text": "CPR Roofing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0418 677 188",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Project One Contracting",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Lewisham, NSW 2049",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Project One Contracting",
                                        "url": "https://www.yellowpages.com.au/nsw/lewisham/project-one-contracting-13934959-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/lewisham/project-one-contracting-13934959-listing.html",
                                                "anchor_text": "Project One Contracting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "798 Parramatta Rd, Lewisham, NSW, 2049",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=798+Parramatta+Rd&context=undefined&directionMode=true&elat=-33.890244&elon=151.146613&ena=Project+One+Contracting&estr=798+Parramatta+Rd&esu=Lewisham%2C+NSW%2C+2049&productVersion=5&productId=999015215240&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DProject+One+Contracting%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.890244%26lon%3D151.146613%26selectedViewMode%3Dlist&yellowId=13934959",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=798+Parramatta+Rd&context=undefined&directionMode=true&elat=-33.890244&elon=151.146613&ena=Project+One+Contracting&estr=798+Parramatta+Rd&esu=Lewisham%2C+NSW%2C+2049&productVersion=5&productId=999015215240&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DProject+One+Contracting%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.890244%26lon%3D151.146613%26selectedViewMode%3Dlist&yellowId=13934959",
                                                "anchor_text": "798 Parramatta Rd, Lewisham, NSW, 2049"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1800 556 137",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "HDR Roofing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Ryde, NSW 2112",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "HDR Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/ryde/hdr-roofing-1000002295057-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ryde/hdr-roofing-1000002295057-listing.html",
                                                "anchor_text": "HDR Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0452 622 393",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Paramount Roof Restoration",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Hunters Hill, NSW 2110",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Paramount Roof Restoration",
                                        "url": "https://www.yellowpages.com.au/sup/paramount-roof-restoration-15367892-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/paramount-roof-restoration-15367892-listing.html",
                                                "anchor_text": "Paramount Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0418 204 042",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "C.M.S. Roofing Pty Ltd",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Rozelle, NSW 2039",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "C.M.S. Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/rozelle/cms-roofing-pty-ltd-12190702-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/rozelle/cms-roofing-pty-ltd-12190702-listing.html",
                                                "anchor_text": "C.M.S. Roofing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "26C Mansfield St, Rozelle, NSW, 2039",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=26C+Mansfield+St&context=undefined&directionMode=true&elat=-33.864499&elon=151.178715&ena=C.M.S.+Roofing+Pty+Ltd&estr=26C+Mansfield+St&esu=Rozelle%2C+NSW%2C+2039&productVersion=4&productId=999999075911&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DC.M.S.+Roofing+Pty+Ltd%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.864499%26lon%3D151.178715%26selectedViewMode%3Dlist&yellowId=12190702",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=26C+Mansfield+St&context=undefined&directionMode=true&elat=-33.864499&elon=151.178715&ena=C.M.S.+Roofing+Pty+Ltd&estr=26C+Mansfield+St&esu=Rozelle%2C+NSW%2C+2039&productVersion=4&productId=999999075911&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DC.M.S.+Roofing+Pty+Ltd%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.864499%26lon%3D151.178715%26selectedViewMode%3Dlist&yellowId=12190702",
                                                "anchor_text": "26C Mansfield St, Rozelle, NSW, 2039"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9555 8944",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Global Roofing Services",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Leichhardt, NSW 2040",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Global Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/leichhardt/global-roofing-services-14560861-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/leichhardt/global-roofing-services-14560861-listing.html",
                                                "anchor_text": "Global Roofing Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1C Athol St, Leichhardt, NSW, 2040",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=1C+Athol+St&context=undefined&directionMode=true&elat=-33.87808&elon=151.149576&ena=Global+Roofing+Services&estr=1C+Athol+St&esu=Leichhardt%2C+NSW%2C+2040&productVersion=3&productId=999015539203&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGlobal+Roofing+Services%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.87808%26lon%3D151.149576%26selectedViewMode%3Dlist&yellowId=14560861",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=1C+Athol+St&context=undefined&directionMode=true&elat=-33.87808&elon=151.149576&ena=Global+Roofing+Services&estr=1C+Athol+St&esu=Leichhardt%2C+NSW%2C+2040&productVersion=3&productId=999015539203&ref=ypgd&referredBy=undefined&str=Canada+Bay%2C+NSW+2046&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGlobal+Roofing+Services%26locationClue%3DCanada+Bay%2C+NSW+2046%26lat%3D-33.87808%26lon%3D151.149576%26selectedViewMode%3Dlist&yellowId=14560861",
                                                "anchor_text": "1C Athol St, Leichhardt, NSW, 2040"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1300 762 067",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Project One Contracting",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Leichhardt, NSW 2040",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Project One Contracting",
                                        "url": "https://www.yellowpages.com.au/nsw/leichhardt/project-one-contracting-14683741-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/leichhardt/project-one-contracting-14683741-listing.html",
                                                "anchor_text": "Project One Contracting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9560 6274",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Alpha Plumbing NSW",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Ryde, NSW 2112",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Alpha Plumbing NSW",
                                        "url": "https://www.yellowpages.com.au/nsw/ryde/alpha-plumbing-nsw-14009017-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ryde/alpha-plumbing-nsw-14009017-listing.html",
                                                "anchor_text": "Alpha Plumbing NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9126 9343",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "A.S.A.P Roof Plumbing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Leichhardt, NSW 2040",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A.S.A.P Roof Plumbing",
                                        "url": "https://www.yellowpages.com.au/nsw/leichhardt/asap-roof-plumbing-12308603-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/leichhardt/asap-roof-plumbing-12308603-listing.html",
                                                "anchor_text": "A.S.A.P Roof Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0405 613 213",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "The Roofing Professionals Northside",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Artarmon, NSW 2064",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "The Roofing Professionals Northside",
                                        "url": "https://www.yellowpages.com.au/nsw/artarmon/the-roofing-professionals-northside-1000002154140-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/artarmon/the-roofing-professionals-northside-1000002154140-listing.html",
                                                "anchor_text": "The Roofing Professionals Northside"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 7:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0432 286 448",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Bulli Roof Restorations",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Marrickville, NSW 2204",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Bulli Roof Restorations",
                                        "url": "https://www.yellowpages.com.au/nsw/marrickville/bulli-roof-restorations-1000002086797-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/marrickville/bulli-roof-restorations-1000002086797-listing.html",
                                                "anchor_text": "Bulli Roof Restorations"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open by appt",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Rheem",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Rydalmere, NSW 2116",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Rheem",
                                        "url": "https://www.yellowpages.com.au/sup/rheem-15745982-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/rheem-15745982-listing.html",
                                                "anchor_text": "Rheem"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(03) 9556 5560",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Average rating for Roof Restoration & Repairs in Canada Bay and surrounding suburbs",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Based on 767 reviews of 160 businesses on this page",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Articles",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Nearby Locations for Roof Restorations",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular Categories in Canada Bay",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Categories in Canada Bay",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Gutter & Roof Restoration",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Warning, Not All Roof Companies Are The Same",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Slaters & Roof Tilers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 654 884",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Guttering & Spouting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Regent Skylights",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Factory Direct Skylights, Energy Efficient Patented Press & Flashings",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(07) 3274 3344",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Eco Wool Insulation Services",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Insulation Installers & Contractors",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0481 845 529",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Gutter & Roof Restoration",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Warning, Not All Roof Companies Are The Same",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Guttering & Spouting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 654 884",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "A Class Plumbing",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Reliable, Professional Industrial & Commercial Specialists",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9630 4227",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Related Articles",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our directory.",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Yellow Pages",
                                        "url": "https://www.yellowpages.com.au/pages/about-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/about-us",
                                                "anchor_text": "About Yellow Pages"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://www.yellowpages.com.au/pages/contact-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/contact-us",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Site Index",
                                        "url": "https://www.yellowpages.com.au/sitemap",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sitemap",
                                                "anchor_text": "Site Index"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Order or cancel your book",
                                        "url": "https://www.directoryselect.com.au/action/home",
                                        "urls": [
                                            {
                                                "url": "https://www.directoryselect.com.au/action/home",
                                                "anchor_text": "Order or cancel your book"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our advertising.",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Get a free listing",
                                        "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                                "anchor_text": "Get a free listing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Digital marketing solutions",
                                        "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                                "anchor_text": "Digital marketing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Business hub",
                                        "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                                "anchor_text": "Business hub"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "myYellow login",
                                        "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                                "anchor_text": "myYellow login"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Connect with us.",
                                "main_title": "35 BEST local Roof Restorations in Canada Bay NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Thryv Australia",
                                        "url": "https://corporate.thryv.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/",
                                                "anchor_text": "About Thryv Australia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://corporate.thryv.com/privacy/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com/privacy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://corporate.thryv.com.au/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.2,
                                "max_rating_value": 5,
                                "rating_count": 767,
                                "relative_rating": 0.8400000000000001
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0485 800 063",
                                "1300 492 880",
                                "(02) 9798 7075",
                                "(02) 9888 9672",
                                "0421 951 272",
                                "0416 224 505",
                                "0430 070 149",
                                "(02) 8086 2059",
                                "0427 121 800",
                                "0415 580 507",
                                "0407 153 504",
                                "0424 495 172",
                                "(02) 8005 5871",
                                "0432 466 466",
                                "0412 962 526",
                                "(02) 9799 2158",
                                "0450 076 923",
                                "(02) 9648 4811",
                                "(02) 9799 0065",
                                "0414 707 561",
                                "0418 677 188",
                                "1800 556 137",
                                "0452 622 393",
                                "0418 204 042",
                                "(02) 9555 8944",
                                "1300 762 067",
                                "(02) 9560 6274",
                                "(02) 9126 9343",
                                "0405 613 213",
                                "(02) 9559 1616",
                                "0432 286 448",
                                "none",
                                "(03) 9556 5560",
                                "0421951272",
                                "0416224505",
                                "0430070149",
                                "0280862059",
                                "0427121800",
                                "0415580507",
                                "0407153504",
                                "0424495172",
                                "0280055871",
                                "0432466466",
                                "0412962526",
                                "0297992158",
                                "0450076923",
                                "0296484811",
                                "0297990065",
                                "0414707561",
                                "0418677188",
                                "1800556137",
                                "0452622393",
                                "0418204042",
                                "0295558944",
                                "1300762067",
                                "0295606274",
                                "0291269343",
                                "0405613213",
                                "0295591616",
                                "0432286448",
                                "0395565560",
                                "1300654884",
                                "1300556541",
                                "0732743344",
                                "0481845529",
                                "0296304227"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}