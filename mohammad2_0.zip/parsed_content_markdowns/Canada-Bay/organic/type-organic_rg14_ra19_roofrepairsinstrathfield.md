{
    "id": "01190728-1132-0216-0000-82576614c63f",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0183 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrepairsinstrathfield.com.au/in/canada-bay/",
        "target": "roofrepairsinstrathfield.com.au",
        "start_url": "https://roofrepairsinstrathfield.com.au/in/canada-bay/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Canada-Bay\\organic\\type-organic_rg14_ra19_roofrepairsinstrathfield.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:39 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "We Take Care Of Your Roof",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Canada Bay is a lovely city, and you deserve the very best roof for your home or business. However, severe climate condition can be harsh on your roof and cause it to degrade over time. Whether you need a new roof or repairs for an existing one, Roofing Today Canada Bay is here to help you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With years of experience in repair and installation, our team of certified experts are specialists in doing the job right the first time. We provide a vast array of services to guarantee your roof is safe and protected. From small repairs, such as replacing tiles or repairing leaks, to more involved tasks, like complete replacements or re-roofing, our specialists will work with you to help identify the very best solution for your property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We understand the significance of having a reliable and secure roof over your head, which is why we aim to provide quality workmanship and remarkable client service. Our team of knowledgeable experts takes pride in their work and utilizes only the first-rate products for all our tasks. We are also delighted to talk about any special requests or questions you may have and provide valuable guidance throughout the process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter what kind of roofing needs you have, Roofing Today Canada Bay is here to help. Contact our team today, and let us be the ones to fix your roof!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Colorbond roofing is a popular option for both residential and industrial properties. Our team of knowledgeable experts is trained in the installation of colorbond roofing and uses the first-rate products to guarantee your roof looks its best.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing Contractors Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Whether you need a complete replacement or repairs for an existing roof, our team of certified experts can help. We understand that a minor interruption in company can be pricey. We work around your schedule to decrease downtime, that includes weekends and/or nights if needed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing Contractors Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We understand that emergency situations can happen anytime and require quick action to decrease damage. Our team of knowledgeable experts is available 24/7 to provide fast and reliable emergency roof repair services. From small repairs to more extensive work, we can be depended on to finish the job right.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Emergency Roof Repairs Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Canada Bay Roof and Gutter",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Regular maintenance of your roof and gutter is vital in guaranteeing that it stays in good condition. Our team of trained experts offers various services, such as cleaning and repairs, to keep your gutters working effectively and help prolong the life of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Canada Bay Roof and Gutter",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Canada Bay Roof and Gutter"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Let our team of certified experts help you evaluate the condition of your roof. We\u2019ll provide an in-depth inspection to identify roof concerns and precisely recommend cost-effective options. We provide a comprehensive report of our findings, which can then be used to plan any necessary repairs or replacements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Inspections Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Roof Repairs Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Do not let a little leak become a larger problem. We utilize the most recent leak detection strategies to identify and repair any concerns properly. They consist of water tests, thermal imaging, and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Leaking Roof Repairs Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of experienced experts is can install all roofing materials, including metal roofs, slate roofs, solar roofs, tile roofs, and more. our company believe in quality workmanship and use only the first-rate products to guarantee your roof is strong and secure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Installation Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal roofs are becoming increasingly popular due to their toughness, low maintenance, and energy effectiveness. We handle various type of metal roofing, from corrugated to standing seam, and several color alternatives. Additionally, we can install soaker panels and other accessories for a more custom look.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of knowledgeable experts can provide a full roof replacement service if your roof is beyond repair. We\u2019ll help you pick the right product, size, and shape to match your residential or commercial property and spending plan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Canada Bay Roof Restoration",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roofing Today Canada Bay, our company believe in maintaining existing structures wherever possible rather than replacing them. We utilize the most recent products and strategies to extend the life of your roof while bearing in mind its historic worth and character.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Canada Bay Roof Restoration",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                                "anchor_text": "Canada Bay Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We provide various services for residential and industrial properties in Canada Bay, ranging from small repairs to full-scale installations. Whether it\u2019s metal or tile roofs, skylights, or solar panels\u2013 our knowledgeable team will provide quality services that satisfy your requirements and spending plan. We manage every little thing from start to finish and provide remarkable client service throughout the entire process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roofing/",
                                                "anchor_text": "Roofing Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Skylights Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Skylights are amongst the most popular attributes of a home, offering natural light and ventilation. Our team of certified experts can install residential and office skylights, from basic systems to custom designs. We also offer repair services, including replacing damaged seals and frames.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Skylights Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/skylights/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/skylights/",
                                                "anchor_text": "Skylights Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tilers Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Tiling is a specialized task that requires understanding, skill, and experience\u2013 all of which our team has in abundance. We provide installation and repairs for slate, terracotta, metal, concrete tiles, and all kinds of roof devices.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Tilers Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Repairs Canada Bay",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Slate roofs are a popular option for heritage homes due to their lasting toughness and classic look. We comprehend the significance of maintaining a building\u2019s original character and can help you with all your slate roof repair requirements. Our knowledgeable service technicians utilize only the first-rate products to restore your roof to its former magnificence.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Slate Roof Repairs Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Canada Bay\u200b",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We understand that some Canada Bay citizens may not be able to pay for a roof repair or installation. Given that our desire is to help everybody, we provide a special discount program for qualified Canada Bay citizens. With our Canada Bay Discount Roof Repair program, you can get the repairs or installations you need at a lower expense.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019re proud to be part of the Canada Bay community and do all we can to help our neighbors. It doesn\u2019t matter if you need a basic repair or a full roof replacement; our knowledgeable experts are here to help.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our 100% satisfaction guarantee backs every task we do. We back up all of our work and won\u2019t rest until you\u2019re totally delighted with the results. From when you first contact us to when we accomplish the task, you can depend on our team for remarkable service and workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A reliable and secure roof is one of the most essential investments in your life. That\u2019s why when it pertains to repair or installation, you can depend on the experts at Roofing Today Canada Bay for quality service and workmanship.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We proudly serve: Five Dock, Concord, Wareemba, Cabarita, Abbotsford, Burwood, Croydon, Chiswick, Russell Lea, Breakfast Point and Canada Bay",
                                        "url": "https://roofrepairsinstrathfield.com.au/in/five-dock/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/five-dock/",
                                                "anchor_text": "Five Dock"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/concord/",
                                                "anchor_text": "Concord"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/wareemba/",
                                                "anchor_text": "Wareemba"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/cabarita/",
                                                "anchor_text": "Cabarita"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/abbotsford/",
                                                "anchor_text": "Abbotsford"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/burwood/",
                                                "anchor_text": "Burwood"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/croydon/",
                                                "anchor_text": "Croydon"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/chiswick/",
                                                "anchor_text": "Chiswick"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/russell-lea/",
                                                "anchor_text": "Russell Lea"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/breakfast-point/",
                                                "anchor_text": "Breakfast Point"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Canada Bay\u200b",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We at Roofing Today Canada Bay are the roof experts! We can fix any type of roof from flat roofs to gabled roofs and everything in between. Contact us today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Are You Waiting For?",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A reliable and secure roof is one of the most important investments in your life. That\u2019s why when it comes to repair or installation, you can count on the professionals at Roofing Today Canada Bay for quality service and workmanship. Call us now!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Canada Bay\u200b",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Talk to us today about roofing services for your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "GET IN TOUCH",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repairs Canada Bay Services",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What we offer",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We provide a vast array of services, consisting of:",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Canada Bay Discount Roof Repair",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Canada Bay, New South Wales",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "For more information about Canada Bay, New South Wales",
                                        "url": "https://en.wikipedia.org/wiki/Canada%20Bay,_New%20South%20Wales",
                                        "urls": [
                                            {
                                                "url": "https://en.wikipedia.org/wiki/Canada%20Bay,_New%20South%20Wales",
                                                "anchor_text": "For more information about Canada Bay, New South Wales"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Google News:",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Latest Canada Bay News",
                                        "url": "https://news.google.com/search?q=Canada%20Bay,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                        "urls": [
                                            {
                                                "url": "https://news.google.com/search?q=Canada%20Bay,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                                "anchor_text": "Latest Canada Bay News"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Links",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Us",
                                        "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                                "anchor_text": "About Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our Services",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/",
                                                "anchor_text": "Our Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roofing Contractors",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof and Gutter",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Roof and Gutter"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof Repairs",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tilers",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slate Roof Repairs",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Info",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "ROOFING TODAY",
                                        "url": "https://maps.app.goo.gl/mouDDnPwo7U3eevt6",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/mouDDnPwo7U3eevt6",
                                                "anchor_text": "ROOFING TODAY\n1/19 Dick St,Henley NSW 2111\n(02) 8261 0051"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1/19 Dick St,",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Henley NSW 2111",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 8261 0051",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Email Us",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "[email\u00a0protected]",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "[email\u00a0protected]",
                                        "url": "https://roofrepairsinstrathfield.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "&copy 2022 Roofing Today Strathfield",
                                "main_title": "Roof Repairs Canada Bay\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "&copy 2022 Roofing Today Strathfield",
                                        "url": "https://roofrepairsinstrathfield.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/",
                                                "anchor_text": "Roofing Today Strathfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://roofrepairsinstrathfield.com.au/privacy-policy/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/privacy-policy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms & Conditions",
                                        "url": "https://roofrepairsinstrathfield.com.au/terms-and-conditions/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/terms-and-conditions/",
                                                "anchor_text": "Terms & Conditions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 8261 0051",
                                "(02)%208261%200051"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}