{
    "id": "01190728-1132-0216-0000-a7640052b078",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0320 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.oneflare.com.au/roofing/nsw/five-dock",
        "target": "www.oneflare.com.au",
        "start_url": "https://www.oneflare.com.au/roofing/nsw/five-dock",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Canada-Bay\\organic\\type-organic_rg16_ra21_oneflare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:32:49 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Best roofing experts in Five Dock",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Post a job now to get quotes from local roofing experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average rating of roofing experts in Five Dock based on 353 reviews of 36 businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oneflare /",
                                        "url": "https://www.oneflare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/",
                                                "anchor_text": "Oneflare"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Categories /",
                                        "url": "https://www.oneflare.com.au/directory",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/directory",
                                                "anchor_text": "Categories"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.oneflare.com.au/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NSW /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw",
                                                "anchor_text": "NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                                "anchor_text": "Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "24 hours Downward Chevron",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ua Roofing",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "South Hurstville, NSW (12.4km from South Hurstville)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We specialize in high-quality **metal and tile roofing** for homes and businesses. Our services include installation, repair, and maintenance using durable materials like colorbond, and clay/concrete tiles. We ensure weather resistance, energy efficiency, and long-lasting performance. Free estimates, skilled craftsmanship, and tailored solutions for every roof. Trust us for strength and style!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ua Roofing",
                                        "url": "https://www.oneflare.com.au/b/ua-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/ua-roofing",
                                                "anchor_text": "Ua Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Render My Home Pty Ltd",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Waterloo, NSW (8.1km from Waterloo)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Render My Home is your one-stop design and building service that Renovates, Rejuvenates and Restores your home facade. We only deal with quality products and systems from trusted suppliers. Render My Home are accredited and use products by Dulux and CSR.\nRender My Home \u2013 Exterior Fa\u00e7ade Home Improvement Specialists, can dramatically boost your home\u2019s value by transforming your home into a vibrant and intriguing reflection of your own personal style and individualism. For all small and large jobs, Render My Home specialises in restoring and rejuvenating your homes facade, by using renders, coatings, wall panels, paints, landscaping, tiling, balustrade upgrades, roof restorations, awnings and shutters to breathe new life into your home.\nThe Render My Home design team are",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Render My Home Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/render-my-home-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/render-my-home-pty-ltd",
                                                "anchor_text": "Render My Home Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Oracle Carpentry Sydney Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Chullora, NSW (8.0km from Chullora)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Established in 1995, Oracle roofing are well established, highly experienced, skilled, professional and extremely reliable providing the very best roofing services in the Sydney Metropolitan area.\nRoof repairs and maintenance is the top quality of our work. We specialise in roof leak detection and all roof maintenance services - including gutter and down pipe installation, gutter installation and cleaning, roof restoration, roof carpentry, roof painting and skylight installation. Our emphasis has been and always will be to provide top quality work and service at all times.\nWe are a team of 11 experienced professionals and able to service your needs at all times and provide quick and efficient service. We provide free site inspections, and at times, within hours of",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oracle Carpentry Sydney Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/sydney-home-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/sydney-home-services",
                                                "anchor_text": "Oracle Carpentry Sydney Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slide 1 of 27",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Plumbing Expert",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood, NSW (2.6km from Burwood)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are Professional Roofing Company Based on Whole around the Sydney.We are mutually trade ,hardworking ,fit,smart and young who pride to take care in my work and delivering a professional Australia standard result . I run a fully insured and licensed . We Offer Gutter Cleaning Gutter Guard Installation\nGutter Installation High Pressure Wash Roof and Drive way Rebedding and Pointing Installation Metal roof On and Off Roof Repair Fasical Board Replace and Paint Gyprock Installation\nRoof Restoration We will look Forward to work with You ..\nYours Regard Roof Plumbing Expert Group\nwww.roofplumbingexpert.com.au [email\u00a0protected] 0416224505",
                                        "url": "https://www.oneflare.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Plumbing Expert",
                                        "url": "https://www.oneflare.com.au/b/roof-plumbing-expert-50",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roof-plumbing-expert-50",
                                                "anchor_text": "Roof Plumbing Expert"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Flash Plumbing Services",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Concord, NSW (2.6km from Concord)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flash plumbing services specialise in New residential plumbing (free quote)\ndrain cleaning and drain maintenance and utilise our custom built vehicles fitted with the latest equipment available High Pressure water jet cleaner for all blocked drains and sewer problems\nPlumbing for kitchens and bathrooms Roof and guttering repairs and installation Gas Installation, maintenance and repairs Complete Bathroom renovations\nNew Residential Plumbing / Gas / Drainage\nC.C T.V diagnostic pipe camera Electronic underground pipe and cable locator Hot Water Systems New - Repairs\nBackflow Prevention inspections and testing\nThermostatic Mixing Valves Electronic Pipe Location and Leak Detection .",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Flash Plumbing Services",
                                        "url": "https://www.oneflare.com.au/b/flash-plumbing-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/flash-plumbing-services",
                                                "anchor_text": "Flash Plumbing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Roofing Services",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Croydon, NSW (1.9km from Croydon)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All Roofing Services has provided the Innerwest Sydney area with experienced, professional roof installation, repair maintenance advice and assessment, restoration and replacement for over 10 years. ARS specialise in Metal and Colorbond roof installation and replacement for residences and small businesses. We have expanded across Sydney with our Roof Replacements.\nAll Roofing Services also provide all aspects of services for roof plumbing and gutter installation, repair assessment and replacement and asbestos removal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Roofing Services",
                                        "url": "https://www.oneflare.com.au/b/all-roofing-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-roofing-services",
                                                "anchor_text": "All Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Care Roof Services",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield, NSW (2.4km from Ashfield)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All Care Roofing specialise in Roof Restoration and all roof maintenance work. Servicing all areas of Sydney we strive to provide top quality roof services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Care Roof Services",
                                        "url": "https://www.oneflare.com.au/b/all-care-roof-services-508",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-care-roof-services-508",
                                                "anchor_text": "All Care Roof Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Interstate Prestige Roofing",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Olympic Park, NSW (5.6km from Sydney Olympic Park)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All types of Roof maintenance we do! \u2022 Gutter Cleaning\n\u2022 Roof Repairs\n\u2022 Drive way Sealing\n\u2022 Roof Restorations\n\u2022 Roof Replacement\n\u2022 We specialise in, terracotta, concrete and Slate roof tiles.\n\u2022 7 Years Warranty\nEvery job is provided with warranty. Rain, hail or shine we are at your doorstep!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Interstate Prestige Roofing",
                                        "url": "https://www.oneflare.com.au/b/interstate-prestige-roofing-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/interstate-prestige-roofing-roofing",
                                                "anchor_text": "Interstate Prestige Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Complete Pest & Termite Solutions Pty Ltd",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Green Valley, NSW (24.5km from Green Valley)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Effective Pest Control Servicess\nFor Insects, Rodents, Birds & More\nWe\u2019re passionate about what we do and we always strive for absolute pest elimination on the properties we visit. When you work with us, you can rest assured that your home or site will be back to normal as soon as possible. It\u2019s always been our mission to provide affordable, comprehensive and effective pest control services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Complete Pest & Termite Solutions Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/complete-pest-and-termite-solution",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/complete-pest-and-termite-solution",
                                                "anchor_text": "Complete Pest & Termite Solutions Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "NGP Projects",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Randwick, NSW (11.6km from Randwick)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "New Generation Plus (NGP) is an established, multi-skilled Sydney based Building company in operation for over 17 years, with a focus on customer service, quality tradesmanship and the highest standard of excellence. We have extensive experience within the commercial, residential, retail, hospitality & healthcare sectors. With excellent management and coordination, we give every project 100% commitment and our project teams have a reputation for quality and efficiency. We have the capacity to integrate services from make good to complete product so we can have a greater control on the outcome of the project. We provide a free quotation service and offer extremely competitive rates whether on an hourly rate or square metre rate. Our trades are painter, plasterer including commercial",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "NGP Projects",
                                        "url": "https://www.oneflare.com.au/b/new-generation-plus",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/new-generation-plus",
                                                "anchor_text": "NGP Projects"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Allguard Roofing And Restoration Pty Ltd",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ryde, NSW (6.5km from Ryde)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully licensed and insured, we specialize in delivering top-quality roofing solutions tailored to your needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "we are your trusted local roofing experts in Sydney, proudly serving the community for over 25 years.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are one of Sydney\u2019s most trusted providers of roofing, painting, and guttering services. With years of experience in the industry, our reputation continues to grow through consistently delivering high-quality workmanship tailored to your needs. Our team of fully licensed professionals brings proven expertise in roof repairs, replacements, restorations, ongoing maintenance, complex gutter work, exterior painting, and a range of home improvement solutions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Allguard Roofing And Restoration Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/allguard-roofing-and-restoration-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/allguard-roofing-and-restoration-pty-ltd",
                                                "anchor_text": "Allguard Roofing And Restoration Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slide 1 of 2",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "D2plumbing",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Hunters Hill, NSW (4.4km from Hunters Hill)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "D2plumbing are a friendly fair priced company and are fully licenced and insured.\nwe are trained in all types of plumbing.\nTo see more about us check out our website on www.d2plumbing.com.au",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "D2plumbing",
                                        "url": "https://www.oneflare.com.au/b/d2plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/d2plumbing",
                                                "anchor_text": "D2plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ozroof Roof Repairs & Restorations",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (7.5km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OZROOF specialise in Roof Restoration, Roof Repairs, Roof Painting, Metal Roofing and Guttering Replacement - Sydney Wide\nOZROOF Repairs & Restoration provide homeowners with high quality roofing services including roof restoration, roof repairs, roof painting, metal roofing and guttering replacement throughout Sydney and surrounding suburbs. Family owned and operated, we are dedicated to delivering exceptional quality to every task undertaken, regardless of the size of the project. All work is carried out by our own tradesmen and we certainly don't appoint flashy, commission based salesmen. This allows us to maintain lower overheads, in-turn keeping our prices affordable and competitive!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ozroof Roof Repairs & Restorations",
                                        "url": "https://www.oneflare.com.au/b/21st-roofing-guttering-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/21st-roofing-guttering-pty-ltd",
                                                "anchor_text": "Ozroof Roof Repairs & Restorations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pitched Roofing",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Five Dock, NSW 0",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a Family Based Roofing Business servicing all over Sydney based in Five Dock NSW.We have been in the Roofing Industry for 35 yrs.We specialise in all aspects of Roofing Slate,Tiles & Metal Roofing, also Guttering & Downpipes, Leaf guard, Gutter Cleaning Re -Roofs No Job Is Too Big Or To Small.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pitched Roofing",
                                        "url": "https://www.oneflare.com.au/b/pitched-roofing-432",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/pitched-roofing-432",
                                                "anchor_text": "Pitched Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Orb It Roofing",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Marrickville, NSW (5.4km from Marrickville)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Orb It Roofing are skilled, professional and extremely reliable providing the very best roofing services. Metal Roofing - Reroofing - All Repairs & Guttering - Call Now Orb It Roofing provides Sydneys domestic and commercial properties with a reliable Metal roofing, roofing repair and re-roofing service. Services include; Metal Roofing Re-Roofs Leak Repairs Roof Repairs New Work Guttering Downpipes Tile and Slate Repairs 100% committed to the highest standard of workmanship, prompt, reliable, unrivalled service! Call Now for a Free Quote!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Orb It Roofing",
                                        "url": "https://www.oneflare.com.au/b/orb-it-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/orb-it-roofing",
                                                "anchor_text": "Orb It Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Strong Shield Roofing",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Mount Lewis, NSW (9.3km from Mount Lewis)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are dedicated roofing professionals committed to delivering high-quality workmanship on every project, regardless of size or complexity. Our focus is on precision, durability, and long-term performance. You can trust us with your roof, as we take pride in providing reliable, compliant solutions\u2014because strong homes require strong roofs, and that is exactly what we deliver",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Strong Shield Roofing",
                                        "url": "https://www.oneflare.com.au/b/strong-shield-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/strong-shield-roofing",
                                                "anchor_text": "Strong Shield Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aus Topline Roofing",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "South Granville, NSW (11.0km from South Granville)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Aus Topline Roofing is owned and operated by Gaz who is a Licensed Tradie with over 7 years industry experience.\nOur aim is to provide professional, quality service at affordable prices. Over 7 years experience in the Roofing and Guttering industry. I guarantee to provide the best customer service to all my customers and in the past 7 years! Our clients are our number one priority, and we will go the extra mile to make sure they're completely satisfied with the work. Contact me today for a free quote and inquiry!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aus Topline Roofing",
                                        "url": "https://www.oneflare.com.au/b/austopline-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/austopline-roofing",
                                                "anchor_text": "Aus Topline Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Spartan Roofing And Guttering Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Strathfield, NSW (3.2km from Strathfield)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Spartan Roofing, we take pride in providing reliable, high-quality roofing services for homes and businesses across Sydney. As a local tradie, I\u2019m committed to delivering honest workmanship, clear communication, and solutions that are tailored to each customer\u2019s needs. Whether you need roof repairs, storm-damage restoration, guttering work, or a full roof replacement, you can count on me to get the job done properly. I combine years of hands-on experience with a genuine dedication to customer satisfaction, ensuring every project is completed safely, efficiently, and to the highest standard.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Spartan Roofing And Guttering Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/spartan-roofing-and-guttering-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/spartan-roofing-and-guttering-pty-ltd",
                                                "anchor_text": "Spartan Roofing And Guttering Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get the right price for your job",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Oneflare Cost Guide Centre is your one-stop shop to help you set your budget; from smaller tasks to larger projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Top Five Dock roofing experts near you",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Browse top Roofing Expert experts with top ratings and reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Elizabeth's review for a Roofing job in St Clair",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Lovely guys, done a great job well worth the money",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best roofing experts in Five Dock",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "View more roofing experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Truss costs",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Truss costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Roof Truss costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $9,000 - $15,000",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Average price $9,000 - $15,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof costs",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roof costs",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Colorbond Roof costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $15,000 - $25,000",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Average price $15,000 - $25,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling costs",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Roof Tiling costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $35 - $140 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Average price $35 - $140 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing costs",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing costs",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Roofing costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $45 - $90 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Average price $45 - $90 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse roofing experts by suburb",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular searches on Oneflare",
                                "main_title": "Best roofing experts in Five Dock",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.8,
                                "max_rating_value": 5,
                                "rating_count": 353,
                                "relative_rating": 0.96
                            }
                        ],
                        "offers": null,
                        "comments": [
                            {
                                "rating": null,
                                "title": null,
                                "publish_date": null,
                                "author": "Elizabeth Macdonald",
                                "primary_content": [
                                    {
                                        "text": "Lovely guys, done a great job well worth the money ",
                                        "url": null,
                                        "urls": null
                                    }
                                ]
                            }
                        ],
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}