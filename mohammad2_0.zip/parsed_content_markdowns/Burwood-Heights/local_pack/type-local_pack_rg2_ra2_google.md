# Type: local_pack | Rank: 2 | RG: 2
### Raw Row Data:
{
    "rank_group": "2",
    "rank_absolute": "2",
    "service": "roofer",
    "suburb": "Burwood Heights",
    "title": "All Roofing Services Pty Ltd",
    "domain": "www.google.com",
    "url": "https://www.google.com/viewer/place?sca_esv=ed956a20e7b48028&hl=en&gl=AU&output=search&mid=/g/1tcxz_1z&pip=CgZyb29mZXIQAg%3D%3D",
    "description": "Closed",
    "type": "local_pack"
}