# Type: people_also_ask | Rank: 10 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "10",
    "service": "roofer",
    "suburb": "Burwood Heights",
    "title": "",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_ask"
}