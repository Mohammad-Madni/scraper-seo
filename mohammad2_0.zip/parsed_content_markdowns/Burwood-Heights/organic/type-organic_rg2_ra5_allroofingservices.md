{
    "id": "01190728-1132-0216-0000-4234778a1b2e",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0328 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.allroofingservices.com.au/burwood-heights/",
        "target": "www.allroofingservices.com.au",
        "start_url": "https://www.allroofingservices.com.au/burwood-heights/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-Heights\\organic\\type-organic_rg2_ra5_allroofingservices.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:30:30 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "ARS are local roofing contractors owned and operated by Julian Dirou. Julian is a very experienced and licensed metal roof plumber who believes in doing things properly the first time, without short cuts and never compromising on quality.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright \u00a9 2026 All Roofing Services",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "On Time And On Budget.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "We Never Compromise On Quality.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Fully Insured And Licensed.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "A Great Team Of Experienced, Friendly & Competent Roofers.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Free Inspections, Consultations And Quotes.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Voted Top Roofing Business For 3 Years.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "618 Parramatta Road,",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Croydon NSW 2132 Australia",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Office: 02 8086 2059",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mobile: 0406 969 061",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "info@allroofingservices. com.au",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Website by Nasyana Marketing",
                                    "url": "https://www.nasyana.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://www.nasyana.com.au/",
                                            "anchor_text": "Nasyana Marketing"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roofing Services\nin Burwood Heights",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We Provide Superior Roofing Services for Homes and Businesses",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Reputable Roofing Specialist Burwood Heights",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Need roofing services in Burwood Heights? All Roofing Services has over 20 years of experience in providing roofing services at a competitive price.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether you need roof maintenance, roof replacement, residential roofing or roof plumbing services, All Roofing Services is the most reliable company you should work with. We also offer fast and high-quality roof restoration services in Burwood Heights.",
                                        "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                                "anchor_text": "roof maintenance"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                                "anchor_text": "roof replacement"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                                "anchor_text": "roof plumbing"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/roof-restoration/",
                                                "anchor_text": "roof restoration"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing Services\u200b Burwood Heights",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Transforming Sydney roofs to enhance the safety, durability, and aesthetic appeal",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At All Roofing Services, we specialize in transforming roofs to enhance the safety, durability, and aesthetic appeal of your home or business. Our expert team handles a wide range of roof types, including terracotta, concrete tile, metal, asbestos, and more. Whether you need a complete roof replacement or a minor repair, our Roofing Replacement service ensures a high-quality finish that stands the test of time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Always Up Front",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "There are no hidden costs. We are honest regarding what we will do and the cost involved.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing Services Burwood Heights\u200b",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Sydney Based, Commercial Roof Replacement Specialists",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our experienced team is equipped to handle various commercial roof types, including metal, fiberglass, polycarbonate, and flat roofs. We understand the importance of a durable, weather-resistant roof for your business, and our services are designed to enhance the longevity and performance of your commercial roof, ensuring a safe and professional environment.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Initial Consultation",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We will organise a time that suits you for our Estimator to inspect your roof, find out from you exactly what look and function you are hoping to achieve and assist with colour choice and other features such as ventilation, skylights, and insulation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Detailed Quote",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "You will receive your full quotation including details on our insurance coverage and licenses, in a timely manner.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Confirmation",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "If you are happy with the quote and wish to proceed, you can electronically accept the quote which instantly alerts the office, and we then get things moving for you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Project Execution",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "The actual roof replacement process can take between 1-7 days, depending on factors such as pitch, accessibility, size, and height of the roof. We\u2019ll provide an estimated timeline before starting the project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Project Progression",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "The site is set-up to provide safe access and working. Materials are delivered and put in a suitable place, the old roofing is removed, new battens are fixed into position, insulation is installed ready for your new roof. The roof sheeting, flashings, gutters, and downpipes are installed, as well as any additional components such as skylights or vents, and finally, the site is completely cleared of any rubbish or left over materials.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With over 20 years in the industry, we\u2019re a trusted local provider. We use high-quality materials and offer a 7-year guarantee on all workmanship. Choose ARS for your Roofing Requirements in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Qualified Expert",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We\u2019re fully Licensed and Fully Insured as well as being some of the most experienced Roofers in Sydney across all sectors.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "7 Year Guarantee",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "With over 20 years in the industry, we\u2019re a trusted local provider. We use high-quality materials and offer a 7-year guarantee on all workmanship.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Specialists",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We offer expert services in Colorbond roof replacements, known for its durability and sleek design.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "People recommend us because we\u2019re professional, considerate and completely up front about everything.",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Read all our reviews on Google Reviews",
                                        "url": "https://g.page/r/CQaI0BZafke4EAE",
                                        "urls": [
                                            {
                                                "url": "https://g.page/r/CQaI0BZafke4EAE",
                                                "anchor_text": "Google Reviews"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "A big thank you to Julian and Seth and the team for our new colourbond roof. Seth was professional and courteous, and great to work with. Their communication was exceptional, kept to timelines, and was able to provide clear updates and answer all questions. The work exceed expectations, along with their teams customer service, cleanliness, and work. Highly recommend All Roofing Services!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Very impressed with All Roofing Services. From quote to completion they are a very professional team. Our house is 120 years old was not a straight forward job. Thanks Ben, Julian and Seth for your quality workmanship and attention to detail. We are water tight and very happy with the job.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I cannot express how happy I am with my roof conversion!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If I could give you guys 10 stars I would. Thank you for your excellent work and I would be most happy to be a future reference for you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Very happy with my new roof from All Roofing Services. Such a professional crew, supplied a detailed quote, turned up on time and finished in the time quoted. Would highly recommend them 5 stars all round.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get Your Free Inspection & Quote",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Get your free, no-obligation quote today from Sydney\u2019s trusted roofing specialists! Fill out our quote request form, and we\u2019ll be in touch shortly to schedule your free site visit and provide an accurate estimate. Secure your roof with the best\u2014contact us now!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Get a Free Quote",
                                        "url": "https://www.allroofingservices.com.au/free-quote/",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/free-quote/",
                                                "anchor_text": "Get a Free Quote"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Call Us Now",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is better \u2013 Tiles or Colorbond?",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "\u201cDepends on who you ask!\u201d is one answer, but each has advantages and disadvantages.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 A new Colorbond roof is lighter than tiles, so it is a good option for an old roof where the roof or building structure has begun to sag, crack or twist under the weight of the old, tiled roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 A new Colorbond roof will also tend to tie the whole roof together making it stronger.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 A tiled roof is more susceptible to severe hail damage than a metal roof as even new tiles can crack with good size hail, whereas the metal may be dented, but not break.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 A Colorbond roof is much better under trees too, as falling tree branches tend to break tiles, whereas the Colorbond may only be dented.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Steel roofing is also more versatile. It can be used on any pitch and made into all kinds of shapes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "And arguably, a new Colorbond roof just looks a lot better!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Should I use Zincalume or Colorbond for my roof?",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "This is really a question of what look you are after as the cost is very similar. Colorbond has Zincalume steel as its base and is then painted with multiple layers using patented methods that have been tried and tested in Australian conditions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Zincalume is a fantastic product, but Colorbond is far Superior in terms of its durability and look. It comes in 22 different colours. Zincalume has that silver steel roof colour that many people like and up until recently was slightly cheaper, which is why it was used more commonly on commercial buildings with large roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Should I replace or repair my roof?",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "This is a common question and\u00a0fundamentally depends on two factors:\u00a0how bad the existing roof is and your budget. The only way to know how bad the roof really is would be to get an un-biased professional opinion. Some companies only do roof replacements so they will only try and sell you a new roof. Some only do repairs and will tell you there\u2019s a good 20 more years for your roof when actually it really is best to replace it now.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much does a roof replacement cost?",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "The cost to replace your roof can vary considerably depending on a whole range a factors such as access, how steep the roof is, whether guttering and insulation is to be done at the same time to name a few. Basically, every roof is different so an experienced estimator will come out, at a time that suits you, and provide a free quote that will tell you exactly how much it will cost to replace your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much does it cost to repair my roof?",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Again, the cost to repair your roof can vary considerably depending on a whole range a of factors such as access, how steep the roof is, what condition it is in, and whether it\u2019s tile or metal. As licenced roofers we are able to advise and complete any repairs that are needed to Australian standards, and in most instances can offer a warranty on these works.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Reliable",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Always show up",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We always show up and complete the work when we say we will.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Transparency",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Reputation for Quality",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We have a long standing reputation for delivering the highest quality roofing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What happens next?",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Start Your Journey \u200b",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "The first step is to call or fill out our quote request form",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Scheduling the Job \u200b",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Our typical lead time ranges from 3-6 weeks, contingent upon our current workload.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Clean Up",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Upon completion, we leave your site completely clean, removing any rubbish or leftover materials.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Other Areas in Inner West we service:",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Balmain East",
                                        "url": "https://www.allroofingservices.com.au/balmain-east",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/balmain-east",
                                                "anchor_text": "Balmain East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Breakfast Point",
                                        "url": "https://www.allroofingservices.com.au/breakfast-point",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/breakfast-point",
                                                "anchor_text": "Breakfast Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Burwood Heights",
                                        "url": "https://www.allroofingservices.com.au/burwood-heights",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/burwood-heights",
                                                "anchor_text": "Burwood Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canada Bay",
                                        "url": "https://www.allroofingservices.com.au/canada-bay",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/canada-bay",
                                                "anchor_text": "Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Concord West",
                                        "url": "https://www.allroofingservices.com.au/concord-west",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/concord-west",
                                                "anchor_text": "Concord West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park",
                                        "url": "https://www.allroofingservices.com.au/croydon-park",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/croydon-park",
                                                "anchor_text": "Croydon Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://www.allroofingservices.com.au/dulwich-hill",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/dulwich-hill",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": "https://www.allroofingservices.com.au/five-dock",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/five-dock",
                                                "anchor_text": "Five Dock"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Forest Lodge",
                                        "url": "https://www.allroofingservices.com.au/forest-lodge",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/forest-lodge",
                                                "anchor_text": "Forest Lodge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Homebush West",
                                        "url": "https://www.allroofingservices.com.au/homebush-west",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/homebush-west",
                                                "anchor_text": "Homebush West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hurlstone Park",
                                        "url": "https://www.allroofingservices.com.au/hurlstone-park",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/hurlstone-park",
                                                "anchor_text": "Hurlstone Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Liberty Grove",
                                        "url": "https://www.allroofingservices.com.au/liberty-grove",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/liberty-grove",
                                                "anchor_text": "Liberty Grove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Strathfield",
                                        "url": "https://www.allroofingservices.com.au/north-strathfield",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/north-strathfield",
                                                "anchor_text": "North Strathfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rodd Point",
                                        "url": "https://www.allroofingservices.com.au/rodd-point",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/rodd-point",
                                                "anchor_text": "Rodd Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Russell Lea",
                                        "url": "https://www.allroofingservices.com.au/russell-lea",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/russell-lea",
                                                "anchor_text": "Russell Lea"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Peters",
                                        "url": "https://www.allroofingservices.com.au/st-peters",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/st-peters",
                                                "anchor_text": "St Peters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strathfield South",
                                        "url": "https://www.allroofingservices.com.au/strathfield-south",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/strathfield-south",
                                                "anchor_text": "Strathfield South"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://www.allroofingservices.com.au/summer-hill",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/summer-hill",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Quality Professionals",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Our experienced team is equipped to handle both residential and commercial projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Always On Time",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Well established reputation for always being on time and on budget.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quotes & Inspection",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Start with a free quote and inspection to understand the needs of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FAQ\u2019s",
                                "main_title": "Roofing Services\nin Burwood Heights",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0406 969 061",
                                "0406%20969%20061",
                                "0280862059"
                            ],
                            "emails": [
                                "info@allroofingservices.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}