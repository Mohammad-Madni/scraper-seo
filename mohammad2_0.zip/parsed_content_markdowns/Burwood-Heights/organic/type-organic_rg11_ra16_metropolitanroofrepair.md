{
    "id": "01190728-1132-0216-0000-4d19f66503ec",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0312 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
        "target": "metropolitanroofrepair.com.au",
        "start_url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-Heights\\organic\\type-organic_rg11_ra16_metropolitanroofrepair.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:26 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/tile-roofing-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/tile-roofing-repairs-melbourne/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/gutter-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/gutter-repairs-melbourne/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leaks",
                                    "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                            "anchor_text": "Roof Leaks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://metropolitanroofrepair.com.au/roof-inspections-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-inspections-melbourne/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://metropolitanroofrepair.com.au/roof-plumbing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-plumbing-melbourne/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repair",
                                    "url": "https://metropolitanroofrepair.com.au/downpipe-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/downpipe-repair-melbourne/",
                                            "anchor_text": "Downpipe Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://metropolitanroofrepair.com.au/roof-painting-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-painting-melbourne/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Valley Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-valley-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-valley-repair-melbourne/",
                                            "anchor_text": "Roof Valley Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-flashing-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-flashing-repairs-melbourne/",
                                            "anchor_text": "Roof Flashing Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Carpentry",
                                    "url": "https://metropolitanroofrepair.com.au/roof-carpentry-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-carpentry-melbourne/",
                                            "anchor_text": "Roof Carpentry"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://metropolitanroofrepair.com.au/roof-replacement-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-replacement-melbourne/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/emergency-roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/emergency-roof-repairs-melbourne/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://metropolitanroofrepair.com.au/tile-roofing-restoration-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/tile-roofing-restoration-melbourne/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing Repairs & Replacement Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/",
                                            "anchor_text": "Colorbond\u00ae Roofing Repairs & Replacement Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/toorak/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Kew",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/kew/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/malvern/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/camberwell/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/glen-iris/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/richmond/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/carlton/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/balwyn/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repairs Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roof Repairs Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Abbotsford",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/abbotsford/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/abbotsford/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Abbotsford"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Balwyn North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn-north/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Blackburn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/blackburn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/blackburn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Blackburn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Bulleen",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/bulleen/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/bulleen/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Bulleen"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Burwood East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Burwood East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/camberwell/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/carlton/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Clifton Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/clifton-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/clifton-hill/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Clifton Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Deepened",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/deepened/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/deepened/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Deepened"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Eaglemont",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/eaglemont/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/eaglemont/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Eaglemont"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement East Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/east-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/east-melbourne/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement East Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-iris/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Hawthorn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Hawthorn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Hawthorn East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Hawthorn East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Ivanhoe",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Ivanhoe"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Ivanhoe East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Ivanhoe East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kew",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kew East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kew East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kooyong",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kooyong/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kooyong/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kooyong"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Mont Albert North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mont-albert-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mont-albert-north/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Mont Albert North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Northcote",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/northcote/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/northcote/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Northcote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Prahan",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahan/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahan/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Prahan"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/richmond/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-yarra/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/toorak/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Albert Park",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/albert-park/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/albert-park/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Albert Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Armadale",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Armadale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ashwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ashwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Balaclava",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balaclava/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balaclava/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Balaclava"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Brighton East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Brighton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Burnley",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burnley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burnley/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Burnley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Canterbury",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/canterbury/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/canterbury/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Canterbury"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Collingwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/collingwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/collingwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Collingwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Doncaster Heights",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster-heights/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Doncaster Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Donvale",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/donvale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/donvale/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Donvale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Elsternwick",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elsternwick/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elsternwick/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Elsternwick"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Fairfield",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fairfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fairfield/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Fairfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Elwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Elwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Fitzroy",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fitzroy/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fitzroy/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Fitzroy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Hampton East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Hampton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Hampton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Glen Huntly",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-huntly/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-huntly/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Glen Huntly"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Glen Waverley",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-waverley/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Heidelberg Heights",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg-heights/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Heidelberg Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Heidelberg",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Heidelberg"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Malvern East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Merlynston",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/merlynston/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/merlynston/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Merlynston"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Murrumbeena",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/murrumbeena/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/murrumbeena/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Murrumbeena"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Mulgrave",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mulgrave/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mulgrave/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Mulgrave"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement North Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/north-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/north-melbourne/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement North Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Oakleigh South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Oakleigh South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ormond",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ormond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ormond/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Oakleigh",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Oakleigh"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Prahran East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahran-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahran-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Prahran East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ringwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ringwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ringwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ringwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Rosanna",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/rosanna/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/rosanna/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Rosanna"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Armadale North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Armadale North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Sandringham",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/sandringham/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement South Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-melbourne/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement South Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement St Kilda East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/st-kilda-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/st-kilda-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement St Kilda East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Southbank",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/southbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/southbank/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Southbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Viewbank",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/viewbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/viewbank/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Viewbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Wantirna South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wantirna-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wantirna-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Wantirna South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Surrey Hills East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Surrey Hills East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Box Hill North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Box Hill North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Wheelers Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wheelers-hill/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/box-hill/",
                                            "anchor_text": "Roof Restoration Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
                                            "anchor_text": "Roof Restoration Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/camberwell/",
                                            "anchor_text": "Roof Restoration Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/doncaster/",
                                            "anchor_text": "Roof Restoration Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Hawthorn",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/hawthorn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/hawthorn/",
                                            "anchor_text": "Roof Restoration Hawthorn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Kew",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/kew/",
                                            "anchor_text": "Roof Restoration Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/surrey-hills/",
                                            "anchor_text": "Roof Restoration Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/south-yarra/",
                                            "anchor_text": "Roof Restoration South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ashwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ashwood/",
                                            "anchor_text": "Roof Repairs Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Armadale",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale/",
                                            "anchor_text": "Roof Repairs Armadale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Armadale North",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale-north/",
                                            "anchor_text": "Roof Repairs Armadale North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn/",
                                            "anchor_text": "Roof Repairs Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Balwyn North",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn-north/",
                                            "anchor_text": "Roof Repairs Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Black Rock",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/black-rock/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/black-rock/",
                                            "anchor_text": "Roof Repairs Black Rock"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/box-hill/",
                                            "anchor_text": "Roof Repairs Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Brighton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton/",
                                            "anchor_text": "Roof Repairs Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Brighton East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton-east/",
                                            "anchor_text": "Roof Repairs Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Bulleen",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/bulleen/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/bulleen/",
                                            "anchor_text": "Roof Repairs Bulleen"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Burnley",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burnley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burnley/",
                                            "anchor_text": "Roof Repairs Burnley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burwood/",
                                            "anchor_text": "Roof Repairs Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/camberwell/",
                                            "anchor_text": "Roof Repairs Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/carlton/",
                                            "anchor_text": "Roof Repairs Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Canterbury",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/canterbury/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/canterbury/",
                                            "anchor_text": "Roof Repairs Canterbury"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Caulfield",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/caulfield/",
                                            "anchor_text": "Roof Repairs Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Cheltenham",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/cheltenham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/cheltenham/",
                                            "anchor_text": "Roof Repairs Cheltenham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Deepdene",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/deepdene/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/deepdene/",
                                            "anchor_text": "Roof Repairs Deepdene"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster/",
                                            "anchor_text": "Roof Repairs Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Doncaster Heights",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster-heights/",
                                            "anchor_text": "Roof Repairs Doncaster Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Eaglemont",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/eaglemont/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/eaglemont/",
                                            "anchor_text": "Roof Repairs Eaglemont"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs East Melbourne",
                                    "url": "https://metropolihttps//metropolitanroofrepair.com.au/roof-repairs-melbourne/east-melbourne//tanroofrepair.com.au/roof-repairs-melbourne/bentleigh/",
                                    "urls": [
                                        {
                                            "url": "https://metropolihttps//metropolitanroofrepair.com.au/roof-repairs-melbourne/east-melbourne//tanroofrepair.com.au/roof-repairs-melbourne/bentleigh/",
                                            "anchor_text": "Roof Repairs East Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Elsternwick",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/elsternwick/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/elsternwick/",
                                            "anchor_text": "Roof Repairs Elsternwick"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Fairfield",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fairfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fairfield/",
                                            "anchor_text": "Roof Repairs Fairfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Fitzroy",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fitzroy/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fitzroy/",
                                            "anchor_text": "Roof Repairs Fitzroy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-iris/",
                                            "anchor_text": "Roof Repairs Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Glen Waverley",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-waverley/",
                                            "anchor_text": "Roof Repairs Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Hampton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hampton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hampton/",
                                            "anchor_text": "Roof Repairs Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Hawthorn East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hawthorn-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hawthorn-east/",
                                            "anchor_text": "Roof Repairs Hawthorn East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Heidelberg",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/heidelberg/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/heidelberg/",
                                            "anchor_text": "Roof Repairs Heidelberg"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ivanhoe",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ivanhoe/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ivanhoe/",
                                            "anchor_text": "Roof Repairs Ivanhoe"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Kew",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew/",
                                            "anchor_text": "Roof Repairs Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Kew East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew-east/",
                                            "anchor_text": "Roof Repairs Kew East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern/",
                                            "anchor_text": "Roof Repairs Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Malvern East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern-east/",
                                            "anchor_text": "Roof Repairs Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Mont Albert",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/mont-albert/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/mont-albert/",
                                            "anchor_text": "Roof Repairs Mont Albert"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs North Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/north-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/north-melbourne/",
                                            "anchor_text": "Roof Repairs North Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ormond",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ormond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ormond/",
                                            "anchor_text": "Roof Repairs Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Rosanna",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/rosanna/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/rosanna/",
                                            "anchor_text": "Roof Repairs Rosanna"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/richmond/",
                                            "anchor_text": "Roof Repairs Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Sandringham",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/sandringham/",
                                            "anchor_text": "Roof Repairs Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs South Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-melbourne/",
                                            "anchor_text": "Roof Repairs South Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-yarra/",
                                            "anchor_text": "Roof Repairs South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs St Kilda",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/st-kilda/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/st-kilda/",
                                            "anchor_text": "Roof Repairs St Kilda"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/surrey-hills/",
                                            "anchor_text": "Roof Repairs Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Southbank",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/southbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/southbank/",
                                            "anchor_text": "Roof Repairs Southbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/toorak/",
                                            "anchor_text": "Roof Repairs Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Viewbank",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/viewbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/viewbank/",
                                            "anchor_text": "Roof Repairs Viewbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Wheelers Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/wheelers-hill/",
                                            "anchor_text": "Roof Repairs Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://metropolitanroofrepair.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/tile-roofing-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/tile-roofing-repairs-melbourne/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/gutter-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/gutter-repairs-melbourne/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leaks",
                                    "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                            "anchor_text": "Roof Leaks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://metropolitanroofrepair.com.au/roof-inspections-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-inspections-melbourne/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://metropolitanroofrepair.com.au/roof-plumbing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-plumbing-melbourne/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repair",
                                    "url": "https://metropolitanroofrepair.com.au/downpipe-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/downpipe-repair-melbourne/",
                                            "anchor_text": "Downpipe Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://metropolitanroofrepair.com.au/roof-painting-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-painting-melbourne/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Valley Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-valley-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-valley-repair-melbourne/",
                                            "anchor_text": "Roof Valley Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-flashing-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-flashing-repairs-melbourne/",
                                            "anchor_text": "Roof Flashing Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Carpentry",
                                    "url": "https://metropolitanroofrepair.com.au/roof-carpentry-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-carpentry-melbourne/",
                                            "anchor_text": "Roof Carpentry"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://metropolitanroofrepair.com.au/roof-replacement-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-replacement-melbourne/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/emergency-roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/emergency-roof-repairs-melbourne/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://metropolitanroofrepair.com.au/tile-roofing-restoration-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/tile-roofing-restoration-melbourne/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing Repairs & Replacement Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/",
                                            "anchor_text": "Colorbond\u00ae Roofing Repairs & Replacement Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/toorak/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Kew",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/kew/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/malvern/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/camberwell/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/glen-iris/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/richmond/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/carlton/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/balwyn/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repairs Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roof Repairs Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Abbotsford",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/abbotsford/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/abbotsford/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Abbotsford"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Balwyn North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn-north/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Blackburn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/blackburn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/blackburn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Blackburn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Bulleen",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/bulleen/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/bulleen/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Bulleen"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Burwood East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Burwood East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/camberwell/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/carlton/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Clifton Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/clifton-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/clifton-hill/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Clifton Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Deepened",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/deepened/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/deepened/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Deepened"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Eaglemont",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/eaglemont/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/eaglemont/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Eaglemont"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement East Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/east-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/east-melbourne/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement East Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-iris/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Hawthorn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Hawthorn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Hawthorn East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Hawthorn East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Ivanhoe",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Ivanhoe"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Ivanhoe East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Ivanhoe East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kew",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kew East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kew East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kooyong",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kooyong/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kooyong/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kooyong"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Mont Albert North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mont-albert-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mont-albert-north/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Mont Albert North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Northcote",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/northcote/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/northcote/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Northcote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Prahan",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahan/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahan/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Prahan"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/richmond/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-yarra/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/toorak/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Albert Park",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/albert-park/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/albert-park/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Albert Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Armadale",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Armadale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ashwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ashwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Balaclava",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balaclava/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balaclava/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Balaclava"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Brighton East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Brighton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Burnley",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burnley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burnley/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Burnley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Canterbury",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/canterbury/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/canterbury/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Canterbury"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Collingwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/collingwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/collingwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Collingwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Doncaster Heights",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster-heights/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Doncaster Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Donvale",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/donvale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/donvale/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Donvale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Elsternwick",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elsternwick/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elsternwick/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Elsternwick"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Fairfield",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fairfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fairfield/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Fairfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Elwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Elwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Fitzroy",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fitzroy/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fitzroy/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Fitzroy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Hampton East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Hampton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Hampton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Glen Huntly",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-huntly/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-huntly/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Glen Huntly"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Glen Waverley",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-waverley/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Heidelberg Heights",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg-heights/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Heidelberg Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Heidelberg",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Heidelberg"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Malvern East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Merlynston",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/merlynston/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/merlynston/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Merlynston"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Murrumbeena",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/murrumbeena/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/murrumbeena/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Murrumbeena"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Mulgrave",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mulgrave/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mulgrave/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Mulgrave"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement North Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/north-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/north-melbourne/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement North Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Oakleigh South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Oakleigh South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ormond",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ormond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ormond/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Oakleigh",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Oakleigh"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Prahran East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahran-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahran-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Prahran East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ringwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ringwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ringwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ringwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Rosanna",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/rosanna/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/rosanna/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Rosanna"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Armadale North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Armadale North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Sandringham",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/sandringham/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement South Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-melbourne/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement South Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement St Kilda East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/st-kilda-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/st-kilda-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement St Kilda East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Southbank",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/southbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/southbank/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Southbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Viewbank",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/viewbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/viewbank/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Viewbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Wantirna South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wantirna-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wantirna-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Wantirna South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Surrey Hills East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Surrey Hills East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Box Hill North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Box Hill North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Wheelers Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wheelers-hill/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/box-hill/",
                                            "anchor_text": "Roof Restoration Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
                                            "anchor_text": "Roof Restoration Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/camberwell/",
                                            "anchor_text": "Roof Restoration Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/doncaster/",
                                            "anchor_text": "Roof Restoration Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Hawthorn",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/hawthorn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/hawthorn/",
                                            "anchor_text": "Roof Restoration Hawthorn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Kew",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/kew/",
                                            "anchor_text": "Roof Restoration Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/surrey-hills/",
                                            "anchor_text": "Roof Restoration Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/south-yarra/",
                                            "anchor_text": "Roof Restoration South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ashwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ashwood/",
                                            "anchor_text": "Roof Repairs Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Armadale",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale/",
                                            "anchor_text": "Roof Repairs Armadale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Armadale North",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale-north/",
                                            "anchor_text": "Roof Repairs Armadale North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn/",
                                            "anchor_text": "Roof Repairs Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Balwyn North",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn-north/",
                                            "anchor_text": "Roof Repairs Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Black Rock",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/black-rock/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/black-rock/",
                                            "anchor_text": "Roof Repairs Black Rock"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/box-hill/",
                                            "anchor_text": "Roof Repairs Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Brighton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton/",
                                            "anchor_text": "Roof Repairs Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Brighton East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton-east/",
                                            "anchor_text": "Roof Repairs Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Bulleen",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/bulleen/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/bulleen/",
                                            "anchor_text": "Roof Repairs Bulleen"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Burnley",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burnley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burnley/",
                                            "anchor_text": "Roof Repairs Burnley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burwood/",
                                            "anchor_text": "Roof Repairs Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/camberwell/",
                                            "anchor_text": "Roof Repairs Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/carlton/",
                                            "anchor_text": "Roof Repairs Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Canterbury",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/canterbury/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/canterbury/",
                                            "anchor_text": "Roof Repairs Canterbury"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Caulfield",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/caulfield/",
                                            "anchor_text": "Roof Repairs Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Cheltenham",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/cheltenham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/cheltenham/",
                                            "anchor_text": "Roof Repairs Cheltenham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Deepdene",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/deepdene/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/deepdene/",
                                            "anchor_text": "Roof Repairs Deepdene"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster/",
                                            "anchor_text": "Roof Repairs Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Doncaster Heights",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster-heights/",
                                            "anchor_text": "Roof Repairs Doncaster Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Eaglemont",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/eaglemont/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/eaglemont/",
                                            "anchor_text": "Roof Repairs Eaglemont"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs East Melbourne",
                                    "url": "https://metropolihttps//metropolitanroofrepair.com.au/roof-repairs-melbourne/east-melbourne//tanroofrepair.com.au/roof-repairs-melbourne/bentleigh/",
                                    "urls": [
                                        {
                                            "url": "https://metropolihttps//metropolitanroofrepair.com.au/roof-repairs-melbourne/east-melbourne//tanroofrepair.com.au/roof-repairs-melbourne/bentleigh/",
                                            "anchor_text": "Roof Repairs East Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Elsternwick",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/elsternwick/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/elsternwick/",
                                            "anchor_text": "Roof Repairs Elsternwick"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Fairfield",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fairfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fairfield/",
                                            "anchor_text": "Roof Repairs Fairfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Fitzroy",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fitzroy/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fitzroy/",
                                            "anchor_text": "Roof Repairs Fitzroy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-iris/",
                                            "anchor_text": "Roof Repairs Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Glen Waverley",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-waverley/",
                                            "anchor_text": "Roof Repairs Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Hampton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hampton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hampton/",
                                            "anchor_text": "Roof Repairs Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Hawthorn East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hawthorn-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hawthorn-east/",
                                            "anchor_text": "Roof Repairs Hawthorn East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Heidelberg",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/heidelberg/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/heidelberg/",
                                            "anchor_text": "Roof Repairs Heidelberg"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ivanhoe",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ivanhoe/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ivanhoe/",
                                            "anchor_text": "Roof Repairs Ivanhoe"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Kew",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew/",
                                            "anchor_text": "Roof Repairs Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Kew East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew-east/",
                                            "anchor_text": "Roof Repairs Kew East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern/",
                                            "anchor_text": "Roof Repairs Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Malvern East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern-east/",
                                            "anchor_text": "Roof Repairs Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Mont Albert",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/mont-albert/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/mont-albert/",
                                            "anchor_text": "Roof Repairs Mont Albert"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs North Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/north-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/north-melbourne/",
                                            "anchor_text": "Roof Repairs North Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ormond",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ormond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ormond/",
                                            "anchor_text": "Roof Repairs Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Rosanna",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/rosanna/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/rosanna/",
                                            "anchor_text": "Roof Repairs Rosanna"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/richmond/",
                                            "anchor_text": "Roof Repairs Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Sandringham",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/sandringham/",
                                            "anchor_text": "Roof Repairs Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs South Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-melbourne/",
                                            "anchor_text": "Roof Repairs South Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-yarra/",
                                            "anchor_text": "Roof Repairs South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs St Kilda",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/st-kilda/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/st-kilda/",
                                            "anchor_text": "Roof Repairs St Kilda"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/surrey-hills/",
                                            "anchor_text": "Roof Repairs Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Southbank",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/southbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/southbank/",
                                            "anchor_text": "Roof Repairs Southbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/toorak/",
                                            "anchor_text": "Roof Repairs Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Viewbank",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/viewbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/viewbank/",
                                            "anchor_text": "Roof Repairs Viewbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Wheelers Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/wheelers-hill/",
                                            "anchor_text": "Roof Repairs Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://metropolitanroofrepair.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/tile-roofing-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/tile-roofing-repairs-melbourne/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/gutter-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/gutter-repairs-melbourne/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leaks",
                                    "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                            "anchor_text": "Roof Leaks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://metropolitanroofrepair.com.au/roof-inspections-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-inspections-melbourne/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://metropolitanroofrepair.com.au/roof-plumbing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-plumbing-melbourne/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repair",
                                    "url": "https://metropolitanroofrepair.com.au/downpipe-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/downpipe-repair-melbourne/",
                                            "anchor_text": "Downpipe Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://metropolitanroofrepair.com.au/roof-painting-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-painting-melbourne/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Valley Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-valley-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-valley-repair-melbourne/",
                                            "anchor_text": "Roof Valley Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-flashing-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-flashing-repairs-melbourne/",
                                            "anchor_text": "Roof Flashing Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Carpentry",
                                    "url": "https://metropolitanroofrepair.com.au/roof-carpentry-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-carpentry-melbourne/",
                                            "anchor_text": "Roof Carpentry"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://metropolitanroofrepair.com.au/roof-replacement-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-replacement-melbourne/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/emergency-roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/emergency-roof-repairs-melbourne/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://metropolitanroofrepair.com.au/tile-roofing-restoration-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/tile-roofing-restoration-melbourne/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing Repairs & Replacement Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/",
                                            "anchor_text": "Colorbond\u00ae Roofing Repairs & Replacement Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/toorak/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Kew",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/kew/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/malvern/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/camberwell/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/glen-iris/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/richmond/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/carlton/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/balwyn/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repairs Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roof Repairs Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Abbotsford",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/abbotsford/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/abbotsford/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Abbotsford"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Balwyn North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn-north/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Blackburn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/blackburn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/blackburn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Blackburn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Bulleen",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/bulleen/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/bulleen/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Bulleen"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Burwood East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Burwood East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/camberwell/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/carlton/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Clifton Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/clifton-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/clifton-hill/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Clifton Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Deepened",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/deepened/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/deepened/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Deepened"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Eaglemont",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/eaglemont/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/eaglemont/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Eaglemont"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement East Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/east-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/east-melbourne/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement East Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-iris/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Hawthorn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Hawthorn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Hawthorn East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Hawthorn East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Ivanhoe",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Ivanhoe"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Ivanhoe East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Ivanhoe East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kew",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kew East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kew East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kooyong",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kooyong/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kooyong/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kooyong"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Mont Albert North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mont-albert-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mont-albert-north/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Mont Albert North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Northcote",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/northcote/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/northcote/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Northcote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Prahan",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahan/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahan/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Prahan"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/richmond/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-yarra/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/toorak/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Albert Park",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/albert-park/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/albert-park/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Albert Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Armadale",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Armadale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ashwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ashwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Balaclava",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balaclava/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balaclava/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Balaclava"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Brighton East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Brighton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Burnley",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burnley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burnley/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Burnley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Canterbury",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/canterbury/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/canterbury/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Canterbury"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Collingwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/collingwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/collingwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Collingwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Doncaster Heights",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster-heights/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Doncaster Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Donvale",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/donvale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/donvale/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Donvale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Elsternwick",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elsternwick/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elsternwick/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Elsternwick"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Fairfield",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fairfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fairfield/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Fairfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Elwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Elwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Fitzroy",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fitzroy/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fitzroy/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Fitzroy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Hampton East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Hampton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Hampton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Glen Huntly",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-huntly/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-huntly/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Glen Huntly"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Glen Waverley",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-waverley/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Heidelberg Heights",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg-heights/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Heidelberg Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Heidelberg",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Heidelberg"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Malvern East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Merlynston",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/merlynston/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/merlynston/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Merlynston"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Murrumbeena",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/murrumbeena/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/murrumbeena/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Murrumbeena"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Mulgrave",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mulgrave/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mulgrave/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Mulgrave"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement North Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/north-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/north-melbourne/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement North Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Oakleigh South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Oakleigh South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ormond",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ormond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ormond/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Oakleigh",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Oakleigh"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Prahran East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahran-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahran-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Prahran East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ringwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ringwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ringwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ringwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Rosanna",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/rosanna/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/rosanna/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Rosanna"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Armadale North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Armadale North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Sandringham",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/sandringham/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement South Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-melbourne/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement South Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement St Kilda East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/st-kilda-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/st-kilda-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement St Kilda East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Southbank",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/southbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/southbank/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Southbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Viewbank",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/viewbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/viewbank/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Viewbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Wantirna South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wantirna-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wantirna-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Wantirna South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Surrey Hills East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Surrey Hills East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Box Hill North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Box Hill North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Wheelers Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wheelers-hill/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/box-hill/",
                                            "anchor_text": "Roof Restoration Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
                                            "anchor_text": "Roof Restoration Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/camberwell/",
                                            "anchor_text": "Roof Restoration Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/doncaster/",
                                            "anchor_text": "Roof Restoration Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Hawthorn",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/hawthorn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/hawthorn/",
                                            "anchor_text": "Roof Restoration Hawthorn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Kew",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/kew/",
                                            "anchor_text": "Roof Restoration Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/surrey-hills/",
                                            "anchor_text": "Roof Restoration Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/south-yarra/",
                                            "anchor_text": "Roof Restoration South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ashwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ashwood/",
                                            "anchor_text": "Roof Repairs Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Armadale",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale/",
                                            "anchor_text": "Roof Repairs Armadale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Armadale North",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale-north/",
                                            "anchor_text": "Roof Repairs Armadale North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn/",
                                            "anchor_text": "Roof Repairs Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Balwyn North",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn-north/",
                                            "anchor_text": "Roof Repairs Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Black Rock",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/black-rock/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/black-rock/",
                                            "anchor_text": "Roof Repairs Black Rock"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/box-hill/",
                                            "anchor_text": "Roof Repairs Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Brighton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton/",
                                            "anchor_text": "Roof Repairs Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Brighton East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton-east/",
                                            "anchor_text": "Roof Repairs Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Bulleen",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/bulleen/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/bulleen/",
                                            "anchor_text": "Roof Repairs Bulleen"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Burnley",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burnley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burnley/",
                                            "anchor_text": "Roof Repairs Burnley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burwood/",
                                            "anchor_text": "Roof Repairs Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/camberwell/",
                                            "anchor_text": "Roof Repairs Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/carlton/",
                                            "anchor_text": "Roof Repairs Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Canterbury",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/canterbury/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/canterbury/",
                                            "anchor_text": "Roof Repairs Canterbury"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Caulfield",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/caulfield/",
                                            "anchor_text": "Roof Repairs Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Cheltenham",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/cheltenham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/cheltenham/",
                                            "anchor_text": "Roof Repairs Cheltenham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Deepdene",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/deepdene/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/deepdene/",
                                            "anchor_text": "Roof Repairs Deepdene"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster/",
                                            "anchor_text": "Roof Repairs Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Doncaster Heights",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster-heights/",
                                            "anchor_text": "Roof Repairs Doncaster Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Eaglemont",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/eaglemont/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/eaglemont/",
                                            "anchor_text": "Roof Repairs Eaglemont"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs East Melbourne",
                                    "url": "https://metropolihttps//metropolitanroofrepair.com.au/roof-repairs-melbourne/east-melbourne//tanroofrepair.com.au/roof-repairs-melbourne/bentleigh/",
                                    "urls": [
                                        {
                                            "url": "https://metropolihttps//metropolitanroofrepair.com.au/roof-repairs-melbourne/east-melbourne//tanroofrepair.com.au/roof-repairs-melbourne/bentleigh/",
                                            "anchor_text": "Roof Repairs East Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Elsternwick",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/elsternwick/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/elsternwick/",
                                            "anchor_text": "Roof Repairs Elsternwick"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Fairfield",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fairfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fairfield/",
                                            "anchor_text": "Roof Repairs Fairfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Fitzroy",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fitzroy/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fitzroy/",
                                            "anchor_text": "Roof Repairs Fitzroy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-iris/",
                                            "anchor_text": "Roof Repairs Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Glen Waverley",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-waverley/",
                                            "anchor_text": "Roof Repairs Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Hampton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hampton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hampton/",
                                            "anchor_text": "Roof Repairs Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Hawthorn East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hawthorn-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hawthorn-east/",
                                            "anchor_text": "Roof Repairs Hawthorn East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Heidelberg",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/heidelberg/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/heidelberg/",
                                            "anchor_text": "Roof Repairs Heidelberg"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ivanhoe",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ivanhoe/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ivanhoe/",
                                            "anchor_text": "Roof Repairs Ivanhoe"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Kew",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew/",
                                            "anchor_text": "Roof Repairs Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Kew East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew-east/",
                                            "anchor_text": "Roof Repairs Kew East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern/",
                                            "anchor_text": "Roof Repairs Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Malvern East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern-east/",
                                            "anchor_text": "Roof Repairs Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Mont Albert",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/mont-albert/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/mont-albert/",
                                            "anchor_text": "Roof Repairs Mont Albert"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs North Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/north-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/north-melbourne/",
                                            "anchor_text": "Roof Repairs North Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ormond",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ormond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ormond/",
                                            "anchor_text": "Roof Repairs Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Rosanna",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/rosanna/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/rosanna/",
                                            "anchor_text": "Roof Repairs Rosanna"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/richmond/",
                                            "anchor_text": "Roof Repairs Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Sandringham",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/sandringham/",
                                            "anchor_text": "Roof Repairs Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs South Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-melbourne/",
                                            "anchor_text": "Roof Repairs South Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-yarra/",
                                            "anchor_text": "Roof Repairs South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs St Kilda",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/st-kilda/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/st-kilda/",
                                            "anchor_text": "Roof Repairs St Kilda"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/surrey-hills/",
                                            "anchor_text": "Roof Repairs Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Southbank",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/southbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/southbank/",
                                            "anchor_text": "Roof Repairs Southbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/toorak/",
                                            "anchor_text": "Roof Repairs Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Viewbank",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/viewbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/viewbank/",
                                            "anchor_text": "Roof Repairs Viewbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Wheelers Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/wheelers-hill/",
                                            "anchor_text": "Roof Repairs Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://metropolitanroofrepair.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/tile-roofing-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/tile-roofing-repairs-melbourne/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/gutter-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/gutter-repairs-melbourne/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leaks",
                                    "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                            "anchor_text": "Roof Leaks"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://metropolitanroofrepair.com.au/roof-inspections-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-inspections-melbourne/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://metropolitanroofrepair.com.au/roof-plumbing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-plumbing-melbourne/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repair",
                                    "url": "https://metropolitanroofrepair.com.au/downpipe-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/downpipe-repair-melbourne/",
                                            "anchor_text": "Downpipe Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://metropolitanroofrepair.com.au/roof-painting-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-painting-melbourne/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Valley Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-valley-repair-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-valley-repair-melbourne/",
                                            "anchor_text": "Roof Valley Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/roof-flashing-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-flashing-repairs-melbourne/",
                                            "anchor_text": "Roof Flashing Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Carpentry",
                                    "url": "https://metropolitanroofrepair.com.au/roof-carpentry-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-carpentry-melbourne/",
                                            "anchor_text": "Roof Carpentry"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://metropolitanroofrepair.com.au/roof-replacement-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-replacement-melbourne/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://metropolitanroofrepair.com.au/emergency-roof-repairs-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/emergency-roof-repairs-melbourne/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://metropolitanroofrepair.com.au/tile-roofing-restoration-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/tile-roofing-restoration-melbourne/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing Repairs & Replacement Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/",
                                            "anchor_text": "Colorbond\u00ae Roofing Repairs & Replacement Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/toorak/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Kew",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/kew/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/malvern/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/camberwell/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/glen-iris/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roofing And Roof Replacement Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/richmond/",
                                            "anchor_text": "Colorbond\u00ae Roofing And Roof Replacement Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/carlton/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond\u00ae Roof Repairs & Replacement Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/balwyn/",
                                            "anchor_text": "Colorbond\u00ae Roof Repairs & Replacement Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repairs Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roof Repairs Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Abbotsford",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/abbotsford/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/abbotsford/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Abbotsford"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Balwyn North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balwyn-north/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Blackburn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/blackburn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/blackburn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Blackburn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Bulleen",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/bulleen/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/bulleen/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Bulleen"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Burwood East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burwood-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Burwood East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/camberwell/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/carlton/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Clifton Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/clifton-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/clifton-hill/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Clifton Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Deepened",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/deepened/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/deepened/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Deepened"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Eaglemont",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/eaglemont/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/eaglemont/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Eaglemont"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement East Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/east-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/east-melbourne/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement East Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-iris/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Hawthorn",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Hawthorn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Hawthorn East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hawthorn-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Hawthorn East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Ivanhoe",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Ivanhoe"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Ivanhoe East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ivanhoe-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Ivanhoe East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kew",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kew East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kew-east/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kew East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Kooyong",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kooyong/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/kooyong/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Kooyong"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Mont Albert North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mont-albert-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mont-albert-north/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Mont Albert North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Northcote",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/northcote/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/northcote/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Northcote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Prahan",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahan/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahan/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Prahan"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/richmond/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-yarra/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair, Restoration & Replacement Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/toorak/",
                                            "anchor_text": "Slate Roof Repair, Restoration & Replacement Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Albert Park",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/albert-park/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/albert-park/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Albert Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Armadale",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Armadale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ashwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ashwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Balaclava",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balaclava/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/balaclava/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Balaclava"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Brighton East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Brighton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/brighton/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Burnley",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burnley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/burnley/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Burnley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Canterbury",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/canterbury/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/canterbury/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Canterbury"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Collingwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/collingwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/collingwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Collingwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Doncaster Heights",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/doncaster-heights/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Doncaster Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Donvale",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/donvale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/donvale/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Donvale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Elsternwick",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elsternwick/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elsternwick/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Elsternwick"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Fairfield",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fairfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fairfield/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Fairfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Elwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/elwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Elwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Fitzroy",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fitzroy/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/fitzroy/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Fitzroy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Hampton East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Hampton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Hampton",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/hampton/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Glen Huntly",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-huntly/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-huntly/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Glen Huntly"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Glen Waverley",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/glen-waverley/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Heidelberg Heights",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg-heights/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Heidelberg Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Heidelberg",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/heidelberg/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Heidelberg"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Malvern East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/malvern-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Merlynston",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/merlynston/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/merlynston/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Merlynston"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Murrumbeena",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/murrumbeena/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/murrumbeena/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Murrumbeena"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Mulgrave",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mulgrave/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/mulgrave/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Mulgrave"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement North Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/north-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/north-melbourne/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement North Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Oakleigh South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Oakleigh South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ormond",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ormond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ormond/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Oakleigh",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/oakleigh/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Oakleigh"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Prahran East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahran-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/prahran-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Prahran East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Ringwood",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ringwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/ringwood/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Ringwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Rosanna",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/rosanna/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/rosanna/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Rosanna"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Armadale North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/armadale-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Armadale North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Sandringham",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/sandringham/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement South Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/south-melbourne/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement South Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement St Kilda East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/st-kilda-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/st-kilda-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement St Kilda East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Southbank",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/southbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/southbank/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Southbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Viewbank",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/viewbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/viewbank/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Viewbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Wantirna South",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wantirna-south/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wantirna-south/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Wantirna South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Caulfield North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/caulfield-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Caulfield North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Surrey Hills East",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/surrey-hills-east/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Surrey Hills East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Box Hill North",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/box-hill-north/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Box Hill North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repair & Restoration & Replacement Wheelers Hill",
                                    "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/wheelers-hill/",
                                            "anchor_text": "Slate Roof Repair & Restoration & Replacement Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/box-hill/",
                                            "anchor_text": "Roof Restoration Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
                                            "anchor_text": "Roof Restoration Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/camberwell/",
                                            "anchor_text": "Roof Restoration Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/doncaster/",
                                            "anchor_text": "Roof Restoration Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Hawthorn",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/hawthorn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/hawthorn/",
                                            "anchor_text": "Roof Restoration Hawthorn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Kew",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/kew/",
                                            "anchor_text": "Roof Restoration Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/surrey-hills/",
                                            "anchor_text": "Roof Restoration Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/south-yarra/",
                                            "anchor_text": "Roof Restoration South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ashwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ashwood/",
                                            "anchor_text": "Roof Repairs Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Armadale",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale/",
                                            "anchor_text": "Roof Repairs Armadale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Armadale North",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale-north/",
                                            "anchor_text": "Roof Repairs Armadale North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Balwyn",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn/",
                                            "anchor_text": "Roof Repairs Balwyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Balwyn North",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn-north/",
                                            "anchor_text": "Roof Repairs Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Black Rock",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/black-rock/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/black-rock/",
                                            "anchor_text": "Roof Repairs Black Rock"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Box Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/box-hill/",
                                            "anchor_text": "Roof Repairs Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Brighton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton/",
                                            "anchor_text": "Roof Repairs Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Brighton East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/brighton-east/",
                                            "anchor_text": "Roof Repairs Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Bulleen",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/bulleen/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/bulleen/",
                                            "anchor_text": "Roof Repairs Bulleen"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Burnley",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burnley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burnley/",
                                            "anchor_text": "Roof Repairs Burnley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Burwood",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burwood/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/burwood/",
                                            "anchor_text": "Roof Repairs Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Camberwell",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/camberwell/",
                                            "anchor_text": "Roof Repairs Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Carlton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/carlton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/carlton/",
                                            "anchor_text": "Roof Repairs Carlton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Canterbury",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/canterbury/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/canterbury/",
                                            "anchor_text": "Roof Repairs Canterbury"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Caulfield",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/caulfield/",
                                            "anchor_text": "Roof Repairs Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Cheltenham",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/cheltenham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/cheltenham/",
                                            "anchor_text": "Roof Repairs Cheltenham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Deepdene",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/deepdene/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/deepdene/",
                                            "anchor_text": "Roof Repairs Deepdene"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Doncaster",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster/",
                                            "anchor_text": "Roof Repairs Doncaster"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Doncaster Heights",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster-heights/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster-heights/",
                                            "anchor_text": "Roof Repairs Doncaster Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Eaglemont",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/eaglemont/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/eaglemont/",
                                            "anchor_text": "Roof Repairs Eaglemont"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs East Melbourne",
                                    "url": "https://metropolihttps//metropolitanroofrepair.com.au/roof-repairs-melbourne/east-melbourne//tanroofrepair.com.au/roof-repairs-melbourne/bentleigh/",
                                    "urls": [
                                        {
                                            "url": "https://metropolihttps//metropolitanroofrepair.com.au/roof-repairs-melbourne/east-melbourne//tanroofrepair.com.au/roof-repairs-melbourne/bentleigh/",
                                            "anchor_text": "Roof Repairs East Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Elsternwick",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/elsternwick/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/elsternwick/",
                                            "anchor_text": "Roof Repairs Elsternwick"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Fairfield",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fairfield/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fairfield/",
                                            "anchor_text": "Roof Repairs Fairfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Fitzroy",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fitzroy/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fitzroy/",
                                            "anchor_text": "Roof Repairs Fitzroy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Glen Iris",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-iris/",
                                            "anchor_text": "Roof Repairs Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Glen Waverley",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-waverley/",
                                            "anchor_text": "Roof Repairs Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Hampton",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hampton/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hampton/",
                                            "anchor_text": "Roof Repairs Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Hawthorn East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hawthorn-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hawthorn-east/",
                                            "anchor_text": "Roof Repairs Hawthorn East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Heidelberg",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/heidelberg/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/heidelberg/",
                                            "anchor_text": "Roof Repairs Heidelberg"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ivanhoe",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ivanhoe/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ivanhoe/",
                                            "anchor_text": "Roof Repairs Ivanhoe"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Kew",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew/",
                                            "anchor_text": "Roof Repairs Kew"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Kew East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew-east/",
                                            "anchor_text": "Roof Repairs Kew East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Malvern",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern/",
                                            "anchor_text": "Roof Repairs Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Malvern East",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern-east/",
                                            "anchor_text": "Roof Repairs Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Mont Albert",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/mont-albert/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/mont-albert/",
                                            "anchor_text": "Roof Repairs Mont Albert"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs North Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/north-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/north-melbourne/",
                                            "anchor_text": "Roof Repairs North Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ormond",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ormond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ormond/",
                                            "anchor_text": "Roof Repairs Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Rosanna",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/rosanna/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/rosanna/",
                                            "anchor_text": "Roof Repairs Rosanna"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Richmond",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/richmond/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/richmond/",
                                            "anchor_text": "Roof Repairs Richmond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Sandringham",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/sandringham/",
                                            "anchor_text": "Roof Repairs Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs South Melbourne",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-melbourne/",
                                            "anchor_text": "Roof Repairs South Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs South Yarra",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-yarra/",
                                            "anchor_text": "Roof Repairs South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs St Kilda",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/st-kilda/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/st-kilda/",
                                            "anchor_text": "Roof Repairs St Kilda"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Surrey Hills",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/surrey-hills/",
                                            "anchor_text": "Roof Repairs Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Southbank",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/southbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/southbank/",
                                            "anchor_text": "Roof Repairs Southbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Toorak",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/toorak/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/toorak/",
                                            "anchor_text": "Roof Repairs Toorak"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Viewbank",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/viewbank/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/viewbank/",
                                            "anchor_text": "Roof Repairs Viewbank"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Wheelers Hill",
                                    "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/wheelers-hill/",
                                            "anchor_text": "Roof Repairs Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://metropolitanroofrepair.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://metropolitanroofrepair.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Roof Repointing",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "This involves replacing the mortar between tiles, which can become loose or cracked over time. This improves water resistance and the overall stability of the roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Timber Baton Replacement",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The battens are the wooden supports under the tiles. Damaged or rotten battens compromise the structural integrity of the roof and need replacement.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Waterproof Sarking Installation",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sarking is a waterproof membrane installed underneath the tiles. A new sarking layer can be necessary if the existing one is damaged or missing, providing an extra layer of protection from water infiltration.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Painting & Replacement",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Guttering systems deteriorate with time, including storm damage, rust and more. We can fully refurbish your guttering, replacing any existing damaged guttering, or painting it to make it appear brand new.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ridge Capping Replacement",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The ridge capping covers the peak of the roof. Cracked or broken ridge capping allows water infiltration and needs to be replaced to ensure proper sealing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof painting doesn't just improve aesthetics. A specialised roof paint creates a protective layer that enhances weather resistance and extends the lifespan of the tiles.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Carpentry",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roof carpentry services ensure your roof has a strong, stable framework built to withstand the harshest Australian conditions. From new builds to roof replacements and structural upgrades, we deliver precision workmanship that supports long-term durability, proper water drainage, and overall roof performance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Burwood",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Metropolitan Roof Repairs came recommended to us because of their extensive work on heritage buildings and their good reputation. We have used Metropolitan roof repairs for a number of our roof projects from repairs to replacement and from slate to terracotta and also for a metal roof on the extension. They have never let us down. Their knowledge and expertise in roofing is extensive, they are very skilled and reliable. We wont use anyone else.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Steve and his team from metropolitan roof repairs Kew installed my new Spanish Del Carmen slate roof at my house in Southyarra. Highly recommended them one of the best roofing companies in Melbourne he kept me updated throughout the entire process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All the things you want from any quality trade work. Responsive to our requests and questions, clear in their quoting and timeframes, cleaned up (more than just their own work), the quality of the work is great, and they followed up afterwards to confirm we were satisfied. Many thanks from us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What's the difference between roof repair and roof restoration?",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof restoration goes beyond just fixing leaks. It\u2019s a comprehensive overhaul that addresses existing issues such as damaged tiles or failing mortar, adds preventative measures such as waterproof membranes and improved ventilation, and rejuvenates your roof with repointing and painting. This extends your roof\u2019s lifespan, improves its performance, and enhances your home\u2019s curb appeal and value.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What does roof restoration include?",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A typical roof restoration includes a thorough inspection, repairs to address leaks and damaged components, preventative measures like installing sarking and improving ventilation, and improvements like repointing and a fresh coat of paint.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How do I know if my roof needs restoration or just repairs?",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Signs your roof may need restoration include curling or cracked shingles, leaks, visible moss growth, or a noticeable decline in energy efficiency. For minor leaks or damaged tiles, repairs might suffice. However, if you see widespread issues or your roof is nearing the end of its lifespan (around 15-20 years for some materials), restoration is a better long-term solution.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof restoration cost?",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The cost of roof restoration varies depending on the size and condition of your roof, the materials used, and the complexity of the job. Generally, roof restoration can range from $3,000 to $12,000 for an average-sized home. For a more accurate estimate, we can provide you an obligation free inspection and consultation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Burwood",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We accept Crypto, enquire now!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "35 Cotham Rd, Kew VIC 3101",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "30 years experience in the roofing industry and specialists in all roof replacements, roof restorations and roof repairs, including tile, Colorbond metal and slate roofs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Steve & Tom Established Metropolitan Roof Repairs in 1999 and have being going strong ever since. We have built strong ties and relations with suppliers and tradesmen alike.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "About us",
                                        "url": "https://metropolitanroofrepair.com.au/about/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/about/",
                                                "anchor_text": "About us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact Us",
                                        "url": "https://metropolitanroofrepair.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/contact-us/",
                                                "anchor_text": "Contact Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Areas We Serve",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Repairs Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/",
                                                "anchor_text": "Roof Repairs Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Kew",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew/",
                                                "anchor_text": "Roof Repairs Kew"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Kew East",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew-east/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/kew-east/",
                                                "anchor_text": "Roof Repairs Kew East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Ashwood",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ashwood/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ashwood/",
                                                "anchor_text": "Roof Repairs Ashwood"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Armadale",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/armadale/",
                                                "anchor_text": "Roof Repairs Armadale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Balwyn North",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn-north/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/balwyn-north/",
                                                "anchor_text": "Roof Repairs Balwyn North"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Box Hill",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/box-hill/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/box-hill/",
                                                "anchor_text": "Roof Repairs Box Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Camberwell",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/camberwell/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/camberwell/",
                                                "anchor_text": "Roof Repairs Camberwell"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Canterbury",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/canterbury/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/canterbury/",
                                                "anchor_text": "Roof Repairs Canterbury"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Deepdene",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/deepdene/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/deepdene/",
                                                "anchor_text": "Roof Repairs Deepdene"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Doncaster",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/doncaster/",
                                                "anchor_text": "Roof Repairs Doncaster"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Eaglemont",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/eaglemont/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/eaglemont/",
                                                "anchor_text": "Roof Repairs Eaglemont"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Glen Iris",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-iris/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/glen-iris/",
                                                "anchor_text": "Roof Repairs Glen Iris"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Fairfield",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fairfield/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/fairfield/",
                                                "anchor_text": "Roof Repairs Fairfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Hawthorn East",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hawthorn-east/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/hawthorn-east/",
                                                "anchor_text": "Roof Repairs Hawthorn East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Heidelberg",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/heidelberg/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/heidelberg/",
                                                "anchor_text": "Roof Repairs Heidelberg"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Ivanhoe",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ivanhoe/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/ivanhoe/",
                                                "anchor_text": "Roof Repairs Ivanhoe"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Malvern",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/malvern/",
                                                "anchor_text": "Roof Repairs Malvern"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs North Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/north-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/north-melbourne/",
                                                "anchor_text": "Roof Repairs North Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs South Yarra",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-yarra/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/south-yarra/",
                                                "anchor_text": "Roof Repairs South Yarra"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Surrey Hills",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/surrey-hills/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/surrey-hills/",
                                                "anchor_text": "Roof Repairs Surrey Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs Toorak",
                                        "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/toorak/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-repairs-melbourne/toorak/",
                                                "anchor_text": "Roof Repairs Toorak"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/",
                                                "anchor_text": "Roof Restoration Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/roof-replacement-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-replacement-melbourne/",
                                                "anchor_text": "Roof Replacement Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Carpentry Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/roof-carpentry-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-carpentry-melbourne/",
                                                "anchor_text": "Roof Carpentry Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tile Roof Repairs Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/tile-roofing-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/tile-roofing-repairs-melbourne/",
                                                "anchor_text": "Tile Roof Repairs Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tile Roof Restoration Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/tile-roofing-restoration-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/tile-roofing-restoration-melbourne/",
                                                "anchor_text": "Tile Roof Restoration Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slate Roof Repairs Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/slate-roofing-melbourne/",
                                                "anchor_text": "Slate Roof Repairs Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Colorbond Roof Repairs Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/colorbond-roofing-melbourne/",
                                                "anchor_text": "Colorbond Roof Repairs Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/emergency-roof-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/emergency-roof-repairs-melbourne/",
                                                "anchor_text": "Emergency Roof Repairs Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roof Repairs Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/metal-roofing/",
                                                "anchor_text": "Metal Roof Repairs Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof Repairs Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                                "anchor_text": "Leaking Roof Repairs Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Repairs Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/gutter-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/gutter-repairs-melbourne/",
                                                "anchor_text": "Gutter Repairs Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Flashing Repairs Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/roof-flashing-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-flashing-repairs-melbourne/",
                                                "anchor_text": "Roof Flashing Repairs Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/roof-painting-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-painting-melbourne/",
                                                "anchor_text": "Roof Painting Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Plumbing Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/roof-plumbing-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-plumbing-melbourne/",
                                                "anchor_text": "Roof Plumbing Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Downpipe Repair Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/downpipe-repair-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/downpipe-repair-melbourne/",
                                                "anchor_text": "Downpipe Repair Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Valley Repair Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/roof-valley-repair-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-valley-repair-melbourne/",
                                                "anchor_text": "Roof Valley Repair Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections Melbourne",
                                        "url": "https://metropolitanroofrepair.com.au/roof-inspections-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-inspections-melbourne/",
                                                "anchor_text": "Roof Inspections Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Kew",
                                        "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/kew/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/kew/",
                                                "anchor_text": "Roof Restoration Kew"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Hawthorn",
                                        "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/hawthorn/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/hawthorn/",
                                                "anchor_text": "Roof Restoration Hawthorn"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Camberwell",
                                        "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/camberwell/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/camberwell/",
                                                "anchor_text": "Roof Restoration Camberwell"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Surrey Hills",
                                        "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/surrey-hills/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/surrey-hills/",
                                                "anchor_text": "Roof Restoration Surrey Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Burwood",
                                        "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/burwood/",
                                                "anchor_text": "Roof Restoration Burwood"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Box Hill",
                                        "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/box-hill/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/box-hill/",
                                                "anchor_text": "Roof Restoration Box Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Doncaster",
                                        "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/doncaster/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/doncaster/",
                                                "anchor_text": "Roof Restoration Doncaster"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration South Yarra",
                                        "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/south-yarra/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/roof-restoration-melbourne/south-yarra/",
                                                "anchor_text": "Roof Restoration South Yarra"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Working Hours",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Monday \u2013 Friday: 7.00 AM \u2013 5.30 PM",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Saturday: 9.00 AM \u2013 2.00 PM",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sunday: Holiday",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Emergency Roof Repairs: 24/7",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Contact Us",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "abn: 99680738434",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metropolitan Roof Repairs is an independent company and has no affiliation with other local businesses that include \u201cMetropolitan\u201d in their name.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Restoration Burwood",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Metropolitan Roof Repairs specialises in Professional Roof Restorations in Burwood. If your roof is weathered, worn, or showing signs of age, our expert team can restore it to peak condition, improving both its appearance and life-span.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "30+ Years of Experience with 150,000+ Projects Completed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully Insured with 10-Year Guarantee",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Licensed Roofers, Master Builders Association Member",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Specialists in Roof Leaks",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "This field is for validation purposes and should be left unchanged.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Over 200 5-Star Reviews",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Affordable, Competitive Pricing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" * \" indicates required fields",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Complete Restoration",
                                        "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                                "anchor_text": "Complete Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Carpentry",
                                        "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                                "anchor_text": "Roof Carpentry"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Weather Protection",
                                        "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                                "anchor_text": "Weather Protection"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://metropolitanroofrepair.com.au/leaking-roof-repairs-melbourne/",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "We've Been Restoring Roofs in Burwood for over 30 years",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Our motto is \u2018We do it right the first time.\u2019",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Metropolitan Roof Repairs, we provide complete roof restoration services for homes in Burwood, covering everything from structural timber work to tile replacement and finishing coats. With over 30 years of experience and a 10-year guarantee on all restoration work, we take care of every detail to ensure your roof is strong, weatherproof, and built to last.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repointing",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Timber Baton Replacement",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Waterproof Sarking Installation",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Painting & Replacement",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Damaged Tile Replacement",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Damaged Tile Replacement",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Upgrading your roof to replace individual broken, cracked, or missing tiles to maintain a watertight roof surface which looks great.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ridge Capping Replacement",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Carpentry",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "The Difference Restored Roof Tiles Can Make In Burwood",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Burwood",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Free roof inspections, advice and quotes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We use only the best suppliers and materials",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What people are saying about Metropolitan Roof Repairs",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restorations Burwood",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roof Restoration Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0386780398"
                            ],
                            "emails": [
                                "metropolitanroofing.vic@gmail.com"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}