{
    "id": "01190728-1132-0216-0000-19221dc6b072",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0244 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofguardroofing.com.au/areas-we-service/burwood/",
        "target": "roofguardroofing.com.au",
        "start_url": "https://roofguardroofing.com.au/areas-we-service/burwood/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-Heights\\organic\\type-organic_rg12_ra18_roofguardroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:25 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Your roof is the first barrier of protection between your home and the outdoor elements.\u00a0Whether it\u2019s your Burwood home or workplace, a solid, stable roof is significant to ensuring the integrity of the structure. Our expert team of roofing professionals can help you maintain it.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "You know it is time to contact the professionals for roof restorations or roof repairs if your roof is a couple of decades old or more and exhibiting any of the following signs:",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Loose tiling or materials around the roof, chimney, pipes",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Cracks and signs of wear, broken tiles, cracked bedding and pointing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Biological growth i.e signs of mould, moss, fungus or rot",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Storm or weather damage",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Natural weathering over a longer period of time",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Damage from inexperienced people and amateurs walking on the roof",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Leaving roof damage untreated is a serious hazard to you and your family\u2019s health and safety.\u00a0DO NOT allow for any of the above signs to worsen before you\u00a0contact Roof Guard Roofing\u00a0professionals to help restore your roof back to a safe standard. We cover all areas of Burwood and surrounds and will provide you with a same day free quote on any of our services.",
                                    "url": "https://roofguardroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/contact-us/",
                                            "anchor_text": "contact Roof Guard Roofing"
                                        }
                                    ]
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://roofguardroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofguardroofing.com.au/roof-services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://roofguardroofing.com.au/roof-services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofguardroofing.com.au/roof-services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://roofguardroofing.com.au/roof-services/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "High-Pressure Roof Cleaning",
                                    "url": "https://roofguardroofing.com.au/roof-services/high-pressure-roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/high-pressure-roof-cleaning/",
                                            "anchor_text": "High-Pressure Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting And Sealing",
                                    "url": "https://roofguardroofing.com.au/roof-services/roof-painting-and-sealing/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/roof-painting-and-sealing/",
                                            "anchor_text": "Roof Painting And Sealing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Valley Replacement",
                                    "url": "https://roofguardroofing.com.au/roof-services/roof-valley-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/roof-valley-replacement/",
                                            "anchor_text": "Roof Valley Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://roofguardroofing.com.au/roof-services/gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/gutter-replacement/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Garage & Carport Roofs",
                                    "url": "https://roofguardroofing.com.au/roof-services/garage-carport-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/garage-carport-roofs/",
                                            "anchor_text": "Garage & Carport Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofguardroofing.com.au/roof-services/metal-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/metal-roof-repair/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Carpentry",
                                    "url": "https://roofguardroofing.com.au/roof-services/roof-carpentry/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/roof-carpentry/",
                                            "anchor_text": "Roof Carpentry"
                                        }
                                    ]
                                },
                                {
                                    "text": "Polycarbonate Roofing",
                                    "url": "https://roofguardroofing.com.au/roof-services/polycarbonate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/polycarbonate-roofing/",
                                            "anchor_text": "Polycarbonate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Spin Ventilators (Whirly Birds)",
                                    "url": "https://roofguardroofing.com.au/roof-services/roof-ventilation/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/roof-services/roof-ventilation/",
                                            "anchor_text": "Roof Spin Ventilators (Whirly Birds)"
                                        }
                                    ]
                                },
                                {
                                    "text": "Recent Projects",
                                    "url": "https://roofguardroofing.com.au/recent-projects/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/recent-projects/",
                                            "anchor_text": "Recent Projects"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cost Calculator",
                                    "url": "https://roofguardroofing.com.au/cost-calculator/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/cost-calculator/",
                                            "anchor_text": "Cost Calculator"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofguardroofing.com.au/contact/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/contact/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "03 8738 3451",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Moisture damage",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "At Roof Guard we are so confident in our workmanship and materials that we offer an unprecedented 10 yr signed warranty at the end of every completed project.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Unit 9/14 Concord Cres, Carrum Downs VIC 3201",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a92026 Roof Guard Roofing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "I agree to have my details saved",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Read More",
                                    "url": "https://roofguardroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/about-us/",
                                            "anchor_text": "Read More"
                                        }
                                    ]
                                },
                                {
                                    "text": "03 8738 3451",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Obligation Free Quote",
                                    "url": "https://roofguardroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/contact-us/",
                                            "anchor_text": "Obligation Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cost Calculator",
                                    "url": "https://roofguardroofing.com.au/cost-calculator/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/cost-calculator/",
                                            "anchor_text": "Cost Calculator"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://roofguardroofing.com.au/service-areas/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/service-areas/",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "A rmadale",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/armadale/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/armadale/",
                                            "anchor_text": "A"
                                        },
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/armadale/",
                                            "anchor_text": "rmadale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Aspendale Gardens",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Balwyn North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Bayswater North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Belgrave Heights",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Bentleigh East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Blackburn North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Blackburn South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Black Rock",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/black-rock/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/black-rock/",
                                            "anchor_text": "Black Rock"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Hill",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/box-hill/",
                                            "anchor_text": "Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Hill North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Box Hill South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Brighton East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Burwood East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Carrum Downs",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/carrum-downs/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/carrum-downs/",
                                            "anchor_text": "Carrum Downs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Caulfield East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Caulfield North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Caulfield South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Chelsea Heights",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Chirnside Park",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/chirnside-park/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/chirnside-park/",
                                            "anchor_text": "Chirnside Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Clayton South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Clyde North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Cranbourne East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Cranbourne North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Croydon Hills",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/croydon-hills/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/croydon-hills/",
                                            "anchor_text": "Croydon Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Croydon South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Dandenong North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Dandenong South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Dingley Village",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/dingley-village/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/dingley-village/",
                                            "anchor_text": "Dingley Village"
                                        }
                                    ]
                                },
                                {
                                    "text": "Doncaster East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "East Melbourne",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/east-melbourne/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/east-melbourne/",
                                            "anchor_text": "East Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Endeavour Hills",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/endeavour-hills/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/endeavour-hills/",
                                            "anchor_text": "Endeavour Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ferntree Gully",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/ferntree-gully/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/ferntree-gully/",
                                            "anchor_text": "Ferntree Gully"
                                        }
                                    ]
                                },
                                {
                                    "text": "Forest Hill",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/forest-hill/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/forest-hill/",
                                            "anchor_text": "Forest Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Frankston South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Glen Iris",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/glen-iris/",
                                            "anchor_text": "Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Glen Waverley",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/glen-waverley/",
                                            "anchor_text": "Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hampton East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Hampton Park",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/hampton-park/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/hampton-park/",
                                            "anchor_text": "Hampton Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hawthorn East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Kilsyth South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Lysterfield South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Malvern East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Middle Park",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/middle-park/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/middle-park/",
                                            "anchor_text": "Middle Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mont Albert",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/mont-albert/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/mont-albert/",
                                            "anchor_text": "Mont Albert"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mont Albert North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mount Evelyn",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/mount-evelyn/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/mount-evelyn/",
                                            "anchor_text": "Mount Evelyn"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mount Waverley",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/mount-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/mount-waverley/",
                                            "anchor_text": "Mount Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Narre Warren",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/narre-warren/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/narre-warren/",
                                            "anchor_text": "Narre Warren"
                                        }
                                    ]
                                },
                                {
                                    "text": "Narre Warren North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Narre Warren South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Noble Park",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/noble-park/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/noble-park/",
                                            "anchor_text": "Noble Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Notting Hill",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Oakleigh East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Oakleigh South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Pakenham East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Pakenham South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Pakenham Upper",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Park Orchards",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/park-orchards/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/park-orchards/",
                                            "anchor_text": "Park Orchards"
                                        }
                                    ]
                                },
                                {
                                    "text": "Patterson Lakes",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/patterson-lakes/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/patterson-lakes/",
                                            "anchor_text": "Patterson Lakes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Ringwood East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Ringwood North",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "South Eastern Suburbs",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/south-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/south-eastern-suburbs/",
                                            "anchor_text": "South Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "South Yarra",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/south-yarra/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/south-yarra/",
                                            "anchor_text": "South Yarra"
                                        }
                                    ]
                                },
                                {
                                    "text": "St Kilda",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/st-kilda/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/st-kilda/",
                                            "anchor_text": "St Kilda"
                                        }
                                    ]
                                },
                                {
                                    "text": "St Kilda East",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "St Kilda West",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Surrey Hills",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/surrey-hills/",
                                            "anchor_text": "Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Templestowe Lower",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "The Basin",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/the-basin/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/the-basin/",
                                            "anchor_text": "The Basin"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Patch",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/the-patch/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/the-patch/",
                                            "anchor_text": "The Patch"
                                        }
                                    ]
                                },
                                {
                                    "text": "Upper Ferntree Gully",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Vermont South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Wantirna South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Warrandyte South",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Wheelers Hill",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/wheelers-hill/",
                                            "anchor_text": "Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wonga Park",
                                    "url": "https://roofguardroofing.com.au/areas-we-service/wonga-park/",
                                    "urls": [
                                        {
                                            "url": "https://roofguardroofing.com.au/areas-we-service/wonga-park/",
                                            "anchor_text": "Wonga Park"
                                        }
                                    ]
                                },
                                {
                                    "text": "Designed & Developed by",
                                    "url": "https://stardigital.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://stardigital.com.au/",
                                            "anchor_text": "Designed & Developed by"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Our Roof Restoration Services",
                                "main_title": "Our Roof Restoration Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Whether your roof is made from cement or terracotta, the experts at Roof Guard roofing will help restore it to an excellent condition. The process and services involved in roof restoration include the following:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Inspection \u2013\u00a0A qualified Roof Guard team member meets the client at an arranged time at their Burwood home. We\u2019ll prepare a detailed inspection report from our findings during the roof inspection. We will go over this with you in a way that you can fully understand the terminology. We will decide on a course of action together based on this discussion.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Colour Selection and Painting (for cement roofs) \u2013\u00a0For cement based roofing we supply the client with a colour chart nice and early to ensure we can order your desired paint colour in time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Property Care As We Go \u2013\u00a0We will clean, take all necessary OH&S precautions and care for your property as when your roof is restored and the job is complete, there are no remnants left behind!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Installation of Guard Rail \u2013\u00a0Once we have the go ahead it will be time to book in the restoration. In most cases, the roof will need to be raised so that we can safely and legally start the roof restoration. We will usually get the rail booked in a couple of days before we commence.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replace Broken Tiles \u2013 Before any cleaning or high-pressure cleaning takes place we will remove and replace any broken tiles. We can almost always match the tiles with the exact same replacements.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "High Pressure Cleaning \u2013\u00a0The best way to remove years of dirt, grime and contaminants from your roof. This stage is also important to allow the paint to bond properly to your roof afterwards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Repair Work \u2013\u00a0We\u2019ll take care of things like the renewal of old valley irons, the inspection and repair of all flashings, skylight repairs etc.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bedding & Pointing \u2013\u00a0This often includes the removal of the old mortar and cement work. After old bedding is removed, the new bedding foundation is laid and ridge cappings are put into place with the help of a bedding frame. Once this has dried we apply our flexible pointing compound to all ridge cappings and gable tiles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Final Washdown and Cleanup \u2013\u00a0After the roof repairs and care work is completed but prior to painting is the final washdown where we complete a full blowdown of the roof, and if necessary a secondary rinse with the high pressure washers. This is to remove any remaining debris or foreign matter before we paint your roof. After painting, our final cleanup will include a final inspection of your roof and property and removal of any rubbish and debris from the site.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs in Burwood",
                                "main_title": "Our Roof Restoration Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our roof repair services include like the renewal of old valley irons, the inspection and repair of all flashings, the repairs to any timberwork or tiling on the roof, skylight repairs etc. This work will always be discussed in the inspection stage so that the client knows exactly what work is being completed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Our Roof Restoration Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A roof made from cement, tiles or any other high-quality, durable materials can last well over 50 years depending on how well it is maintained and the weather conditions of its location. A complete roof replacement may be an option for you if:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You\u2019ve purchased an older property and the roofing is significantly worn or made from outdated materials",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You wish to upgrade your roofing by replacing it with a more durable solution",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Your want to replace roofing that\u2019s made from short-life materials like timber or asphalt shingles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Your roof has sustained significant damage that cannot be completely repaired or is far too costly to justify repair over roof replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Your undergoing major renovations or redevelopment of a property or site",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Contact us today to discuss your roof replacement needs or if you\u2019d like to learn whether or not your weathered, old roof is worth repairing.",
                                        "url": "https://roofguardroofing.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofguardroofing.com.au/contact-us/",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Cost Calculator",
                                "main_title": "Our Roof Restoration Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We value transparency and keeping our clients informed. If you\u2019d like to get an estimate of the costs your roof restoration service would incur, you can use our quick and\u00a0easy online cost calculator to get a number!",
                                        "url": "https://roofguardroofing.com.au/cost-calculator/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofguardroofing.com.au/cost-calculator/roof-restoration/",
                                                "anchor_text": "easy online cost calculator"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Next contact us for an inspection a free quote based even more closely on your needs. We appreciate that some services may be of an emergency nature so we accept urgent calls, 24/7.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Workmanship & Materials Guarantee",
                                "main_title": "Our Roof Restoration Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We are proud to say that in our roof restoration and repair services, all materials and workmanship comes with an 8-year guarantee. We can do this because we use only the best products available and we don\u2019t cut corners, we do things right the first time. On the off chance there is a problem with any work completed by us within 8 years, just give us a call and we will rectify the problem straight away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Learn More About Our Roof Restoration Services in Burwood",
                                "main_title": "Our Roof Restoration Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "For any queries you may have regarding our roof restoration or repairs services,\u00a0contact our team today. Our friendly team will be able to help you understand what services may be required for your roof maintenance and provide you with a free quote.",
                                        "url": "https://roofguardroofing.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofguardroofing.com.au/contact-us/",
                                                "anchor_text": "contact"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "You can also get a cost estimate easily by filling out our\u00a0free roof restoration cost calculator online.",
                                        "url": "https://roofguardroofing.com.au/cost-calculator/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofguardroofing.com.au/cost-calculator/roof-restoration/",
                                                "anchor_text": "free roof restoration cost calculator"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "We Also Provide Gutter Replacement & Restoration Services",
                                "main_title": "Our Roof Restoration Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutter damage, in many cases, goes hand in hand with roof damage. Find out more about our gutter services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cost Calculator",
                                        "url": "https://roofguardroofing.com.au/calculators/calculator-landing",
                                        "urls": [
                                            {
                                                "url": "https://roofguardroofing.com.au/calculators/calculator-landing",
                                                "anchor_text": "Cost Calculator"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "03 8738 3451",
                                "03%208738%203451"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}