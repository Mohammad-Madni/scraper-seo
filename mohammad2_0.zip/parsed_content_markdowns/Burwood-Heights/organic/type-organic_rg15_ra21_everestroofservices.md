{
    "id": "01190728-1132-0216-0000-40bf4bfe5016",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0193 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://everestroofservices.com.au/roof-repairs-burwood/",
        "target": "everestroofservices.com.au",
        "start_url": "https://everestroofservices.com.au/roof-repairs-burwood/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-Heights\\organic\\type-organic_rg15_ra21_everestroofservices.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:35 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Your Local Roofing Experts!",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "17 Sydney St",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pressure Cleaning",
                                    "url": "https://everestroofservices.com.au/roof-pressure-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-pressure-cleaning/",
                                            "anchor_text": "Roof Pressure Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://everestroofservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Exterior Cleaning",
                                    "url": "https://everestroofservices.com.au/exterior-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/exterior-cleaning/",
                                            "anchor_text": "Exterior Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Driveway Pressure Wash",
                                    "url": "https://everestroofservices.com.au/driveway-pressure-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/driveway-pressure-cleaning/",
                                            "anchor_text": "Driveway Pressure Wash"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panel Cleaning",
                                    "url": "https://everestroofservices.com.au/solar-panel-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/solar-panel-cleaning/",
                                            "anchor_text": "Solar Panel Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Ashburton",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-ashburton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-ashburton/",
                                            "anchor_text": "Gutter Cleaning Ashburton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Ashwood",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-ashwood/",
                                            "anchor_text": "Gutter Cleaning Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Beaumaris",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-beaumaris/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-beaumaris/",
                                            "anchor_text": "Gutter Cleaning Beaumaris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Bentleigh",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-bentleigh/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-bentleigh/",
                                            "anchor_text": "Gutter Cleaning Bentleigh"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Bentleigh East",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-bentleigh-east/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-bentleigh-east/",
                                            "anchor_text": "Gutter Cleaning Bentleigh East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Brighton",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-brighton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-brighton/",
                                            "anchor_text": "Gutter Cleaning Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Box Hill",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-box-hill/",
                                            "anchor_text": "Gutter Cleaning Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Burwood",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-burwood/",
                                            "anchor_text": "Gutter Cleaning Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Camberwell",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-camberwell/",
                                            "anchor_text": "Gutter Cleaning Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Carnegie",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-carnegie/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-carnegie/",
                                            "anchor_text": "Gutter Cleaning Carnegie"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Caulfield",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-caulfield/",
                                            "anchor_text": "Gutter Cleaning Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Chadstone",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-chadstone/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-chadstone/",
                                            "anchor_text": "Gutter Cleaning Chadstone"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Cheltenham",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-cheltenham/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-cheltenham/",
                                            "anchor_text": "Gutter Cleaning Cheltenham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Clayton",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-clayton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-clayton/",
                                            "anchor_text": "Gutter Cleaning Clayton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Glen Iris",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-glen-iris/",
                                            "anchor_text": "Gutter Cleaning Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Glen Waverley",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-glen-waverley/",
                                            "anchor_text": "Gutter Cleaning Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Hampton",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-hampton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-hampton/",
                                            "anchor_text": "Gutter Cleaning Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Malvern",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-malvern/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-malvern/",
                                            "anchor_text": "Gutter Cleaning Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Malvern East",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-malvern-east/",
                                            "anchor_text": "Gutter Cleaning Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Mentone",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-mentone/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-mentone/",
                                            "anchor_text": "Gutter Cleaning Mentone"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Mount Waverley",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-mount-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-mount-waverley/",
                                            "anchor_text": "Gutter Cleaning Mount Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Mulgrave",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-mulgrave/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-mulgrave/",
                                            "anchor_text": "Gutter Cleaning Mulgrave"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Murrumbeena",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-murrumbeena/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-murrumbeena/",
                                            "anchor_text": "Gutter Cleaning Murrumbeena"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Notting Hill",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-notting-hill/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-notting-hill/",
                                            "anchor_text": "Gutter Cleaning Notting Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Oakleigh",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-oakleigh/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-oakleigh/",
                                            "anchor_text": "Gutter Cleaning Oakleigh"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Ormond",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-ormond/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-ormond/",
                                            "anchor_text": "Gutter Cleaning Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Sandringham",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-sandringham/",
                                            "anchor_text": "Gutter Cleaning Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Springvale",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-springvale/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-springvale/",
                                            "anchor_text": "Gutter Cleaning Springvale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Surrey Hills",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-surrey-hills/",
                                            "anchor_text": "Gutter Cleaning Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning Wheelers Hill",
                                    "url": "https://everestroofservices.com.au/gutter-cleaning-wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/gutter-cleaning-wheelers-hill/",
                                            "anchor_text": "Gutter Cleaning Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Ashburton",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-ashburton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-ashburton/",
                                            "anchor_text": "Roof Cleaning Ashburton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Ashwood",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-ashwood/",
                                            "anchor_text": "Roof Cleaning Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Beaumaris",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-beaumaris/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-beaumaris/",
                                            "anchor_text": "Roof Cleaning Beaumaris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Bentleigh",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-bentleigh/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-bentleigh/",
                                            "anchor_text": "Roof Cleaning Bentleigh"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Bentleigh East",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-bentleigh-east/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-bentleigh-east/",
                                            "anchor_text": "Roof Cleaning Bentleigh East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Box Hill",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-box-hill/",
                                            "anchor_text": "Roof Cleaning Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Brighton",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-brighton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-brighton/",
                                            "anchor_text": "Roof Cleaning Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Burwood",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-burwood/",
                                            "anchor_text": "Roof Cleaning Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Camberwell",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-camberwell/",
                                            "anchor_text": "Roof Cleaning Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Carnegie",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-carnegie/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-carnegie/",
                                            "anchor_text": "Roof Cleaning Carnegie"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Caulfield",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-caulfield/",
                                            "anchor_text": "Roof Cleaning Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Chadstone",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-chadstone/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-chadstone/",
                                            "anchor_text": "Roof Cleaning Chadstone"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Cheltenham",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-cheltenham/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-cheltenham/",
                                            "anchor_text": "Roof Cleaning Cheltenham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Clayton",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-clayton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-clayton/",
                                            "anchor_text": "Roof Cleaning Clayton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Glen Iris",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-glen-iris/",
                                            "anchor_text": "Roof Cleaning Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Glen Waverley",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-glen-waverley/",
                                            "anchor_text": "Roof Cleaning Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Hampton",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-hampton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-hampton/",
                                            "anchor_text": "Roof Cleaning Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Malvern",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-malvern/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-malvern/",
                                            "anchor_text": "Roof Cleaning Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Malvern East",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-malvern-east/",
                                            "anchor_text": "Roof Cleaning Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Mentone",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-mentone/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-mentone/",
                                            "anchor_text": "Roof Cleaning Mentone"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Mount Waverley",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-mount-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-mount-waverley/",
                                            "anchor_text": "Roof Cleaning Mount Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Mulgrave",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-mulgrave/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-mulgrave/",
                                            "anchor_text": "Roof Cleaning Mulgrave"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Murrumbeena",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-murrumbeena/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-murrumbeena/",
                                            "anchor_text": "Roof Cleaning Murrumbeena"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Notting Hill",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-notting-hill/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-notting-hill/",
                                            "anchor_text": "Roof Cleaning Notting Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Ormond",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-ormond/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-ormond/",
                                            "anchor_text": "Roof Cleaning Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Oakleigh",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-oakleigh/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-oakleigh/",
                                            "anchor_text": "Roof Cleaning Oakleigh"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Sandringham",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-sandringham/",
                                            "anchor_text": "Roof Cleaning Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Springvale",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-springvale/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-springvale/",
                                            "anchor_text": "Roof Cleaning Springvale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Surrey Hills",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-surrey-hills/",
                                            "anchor_text": "Roof Cleaning Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Wheelers Hill",
                                    "url": "https://everestroofservices.com.au/roof-cleaning-wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-cleaning-wheelers-hill/",
                                            "anchor_text": "Roof Cleaning Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ashburton",
                                    "url": "https://everestroofservices.com.au/roof-repairs-ashburton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-ashburton/",
                                            "anchor_text": "Roof Repairs Ashburton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ashwood",
                                    "url": "https://everestroofservices.com.au/roof-repairs-ashwood/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-ashwood/",
                                            "anchor_text": "Roof Repairs Ashwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Bentleigh",
                                    "url": "https://everestroofservices.com.au/roof-repairs-bentleigh/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-bentleigh/",
                                            "anchor_text": "Roof Repairs Bentleigh"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Bentleigh East",
                                    "url": "https://everestroofservices.com.au/roof-repairs-bentleigh-east/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-bentleigh-east/",
                                            "anchor_text": "Roof Repairs Bentleigh East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Beaumaris",
                                    "url": "https://everestroofservices.com.au/roof-repairs-beaumaris/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-beaumaris/",
                                            "anchor_text": "Roof Repairs Beaumaris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Box Hill",
                                    "url": "https://everestroofservices.com.au/roof-repairs-box-hill/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-box-hill/",
                                            "anchor_text": "Roof Repairs Box Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Brighton",
                                    "url": "https://everestroofservices.com.au/roof-repairs-brighton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-brighton/",
                                            "anchor_text": "Roof Repairs Brighton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Burwood",
                                    "url": "https://everestroofservices.com.au/roof-repairs-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-burwood/",
                                            "anchor_text": "Roof Repairs Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Camberwell",
                                    "url": "https://everestroofservices.com.au/roof-repairs-camberwell/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-camberwell/",
                                            "anchor_text": "Roof Repairs Camberwell"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Carnegie",
                                    "url": "https://everestroofservices.com.au/roof-repairs-carnegie/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-carnegie/",
                                            "anchor_text": "Roof Repairs Carnegie"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Caulfield",
                                    "url": "https://everestroofservices.com.au/roof-repairs-caulfield/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-caulfield/",
                                            "anchor_text": "Roof Repairs Caulfield"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Chadstone",
                                    "url": "https://everestroofservices.com.au/roof-repairs-chadstone/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-chadstone/",
                                            "anchor_text": "Roof Repairs Chadstone"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Cheltenham",
                                    "url": "https://everestroofservices.com.au/roof-repairs-cheltenham/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-cheltenham/",
                                            "anchor_text": "Roof Repairs Cheltenham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Clayton",
                                    "url": "https://everestroofservices.com.au/roof-repairs-clayton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-clayton/",
                                            "anchor_text": "Roof Repairs Clayton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Glen Iris",
                                    "url": "https://everestroofservices.com.au/roof-repairs-glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-glen-iris/",
                                            "anchor_text": "Roof Repairs Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Glen Waverley",
                                    "url": "https://everestroofservices.com.au/roof-repairs-glen-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-glen-waverley/",
                                            "anchor_text": "Roof Repairs Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Hampton",
                                    "url": "https://everestroofservices.com.au/roof-repairs-hampton/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-hampton/",
                                            "anchor_text": "Roof Repairs Hampton"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Oakleigh",
                                    "url": "https://everestroofservices.com.au/roof-repairs-oakleigh/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-oakleigh/",
                                            "anchor_text": "Roof Repairs Oakleigh"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Malvern",
                                    "url": "https://everestroofservices.com.au/roof-repairs-malvern/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-malvern/",
                                            "anchor_text": "Roof Repairs Malvern"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Malvern East",
                                    "url": "https://everestroofservices.com.au/roof-repairs-malvern-east/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-malvern-east/",
                                            "anchor_text": "Roof Repairs Malvern East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Mentone",
                                    "url": "https://everestroofservices.com.au/roof-repairs-mentone/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-mentone/",
                                            "anchor_text": "Roof Repairs Mentone"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Mount Waverley",
                                    "url": "https://everestroofservices.com.au/roof-repairs-mount-waverley/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-mount-waverley/",
                                            "anchor_text": "Roof Repairs Mount Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Mulgrave",
                                    "url": "https://everestroofservices.com.au/roof-repairs-mulgrave/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-mulgrave/",
                                            "anchor_text": "Roof Repairs Mulgrave"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Murrumbeena",
                                    "url": "https://everestroofservices.com.au/roof-repairs-murrumbeena/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-murrumbeena/",
                                            "anchor_text": "Roof Repairs Murrumbeena"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Notting Hill",
                                    "url": "https://everestroofservices.com.au/roof-repairs-notting-hill/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-notting-hill/",
                                            "anchor_text": "Roof Repairs Notting Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Ormond",
                                    "url": "https://everestroofservices.com.au/roof-repairs-ormond/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-ormond/",
                                            "anchor_text": "Roof Repairs Ormond"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Sandringham",
                                    "url": "https://everestroofservices.com.au/roof-repairs-sandringham/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-sandringham/",
                                            "anchor_text": "Roof Repairs Sandringham"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Surrey Hills",
                                    "url": "https://everestroofservices.com.au/roof-repairs-surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-surrey-hills/",
                                            "anchor_text": "Roof Repairs Surrey Hills"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Springvale",
                                    "url": "https://everestroofservices.com.au/roof-repairs-springvale/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-springvale/",
                                            "anchor_text": "Roof Repairs Springvale"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Wheelers Hill",
                                    "url": "https://everestroofservices.com.au/roof-repairs-wheelers-hill/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/roof-repairs-wheelers-hill/",
                                            "anchor_text": "Roof Repairs Wheelers Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Work",
                                    "url": "https://everestroofservices.com.au/our-work/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/our-work/",
                                            "anchor_text": "Our Work"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://everestroofservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://everestroofservices.com.au/contact/",
                                    "urls": [
                                        {
                                            "url": "https://everestroofservices.com.au/contact/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "17 Sydney St",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Copyright \u00a9 2025 All Rights Reserved by Everest Roof Services Pty Ltd | ACN: 46 662 311 873",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Everest Roof Services is a local roofing business based in Murrumbeena, VIC 3163.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Serving Melbourne\u2019s inner South Eastern Suburbs.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "More About Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Book an Inspection",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Free Quotes",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Request a Callback",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "17 Sydney St,",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Murrumbeena VIC 3163",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "0424 853 545",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "09:00 AM to 07:00 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Google Rating",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "When a roof starts leaking, every second matters. Water infiltrates your home, causing damage to ceilings, walls, and all your precious belongings. At Everest Roof Services, we recognise the urgency of the situation. That's why we deliver quick, dependable roof repairs across Burwood and the surrounding suburbs. Our local team is ready to assist you, whether you require a simple fix for a broken tile or a comprehensive roof restoration.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get your free quote today!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With over 15 years of industry experience, we\u2019ve encountered every roofing issue imaginable. Our licensed and insured roofers possess the tools and expertise to handle any roof leak repair, regardless of size. We work with all types of roofs, from traditional terracotta tiles to contemporary Colorbond steel. No matter the material or the challenge, we\u2019ll develop the optimal solution for your home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Thorough Roof Leak Repairs in Your Area",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A leaking roof is more than just an annoyance. If left unaddressed, it can lead to significant structural damage and even health hazards like mould growth. Our comprehensive roof leak repair services include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter and downpipe fixes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We begin every job with a meticulous inspection, identifying the source of the leak and any other potential problems. Then, we present a transparent, upfront quote with no hidden fees. Our team works efficiently to repair your roof, minimising disruption to your daily routine.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Broken tile replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rebedding and repointing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flashing repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Valley iron replacement",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What\u2019s the Cost to Replace Broken Roof Tiles?",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The cost of replacing broken roof tiles depends on factors like the extent of the damage and the type of tiles. As a rough guide, anticipate paying around $250 to $500 per square metre for tile replacement. However, identifying problems early can often mean a simple repair instead of a full replacement. That\u2019s where our complimentary roof inspections come in handy.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Everest Roof Services",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Everest Roof Services provides a wide range of services including roof repairs, gutters, downpipes, rainwater tanks, water tanks, skylights, window washing, pool cleaning, deck cleaning, pressure washing, driveway cleaning, fence painting, power washing, siding cleaning, concrete cleaning, brick cleaning, tiling cleaning, and so much more!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We offer competitive pricing and guarantee our workmanship. We also provide free estimates. Call us today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "The Everest Roof Services Difference: Why Choose Us?",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "What sets Everest Roof Services apart? It\u2019s our dedication to excellence and customer satisfaction. When you choose us for your Burwood roof repairs, you get:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast response times, 7 days a week",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Experienced, licensed, and insured roofers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "High-quality materials and workmanship",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We take pride in our 5-star rating on Google and our reputation as Melbourne\u2019s go-to roofing contractor. Our team treats every home as if it were their own, going above and beyond to ensure a job well done.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Free, no-obligation quotes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "100% satisfaction guarantee",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How Our Experts Replace a Broken Roof Tile",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "While DIY tile replacement might be tempting, it\u2019s best left to the professionals. Climbing on a roof can be dangerous, and improper repairs can lead to bigger problems down the line. Our seasoned roofers follow a proven process:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Remove the damaged tile carefully to avoid cracking surrounding tiles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clear away any debris and check for underlying damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Install a new tile, ensuring a snug fit.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Secure the tile with roofing nails or clips.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Apply fresh bedding and pointing for a weatherproof seal.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With Everest Roof Services, you can trust that your roof repairs will be done right the first time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "The Benefits of Choosing Everest Roof Services",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "15+ years of roofing experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Family-owned and operated business",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully licensed and insured",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free inspections and quotes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast, reliable service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "5-star rating on Google",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Don\u2019t allow a leaking roof to cause further damage to your Burwood home. Contact Everest Roof Services today for fast, dependable roof repairs. Call us on 0424 853 545 or request a free quote online. We\u2019re here to help, come rain or shine.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "100% satisfaction guarantee",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Book Your Inspection",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Get your free quote and professional service today. Our experts are ready to help!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Reason For\nPeople Choosing Everest\nRoof Services",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Fast Response Time",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "100% Satisfaction Guarantee",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully Insuyred & Licensed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free Inspections",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Affordable Rates",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 Days a Week",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ready to book your service?",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We also provide following services in Burwood",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Other suburbs we provide Roof Repairs",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Need our services in a different area?",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ready to book your service?",
                                "main_title": "Roof Repairs Burwood: Fast, Reliable Service from Your Local Roofing Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0424 853 545",
                                "0424853545"
                            ],
                            "emails": [
                                "info@everestroofservices.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}