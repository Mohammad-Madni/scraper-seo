{
    "id": "01190728-1132-0216-0000-c20608ef06b0",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0196 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrepairsstrathfield.com.au/in/burwood-heights/",
        "target": "roofrepairsstrathfield.com.au",
        "start_url": "https://roofrepairsstrathfield.com.au/in/burwood-heights/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-Heights\\organic\\type-organic_rg14_ra20_roofrepairsstrathfield.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:29 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsstrathfield.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsstrathfield.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsstrathfield.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "We Take Care Of Your Roof",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Burwood Heights is a stunning city, and you are worthy of the best roof for your home or business. Nevertheless, extreme weather can be tough on your roof and cause it to deteriorate in time. Whether you need a new roof or repairs for an existing one, Roof Repairs Burwood Heights is here to help you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With years of experience in repair and installation, our team of certified experts are professionals in doing the job right the first time. We provide a wide variety of services to guarantee your roof is safe and protected. From minor repairs, such as replacing tiles or fixing leakages, to more involved projects, like total replacements or re-roofing, our professionals will work with you to help determine the best solution for your property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We understand the significance of having a reliable and secure roof over your head, which is why we aim to offer quality workmanship and exceptional customer support. Our team of knowledgeable experts takes pride in their work and uses only the highest-quality products for all our projects. We are also happy to go over any unique demands or concerns you might have and offer useful recommendations throughout the process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter what kind of roofing needs you have, Roof Repairs Burwood Heights is here to help. Contact our team today, and let us be the ones to fix your roof!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Colorbond roofing is a popular option for both residential and industrial properties. Our team of knowledgeable experts is trained in the installation of colorbond roofing and uses the highest-quality products to guarantee your roof looks its finest.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing Contractors Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Whether you need a total replacement or repairs for an existing roof, our team of certified experts can help. We understand that a minor interruption in company can be expensive. We work around your schedule to minimize downtime, which includes weekends and/or evenings if required.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing Contractors Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We understand that emergencies can take place anytime and require quick action to minimize damage. Our team of knowledgeable experts is available 24/7 to offer fast and reliable emergency roof repair services. From minor repairs to more substantial work, we can be counted on to get the job done right.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Emergency Roof Repairs Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Heights Roof and Gutter",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Regular maintenance of your roof and gutter is important in making sure that it remains in good condition. Our team of equipped experts offers numerous services, such as cleaning and repairs, to keep your gutters working effectively and help extend the life of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Burwood Heights Roof and Gutter",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Burwood Heights Roof and Gutter"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Let our team of certified experts help you assess the condition of your roof. We\u2019ll offer an extensive inspection to identify roof issues and accurately recommend affordable options. We offer a in-depth report of our findings, which can then be utilized to plan any required repairs or replacements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Inspections Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Roof Repairs Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Do not let a little leak develop into a larger issue. We use the most recent leak detection strategies to identify and repair any issues properly. They include water tests, thermal imaging, and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Leaking Roof Repairs Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of licensed experts is can install all roofing materials, including metal roofs, slate roofs, solar roofs, tile roofs, and more. our company believe in quality workmanship and use only the highest-quality products to guarantee your roof is strong and secure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Installation Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal roofs are becoming considerably popular due to their sturdiness, low maintenance, and energy efficiency. We handle various type of metal roofing, from corrugated to standing seam, and numerous color options. Furthermore, we can install soaker panels and other add-ons for a more custom look.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of knowledgeable experts can offer a full roof replacement service if your roof is beyond repair. We\u2019ll help you select the right product, size, and shape to match your residential or commercial property and spending plan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Heights Roof Restoration",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roof Repairs Burwood Heights, our company believe in preserving existing structures wherever possible rather than replacing them. We use the most recent products and strategies to extend the life of your roof while bearing in mind its historical worth and character.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Burwood Heights Roof Restoration",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                                "anchor_text": "Burwood Heights Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We provide numerous services for residential and industrial properties in Burwood Heights, varying from minor repairs to full-scale installations. Whether it\u2019s metal or tile roofs, skylights, or solar panels\u2013 our knowledgeable team will offer quality remedies that meet your requirements and spending plan. We deal with every little thing from start to finish and offer exceptional customer support throughout the whole process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roofing/",
                                                "anchor_text": "Roofing Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Skylights Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Skylights are among the most popular elements of a home, supplying natural light and ventilation. Our team of certified experts can install residential and office skylights, from standard systems to custom designs. We also provide repair solutions, including replacing damaged seals and frames.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Skylights Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/skylights/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/skylights/",
                                                "anchor_text": "Skylights Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tilers Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Tiling is a specialized job that requires understanding, skill, and experience\u2013 all of which our team has in abundance. We offer setup and repairs for slate, terracotta, metal, concrete tiles, and all types of roof accessories.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Tilers Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Repairs Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Slate roofs are a popular option for heritage houses due to their lasting sturdiness and timeless look. We comprehend the significance of preserving a structure\u2019s initial character and can help you with all your slate roof repair requirements. Our knowledgeable specialists use only the highest-quality products to restore your roof to its former glory.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Slate Roof Repairs Burwood Heights",
                                        "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We understand that some Burwood Heights locals might not have the ability to afford a roof repair or installation. Considering that our desire is to help everyone, we provide a unique discount program for qualified Burwood Heights locals. With our Burwood Heights Discount Roof Repair program, you can get the repairs or installations you need at a lower expense.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019re proud to be part of the Burwood Heights community and do all we can to help our neighbors. It doesn\u2019t matter if you need a easy repair or a full roof replacement; our knowledgeable experts are here to help.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our 100% satisfaction guarantee backs every job we do. We back up all of our work and will not rest till you\u2019re totally happy with the end results. From when you first contact us to when we finish the job, you can count on our team for exceptional service and workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A reliable and secure roof is among the most important financial investments in your life. That\u2019s why when it concerns repair or installation, you can count on the experts at Roof Repairs Burwood Heights for quality service and workmanship.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We proudly serve: Ashfield, Haberfield, Ashbury, Croydon, Canterbury, Rodd Point, Croydon Park, Five Dock, Burwood Heights, Russell Lea and Summer Hill",
                                        "url": "https://roofrepairsstrathfield.com.au/in/ashfield/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/ashfield/",
                                                "anchor_text": "Ashfield"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/haberfield/",
                                                "anchor_text": "Haberfield"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/ashbury/",
                                                "anchor_text": "Ashbury"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/croydon/",
                                                "anchor_text": "Croydon"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/canterbury/",
                                                "anchor_text": "Canterbury"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/rodd-point/",
                                                "anchor_text": "Rodd Point"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/croydon-park/",
                                                "anchor_text": "Croydon Park"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/five-dock/",
                                                "anchor_text": "Five Dock"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/burwood-heights/",
                                                "anchor_text": "Burwood Heights"
                                            },
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/in/russell-lea/",
                                                "anchor_text": "Russell Lea"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Our website connects you with skilled local roofing contractors servicing most Strathfield suburb, including Rookwood, Burwood, and Belfield. With extensive experience in the industry, our roofers are experts in maintaining and enhancing both tile and metal roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Are You Waiting For?",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A reliable and secure roof is one of the most important investments in your life. That\u2019s why when it comes to repair or installation, you can count on the professionals at Roof Repairs Burwood Heights for quality service and workmanship. Call us now!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Talk to us today about roofing services for your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "GET IN TOUCH",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repairs Burwood Heights Services",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What we offer",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We offer a wide variety of services, consisting of:",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Heights Discount Roof Repair",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Summer Hill, New South Wales",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "For more information about Summer Hill, New South Wales",
                                        "url": "https://en.wikipedia.org/wiki/Summer%20Hill,_New%20South%20Wales",
                                        "urls": [
                                            {
                                                "url": "https://en.wikipedia.org/wiki/Summer%20Hill,_New%20South%20Wales",
                                                "anchor_text": "For more information about Summer Hill, New South Wales"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Google News:",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Latest Summer Hill News",
                                        "url": "https://news.google.com/search?q=Summer%20Hill,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                        "urls": [
                                            {
                                                "url": "https://news.google.com/search?q=Summer%20Hill,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                                "anchor_text": "Latest Summer Hill News"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Links",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Us",
                                        "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/about-us/",
                                                "anchor_text": "About Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our Services",
                                        "url": "https://roofrepairsstrathfield.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/",
                                                "anchor_text": "Our Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Info",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing",
                                        "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roofing Contractors",
                                        "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof and Gutter",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Roof and Gutter"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof Repairs",
                                        "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tilers",
                                        "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slate Roof Repairs",
                                        "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "&copy 2025 Roof Repairs Strathfield",
                                "main_title": "Roof Repairs Burwood Heights - #1 Roofing Company in Burwood Heights",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "&copy 2025 Roof Repairs Strathfield",
                                        "url": "https://roofrepairsstrathfield.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsstrathfield.com.au/",
                                                "anchor_text": "Roof Repairs Strathfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "http://roofrepairsstrathfield.com.au/privacy-policy/",
                                        "urls": [
                                            {
                                                "url": "http://roofrepairsstrathfield.com.au/privacy-policy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms & Conditions",
                                        "url": "http://roofrepairsstrathfield.com.au/terms-and-conditions/",
                                        "urls": [
                                            {
                                                "url": "http://roofrepairsstrathfield.com.au/terms-and-conditions/",
                                                "anchor_text": "Terms & Conditions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 8403 0759",
                                "(02)%208403%200759"
                            ],
                            "emails": [
                                "info@roofrepairsstrathfield.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}