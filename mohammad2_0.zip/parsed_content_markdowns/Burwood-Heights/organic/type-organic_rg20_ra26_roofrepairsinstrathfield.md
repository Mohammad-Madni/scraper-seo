{
    "id": "01190728-1132-0216-0000-fac9a99576a6",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0292 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrepairsinstrathfield.com.au/in/burwood-heights/",
        "target": "roofrepairsinstrathfield.com.au",
        "start_url": "https://roofrepairsinstrathfield.com.au/in/burwood-heights/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-Heights\\organic\\type-organic_rg20_ra26_roofrepairsinstrathfield.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:25 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "We Take Care Of Your Roof",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Burwood Heights is a gorgeous city, and you deserve the very best roof for your home or business. Nevertheless, extreme weather conditions can be tough on your roof and trigger it to degrade gradually. Whether you require a new roof or repairs for an existing one, Roofing Today Burwood Heights is here to help you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With years of experience in repair and installation, our team of qualified professionals are professionals in finishing the job right the first time. We provide a large range of services to ensure your roof is safe and protected. From small repairs, such as replacing tiles or fixing leaks, to more involved projects, like complete replacements or re-roofing, our professionals will work with you to help identify the very best solution for your home.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We understand the importance of having a trustworthy and secure roof over your head, which is why we make every effort to offer quality workmanship and exceptional customer service. Our team of knowledgeable professionals takes pride in their work and uses only the highest-quality materials for all our projects. We are also happy to talk about any special demands or concerns you might have and offer practical suggestions throughout the process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter what type of roofing needs you have, Roofing Today Burwood Heights is here to help. Contact our team today, and let us be the ones to repair your roof!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Colorbond roofing is a popular choice for both domestic and commercial properties. Our group of knowledgeable professionals is trained in the installation of colorbond roofing and uses the highest-quality materials to ensure your roof looks its best.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing Contractors Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Whether you require a complete replacement or repairs for an existing roof, our team of qualified professionals can help. We understand that a minor disruption in company can be expensive. We work around your schedule to lessen downtime, which includes weekends and/or evenings if needed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing Contractors Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We understand that emergency situations can occur anytime and need fast action to lessen damage. Our team of knowledgeable professionals is available 24/7 to offer fast and trustworthy emergency roof repair services. From small repairs to more extensive work, we can be depended on to do the job right.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Emergency Roof Repairs Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Heights Roof and Gutter",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Routine maintenance of your roof and gutter is important in making sure that it stays in good condition. Our team of trained professionals provides numerous services, such as cleaning and repairs, to keep your gutters working properly and help prolong the life of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Burwood Heights Roof and Gutter",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Burwood Heights Roof and Gutter"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Let our team of qualified professionals help you assess the condition of your roof. We\u2019ll offer an in-depth inspection to diagnose roof issues and precisely suggest cost-effective options. We offer a in-depth report of our findings, which can then be used to prepare any necessary repairs or replacements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Inspections Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Roof Repairs Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Don\u2019t let a little leak turn into a bigger issue. We utilize the latest leak detection techniques to diagnose and repair any issues precisely. They include water tests, thermal imaging, and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Leaking Roof Repairs Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of licensed professionals is can install all roofing materials, including metal roofs, slate roofs, solar roofs, tile roofs, and more. we believe in quality workmanship and use only the highest-quality materials to ensure your roof is strong and secure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Installation Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal roofs are becoming increasingly popular due to their toughness, low maintenance, and energy efficiency. We deal with different type of metal roofing, from corrugated to standing seam, and multiple color options. Additionally, we can install soaker panels and other add-ons for a more custom-made appearance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of knowledgeable professionals can offer a full roof replacement service if your roof is beyond repair. We\u2019ll help you choose the right product, size, and shape to match your property and budget plan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Heights Roof Restoration",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roofing Today Burwood Heights, we believe in protecting existing structures wherever possible instead of replacing them. We utilize the latest materials and techniques to extend the life of your roof while bearing in mind its historical worth and character.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Burwood Heights Roof Restoration",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                                "anchor_text": "Burwood Heights Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We provide numerous services for residential and commercial properties in Burwood Heights, ranging from small repairs to full-scale installations. Whether it\u2019s metal or tile roofs, skylights, or solar panels\u2013 our knowledgeable team will offer quality remedies that fulfill your needs and budget plan. We deal with every little thing from start to finish and offer exceptional customer service throughout the entire process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roofing/",
                                                "anchor_text": "Roofing Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Skylights Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Skylights are amongst the most popular components of a home, offering natural light and ventilation. Our team of qualified professionals can install residential and commercial skylights, from basic units to custom-made styles. We also provide repair options, including replacing broken seals and frames.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Skylights Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/skylights/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/skylights/",
                                                "anchor_text": "Skylights Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tilers Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Tiling is a specialized job that requires understanding, skill, and experience\u2013 all of which our team has in abundance. We offer setup and repairs for slate, terracotta, metal, concrete tiles, and all types of roof accessories.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Tilers Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Repairs Burwood Heights",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Slate roofs are a popular choice for heritage homes due to their lasting toughness and timeless appearance. We comprehend the importance of protecting a structure\u2019s initial character and can help you with all your slate roof repair needs. Our knowledgeable professionals utilize only the highest-quality materials to restore your roof to its former glory.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Slate Roof Repairs Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Burwood Heights\u200b",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We understand that some Burwood Heights homeowners might not be able to afford a roof repair or installation. Because our desire is to help everybody, we provide a special discount program for qualified Burwood Heights homeowners. With our Burwood Heights Discount Roof Repair program, you can get the repairs or installations you require at a lower expense.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019re proud to be part of the Burwood Heights community and do all we can to help our neighbors. It doesn\u2019t matter if you require a basic repair or a full roof replacement; our knowledgeable professionals are here to help.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our 100% satisfaction guarantee backs every job we do. We support all of our work and won\u2019t rest until you\u2019re completely happy with the end results. From when you initially contact us to when we finish the job, you can rely on our team for exceptional service and workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A trustworthy and secure roof is among the most important financial investments in your life. That\u2019s why when it concerns repair or installation, you can rely on the professionals at Roofing Today Burwood Heights for quality service and workmanship.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We proudly serve: Enfield, Croydon Park, Croydon, Burwood, Ashbury, Strathfield South, Strathfield, Ashfield, Belfield, Campsie and Burwood Heights",
                                        "url": "https://roofrepairsinstrathfield.com.au/in/enfield/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/enfield/",
                                                "anchor_text": "Enfield"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/croydon-park/",
                                                "anchor_text": "Croydon Park"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/croydon/",
                                                "anchor_text": "Croydon"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/burwood/",
                                                "anchor_text": "Burwood"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/ashbury/",
                                                "anchor_text": "Ashbury"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/strathfield-south/",
                                                "anchor_text": "Strathfield South"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/strathfield/",
                                                "anchor_text": "Strathfield"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/ashfield/",
                                                "anchor_text": "Ashfield"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/belfield/",
                                                "anchor_text": "Belfield"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/campsie/",
                                                "anchor_text": "Campsie"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Burwood Heights\u200b",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We at Roofing Today Burwood Heights are the roof experts! We can fix any type of roof from flat roofs to gabled roofs and everything in between. Contact us today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Are You Waiting For?",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A reliable and secure roof is one of the most important investments in your life. That\u2019s why when it comes to repair or installation, you can count on the professionals at Roofing Today Burwood Heights for quality service and workmanship. Call us now!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Burwood Heights\u200b",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Talk to us today about roofing services for your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "GET IN TOUCH",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repairs Burwood Heights Services",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What we offer",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We offer a large range of services, including:",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Heights Discount Roof Repair",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Heights, New South Wales",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "For more information about Burwood Heights, New South Wales",
                                        "url": "https://en.wikipedia.org/wiki/Burwood%20Heights,_New%20South%20Wales",
                                        "urls": [
                                            {
                                                "url": "https://en.wikipedia.org/wiki/Burwood%20Heights,_New%20South%20Wales",
                                                "anchor_text": "For more information about Burwood Heights, New South Wales"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Google News:",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Latest Burwood Heights News",
                                        "url": "https://news.google.com/search?q=Burwood%20Heights,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                        "urls": [
                                            {
                                                "url": "https://news.google.com/search?q=Burwood%20Heights,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                                "anchor_text": "Latest Burwood Heights News"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Links",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Us",
                                        "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                                "anchor_text": "About Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our Services",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/",
                                                "anchor_text": "Our Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roofing Contractors",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof and Gutter",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Roof and Gutter"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof Repairs",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tilers",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slate Roof Repairs",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Info",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "ROOFING TODAY",
                                        "url": "https://maps.app.goo.gl/mouDDnPwo7U3eevt6",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/mouDDnPwo7U3eevt6",
                                                "anchor_text": "ROOFING TODAY\n1/19 Dick St,Henley NSW 2111\n(02) 8261 0051"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1/19 Dick St,",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Henley NSW 2111",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 8261 0051",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Email Us",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "[email\u00a0protected]",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "[email\u00a0protected]",
                                        "url": "https://roofrepairsinstrathfield.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "&copy 2022 Roofing Today Strathfield",
                                "main_title": "Roof Repairs Burwood Heights\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "&copy 2022 Roofing Today Strathfield",
                                        "url": "https://roofrepairsinstrathfield.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/",
                                                "anchor_text": "Roofing Today Strathfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://roofrepairsinstrathfield.com.au/privacy-policy/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/privacy-policy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms & Conditions",
                                        "url": "https://roofrepairsinstrathfield.com.au/terms-and-conditions/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/terms-and-conditions/",
                                                "anchor_text": "Terms & Conditions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 8261 0051",
                                "(02)%208261%200051"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}