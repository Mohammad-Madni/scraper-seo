{
    "id": "01190728-1132-0216-0000-1bf48346a835",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0205 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrepairsburwood.com.au/",
        "target": "roofrepairsburwood.com.au",
        "start_url": "https://roofrepairsburwood.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-Heights\\organic\\type-organic_rg13_ra19_roofrepairsburwood.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:28 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsburwood.com.au/roof-restoration-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsburwood.com.au/roof-restoration-burwood/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsburwood.com.au/roof-replacement-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsburwood.com.au/roof-replacement-burwood/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://roofrepairsburwood.com.au/roof-plumbing-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsburwood.com.au/roof-plumbing-burwood/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://roofrepairsburwood.com.au/roof-painting-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsburwood.com.au/roof-painting-burwood/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsburwood.com.au/roof-restoration-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsburwood.com.au/roof-restoration-burwood/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsburwood.com.au/roof-replacement-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsburwood.com.au/roof-replacement-burwood/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://roofrepairsburwood.com.au/roof-plumbing-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsburwood.com.au/roof-plumbing-burwood/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://roofrepairsburwood.com.au/roof-painting-burwood/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsburwood.com.au/roof-painting-burwood/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "We'll give you a hand",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Disclaimer: The content on TMR Roof Repairs Burwood website serves general informational purposes. While efforts are made for accuracy, we assume no liability for reliance on this information. External links are provided for convenience, and we do not endorse or control the content on those sites.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Address: 301 Burwood Hwy, Burwood VIC 3125",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "TMR Roof Repairs Burwood brings over 20 years of professional experience in roof repair and plumbing services across Burwood and surrounding areas. As a trusted member of the TMR Roofing Group, our dedicated team ensures reliable, high-quality solutions for every roofing project, from minor repairs to full-scale maintenance.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Fancy a Roof Service?",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Open 24 hours a day, 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Phone: 0468 017 100",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email: tmr@roofrepairsburwood.com.au",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Open: 24/7",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://roofrepairsburwood.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsburwood.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "ROOF REPAIRS BURWOOD",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Local Burwood roofing specialists providing reliable residential and commercial roofing services across Burwood and surrounding suburbs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium-Grade Tools & High Quality Materials",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Trustworthy Worksmanship With Attention-to-Detail",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Extensive Warranty Options Available",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Capable of Large/ Industrial Sized Jobs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "TRUSTED LOCAL ROOFERS",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully Insured & Police-Checked",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For more urgent roof enquiries, give us a bell at 0468-017-100",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "COMMITMENT TO QUALITY",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Effortless",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Book a one-time roof inspection with us, and we\u2019ll take care of everything to keep your roof safe and sound for years. To top it off, our work is backed by a 10-year guarantee, giving you total peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Competitive Pricing",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We're able to match any roof job on the market in terms of pricing. We provide a FREE roof inspection and a comprehensive set of warranties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Experts in the Field",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roofers are properly certified for any roof job in the industry. With a combined experience of more than 100 years, we have an experienced team who can handle any job in Melbourne.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Effortless",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Book a one-time roof inspection with us, and we\u2019ll take care of everything to keep your roof safe and sound for years. To top it off, our work is backed by a 10-year guarantee, giving you total peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Competitive Pricing",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We're able to match any roof job on the market in terms of pricing. We provide a FREE roof inspection and a comprehensive set of warranties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Experts in the Field",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roofers are properly certified for any roof job in the industry. With a combined experience of more than 100 years, we have an experienced team who can handle any job in Melbourne.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Welcome to TMR Roof Repairs Burwood",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "TMR Roof Repairs Burwood has been delivering quality roofing solutions to Burwood and surrounding suburbs for over 25 years. Whether it\u2019s a small leak, general roof maintenance, or a complete restoration, our experienced team is here to ensure your home stays protected year-round. Our licensed roofers are committed to workmanship that lasts, helping you prevent costly problems before they arise. Arrange a detailed roof inspection today and receive a no-obligation free quote. Backed by our 10-year workmanship guarantee, you can trust that your roof is in safe hands.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Customers Are Saying...",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\"After noticing a leak on our Burwood home roof, I called TMR Roof Repairs Burwood. They responded immediately, assessed the damage, and had the repair completed the same day. Friendly, professional, and thorough service!\"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"TMR Roof Repairs Burwood did an amazing job replacing a section of our roof. The team was punctual, skilled, and explained everything clearly. I couldn\u2019t be happier with their workmanship!\"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"We needed urgent roof repairs after heavy rain in Burwood. TMR Roof Repairs Burwood came out quickly, fixed the issue efficiently, and left the site clean. Excellent service from start to finish!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"Professional, reliable, and highly skilled! The TMR Roof Repairs Burwood team handled our roof repairs without any fuss and ensured everything was done to a high standard. I highly recommend them!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Range of Services",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At TMR Roof Repairs Burwood, we know every roof has its own challenges. From quick leak repairs and Colorbond fixes to complete roof restorations, our skilled team has the experience to handle it all. With over 25 years in the industry, we work on everything from small residential repairs to larger-scale projects across Burwood, Burwood East, Camberwell, and Surrey Hills. Our goal is to deliver dependable results with minimal disruption, while keeping your roof strong, secure, and well maintained for years to come.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best Roofing Service in Burwood",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At TMR Roof Repairs Burwood, we provide trusted roofing solutions backed by over 30 years of industry experience. From quick leak repairs to full roof replacements, our team delivers reliable workmanship with clear, upfront pricing. Having worked extensively across Burwood and the surrounding suburbs, we know the common roofing challenges in the area and how to resolve them efficiently. Whether you need a professional roof inspection, urgent repair, or ongoing maintenance, you can count on us for fast response and lasting results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team has handled all kinds of roofing challenges, from fixing leaks in Burwood to restoring old Colorbond roofs in Burwood East. Every job is completed by a contractor with over 25 years of hands-on experience, so you can feel confident knowing your roof is in expert care.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We take great pride in delivering quality roofing work throughout Burwood and Burwood East, making sure every project is finished to the highest standard. If something isn\u2019t quite right, we\u2019ll return and fix it without delay. Your satisfaction and our reputation are what drive us to work hard on every job.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At TMR Roof Repairs Burwood, we believe in honest and transparent pricing from the very beginning. You\u2019ll receive a clear, upfront quote, and if any extra work is needed, we\u2019ll always seek your approval first\u2014no hidden costs or unexpected surprises.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Common Roof Problems We Encounter in Burwood",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "In Burwood, many roofing issues stem from cracked or missing tiles, clogged gutters that lead to overflow, and poorly installed roofs that create long-term problems. Constant exposure to the weather can also wear down your roof over time, and delaying repairs often makes the damage worse. From small fixes to complete roof restorations, taking action early is the key to keeping your roof durable and dependable.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recommend Roof Maintence Frequency",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Burwood\u2019s weather can be unpredictable, with hot days turning into heavy rain without warning. That\u2019s why it\u2019s essential to have a roof built to withstand the elements. Colorbond roofing is a strong and reliable choice for these conditions. To keep your roof performing at its best, we recommend a professional inspection once a year, ideally during spring or autumn when the weather is more settled. At TMR Roof Plumbing Burwood, we provide free roof inspections and ensure you only ever pay for the repairs or services that are genuinely required.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair Costs",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The cost of roof repairs in Burwood depends on several factors, including the type of roofing material\u2014such as tiles or Colorbond\u2014the size of your roof, and the extent of any damage. After conducting a thorough inspection, our team will provide you with a clear, detailed estimate. As a general guide, minor roof repairs usually start around $2,000, while complete roof restorations for larger homes or more complex projects often begin at $10,000.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Areas we Service",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At TMR Roof Repairs Burwood, we specialise in professional roof repair, leak detection, and restoration services for homes and businesses throughout the area. Our skilled team proudly serves Burwood and the surrounding suburbs, ensuring reliable solutions and exceptional workmanship every time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Areas we cover include:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Burwood East",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Surrey Hills",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Forest Hill",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair Burwood FAQs",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At TMR Roof Repairs Burwood, we are experts in all types of roofing, including tile, slate, and Colorbond or metal roof repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "While roof repairs address particular issues, roof restoration encompasses a more comprehensive approach, aiming to enhance the roof\u2019s overall functionality, appearance, and lifespan. Typically, roof repairs are minor and often urgent, whereas restoration involves renewing the entire roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We work with specific contractors who are\u00a0licensed to work on Colorbond and metal roofs across Victoria. By law, only certified contractors, approved by the Victorian Building Authority, can legally handle Colorbond roof repairs. Avoid the risks of uncertified roofers and trust our team to get the job done safely and correctly.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We provide a comprehensive range of roof and gutter repair and restoration services. However, we currently do not carry out roof installations on newly built homes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No, once we understand the scope of the job, we are fully capable of executing the roof repair independently.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Keep in mind, if a job takes multiple days to complete, such as a roof replacement or restoration, it may take mutliple days to complete.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "That said, you\u2019re free to stay or leave as you wish, the roof job may just be slightly noisy.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we can repair and replace your roof gutters but we do not offer roof gutter cleaning as a one-off job.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you\u2019re roof collapsed and medical attention is required call 000 for the ambulance right away!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If it\u2019s a roof leak or any roof issues that need to be addressed quickly, call us instead of filling out the forms. We have staff ready for you 24/7 to handle any roof emergencies.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All jobs start with a free inspection before the day of the job is to commence. Our contractors try to finish the job in one day. However, larger projects like restoring an entire roof may take two to three working days to complete.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "On average, most of our roof repair jobs require just two visits \u2013 the inspection and 1 day of work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We offer a 10 year warranty to our clients. We\u2019ve been in the business for a very long time and have loyal staff members who are here to stay.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "That means we will be there to honor your warranty. What\u2019s the point of providing a warranty if a company can\u2019t last long enough to honor it?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The required maintenance for your roof includes regular inspections to check for damage, cleaning gutters to prevent blockages, removing moss and debris, and ensuring that any damaged or missing tiles are promptly replaced. Regular maintenance helps prolong the life of your roof and prevents potential issues such as leaks.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Get a FREE Quote",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "More than a year since your last roof check? Protect your loved ones and prevent costly damages by getting a free roof inspection! Fill out the form below to get get a free quote & roof inspection.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us?",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Born and Bred Burwood ROOFING CONTRACTORS",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Systems",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Systems",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Process",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We kick things off with an inspection to get a clear idea of what your roof needs, whether it\u2019s a patch-up job or a larger restoration. After that, we\u2019ll give you a detailed quote so there are no surprises. Once you\u2019re happy, we\u2019ll get to work at a time that suits you, keeping disruption to a minimum whether you\u2019re in Burwood, Burwood East or any nearby suburbs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Free Consultation and Inspection",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We'll schedule a convenient on-site inspection to assess your roof for damage, leaks, and potential issues.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Followed by Detailed Quotation",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide a detailed, itemized quote outlining all work, materials, labor, and timelines in clear, understandable sections.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Scheduled Repair Work",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We'll schedule the work to minimize disruption to your routine while ensuring your roof gets the necessary attention.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quality Check and Clean-Up",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We perform rigorous quality checks after each roof repair, ensuring all materials and workmanship meet our high standards.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Follow-up and Warranty Information",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We stand behind our work with a guarantee, and we're dedicated to guaranteeing that you're completely satisfied with the results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "ROOF REPAIRS NEAR ME",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Schedule a free roof inspection in Burwood and surrounding suburbs!",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Schedule Your Free Roof Inspection Today!",
                                "main_title": "ROOF REPAIRS BURWOOD",
                                "author": "markyangworks@gmail.com",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "301 Burwood Hwy, Burwood VIC 3125",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Submit the form and one of our friendly staff will get back to you as soon as possible! Feel free to also give us a call at",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0468 017 100",
                                "0468017100",
                                "+61468017100"
                            ],
                            "emails": [
                                "tmr@roofrepairsburwood.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}