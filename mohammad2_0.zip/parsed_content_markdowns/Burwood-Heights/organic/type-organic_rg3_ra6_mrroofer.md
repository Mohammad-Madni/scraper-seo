{
    "id": "01190728-1132-0216-0000-0ede90a490c1",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0130 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.mrroofer.com.au/burwood-heights-roof-repair/",
        "target": "www.mrroofer.com.au",
        "start_url": "https://www.mrroofer.com.au/burwood-heights-roof-repair/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-Heights\\organic\\type-organic_rg3_ra6_mrroofer.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:25 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Sydney Roof Restoration company that caters to residential customers across Sydney.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.mrroofer.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "CONTACT PHONE",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mon - Sat 8:00 - 18:00",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "OPEN HOURS",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.mrroofer.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Mr. Roofer is a premier, Sydney Roof Restoration company that caters to residential customers across Sydney. We have been in this business for over 20 years and provide excellent roofing services.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright 2021 Mr Roofer, All Right Reserved",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Site Map",
                                    "url": "https://www.mrroofer.com.au/site-map/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/site-map/",
                                            "anchor_text": "Site Map"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney NSW. 2200",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Burwood Heights Roof Repair",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Most good quality roofs can last for decades, but sometimes even the best installations need Burwood Heights roof repairs by experts like Mr Roofer. Exposure to the elements, regular wear and tear and the onslaught of stormy weather can sometimes damage your roof. If you have noticed any missing or damaged roof tiles or sheets, simply call us.",
                                        "url": "https://www.mrroofer.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/",
                                                "anchor_text": "Mr Roofer"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "For over 20 years our experienced Burwood Heights roof repair contractors have handled all types of roofing jobs. We offer very high-quality services at competitive pricing, backed by iron-clad guarantees. These and our outstanding customer service set us apart from the crowd.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professional Burwood Heights Roof Repairs",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When you hire us for any roof repair job, you can rest assured that the work will be completed reliably, efficiently and at prices that won\u2019t burn a hole in your pocket. Regardless of the nature & size of the project, our experts will provide exemplary services that will improve not just the integrity, but the appearance of your roof as well.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You no longer need to spend hours online looking for \u201c residential roof repair in Burwood Heights companies \u201d or \u201c cheap roof repair Burwood Heights \u201d.When we handle the job, our on-site supervisors make sure that the project is carried out without a glitch and the repair work is completed to industry standards. There are some signs that indicate you may need roofing repairs including:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Puddles of water in various areas of your home",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Water damage and rot in wooden roof rafters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Water flowing along the siding",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Water accumulating at the foundation or basement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flashing damage and rot",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Missing shingles or tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rust and corrosion on metal roofs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Damage to guttering and downspouts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Fascia damage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Damaged shingles",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Range of Roof Repair in Burwood Heights services",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When you opt for our services, you don\u2019t have to worry about either the quality or scheduling of the work. We offer a comprehensive range of professional Burwood Heights roof repair services and cater to both residential and commercial clients:",
                                        "url": "https://www.mrroofer.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/",
                                                "anchor_text": "Burwood Heights roof repair services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professional Burwood Heights Roof Repair of Tiled Roofs",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Tiles are widely used on commercial and residential structures. Sometimes, the concrete used in the bedding doesn\u2019t affix itself well to the underside of the tiles, causing them to break, crack or come loose. We handle:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repairs of rusted valleys",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of chimney flashings",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Broken tiles replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "De-laminating tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Loose ridge capping",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof Repairs Burwood Heights",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Sometimes, even a resilient colorbond roof can develop rust spots or suffer damage in a storm. We have the expertise to handle all types of Burwood Heights roof repairs of metal roofing such as:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Treating rust spots with liquid fibre-glass",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Treating signs of corrosion and applying anti-rust solutions",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacing rusted ridge caps and rusting screws",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacing rusting roof sheets (if needed)",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs\u00a0Burwood Heights",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Sydney often gets hit by seasonal storms that cause extensive damage to roofing structures.Damaged and missing shingles and tiles, dented metal roofs from a tree collapse etc. are some of the situations in which you may need emergency roofing repairs. We at Mr Roofer offer prompt, high-quality services at a very competitive roof repair Burwood Heights cost.We have the training, experience, and resources to provide quick and efficient services that are required in emergency situations such as these.",
                                        "url": "https://www.mrroofer.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/",
                                                "anchor_text": "Mr Roofer"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Shingle Repairs Burwood Heights",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If you have damaged or missing shingles, they need to be fixed or replaced without delay. We know that every job and setting is unique, with a unique set of challenges. We have the skills to handle every job expertly and can fix leaky roofs in a jiffy. Our team conducts thorough inspections to assess the damage and then provide solutions at a very pocket-friendly roof repair Burwood Heights price.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Re-bedding & Repointing Burwood Heights",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If your roof bedding has deteriorated over time or has been poorly installed, the tiles can become impacted and may also loosen and fall off. We offer customised re-bedding solutions that help improve the overall integrity of the structure, preventing problems like leaks. Once the re-bedding is complete, we also repoint the tiles; this gives the roof some dimension and improves its appearance significantly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ridge Capping Burwood Heights",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Ridge caps are the features that are used to cover the points at which two roof faces meet. If these have suffered any damage or come loose, it\u2019s important to get them replaced or repaired without delay. Brittle and old ridge caps can develop cracks through which wind and water can easily enter the structure, causing it to weaken. Missing ridge caps can cause the rest of the tiles and shingles to fall off too. The best way to prevent all these problems is to call the professional roof repair Burwood Heights experts at Mr Roofer to attend to the problem.",
                                        "url": "https://www.mrroofer.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/",
                                                "anchor_text": "Mr Roofer"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "While we never compromise on quality, we always provide outstanding residential and commercial services at very affordable roof repair Burwood Heights cost. This and the impeccable customer service we provide set us way ahead of the other companies in the field.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Other Burwood Heights Roofing Services",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We also offer other roofing services to suit any roof you may have. These services include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Cleaning Burwood Heights",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Cleaning Burwood Heights",
                                        "url": "https://www.mrroofer.com.au/Burwood%20Heights-roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/Burwood%20Heights-roof-cleaning/",
                                                "anchor_text": "Roof Cleaning Burwood Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting Burwood Heights",
                                        "url": "https://www.mrroofer.com.au/Burwood%20Heights-roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/Burwood%20Heights-roof-painting/",
                                                "anchor_text": "Roof Painting Burwood Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Burwood Heights",
                                        "url": "https://www.mrroofer.com.au/Burwood%20Heights-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/Burwood%20Heights-roof-restoration/",
                                                "anchor_text": "Roof Restoration Burwood Heights"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ask our Burwood Heights Roof Repair Team",
                                "main_title": "Burwood Heights Roof Repair",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "For any more information about our cheap Burwood Heights roof repair services or for a free inspection and quote, call Mr Roofer at 0405 804 804. You can also send us your queries and quote requests via our online form.",
                                        "url": "https://www.mrroofer.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/",
                                                "anchor_text": "Mr Roofer"
                                            },
                                            {
                                                "url": "https://www.mrroofer.com.au/contact-us/",
                                                "anchor_text": "online form"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Years Experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restorations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofs Painted",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": null,
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0405804804"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}