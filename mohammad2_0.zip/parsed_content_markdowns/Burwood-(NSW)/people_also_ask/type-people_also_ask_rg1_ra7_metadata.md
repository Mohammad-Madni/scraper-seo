# Type: people_also_ask | Rank: 7 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "7",
    "service": "roofer",
    "suburb": "Burwood (NSW)",
    "title": "",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_ask"
}