# Type: local_pack | Rank: 1 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "1",
    "service": "roofer",
    "suburb": "Burwood (NSW)",
    "title": "All Roofing Services Pty Ltd",
    "domain": "www.google.com",
    "url": "https://www.google.com/viewer/place?sca_esv=ed956a20e7b48028&hl=en&gl=AU&output=search&mid=/g/1tcxz_1z&pip=Cgtyb29mZXIgTlNXKRAC",
    "description": "Closed \u00b7 Croydon NSW",
    "type": "local_pack"
}