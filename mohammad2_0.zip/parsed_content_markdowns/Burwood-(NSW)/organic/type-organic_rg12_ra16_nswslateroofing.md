{
    "id": "01190728-1132-0216-0000-c85b828fc917",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0137 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://nswslateroofing.com.au/project/burwood-slate-roofing/",
        "target": "nswslateroofing.com.au",
        "start_url": "https://nswslateroofing.com.au/project/burwood-slate-roofing/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg12_ra16_nswslateroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:27 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Meet The Team",
                                    "url": "https://nswslateroofing.com.au/meet-the-team/",
                                    "urls": [
                                        {
                                            "url": "https://nswslateroofing.com.au/meet-the-team/",
                                            "anchor_text": "Meet The Team"
                                        }
                                    ]
                                },
                                {
                                    "text": "Welsh Slate",
                                    "url": "https://nswslateroofing.com.au/welsh-slate/",
                                    "urls": [
                                        {
                                            "url": "https://nswslateroofing.com.au/welsh-slate/",
                                            "anchor_text": "Welsh Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate",
                                    "url": "https://nswslateroofing.com.au/canadian-slate/",
                                    "urls": [
                                        {
                                            "url": "https://nswslateroofing.com.au/canadian-slate/",
                                            "anchor_text": "Canadian Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate",
                                    "url": "https://nswslateroofing.com.au/spanish-slate/",
                                    "urls": [
                                        {
                                            "url": "https://nswslateroofing.com.au/spanish-slate/",
                                            "anchor_text": "Spanish Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cedar Shingles",
                                    "url": "https://nswslateroofing.com.au/cedar-shingles/",
                                    "urls": [
                                        {
                                            "url": "https://nswslateroofing.com.au/cedar-shingles/",
                                            "anchor_text": "Cedar Shingles"
                                        }
                                    ]
                                },
                                {
                                    "text": "Composite Slate",
                                    "url": "https://nswslateroofing.com.au/composite-slate/",
                                    "urls": [
                                        {
                                            "url": "https://nswslateroofing.com.au/composite-slate/",
                                            "anchor_text": "Composite Slate"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Welsh Slate",
                                    "url": "https://nswslateroofing.com.au/index.php/welsh-slate/",
                                    "urls": [
                                        {
                                            "url": "https://nswslateroofing.com.au/index.php/welsh-slate/",
                                            "anchor_text": "Welsh Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Spanish Slate",
                                    "url": "https://nswslateroofing.com.au/index.php/spanish-slate/",
                                    "urls": [
                                        {
                                            "url": "https://nswslateroofing.com.au/index.php/spanish-slate/",
                                            "anchor_text": "Spanish Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Canadian Slate",
                                    "url": "https://nswslateroofing.com.au/index.php/canadian-slate/",
                                    "urls": [
                                        {
                                            "url": "https://nswslateroofing.com.au/index.php/canadian-slate/",
                                            "anchor_text": "Canadian Slate"
                                        }
                                    ]
                                },
                                {
                                    "text": "Composite Slate",
                                    "url": "https://nswslateroofing.com.au/index.php/composite-slate/",
                                    "urls": [
                                        {
                                            "url": "https://nswslateroofing.com.au/index.php/composite-slate/",
                                            "anchor_text": "Composite Slate"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "BURWOOD SLATE ROOFING",
                                "main_title": "BURWOOD SLATE ROOFING",
                                "author": "nsw slate roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "NSW Slate Roofing completed this roof replacement project in Burwood, using Tapco Inspire Composite Slate.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Check out our website or click the link below for more projects: www.nswslateroofing.com.au",
                                        "url": "http://www.nswslateroofing.com.au/",
                                        "urls": [
                                            {
                                                "url": "http://www.nswslateroofing.com.au/",
                                                "anchor_text": "www.nswslateroofing.com.au"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Share this Project",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "BACK TO PROJECTS",
                                        "url": "https://nswslateroofing.com.au/projects/",
                                        "urls": [
                                            {
                                                "url": "https://nswslateroofing.com.au/projects/",
                                                "anchor_text": "BACK TO PROJECTS"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": null,
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": null,
                            "emails": [
                                "?subject=Burwood&#038;body=Hey,%20thought%20you%20might%20enjoy%20this!%20Check%20it%20out%20when%20you%20have%20a%20chance:%20https://nswslateroofing.com.au/projects/burwood-composite-slate/"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}