{
    "id": "01190728-1132-0216-0000-5d61d4a1465d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0311 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrepairsinstrathfield.com.au/in/burwood/",
        "target": "roofrepairsinstrathfield.com.au",
        "start_url": "https://roofrepairsinstrathfield.com.au/in/burwood/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg17_ra21_roofrepairsinstrathfield.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:22 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Contractors",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                            "anchor_text": "Commercial Roofing Contractors"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaking Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                            "anchor_text": "Leaking Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof And Gutter",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                            "anchor_text": "Roof And Gutter"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tilers",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                            "anchor_text": "Roof Tilers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roof Repairs",
                                    "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                            "anchor_text": "Slate Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairsinstrathfield.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "We Take Care Of Your Roof",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Burwood is a lovely city, and you should have the very best roof for your home or business. Nevertheless, severe weather can be tough on your roof and trigger it to deteriorate over time. Whether you require a new roof or repairs for an existing one, Roofing Today Burwood is here to help you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With years of experience in repair and installation, our team of qualified specialists are experts in doing the job right the first time. We provide a large range of services to guarantee your roof is safe and protected. From minor repairs, such as replacing tiles or repairing leaks, to more involved tasks, like total replacements or re-roofing, our experts will work with you to help identify the very best remedy for your residential or commercial property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We understand the significance of having a trustworthy and secure roof over your head, which is why we strive to offer quality craftsmanship and remarkable client service. Our team of knowledgeable specialists takes pride in their work and utilizes only the highest-quality products for all our tasks. We are also pleased to go over any unique requests or concerns you may have and offer useful suggestions throughout the process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter what kind of roofing needs you have, Roofing Today Burwood is here to help. Contact our team today, and let us be the ones to repair your roof!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Colorbond roofing is a popular option for both domestic and commercial properties. Our team of knowledgeable specialists is trained in the installation of colorbond roofing and uses the highest-quality products to guarantee your roof looks its finest.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing Contractors Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Whether you require a total replacement or repairs for an existing roof, our team of qualified specialists can help. We understand that a small disturbance in business can be expensive. We work around your schedule to decrease downtime, that includes weekends and/or nights if needed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing Contractors Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We understand that emergencies can take place anytime and need quick action to decrease damage. Our team of knowledgeable specialists is readily available 24/7 to offer quick and trustworthy emergency roof repair services. From minor repairs to more comprehensive work, we can be depended on to do the job right.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Emergency Roof Repairs Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Roof and Gutter",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Routine maintenance of your roof and gutter is necessary in guaranteeing that it stays in good condition. Our team of trained specialists offers numerous services, such as cleaning and repairs, to keep your gutters working appropriately and help extend the life of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Burwood Roof and Gutter",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Burwood Roof and Gutter"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspections Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Let our team of qualified specialists help you assess the condition of your roof. We\u2019ll offer an in-depth inspection to detect roof issues and accurately recommend affordable remedies. We offer a detailed report of our findings, which can then be used to prepare any essential repairs or replacements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Inspections Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Roof Repairs Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Don\u2019t let a little leak develop into a bigger problem. We use the most recent leak detection strategies to detect and repair any issues precisely. They consist of water tests, thermal imaging, and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Leaking Roof Repairs Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of certified specialists is can install all roofing materials, including metal roofs, slate roofs, solar roofs, tile roofs, and more. we believe in quality craftsmanship and use only the highest-quality products to guarantee your roof is strong and secure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Installation Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal roofs are becoming considerably popular due to their toughness, low maintenance, and energy effectiveness. We handle various kinds of metal roofing, from corrugated to standing seam, and several color alternatives. In addition, we can set up soaker panels and other add-ons for a more customized appearance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our team of knowledgeable specialists can offer a full roof replacement service if your roof is beyond repair. We\u2019ll help you select the ideal material, size, and shape to match your residential or commercial property and budget.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Roof Restoration",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roofing Today Burwood, we believe in preserving existing structures wherever possible rather than replacing them. We use the most recent products and strategies to extend the life of your roof while bearing in mind its historic value and character.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Burwood Roof Restoration",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                                "anchor_text": "Burwood Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We provide numerous services for residential and commercial properties in Burwood, ranging from minor repairs to full-scale installations. Whether it\u2019s metal or tile roofs, skylights, or solar panels\u2013 our knowledgeable team will offer quality solutions that meet your needs and budget. We handle everything from start to finish and offer remarkable client service throughout the whole process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roofing/",
                                                "anchor_text": "Roofing Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Skylights Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Skylights are amongst the most popular attributes of a home, supplying natural light and ventilation. Our team of qualified specialists can set up residential and commercial skylights, from standard systems to customized designs. We also provide repair options, including replacing damaged seals and frames.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Skylights Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/skylights/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/skylights/",
                                                "anchor_text": "Skylights Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tilers Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof Tiling is a specialized task that requires understanding, skill, and experience\u2013 all of which our team has in abundance. We offer setup and repairs for slate, terracotta, metal, concrete tiles, and all types of roof devices.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Tilers Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roof Repairs Burwood",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Slate roofs are a popular option for heritage houses due to their lasting toughness and classic appearance. We comprehend the significance of preserving a structure\u2019s initial character and can help you with all your slate roof repair needs. Our knowledgeable specialists use only the highest-quality products to restore your roof to its previous magnificence.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Slate Roof Repairs Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs Burwood"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Burwood\u200b",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We understand that some Burwood citizens may not have the ability to pay for a roof repair or installation. Considering that our desire is to help everyone, we provide a unique discount program for qualified Burwood citizens. With our Burwood Discount Roof Repair program, you can get the repairs or installations you require at a lower expense.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019re proud to be part of the Burwood community and do all we can to help our neighbors. It doesn\u2019t matter if you require a basic repair or a full roof replacement; our knowledgeable specialists are here to help.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our 100% satisfaction guarantee backs every task we do. We back up all of our work and won\u2019t rest till you\u2019re completely pleased with the final results. From when you first call us to when we complete the task, you can count on our team for remarkable service and craftsmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A trustworthy and secure roof is one of the most important investments in your life. That\u2019s why when it pertains to repair or installation, you can count on the specialists at Roofing Today Burwood for quality service and craftsmanship.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We proudly serve: Strathfield, Croydon, Burwood Heights, Enfield, Canada Bay, Croydon Park, Concord, Ashfield, North Strathfield, Strathfield South and Burwood",
                                        "url": "https://roofrepairsinstrathfield.com.au/in/strathfield/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/strathfield/",
                                                "anchor_text": "Strathfield"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/croydon/",
                                                "anchor_text": "Croydon"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/burwood-heights/",
                                                "anchor_text": "Burwood Heights"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/enfield/",
                                                "anchor_text": "Enfield"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/canada-bay/",
                                                "anchor_text": "Canada Bay"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/croydon-park/",
                                                "anchor_text": "Croydon Park"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/concord/",
                                                "anchor_text": "Concord"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/ashfield/",
                                                "anchor_text": "Ashfield"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/north-strathfield/",
                                                "anchor_text": "North Strathfield"
                                            },
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/in/strathfield-south/",
                                                "anchor_text": "Strathfield South"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Burwood\u200b",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "We at Roofing Today Burwood are the roof experts! We can fix any type of roof from flat roofs to gabled roofs and everything in between. Contact us today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What Are You Waiting For?",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "A reliable and secure roof is one of the most important investments in your life. That\u2019s why when it comes to repair or installation, you can count on the professionals at Roofing Today Burwood for quality service and workmanship. Call us now!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Burwood\u200b",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Talk to us today about roofing services for your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "GET IN TOUCH",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repairs Burwood Services",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What we offer",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We offer a large range of services, consisting of:",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Discount Roof Repair",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood, New South Wales",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "For more information about Burwood, New South Wales",
                                        "url": "https://en.wikipedia.org/wiki/Burwood,_New%20South%20Wales",
                                        "urls": [
                                            {
                                                "url": "https://en.wikipedia.org/wiki/Burwood,_New%20South%20Wales",
                                                "anchor_text": "For more information about Burwood, New South Wales"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Google News:",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Latest Burwood News",
                                        "url": "https://news.google.com/search?q=Burwood,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                        "urls": [
                                            {
                                                "url": "https://news.google.com/search?q=Burwood,+New%20South%20Wales&hl=en-AU&gl=AU&ceid=AU:en",
                                                "anchor_text": "Latest Burwood News"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Links",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Us",
                                        "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/about-us/",
                                                "anchor_text": "About Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our Services",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/",
                                                "anchor_text": "Our Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roofing Contractors",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/commercial-roofing-contractors/",
                                                "anchor_text": "Commercial Roofing Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof and Gutter",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-and-gutter/",
                                                "anchor_text": "Roof and Gutter"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-inspections/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leaking Roof Repairs",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/leaking-roof-repairs/",
                                                "anchor_text": "Leaking Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tilers",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/roof-tilers/",
                                                "anchor_text": "Roof Tilers"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slate Roof Repairs",
                                        "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/services/slate-roof-repairs/",
                                                "anchor_text": "Slate Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Info",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "ROOFING TODAY",
                                        "url": "https://maps.app.goo.gl/mouDDnPwo7U3eevt6",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/mouDDnPwo7U3eevt6",
                                                "anchor_text": "ROOFING TODAY\n1/19 Dick St,Henley NSW 2111\n(02) 8261 0051"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1/19 Dick St,",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Henley NSW 2111",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 8261 0051",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Email Us",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "[email\u00a0protected]",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "[email\u00a0protected]",
                                        "url": "https://roofrepairsinstrathfield.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "&copy 2022 Roofing Today Strathfield",
                                "main_title": "Roof Repairs Burwood\u200b",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "&copy 2022 Roofing Today Strathfield",
                                        "url": "https://roofrepairsinstrathfield.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/",
                                                "anchor_text": "Roofing Today Strathfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://roofrepairsinstrathfield.com.au/privacy-policy/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/privacy-policy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms & Conditions",
                                        "url": "https://roofrepairsinstrathfield.com.au/terms-and-conditions/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairsinstrathfield.com.au/terms-and-conditions/",
                                                "anchor_text": "Terms & Conditions"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 8261 0051",
                                "(02)%208261%200051"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}