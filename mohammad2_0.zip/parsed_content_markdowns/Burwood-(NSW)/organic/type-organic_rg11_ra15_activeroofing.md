{
    "id": "01190728-1132-0216-0000-71d59c923c06",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0184 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/burwood/",
        "target": "activeroofing.net.au",
        "start_url": "https://activeroofing.net.au/roof-repairs/new-south-wales/burwood/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg11_ra15_activeroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:22 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "0488 845 333",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Servicing Hawkesbury, Penrith, Blue Mountains, Liverpool, Hills District, & Inner West Suburbs, North Richmond, NSW, 2754",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 Copyright 2025 \u2022 Active Roof Restorations",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "0488 845 333",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Visit our website",
                                    "url": "https://activeroofing.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://activeroofing.com.au/",
                                            "anchor_text": "Visit our website"
                                        }
                                    ]
                                },
                                {
                                    "text": "07:00 AM - 05:00 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "07:00 AM - 05:00 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "07:00 AM - 05:00 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "07:00 AM - 05:00 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "07:00 AM - 05:00 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "07:00 AM - 05:00 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "07:00 AM - 05:00 PM",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Active Roof Restorations",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Have you noticed damage to your roof? Is it looking worn and in need of repair? If you do, then you need Active Roofing at your doorstep soon.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With 20 years of experience in this industry, we take immense pride in delivering the highest standards and quality for guaranteed customer satisfaction.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Active Roofing, we specialize in full roof restoration and we understand the challenges concerning all roofs to keep it looking in prime and immaculate condition. We have an experienced team of professionals and tools that will find a well-suited solution for your roof. Roofing is something that shouldn't be ignored, and we deliver the expertise you can trust, provide affordable prices, and a free quote.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs in Burwood, New South Wales",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Active Roof Restorations",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "One of the most trusted, respected, professional, and affordable roof repair and roof restoration services in Sydney. We offer roof leak, re-bedding, re-pointing, & other roof repairs. Call us for best rates! L361143c",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Products & Services",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Guttering",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "High Pressure Cleaning",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Replacement and Repairs",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Roof Replacement and Repairs",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Bedding and Re-Pointing",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get started now",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://activeroofing.com.au/roof-repair.html",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.com.au/roof-repair.html",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://activeroofing.com.au/roof-painting.html",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.com.au/roof-painting.html",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://pinkpages.com.au/businesses/active-roof-restorations-11332964",
                                        "urls": [
                                            {
                                                "url": "https://pinkpages.com.au/businesses/active-roof-restorations-11332964",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Call us today",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Servicing Hawkesbury, Penrith, Blue Mountains, Liverpool, Hills District, & Inner West Suburbs, North Richmond, NSW, 2754",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "By checking this box you consent to receive more information about our products/services, events, news, and more via text, email, call, or any other forms of communication",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thank you for reaching out. Your enquiry has been submitted.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "0488 845 333",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Visit our website",
                                        "url": "https://activeroofing.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.com.au/",
                                                "anchor_text": "Visit our website"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Directory of our Services",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs in Hills District, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/hills-district/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/hills-district/",
                                                "anchor_text": "Roof Repairs in Hills District, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Hawkesbury, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/hawkesbury/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/hawkesbury/",
                                                "anchor_text": "Roof Repairs in Hawkesbury, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Blue Mountains, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/blue-mountains/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/blue-mountains/",
                                                "anchor_text": "Roof Repairs in Blue Mountains, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Ryde, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/ryde/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/ryde/",
                                                "anchor_text": "Roof Repairs in Ryde, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Strathfield, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/strathfield/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/strathfield/",
                                                "anchor_text": "Roof Repairs in Strathfield, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Penrith, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/penrith/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/penrith/",
                                                "anchor_text": "Roof Repairs in Penrith, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Parramatta, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/parramatta/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/parramatta/",
                                                "anchor_text": "Roof Repairs in Parramatta, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Kellyville, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/kellyville/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/kellyville/",
                                                "anchor_text": "Roof Repairs in Kellyville, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Bella Vista, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/bella-vista/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/bella-vista/",
                                                "anchor_text": "Roof Repairs in Bella Vista, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Katoomba, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/katoomba/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/katoomba/",
                                                "anchor_text": "Roof Repairs in Katoomba, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Hornsby, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/hornsby/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/hornsby/",
                                                "anchor_text": "Roof Repairs in Hornsby, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Dural, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/dural/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/dural/",
                                                "anchor_text": "Roof Repairs in Dural, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Liverpool, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/liverpool/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/liverpool/",
                                                "anchor_text": "Roof Repairs in Liverpool, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Camden, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/camden/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/camden/",
                                                "anchor_text": "Roof Repairs in Camden, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Mount Vernon, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/mount-vernon/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/mount-vernon/",
                                                "anchor_text": "Roof Repairs in Mount Vernon, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Mount Colah, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/mount-colah/",
                                                "anchor_text": "Roof Repairs in Mount Colah, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Horsley Park, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/horsley-park/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/horsley-park/",
                                                "anchor_text": "Roof Repairs in Horsley Park, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Balmain, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/balmain/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/balmain/",
                                                "anchor_text": "Roof Repairs in Balmain, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Lane Cove, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/lane-cove/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/lane-cove/",
                                                "anchor_text": "Roof Repairs in Lane Cove, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs in Chatswood, NSW",
                                        "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/chatswood/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-repairs/new-south-wales/chatswood/",
                                                "anchor_text": "Roof Repairs in Chatswood, NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration in Hills District, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/hills-district/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/hills-district/",
                                                "anchor_text": "Roof Restoration in Hills District, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Hawkesbury, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/hawkesbury/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/hawkesbury/",
                                                "anchor_text": "Roof Restoration in Hawkesbury, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Blue Mountains, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/blue-mountains/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/blue-mountains/",
                                                "anchor_text": "Roof Restoration in Blue Mountains, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Ryde, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/ryde/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/ryde/",
                                                "anchor_text": "Roof Restoration in Ryde, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Strathfield, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/strathfield/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/strathfield/",
                                                "anchor_text": "Roof Restoration in Strathfield, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Burwood, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/burwood/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/burwood/",
                                                "anchor_text": "Roof Restoration in Burwood, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Penrith, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/penrith/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/penrith/",
                                                "anchor_text": "Roof Restoration in Penrith, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Parramatta, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/parramatta/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/parramatta/",
                                                "anchor_text": "Roof Restoration in Parramatta, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Kellyville, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/kellyville/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/kellyville/",
                                                "anchor_text": "Roof Restoration in Kellyville, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Bella Vista, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/bella-vista/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/bella-vista/",
                                                "anchor_text": "Roof Restoration in Bella Vista, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Katoomba, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/katoomba/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/katoomba/",
                                                "anchor_text": "Roof Restoration in Katoomba, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Hornsby, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/hornsby/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/hornsby/",
                                                "anchor_text": "Roof Restoration in Hornsby, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Dural, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/dural/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/dural/",
                                                "anchor_text": "Roof Restoration in Dural, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Liverpool, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/liverpool/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/liverpool/",
                                                "anchor_text": "Roof Restoration in Liverpool, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Camden, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/camden/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/camden/",
                                                "anchor_text": "Roof Restoration in Camden, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Mount Vernon, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/mount-vernon/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/mount-vernon/",
                                                "anchor_text": "Roof Restoration in Mount Vernon, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Mount Colah, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/mount-colah/",
                                                "anchor_text": "Roof Restoration in Mount Colah, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Horsley Park, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/horsley-park/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/horsley-park/",
                                                "anchor_text": "Roof Restoration in Horsley Park, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Balmain, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/balmain/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/balmain/",
                                                "anchor_text": "Roof Restoration in Balmain, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Lane Cove, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/lane-cove/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/lane-cove/",
                                                "anchor_text": "Roof Restoration in Lane Cove, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration in Chatswood, NSW",
                                        "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/chatswood/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-restoration/new-south-wales/chatswood/",
                                                "anchor_text": "Roof Restoration in Chatswood, NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Roof Repairs in Burwood, New South Wales",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement in Hills District, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/hills-district/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/hills-district/",
                                                "anchor_text": "Roof Replacement in Hills District, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Hawkesbury, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/hawkesbury/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/hawkesbury/",
                                                "anchor_text": "Roof Replacement in Hawkesbury, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Blue Mountains, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/blue-mountains/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/blue-mountains/",
                                                "anchor_text": "Roof Replacement in Blue Mountains, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Ryde, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/ryde/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/ryde/",
                                                "anchor_text": "Roof Replacement in Ryde, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Strathfield, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/strathfield/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/strathfield/",
                                                "anchor_text": "Roof Replacement in Strathfield, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Burwood, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/burwood/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/burwood/",
                                                "anchor_text": "Roof Replacement in Burwood, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Penrith, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/penrith/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/penrith/",
                                                "anchor_text": "Roof Replacement in Penrith, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Parramatta, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/parramatta/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/parramatta/",
                                                "anchor_text": "Roof Replacement in Parramatta, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Kellyville, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/kellyville/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/kellyville/",
                                                "anchor_text": "Roof Replacement in Kellyville, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Bella Vista, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/bella-vista/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/bella-vista/",
                                                "anchor_text": "Roof Replacement in Bella Vista, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Katoomba, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/katoomba/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/katoomba/",
                                                "anchor_text": "Roof Replacement in Katoomba, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Hornsby, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/hornsby/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/hornsby/",
                                                "anchor_text": "Roof Replacement in Hornsby, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Dural, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/dural/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/dural/",
                                                "anchor_text": "Roof Replacement in Dural, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Liverpool, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/liverpool/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/liverpool/",
                                                "anchor_text": "Roof Replacement in Liverpool, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Camden, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/camden/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/camden/",
                                                "anchor_text": "Roof Replacement in Camden, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Mount Vernon, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/mount-vernon/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/mount-vernon/",
                                                "anchor_text": "Roof Replacement in Mount Vernon, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Mount Colah, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/mount-colah/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/mount-colah/",
                                                "anchor_text": "Roof Replacement in Mount Colah, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Horsley Park, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/horsley-park/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/horsley-park/",
                                                "anchor_text": "Roof Replacement in Horsley Park, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Balmain, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/balmain/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/balmain/",
                                                "anchor_text": "Roof Replacement in Balmain, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Lane Cove, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/lane-cove/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/lane-cove/",
                                                "anchor_text": "Roof Replacement in Lane Cove, NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement in Chatswood, NSW",
                                        "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/chatswood/",
                                        "urls": [
                                            {
                                                "url": "https://activeroofing.net.au/roof-replacement/new-south-wales/chatswood/",
                                                "anchor_text": "Roof Replacement in Chatswood, NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0488 845 333"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}