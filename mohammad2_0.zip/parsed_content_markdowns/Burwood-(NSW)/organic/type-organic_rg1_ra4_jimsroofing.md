{
    "id": "01190728-1132-0216-0000-257ce57bf1be",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0408 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://jimsroofing.com.au/locations/sydney/burwood/",
        "target": "jimsroofing.com.au",
        "start_url": "https://jimsroofing.com.au/locations/sydney/burwood/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg1_ra4_jimsroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:26 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Meet The Team",
                                    "url": "https://jimsroofing.com.au/about-jims/meet-the-team/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/about-jims/meet-the-team/",
                                            "anchor_text": "Meet The Team"
                                        }
                                    ]
                                },
                                {
                                    "text": "Customer Service",
                                    "url": "https://jimsroofing.com.au/about-jims/customer-service/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/about-jims/customer-service/",
                                            "anchor_text": "Customer Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become A Franchisor",
                                    "url": "https://jims.net/become-a-regional-franchisor/",
                                    "urls": [
                                        {
                                            "url": "https://jims.net/become-a-regional-franchisor/",
                                            "anchor_text": "Become A Franchisor"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become a Franchisee",
                                    "url": "https://jimsroofing.com.au/become-a-franchisee/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/become-a-franchisee/",
                                            "anchor_text": "Become a Franchisee"
                                        }
                                    ]
                                },
                                {
                                    "text": "Jim\u2019s Divisions",
                                    "url": "https://jimsroofing.com.au/about-jims/jims-family/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/about-jims/jims-family/",
                                            "anchor_text": "Jim\u2019s Divisions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Request a Quote",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Restorations",
                                    "url": "https://jimsroofing.com.au/services-item/roof-restorations/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/services-item/roof-restorations/",
                                            "anchor_text": "Roof Restorations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof cleaning",
                                    "url": "https://jimsroofing.com.au/services-item/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/services-item/roof-cleaning/",
                                            "anchor_text": "Roof cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Re-roofing",
                                    "url": "https://jimsroofing.com.au/services-item/metal-re-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/services-item/metal-re-roofing/",
                                            "anchor_text": "Metal Re-roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://jimsroofing.com.au/services-item/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/services-item/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Repairs",
                                    "url": "https://jimsroofing.com.au/services-item/tile-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/services-item/tile-repairs/",
                                            "anchor_text": "Tile Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://jimsroofing.com.au/services-item/gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/services-item/gutter-replacement/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard Protection",
                                    "url": "https://jimsroofing.com.au/services-item/gutter-guard/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/services-item/gutter-guard/",
                                            "anchor_text": "Gutter Guard Protection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installations",
                                    "url": "https://jimsroofing.com.au/services-item/skylight-installations/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/services-item/skylight-installations/",
                                            "anchor_text": "Skylight Installations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://jimsroofing.com.au/services-item/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/services-item/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Warranty Terms and Conditions",
                                    "url": "https://jimsroofing.com.au/about-jims/warranty-terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/about-jims/warranty-terms-and-conditions/",
                                            "anchor_text": "Warranty Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Accepting Quotes Terms and Conditions",
                                    "url": "https://jimsroofing.com.au/about-jims/accepting-quotes-terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/about-jims/accepting-quotes-terms-and-conditions/",
                                            "anchor_text": "Accepting Quotes Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Menu Menu",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About Jim\u2019s",
                                    "url": "https://jimsroofing.com.au/about-jims/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/about-jims/",
                                            "anchor_text": "About Jim\u2019s"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://jimsroofing.com.au/about-jims/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/about-jims/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms and Conditions",
                                    "url": "https://jimsroofing.com.au/about-jims/terms-and-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://jimsroofing.com.au/about-jims/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Quality Roofing Services around Burwood, Sydney",
                                "main_title": "Quality Roofing Services around Burwood, Sydney",
                                "author": "Mario Pongas",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Franchise owner Jamie is a qualified specialist in roofing in Burwood, Sydney. If you live in the area or nearby and need a quality roofer at a quality price contact us below.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have a wide range of experience in roof services from tile repairs, skylight installation, skylight repairs, roof restorations, roof plumbing, roof painting, roof cleaning, re-bedding, metal re-roofing, gutter replacement, and gutter guard protection.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our roof experts have fully-stocked vehicles with all the tools and equipment needed for most jobs. At Jim\u2019s Roofing Burwood, we use locally produced high-quality products since we know the true value of your roof repair will be in the quality of our workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For any type of roofing work needed throughout Burwood or surrounding areas, give us a call on 13 15 46",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jim\u2019s Roofing Services is a part of the very successful Jim\u2019s Group Of Franchisees. The Jim\u2019s Roofing Services group is dedicated to servicing the public with its roofing needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Here are some benefits when going with Jim\u2019s Roofing Services:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have a passion for customer service, and for this we need the best people. Our selection system rejects hundreds of potential Franchisees per year. We look for people with high standards who take pride in their work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "\u2022 Free Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2022 10-15 Year Guarantee",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2022 Experts in Roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2022 Professional Service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jobs done",
                                        "url": "https://jimsroofing.com.au/about-jims/customer-service/",
                                        "urls": [
                                            {
                                                "url": "https://jimsroofing.com.au/about-jims/customer-service/",
                                                "anchor_text": "Jobs done"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "All over the World",
                                        "url": "https://jimsroofing.com.au/become-a-franchisee/",
                                        "urls": [
                                            {
                                                "url": "https://jimsroofing.com.au/become-a-franchisee/",
                                                "anchor_text": "All over the World"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Divisions to Choose From",
                                        "url": "https://jimsroofing.com.au/about-jims/jims-family/",
                                        "urls": [
                                            {
                                                "url": "https://jimsroofing.com.au/about-jims/jims-family/",
                                                "anchor_text": "Divisions to Choose From"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": null,
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "131546"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}