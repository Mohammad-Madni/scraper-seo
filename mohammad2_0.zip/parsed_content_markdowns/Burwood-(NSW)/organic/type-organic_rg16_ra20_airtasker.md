{
    "id": "01190728-1132-0216-0000-dabbb7d09a28",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0231 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.airtasker.com/au/services/roofing/burwood-nsw/",
        "target": "www.airtasker.com",
        "start_url": "https://www.airtasker.com/au/services/roofing/burwood-nsw/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg16_ra20_airtasker.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:30:27 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "What are you looking for?",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Pick a type of task.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "I'm looking for work in ...",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "I\u2019m looking to hire someone for ...",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "As a tasker",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "As a poster",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Auto Electricians",
                                    "url": "https://www.airtasker.com/au/services/auto-electrician/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/auto-electrician/",
                                            "anchor_text": "Auto Electricians"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bicycle Service",
                                    "url": "https://www.airtasker.com/au/services/bicycle/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/bicycle/",
                                            "anchor_text": "Bicycle Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Building & Construction",
                                    "url": "https://www.airtasker.com/au/services/building-construction/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/building-construction/",
                                            "anchor_text": "Building & Construction"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Body Work",
                                    "url": "https://www.airtasker.com/au/services/car-bodywork/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-bodywork/",
                                            "anchor_text": "Car Body Work"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Detailing",
                                    "url": "https://www.airtasker.com/au/services/car-detailing/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-detailing/",
                                            "anchor_text": "Car Detailing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Repair",
                                    "url": "https://www.airtasker.com/au/services/car-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-repair/",
                                            "anchor_text": "Car Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Service",
                                    "url": "https://www.airtasker.com/au/services/car-servicing/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-servicing/",
                                            "anchor_text": "Car Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cat Care",
                                    "url": "https://www.airtasker.com/au/services/cat-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/cat-care/",
                                            "anchor_text": "Cat Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Computers & IT",
                                    "url": "https://www.airtasker.com/au/services/computers/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/computers/",
                                            "anchor_text": "Computers & IT"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dog Care",
                                    "url": "https://www.airtasker.com/au/services/dog-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/dog-care/",
                                            "anchor_text": "Dog Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Furniture Assembly",
                                    "url": "https://www.airtasker.com/au/services/furniture-assembly/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/furniture-assembly/",
                                            "anchor_text": "Furniture Assembly"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gate Installation",
                                    "url": "https://www.airtasker.com/au/services/gate-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/gate-installation/",
                                            "anchor_text": "Gate Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heating & Cooling",
                                    "url": "https://www.airtasker.com/au/services/heating-cooling/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/heating-cooling/",
                                            "anchor_text": "Heating & Cooling"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Automation and Security",
                                    "url": "https://www.airtasker.com/au/services/home-automation-security/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/home-automation-security/",
                                            "anchor_text": "Home Automation and Security"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Theatre",
                                    "url": "https://www.airtasker.com/au/services/home-theatre/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/home-theatre/",
                                            "anchor_text": "Home Theatre"
                                        }
                                    ]
                                },
                                {
                                    "text": "Interior Designer",
                                    "url": "https://www.airtasker.com/au/services/interior-design/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/interior-design/",
                                            "anchor_text": "Interior Designer"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lawn Care",
                                    "url": "https://www.airtasker.com/au/services/lawn-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/lawn-care/",
                                            "anchor_text": "Lawn Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Makeup Artist",
                                    "url": "https://www.airtasker.com/au/services/makeup-artist/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/makeup-artist/",
                                            "anchor_text": "Makeup Artist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mobile Mechanic",
                                    "url": "https://www.airtasker.com/au/services/mobile-mechanic/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/mobile-mechanic/",
                                            "anchor_text": "Mobile Mechanic"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pest Control",
                                    "url": "https://www.airtasker.com/au/services/pest-control/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/pest-control/",
                                            "anchor_text": "Pest Control"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pet Care",
                                    "url": "https://www.airtasker.com/au/services/pet-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/pet-care/",
                                            "anchor_text": "Pet Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pool Maintenance",
                                    "url": "https://www.airtasker.com/au/services/pool-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/pool-maintenance/",
                                            "anchor_text": "Pool Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tattoo Artists",
                                    "url": "https://www.airtasker.com/au/services/tattoo-artist/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/tattoo-artist/",
                                            "anchor_text": "Tattoo Artists"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wall Hanging & Mounting",
                                    "url": "https://www.airtasker.com/au/services/wall-hanging-mounting/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/wall-hanging-mounting/",
                                            "anchor_text": "Wall Hanging & Mounting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wheel & Tyre Service",
                                    "url": "https://www.airtasker.com/au/services/wheel-tyre-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/wheel-tyre-service/",
                                            "anchor_text": "Wheel & Tyre Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "View all",
                                    "url": "https://www.airtasker.com/au/services/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/",
                                            "anchor_text": "View all"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Airtasker Limited 2011-2026 \u00a9, All rights reserved",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Airtasker Limited 2011-2026 \u00a9, All rights reserved",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Existing Members",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Popular Categories",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Popular Locations",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Find experienced local roofers in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Fill in a short form and get free quotes from local roofers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Great rating - 4.2/5 (11114+ reviews)",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get roofing contractors near me today",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Up to 50% cheaper than franchise dealers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No job too big or small",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Same day or next day service at no extra cost",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2026 or anything else",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free insurance coverage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Secure cashless payments",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Best rated roofers near me",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\" Came as agreed neat and tidy As it\u2019s a roof repair put faith in his hands that it\u2019s fixed and he seems to be very exper... \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Punctual, easy to work with and attention to detail. Was happy to solve a few issues that popped up without any concerns... \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Great work cleaning my extremely dirty gutters. Reliable and fast. \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Amazing work! Awesome person. Thank you highly recommended. \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Good job all done great \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Very happy with the work \"",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Joel D",
                                        "url": "https://www.airtasker.com/users/joel-d-26511288/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/joel-d-26511288/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Joel D"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St James NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/st-james-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/st-james-nsw/",
                                                "anchor_text": "St James NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Dean P",
                                        "url": "https://www.airtasker.com/users/69739113c5cb-p-32541940/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/69739113c5cb-p-32541940/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Dean P"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Parramatta NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Liam M",
                                        "url": "https://www.airtasker.com/users/c80b99bff94a-p-31763860/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/c80b99bff94a-p-31763860/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Liam M"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Brisbane City CBD QLD",
                                        "url": "https://www.airtasker.com/au/services/roofing/brisbane-city-cbd-qld/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/brisbane-city-cbd-qld/",
                                                "anchor_text": "Brisbane City CBD QLD"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Laurence S",
                                        "url": "https://www.airtasker.com/users/laurence-s-3094257/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/laurence-s-3094257/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Laurence S"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St James NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/st-james-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/st-james-nsw/",
                                                "anchor_text": "St James NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Police Check",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "NSW Plumbing Licence",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "NSW Gasfitting Licence",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hong N",
                                        "url": "https://www.airtasker.com/users/jason-n-54103/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/jason-n-54103/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Hong N"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Moorebank NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Punctual, quality work \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Payment Method Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Christopher M",
                                        "url": "https://www.airtasker.com/users/christopher-m-5184108/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/christopher-m-5184108/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Christopher M"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "East Sydney NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/east-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/east-sydney-nsw/",
                                                "anchor_text": "East Sydney NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Daniel M",
                                        "url": "https://www.airtasker.com/users/daniel-m-12298677/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/daniel-m-12298677/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Daniel M"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cherrybrook NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/cherrybrook-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/cherrybrook-nsw/",
                                                "anchor_text": "Cherrybrook NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Payment Method Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Daniel K",
                                        "url": "https://www.airtasker.com/users/daniel-k-14125251/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/daniel-k-14125251/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Daniel K"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Coogee NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/coogee-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/coogee-nsw/",
                                                "anchor_text": "Coogee NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Excellent Service...highly recommended \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing reviews in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Ehab was very good and did more than what was asked of him. I fully recommend Ehab for his work as he\u2019s very honest and trustworthy",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clean Gutters & Install Downpipe Spreader",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Happy with Hong and the team - repointed roof and fixed broken tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repair & Re pointing roof tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Happy with the job at this stage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Was very transparent with scheduling and time. Thanks Aidan, will contact you again.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Professional, polite and personable. I wish I had more work just to have him return!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repair/carpenter for roof eve repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast and prompt work. Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jet blast down pipe",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaking roof",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get it done",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Choose the right person for your task and get it done.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get it done now. Pay later.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repay in 4 fortnightly instalments",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Available on payments up to $1,500",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "No interest",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Statistics from the most recent tasks on Airtasker over the last 4 years.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Airtasker has over 15 roofers in Burwood NSW, with an average rating of 5.0 stars from 8 reviews. Get in touch with roofers such as Joel D, Dean P, and Liam M today to get a wide variety of Roofing jobs done.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I would need a quote to replace the tiles. I have plenty of spare tiles.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I would like a quote for the following: we sourced rockwool batts already and have them at the building. The company who did our roof sent a guy to do half the job but could not finish the other half. We have about 100sq metres of roof needing insulation installed. I prefer to have someone with experience finish the job. The only real challenge is the roof cavity entry is narrow (about 1.6sq m)and the insulation batts have to be pushed up through. Happy to help move the large packages of insulation up to the entry point. Probably one day's work or less. There is no old insulation to remove.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "My 90yo elderly father lives alone and his roof has sprung a leak. Its dripping water into the bedroom.\nHe lives in Burwood 2134 (Sydney Inner West).\nI need someone to climb onto the roof and fix the repair (im guessing its a cracked tile).\nSingle storey - easy access. He has a ladder.\nI can meet you on site to guide you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Happy with the job at this stage",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Hi I need someone to help me to clean the gutters. I don't have a ladder so having a ladder is a must.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quotations for repair/restoration/replacement of balcony colorbond roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Air conditioning down pipe blocked. Need jet blast. No big object blocked.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast and prompt work. Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Blast water down pipe, restaurant air conditioning down pipe blocked.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Single story - Roof repair and Re-pointing required. Older federation home located in Burwood.\nBack room has a leak in the roof and there are some cracked tiles that need to be repaired or replaced. Tarp cover required for a small portion immediately and then works can be completed anytime in the next few weeks.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Happy with Hong and the team - repointed roof and fixed broken tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of eve sections for the two damaged areas displayed in the photos. The eve sections are roughly 350 x 2100mm. Preference for a licensed contractor.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Professional, polite and personable. I wish I had more work just to have him return!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I need my roof re sealed and painted, re pointed. Single storey tiled roof. Qualified roof restoration companies please.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We want slate roof specialist to remove temporary tarp on roof, check for any holes, and potentially repair.\n-\nDue date: Flexible",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Small terrace house gutters cleaning needed. Must take waste/rubbish with you please. Must have your own ladder and equipment. -\nDue date: Flexible",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clean gutter for my house\n-\nDue date: Flexible",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Cleaning the gutter for my house.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replace two fly screens for sliding doors. Both are removed, it is a single large piece. Replace hanging bracket for hanging curtains. It is secured with a metal knock in, so you will need to remove that with out damaging the roof. Materials to be included in price and need it done this afternoon around 1-3.\nWe also have a bit of pressure washing to be done if possible, around 5x5m. And a wall to be cleaned by hand. I have my own pressure washer here. Thanks -\nDue date: Needs to be done on Sunday, 30 April 2023",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast and professional. Expert in the field.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "1. Require gutters to be cleaned on one side of the semi property only\n2. Require 2 downpipe spreaders to be installed (front and rear of the property). Downpipes are not PVC and are metal, you must match the pre-existing downpipe which is a rectangle and not round pipe. Not paying $500 for a gutter clean which goes between $150 to $200. Please read the description and photos - if you have any questions please ask. Please refer to the photos as they clearly explain what needs to be done thank you. -\nDue date: Flexible",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ehab was very good and did more than what was asked of him. I fully recommend Ehab for his work as he\u2019s very honest and trustworthy",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A sheet of corrugated iron shifted in the wind on the roof. Needs to be placed back and fixed. -\nDue date: Needs to be done on Tuesday, 3 January 2023\n-\nDue date: Needs to be done on Wednesday, 4 January 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Redo my roofing am wiring\n-\nDue date: Needs to be done on Thursday, 24 November 2022",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Single storey house, metal roof, skylight.\nSome leaking from around the skylight area.\nASAP would be great.\n-\nDue date: Flexible",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Need a roof gutter to be installed\nNeed a quote. Will have more jobs coming up\nNeed a good roofer an experienced roofer\nsomeone that can be trusted\n-\nDue date: Before Monday, November 7, 2022",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Burwood NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Last updated on 10th Jan 2026 11:04am",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Home /",
                                        "url": "https://www.airtasker.com/au/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/",
                                                "anchor_text": "Home"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Services /",
                                        "url": "https://www.airtasker.com/au/services/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/",
                                                "anchor_text": "Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.airtasker.com/au/services/roofing/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "What's the average cost of a roofer in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "What's the average cost of a roofer in Burwood NSW",
                                        "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                                "anchor_text": "What's the average cost of a roofer in Burwood NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "$135 - $255",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Average reviews for Roofing Services in Burwood NSW",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "based on 8 reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Post your task",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tell us what you need, it's FREE to post.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Review offers",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Get offers from trusted Taskers and view profiles.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "14+",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tasks successfully completed",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "2",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Average amount of offers per task",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "12",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "mins",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Average time to receive offers",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Services near me",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Waterproofing near me",
                                        "url": "https://www.airtasker.com/au/services/waterproofing/burwood-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/waterproofing/burwood-nsw/",
                                                "anchor_text": "Waterproofing near me"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Related Locations",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Homebush South",
                                        "url": "https://www.airtasker.com/au/services/roofing/homebush-south-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/homebush-south-nsw/",
                                                "anchor_text": "Homebush South"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "South West Sydney",
                                        "url": "https://www.airtasker.com/au/services/roofing/south-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/south-west-sydney/",
                                                "anchor_text": "South West Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Enfield NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/enfield-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/enfield-nsw/",
                                                "anchor_text": "Enfield NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://www.airtasker.com/au/services/roofing/summer-hill-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/summer-hill-nsw/",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Abbotsford NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/abbotsford-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/abbotsford-nsw/",
                                                "anchor_text": "Abbotsford NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://www.airtasker.com/au/services/roofing/dulwich-hill-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/dulwich-hill-nsw/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/croydon-park-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/croydon-park-nsw/",
                                                "anchor_text": "Croydon Park NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strathfield South",
                                        "url": "https://www.airtasker.com/au/services/roofing/strathfield-south-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/strathfield-south-nsw/",
                                                "anchor_text": "Strathfield South"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Homebush West",
                                        "url": "https://www.airtasker.com/au/services/roofing/homebush-west-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/homebush-west-nsw/",
                                                "anchor_text": "Homebush West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Concord West",
                                        "url": "https://www.airtasker.com/au/services/roofing/concord-west-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/concord-west-nsw/",
                                                "anchor_text": "Concord West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lewisham NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/lewisham-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/lewisham-nsw/",
                                                "anchor_text": "Lewisham NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Coffs Harbour",
                                        "url": "https://www.airtasker.com/au/services/roofing/coffs-harbour/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/coffs-harbour/",
                                                "anchor_text": "Coffs Harbour"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": "https://www.airtasker.com/au/services/roofing/five-dock-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/five-dock-nsw/",
                                                "anchor_text": "Five Dock"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Homebush NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/homebush-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/homebush-nsw/",
                                                "anchor_text": "Homebush NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dobroyd Point",
                                        "url": "https://www.airtasker.com/au/services/roofing/dobroyd-point-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/dobroyd-point-nsw/",
                                                "anchor_text": "Dobroyd Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Annandale NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/annandale-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/annandale-nsw/",
                                                "anchor_text": "Annandale NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Burwood North",
                                        "url": "https://www.airtasker.com/au/services/roofing/burwood-north-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/burwood-north-nsw/",
                                                "anchor_text": "Burwood North"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Ashfield NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/ashfield-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/ashfield-nsw/",
                                                "anchor_text": "Ashfield NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leichhardt NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/leichhardt-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/leichhardt-nsw/",
                                                "anchor_text": "Leichhardt NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strathfield NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/strathfield-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/strathfield-nsw/",
                                                "anchor_text": "Strathfield NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Inner West Sydney",
                                        "url": "https://www.airtasker.com/au/services/roofing/inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/inner-west-sydney/",
                                                "anchor_text": "Inner West Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sutherland Shire",
                                        "url": "https://www.airtasker.com/au/services/roofing/sutherland-shire/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sutherland-shire/",
                                                "anchor_text": "Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Southern Highlands",
                                        "url": "https://www.airtasker.com/au/services/roofing/southern-highlands/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/southern-highlands/",
                                                "anchor_text": "Southern Highlands"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Russell Lea",
                                        "url": "https://www.airtasker.com/au/services/roofing/russell-lea-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/russell-lea-nsw/",
                                                "anchor_text": "Russell Lea"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/croydon-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/croydon-nsw/",
                                                "anchor_text": "Croydon NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Suggested reads about Roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Top Locations",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sunshine Coast Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/sunshine-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sunshine-coast/",
                                                "anchor_text": "Sunshine Coast Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Adelaide Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/adelaide/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/adelaide/",
                                                "anchor_text": "Adelaide Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Perth Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/perth/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/perth/",
                                                "anchor_text": "Perth Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hobart Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/hobart/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/hobart/",
                                                "anchor_text": "Hobart Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Central Coast Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/central-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/central-coast/",
                                                "anchor_text": "Central Coast Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wollongong Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/wollongong-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/wollongong-nsw/",
                                                "anchor_text": "Wollongong Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Newcastle Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/newcastle/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/newcastle/",
                                                "anchor_text": "Newcastle Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sydney/",
                                                "anchor_text": "Sydney Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Parramatta Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/parramatta/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/parramatta/",
                                                "anchor_text": "Parramatta Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Ballarat Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/ballarat/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/ballarat/",
                                                "anchor_text": "Ballarat Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Geelong Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/geelong/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/geelong/",
                                                "anchor_text": "Geelong Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Melbourne Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/melbourne/",
                                                "anchor_text": "Melbourne Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canberra Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/canberra/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/canberra/",
                                                "anchor_text": "Canberra Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Brisbane Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/brisbane/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/brisbane/",
                                                "anchor_text": "Brisbane Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gold Coast Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/gold-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/gold-coast/",
                                                "anchor_text": "Gold Coast Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does gutter cleaning cost in Australia?",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does gutter cleaning cost in Australia?",
                                        "url": "https://www.airtasker.com/au/costs/gutter-cleaning/gutter-cleaning-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/gutter-cleaning/gutter-cleaning-cost/",
                                                "anchor_text": "How much does gutter cleaning cost in Australia?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof plumbing cost?",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does roof plumbing cost?",
                                        "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                                "anchor_text": "How much does roof plumbing cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does a new roof cost in Australia?",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does a new roof cost in Australia?",
                                        "url": "https://www.airtasker.com/au/costs/roof-installation/new-roofing-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roof-installation/new-roofing-cost/",
                                                "anchor_text": "How much does a new roof cost in Australia?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does a chimney sweep cost?",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does a chimney sweep cost?",
                                        "url": "https://www.airtasker.com/au/costs/chimney-sweep/chimney-sweeping-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/chimney-sweep/chimney-sweeping-cost/",
                                                "anchor_text": "How much does a chimney sweep cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof cleaning cost?",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does roof cleaning cost?",
                                        "url": "https://www.airtasker.com/au/costs/roof-cleaning/roof-cleaner-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roof-cleaning/roof-cleaner-cost/",
                                                "anchor_text": "How much does roof cleaning cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Solar panel cleaning cost: What it takes to stay efficient in 2025",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Solar panel cleaning cost: What it takes to stay efficient in 2025",
                                        "url": "https://www.airtasker.com/au/costs/solar-panel-cleaning/solar-panel-cleaning-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/solar-panel-cleaning/solar-panel-cleaning-cost/",
                                                "anchor_text": "Solar panel cleaning cost: What it takes to stay efficient in 2025"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does insulation cost?",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does insulation cost?",
                                        "url": "https://www.airtasker.com/au/costs/insulation/insulation-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/insulation/insulation-cost/",
                                                "anchor_text": "How much does insulation cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How to fix a leaking roof",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to fix a leaking roof",
                                        "url": "https://www.airtasker.com/au/guides/roof-leak-repair/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/guides/roof-leak-repair/",
                                                "anchor_text": "How to fix a leaking roof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How to clean your gutters",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to clean your gutters",
                                        "url": "https://www.airtasker.com/au/guides/how-to-clean-gutters/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/guides/how-to-clean-gutters/",
                                                "anchor_text": "How to clean your gutters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How to fix your roof tiles",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to fix your roof tiles",
                                        "url": "https://www.airtasker.com/au/guides/how-to-fix-roof-tiles/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/guides/how-to-fix-roof-tiles/",
                                                "anchor_text": "How to fix your roof tiles"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tiled roof leaking. Some tiles are cracked and would need replacing.",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW 2134, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "17th Nov 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Quote for insulation install",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood, New South Wales",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "9th Jul 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "22nd May 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter cleaning",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW 2134, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "22nd Jan 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Quotations for balcony roof repair",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "18th Jan 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Jet blast down pipe",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "7th Dec 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Blast water down pipe",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "5th Dec 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Repair & Re pointing roof tiles",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "6th Apr 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof repair/carpenter for roof eve repair",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "27th Feb 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Need a tiled roof restored",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW 2134, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "11th Dec 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate roof specialist to remove roof tarp and a quick inspection",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "7th Dec 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Small terrace house gutter cleaning needed",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "2nd Oct 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Clean gutter",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW 2134, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "15th Jun 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter cleaning",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW 2134, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "15th Jun 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Handyman-replace fly screen on two doors, fixing bracket on roof.",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "29th Apr 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Clean Gutters & Install Downpipe Spreader",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "18th Mar 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Move couple of roof sheets of corrugated iron back into the place.",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "3rd Jan 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "House roof",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "23rd Nov 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof leak around skylight",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "13th Nov 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofer gutter",
                                "main_title": "Find experienced local roofers in Burwood NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "2nd Nov 2022",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 8,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}