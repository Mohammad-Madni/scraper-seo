{
    "id": "01190728-1132-0216-0000-d5e86f67dc61",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0374 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://vertecroofing.com.au/roof-repairs/roof-repairs-burwood",
        "target": "vertecroofing.com.au",
        "start_url": "https://vertecroofing.com.au/roof-repairs/roof-repairs-burwood",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg19_ra23_vertecroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:29 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Mon - Fri: 08.00 - 17.00",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "SYDNEY ROOFING SPECIALISTS",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ROOF TILING",
                                    "url": "https://vertecroofing.com.au/services/roof-tiling/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/roof-tiling/",
                                            "anchor_text": "ROOF TILING"
                                        }
                                    ]
                                },
                                {
                                    "text": "METAL ROOFING",
                                    "url": "https://vertecroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "METAL ROOFING"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF REPAIRS",
                                    "url": "https://vertecroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "ROOF REPAIRS"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF REPLACEMENT",
                                    "url": "https://vertecroofing.com.au/services/roofreplacement/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/roofreplacement/",
                                            "anchor_text": "ROOF REPLACEMENT"
                                        }
                                    ]
                                },
                                {
                                    "text": "STRATA ROOF MAINTENANCE",
                                    "url": "https://vertecroofing.com.au/services/strata-roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/strata-roof-maintenance/",
                                            "anchor_text": "STRATA ROOF MAINTENANCE"
                                        }
                                    ]
                                },
                                {
                                    "text": "GUTTER & FASICA",
                                    "url": "https://vertecroofing.com.au/services/gutter-fasica/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/gutter-fasica/",
                                            "anchor_text": "GUTTER & FASICA"
                                        }
                                    ]
                                },
                                {
                                    "text": "GUTTER CLEANING",
                                    "url": "https://vertecroofing.com.au/services/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/gutter-cleaning/",
                                            "anchor_text": "GUTTER CLEANING"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF RESTORATION",
                                    "url": "https://vertecroofing.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/roof-restoration/",
                                            "anchor_text": "ROOF RESTORATION"
                                        }
                                    ]
                                },
                                {
                                    "text": "WHIRLY BIRD INSTALLATION",
                                    "url": "https://vertecroofing.com.au/services/whirly-bird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/whirly-bird-installation/",
                                            "anchor_text": "WHIRLY BIRD INSTALLATION"
                                        }
                                    ]
                                },
                                {
                                    "text": "SKYLIGHT INSTALLATION",
                                    "url": "https://vertecroofing.com.au/services/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/skylight-installation/",
                                            "anchor_text": "SKYLIGHT INSTALLATION"
                                        }
                                    ]
                                },
                                {
                                    "text": "ABOUT US",
                                    "url": "https://vertecroofing.com.au/about/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/about/",
                                            "anchor_text": "ABOUT US"
                                        }
                                    ]
                                },
                                {
                                    "text": "BOOK A JOB",
                                    "url": "https://vertecroofing.com.au/book-a-job/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/book-a-job/",
                                            "anchor_text": "BOOK A JOB"
                                        }
                                    ]
                                },
                                {
                                    "text": "CONTACT US",
                                    "url": "https://vertecroofing.com.au/contact/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/contact/",
                                            "anchor_text": "CONTACT US"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF TILING",
                                    "url": "https://vertecroofing.com.au/services/roof-tiling/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/roof-tiling/",
                                            "anchor_text": "ROOF TILING"
                                        }
                                    ]
                                },
                                {
                                    "text": "METAL ROOFING",
                                    "url": "https://vertecroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "METAL ROOFING"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF REPAIRS",
                                    "url": "https://vertecroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "ROOF REPAIRS"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF REPLACEMENT",
                                    "url": "https://vertecroofing.com.au/services/roofreplacement/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/roofreplacement/",
                                            "anchor_text": "ROOF REPLACEMENT"
                                        }
                                    ]
                                },
                                {
                                    "text": "STRATA ROOF MAINTENANCE",
                                    "url": "https://vertecroofing.com.au/services/strata-roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/strata-roof-maintenance/",
                                            "anchor_text": "STRATA ROOF MAINTENANCE"
                                        }
                                    ]
                                },
                                {
                                    "text": "GUTTER & FASICA",
                                    "url": "https://vertecroofing.com.au/services/gutter-fasica/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/gutter-fasica/",
                                            "anchor_text": "GUTTER & FASICA"
                                        }
                                    ]
                                },
                                {
                                    "text": "GUTTER CLEANING",
                                    "url": "https://vertecroofing.com.au/services/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/gutter-cleaning/",
                                            "anchor_text": "GUTTER CLEANING"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF RESTORATION",
                                    "url": "https://vertecroofing.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/roof-restoration/",
                                            "anchor_text": "ROOF RESTORATION"
                                        }
                                    ]
                                },
                                {
                                    "text": "WHIRLY BIRD INSTALLATION",
                                    "url": "https://vertecroofing.com.au/services/whirly-bird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/whirly-bird-installation/",
                                            "anchor_text": "WHIRLY BIRD INSTALLATION"
                                        }
                                    ]
                                },
                                {
                                    "text": "SKYLIGHT INSTALLATION",
                                    "url": "https://vertecroofing.com.au/services/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/services/skylight-installation/",
                                            "anchor_text": "SKYLIGHT INSTALLATION"
                                        }
                                    ]
                                },
                                {
                                    "text": "ABOUT US",
                                    "url": "https://vertecroofing.com.au/about/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/about/",
                                            "anchor_text": "ABOUT US"
                                        }
                                    ]
                                },
                                {
                                    "text": "BOOK A JOB",
                                    "url": "https://vertecroofing.com.au/book-a-job/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/book-a-job/",
                                            "anchor_text": "BOOK A JOB"
                                        }
                                    ]
                                },
                                {
                                    "text": "CONTACT US",
                                    "url": "https://vertecroofing.com.au/contact/",
                                    "urls": [
                                        {
                                            "url": "https://vertecroofing.com.au/contact/",
                                            "anchor_text": "CONTACT US"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Reliable and Affordable Burwood Roof Repairs",
                                "main_title": "Roof Repairs Burwood, 2134",
                                "author": null,
                                "language": null,
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With more than 10 years of experience, Vertec Roofing are the trusted choice for Roof Repairs in Burwood. We are committed to providing a fuss-free roofing experience so that you can spend less time worrying about the roof over your head and more time enjoying what\u2019s inside. We stand behind every project that we complete and provide quotes and inspections to help you make the right decision for your Burwood roof repairs",
                                        "url": "https://en.wikipedia.org/wiki/Burwood,_New_South_Wales",
                                        "urls": [
                                            {
                                                "url": "https://en.wikipedia.org/wiki/Burwood,_New_South_Wales",
                                                "anchor_text": "Burwood"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "What Makes Vertec Roofing the Right Choice for Your Burwood, 2134 Roofing Project? Vertec Roofing is a professional, honest and reliable roofing company that provides high-quality and competitively priced roof repairs in Burwood. We understand that delivering roofing services to the Inner West area presents its own unique set of challenges which is why we\u2019ll work with you to identify the best solution for your roof repairs in Burwood. Each property that we work on is completely unique, and so is the solution. We\u2019ll take the time to understand the unique set of circumstances for your Burwood roofing project so that we can find the most reliable and cost-effective solution for you.",
                                        "url": "https://vertecroofing.com.au/roof-repairs/roof-repairs-inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://vertecroofing.com.au/roof-repairs/roof-repairs-inner-west-sydney/",
                                                "anchor_text": "Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whether you\u2019re looking for Commercial, Industrial, or Residential roof repairs in Burwood, our team of roofing professionals is equipped to handle the job. With more than 10 years of experience across a wide range of projects, you can be sure that your Burwood roofing project is in safe hands with Vertec.",
                                        "url": "https://vertecroofing.com.au/commercial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://vertecroofing.com.au/commercial-roofing/",
                                                "anchor_text": "Commercial"
                                            },
                                            {
                                                "url": "https://vertecroofing.com.au/industrial-roofing/",
                                                "anchor_text": "Industrial"
                                            },
                                            {
                                                "url": "https://vertecroofing.com.au/residential-roofing/",
                                                "anchor_text": "Residential"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Vertec Roofing Are the Leading Burwood Roof Repair Experts",
                                "main_title": "Roof Repairs Burwood, 2134",
                                "author": null,
                                "language": null,
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Vertec Roofing Are the Leading Burwood Roof Repairs Experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Looking for the most reliable and efficient Burwood Roof Repairs specialists? You\u2019re in the right place. We offer a range of roof repair solutions to suit your Burwood property. Irrespective of the size or scope of your project, our team of roofing professionals will find a roof repair solution that best suits your needs. Over the last decade we\u2019ve seen more than our fair share of dodgy roofs in Burwood. Despite this, we know that no two roofing projects are the same. That\u2019s why you\u2019ll get a specialised quote and inspection that takes into account your unique set of circumstances. Our goal is to find a lasting and cost-effective solution for your Burwood roof repair project.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Vertec, we love roofing \u2013 but we know that may not be everyone\u2019s cup of tea. A damaged roof at your Burwood property probably seems like more of a pain than an exciting renovation project. Let\u2019s face it, you\u2019re probably not going to see a roof repair week on The Block \u2013 it\u2019s just not that exciting.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "So, while a damaged roof at your Burwood property might not be at the top of your to-do list, it\u2019s important to understand that roof damage, leaks, or holes that are left unrepaired can cause major problems down the line. To ensure that your roof damage doesn\u2019t turn into a continued source of stress, our team provides Burwood roof repair services that will identify the root of your problem. We know that you\u2019ll love the quality of our work, but you probably don\u2019t want to see us again anytime soon. So, rather than just patching your roof with a temporary fix, we provide a complete roof repair solution for our Burwood customers so you won\u2019t need any further work done.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019re proud of our proven track record of providing outstanding roof repairs in Burwood. Our roof repairs experts have been servicing the Burwood area for more than a decade with a long list of satisfied customers who can vouch for the quality and longevity of our workmanship. We are able to repair or replace any leaking or damaged roof efficiently. Whether the cause of the damage is easy to spot or requires a little more investigation, our team of Burwoodroof repairs experts will take the hassle out of repairing your damaged roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Vertec Roofing, you\u2019ll be dealing with an experienced professional for your Burwood roof repairs. We won\u2019t send out a team of novices or apprentices to inspect your roof and perform sub-par repairs, you\u2019ll be dealing with our experienced team of roofing specialists who will take the time to understand your Burwood roofing project and provide you with expert advice from the very first consultation. By dealing directly with the professional, we can assess the specifics of your job with the same person who will be completing the work - so that there won\u2019t be any \u201cunexpected costs\u201d down the line.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Want to talk about your Burwood roof repair project or schedule an inspection? Our team of roofing specialists are available to answer your questions, arrange an inspection and talk about the particulars of your Burwood property. Get in contact today via phone or email to schedule a consultation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Burwood, 2134",
                                "main_title": "Roof Repairs Burwood, 2134",
                                "author": null,
                                "language": null,
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Request a quote",
                                "main_title": "Roof Repairs Burwood, 2134",
                                "author": null,
                                "language": null,
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "AREAS IN SYDNEY INNER WEST SYDNEY WE SERVICE",
                                "main_title": "Roof Repairs Burwood, 2134",
                                "author": null,
                                "language": null,
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61280074366",
                                "+0481 143 181",
                                "0280074366"
                            ],
                            "emails": [
                                "leads@vertecroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}