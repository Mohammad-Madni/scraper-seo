{
    "id": "01190728-1132-0216-0000-83da73deaad8",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0363 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneywideroofingco.com.au/burwood/burwood-heights/",
        "target": "sydneywideroofingco.com.au",
        "start_url": "https://sydneywideroofingco.com.au/burwood/burwood-heights/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg6_ra10_sydneywideroofingco.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:24 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipes",
                                    "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                            "anchor_text": "Gutters and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tile Pointing and Bedding",
                                    "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                            "anchor_text": "Roof Tile Pointing and Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Roofing",
                                    "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                            "anchor_text": "Zinc Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs in Randwick NSW",
                                    "url": "https://sydneywideroofingco.com.au/randwick/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/randwick/",
                                            "anchor_text": "Roof Repairs in Randwick NSW"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Georges River",
                                    "url": "https://sydneywideroofingco.com.au/georges-river/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/georges-river/",
                                            "anchor_text": "Georges River"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Inner West Roof Repairs",
                                    "url": "https://sydneywideroofingco.com.au/inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/inner-west/",
                                            "anchor_text": "Sydney Inner West Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "City of Sydney",
                                    "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                            "anchor_text": "City of Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "GET QUOTE",
                                    "url": "https://sydneywideroofingco.com.au/get-quote/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/get-quote/",
                                            "anchor_text": "GET QUOTE"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "95 Bellingara Rd, Miranda NSW 2228.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "(02) 8294 4654",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Burwood Heights Roof Repair | Restoration | Re-roofing | Gutter Cleaning",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With over 30 years of experience in the roofing industry, you can trust that we\u2019re one of the top roofing businesses in Sydney. Not only have we provided our services to a large number of satisfied clients but also we have a proven track record of excellence. Working closely with our clients to identify their roofing options, find the best solution for their unique case and produce an appealing roof that lasts and this put us ahead of our competitors. We are the leaders among roofing companies because we\u2019re committed to providing the utmost in service using only the very best materials. We are conveniently located in Sydney South at 95 Bellingara Rd Miranda NSW 2228",
                                        "url": "https://www.google.com.au/maps/place/Sydney+Wide+Roofing+Co/@-34.0232185,151.0997513,17z/data=!3m1!4b1!4m5!3m4!1s0x6b12b878fba38d03:0xafa4b22115163d7!8m2!3d-34.023223!4d151.10194",
                                        "urls": [
                                            {
                                                "url": "https://www.google.com.au/maps/place/Sydney+Wide+Roofing+Co/@-34.0232185,151.0997513,17z/data=!3m1!4b1!4m5!3m4!1s0x6b12b878fba38d03:0xafa4b22115163d7!8m2!3d-34.023223!4d151.10194",
                                                "anchor_text": "95 Bellingara Rd Miranda NSW 2228"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney Wide Roofing Company\u00a0is the premier roofing company in Sydney with over three decades of experience serving most of NSW. We specialise in all roofing products including; Colorbond, slate, metal, tile, copper, gabled, pitched, skillion and polycarbonate roofing. Our full list of service includes; roof repair, roof leak repair, roof restoration, gutters and downpipes and roof installs. We also offer services in the commercial roofing industry.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Height \u2018s favourite Master Roofer",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Wide Roofing is one of the select few contractors who has fully accredited Master Roofer contractors in the whole of Sydney. Having been bestowed such prestigious accreditation, we must adhere to much more stringent requirements than your regular roofing company. Our roofers only deliver the highest levels of service, safety and quality. We are constantly being vetted to ensure we maintain the highest levels of service possible, as such all our jobs come with a lifetime guarantee on all roofing works.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Burwood Height \u2018s favourite Master Roofer",
                                        "url": "https://goo.gl/maps/9P3BgHSYxBx",
                                        "urls": [
                                            {
                                                "url": "https://goo.gl/maps/9P3BgHSYxBx",
                                                "anchor_text": "Burwood Height"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why use a Master Roofer?",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The few Master Roofers who do operate in Sydney receive their accreditation from Master Roof Tilers and Slaters Australia (MRTSA), and make no mistake, Master Roofers are the cream of the crop in the highly competitive roofing industry. We provide a highly reliable and professional service to suit any budget. The road to become a Master Roofer is not one easily walked, one must pass various tests where he/she is judged upon their expertise, workmanship and knowledge of safety standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cAt Sydney Roofing Co we understand that your roof is not just a roof; it is the only layer of protection your family has against the harsh Australian elements\u201d.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Check Out Our Google+ Page",
                                        "url": "http://sydney-wide-roofing-co.business.site/",
                                        "urls": [
                                            {
                                                "url": "http://sydney-wide-roofing-co.business.site/",
                                                "anchor_text": "Check Out Our Google+ Page"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Experts in Roof Repair",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our roof repair service includes general repairs, repairs of broken or damaged tiles, repair of roof hips and skellions and repair of water leaks",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installs",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "A re-roofing or brand new roof install project can be stressful project, which is why you need the best contractors to help ease you through the process.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Bedding",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Pointing has the function of binding the ridge capping onto the tiles so that the tiles do not get blown off in strong winds.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "December 21st, 2025 |",
                                        "url": "https://sydneywideroofingco.com.au/author/admin/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/author/admin/",
                                                "anchor_text": "admin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Picture water slowly tracking under your roof tiles during Sydney's next downpour. Not through obvious damage you can see, but through tiny gaps where metal meets tile. That's the reality when flashing fails. And it",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                        "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                                "anchor_text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Steps to Fix Broken, Cracked, or Dislodged Roof Tiles",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "November 14th, 2025 |",
                                        "url": "https://sydneywideroofingco.com.au/author/admin/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/author/admin/",
                                                "anchor_text": "admin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Broken, cracked, or dislodged roof tiles can lead to major issues if not repaired quickly. These tiles shield your home from the weather, and any damage could allow leaks or water to cause further harm.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Steps to Fix Broken, Cracked, or Dislodged Roof Tiles",
                                        "url": "https://sydneywideroofingco.com.au/steps-to-fix-broken-cracked-or-dislodged-roof-tiles/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/steps-to-fix-broken-cracked-or-dislodged-roof-tiles/",
                                                "anchor_text": "Steps to Fix Broken, Cracked, or Dislodged Roof Tiles"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "October 10th, 2025 |",
                                        "url": "https://sydneywideroofingco.com.au/author/admin/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/author/admin/",
                                                "anchor_text": "admin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Clogged gutters cause issues for your roof, especially for tiles and ridge capping. Blocked gutters lead to water overflow, which can damage the roof structure. This damages the tiles and ridge capping, resulting in leaks",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                        "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                                "anchor_text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Freshen up your Roof",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We specialise in the restoration of all types of roofs including; Colorbond, slate, metal, tin, terracotta and tiled.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Roofing",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leak Repair",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof leaks may be insignificant to begin with. However, they can soon turn into an expensive problem with water damage and mould",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters Downpipes",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Freshen up your Roof",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If not properly maintained your gutter and down-pipe system can soon cause an immense amount of damage to your home",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Pointing",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Handy Tips About Roofing",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leaks",
                                        "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                                "anchor_text": "Roof Leaks"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-roofing",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Re-roofing",
                                        "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                                "anchor_text": "Re-roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Downpipes",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                                "anchor_text": "Roof Tiling"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our company is conveniently located near some of Sydney\u2019s best sites including;",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "\u2013\u00a0Centennial Park",
                                        "url": "https://www.google.com.au/maps/place/Centennial+Park+NSW+2021/@-33.8977587,151.2238325,15z/",
                                        "urls": [
                                            {
                                                "url": "https://www.google.com.au/maps/place/Centennial+Park+NSW+2021/@-33.8977587,151.2238325,15z/",
                                                "anchor_text": "\u2013\u00a0 Centennial Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "\u2013 Bondi Beach",
                                        "url": "https://www.google.com.au/maps/place/Bondi+Beach+NSW+2026/@-33.9069836,151.1813126,12.98z/",
                                        "urls": [
                                            {
                                                "url": "https://www.google.com.au/maps/place/Bondi+Beach+NSW+2026/@-33.9069836,151.1813126,12.98z/",
                                                "anchor_text": "\u2013 Bondi Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "\u2013 Cronulla Beach",
                                        "url": "https://www.google.com.au/maps/place/Cronulla+Beach/@-34.0526384,151.1431515,14.22z/",
                                        "urls": [
                                            {
                                                "url": "https://www.google.com.au/maps/place/Cronulla+Beach/@-34.0526384,151.1431515,14.22z/",
                                                "anchor_text": "\u2013 Cronulla Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "\u2013 Royal National Park",
                                        "url": "https://www.google.com.au/maps/place/Royal+National+Park+NSW+2233/@-34.1062063,151.0125321,12z/",
                                        "urls": [
                                            {
                                                "url": "https://www.google.com.au/maps/place/Royal+National+Park+NSW+2233/@-34.1062063,151.0125321,12z/",
                                                "anchor_text": "Royal National Park"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Read all of our reviews on Google +",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Read all of our reviews on Google +",
                                        "url": "https://plus.google.com/u/0/117630578737877513335/about/",
                                        "urls": [
                                            {
                                                "url": "https://plus.google.com/u/0/117630578737877513335/about/",
                                                "anchor_text": "Read all of our reviews on Google +"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Latest News",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide",
                                        "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-repair-or-replace-flashing-on-tiled-roofs-sydney-homeowners-complete-guide/",
                                                "anchor_text": "How to Repair or Replace Flashing on Tiled Roofs: Sydney Homeowner\u2019s Complete Guide"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way",
                                        "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-clean-clogged-gutters-to-protect-roof-tiles-and-ridge-capping/",
                                                "anchor_text": "Protect Roof Tiles and Ridge Capping: Clean Your Gutters the Right Way"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations We Service",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sutherland Shire",
                                        "url": "https://sydneywideroofingco.com.au/home/sutherland-shire/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/home/sutherland-shire/",
                                                "anchor_text": "Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/home/eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/home/eastern-suburbs/",
                                                "anchor_text": "Eastern Suburbs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georges River",
                                        "url": "https://sydneywideroofingco.com.au/sydney/georges-river/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sydney/georges-river/",
                                                "anchor_text": "Georges River"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Northern Beaches",
                                        "url": "https://sydneywideroofingco.com.au/sydney/northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sydney/northern-beaches/",
                                                "anchor_text": "Northern Beaches"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Central Coast",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Building Inspiring Roofs",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Only takes a few seconds!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Locations in Canterbury-Bankstown We Service",
                                "main_title": "Burwood Heights Roofing | Call us now on\u00a0(02) 8294 4654",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Burwood Heights",
                                        "url": "https://sydneywideroofingco.com.au/sydney/burwood/burwood-heights/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sydney/burwood/burwood-heights/",
                                                "anchor_text": "Burwood Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Enfield South",
                                        "url": "https://sydneywideroofingco.com.au/sydney/burwood/enfield-south/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sydney/burwood/enfield-south/",
                                                "anchor_text": "Enfield South"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61282944654"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}