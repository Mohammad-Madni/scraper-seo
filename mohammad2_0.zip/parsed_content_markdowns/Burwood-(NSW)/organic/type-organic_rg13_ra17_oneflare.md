{
    "id": "01190728-1132-0216-0000-143e6f7a6056",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0194 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.oneflare.com.au/roofing/nsw/burwood",
        "target": "www.oneflare.com.au",
        "start_url": "https://www.oneflare.com.au/roofing/nsw/burwood",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg13_ra17_oneflare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:23 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Best roofing experts in Burwood",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Post a job now to get quotes from local roofing experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average rating of roofing experts in Burwood based on 268 reviews of 39 businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oneflare /",
                                        "url": "https://www.oneflare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/",
                                                "anchor_text": "Oneflare"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Categories /",
                                        "url": "https://www.oneflare.com.au/directory",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/directory",
                                                "anchor_text": "Categories"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.oneflare.com.au/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NSW /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw",
                                                "anchor_text": "NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                                "anchor_text": "Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Plumbing Expert",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood, NSW (0.2km from Burwood)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are Professional Roofing Company Based on Whole around the Sydney.We are mutually trade ,hardworking ,fit,smart and young who pride to take care in my work and delivering a professional Australia standard result . I run a fully insured and licensed . We Offer Gutter Cleaning Gutter Guard Installation\nGutter Installation High Pressure Wash Roof and Drive way Rebedding and Pointing Installation Metal roof On and Off Roof Repair Fasical Board Replace and Paint Gyprock Installation\nRoof Restoration We will look Forward to work with You ..\nYours Regard Roof Plumbing Expert Group\nwww.roofplumbingexpert.com.au [email\u00a0protected] 0416224505",
                                        "url": "https://www.oneflare.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Plumbing Expert",
                                        "url": "https://www.oneflare.com.au/b/roof-plumbing-expert-50",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roof-plumbing-expert-50",
                                                "anchor_text": "Roof Plumbing Expert"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Interstate Prestige Roofing",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Olympic Park, NSW (4.4km from Sydney Olympic Park)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All types of Roof maintenance we do! \u2022 Gutter Cleaning\n\u2022 Roof Repairs\n\u2022 Drive way Sealing\n\u2022 Roof Restorations\n\u2022 Roof Replacement\n\u2022 We specialise in, terracotta, concrete and Slate roof tiles.\n\u2022 7 Years Warranty\nEvery job is provided with warranty. Rain, hail or shine we are at your doorstep!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Interstate Prestige Roofing",
                                        "url": "https://www.oneflare.com.au/b/interstate-prestige-roofing-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/interstate-prestige-roofing-roofing",
                                                "anchor_text": "Interstate Prestige Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Flash Plumbing Services",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Concord, NSW (2.3km from Concord)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flash plumbing services specialise in New residential plumbing (free quote)\ndrain cleaning and drain maintenance and utilise our custom built vehicles fitted with the latest equipment available High Pressure water jet cleaner for all blocked drains and sewer problems\nPlumbing for kitchens and bathrooms Roof and guttering repairs and installation Gas Installation, maintenance and repairs Complete Bathroom renovations\nNew Residential Plumbing / Gas / Drainage\nC.C T.V diagnostic pipe camera Electronic underground pipe and cable locator Hot Water Systems New - Repairs\nBackflow Prevention inspections and testing\nThermostatic Mixing Valves Electronic Pipe Location and Leak Detection .",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Flash Plumbing Services",
                                        "url": "https://www.oneflare.com.au/b/flash-plumbing-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/flash-plumbing-services",
                                                "anchor_text": "Flash Plumbing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Deen Roofing Verified Business",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Auburn, NSW (7.0km from Auburn)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Deen Roofing focuses on the quality of work and our customer's satisfaction, we strive to provide the best experience possible for our customers, from the quality of work achieved to the quality of service provided to our customers. We offer a free no obligation quote. We possess over 10 years experience in the Roofing business and we endeavor to provide quality results to our customers for their roofing needs in every possible means.\nNo job is too big or too small and travelling is not an issue for us as Customer's satisfaction is our high priority.\nOur services include the following:\n-Gutter , downpipes , fascia installation & repair -Roof leak repair & general roof repair\n-Roof Restoration\n-Metal Roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Deen Roofing Verified Business",
                                        "url": "https://www.oneflare.com.au/b/deen-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/deen-roofing",
                                                "anchor_text": "Deen Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing123 Verified Business",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Auburn, NSW (7.6km from Auburn)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hi my name is Mo from Roofing123 I am 40 years of age and the current business owner. I have 9 years of roofing experience. I take great pride in all work I provide. My business focuses on all roofing maintenance and repairs along with gutter cleaning services. Thank you in advance for taking the time to read my business description. Please call Mo on 0420907147 for all your gutter cleaning and roofing maintenance thank you.\nMouhmad https://roofing123.webflow.io",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing123 Verified Business",
                                        "url": "https://www.oneflare.com.au/b/roofing123-484",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roofing123-484",
                                                "anchor_text": "Roofing123"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Oracle Carpentry Sydney Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Chullora, NSW (5.4km from Chullora)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Established in 1995, Oracle roofing are well established, highly experienced, skilled, professional and extremely reliable providing the very best roofing services in the Sydney Metropolitan area.\nRoof repairs and maintenance is the top quality of our work. We specialise in roof leak detection and all roof maintenance services - including gutter and down pipe installation, gutter installation and cleaning, roof restoration, roof carpentry, roof painting and skylight installation. Our emphasis has been and always will be to provide top quality work and service at all times.\nWe are a team of 11 experienced professionals and able to service your needs at all times and provide quick and efficient service. We provide free site inspections, and at times, within hours of",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oracle Carpentry Sydney Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/sydney-home-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/sydney-home-services",
                                                "anchor_text": "Oracle Carpentry Sydney Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slide 1 of 27",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Roofing Services",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Croydon, NSW (1.1km from Croydon)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All Roofing Services has provided the Innerwest Sydney area with experienced, professional roof installation, repair maintenance advice and assessment, restoration and replacement for over 10 years. ARS specialise in Metal and Colorbond roof installation and replacement for residences and small businesses. We have expanded across Sydney with our Roof Replacements.\nAll Roofing Services also provide all aspects of services for roof plumbing and gutter installation, repair assessment and replacement and asbestos removal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Roofing Services",
                                        "url": "https://www.oneflare.com.au/b/all-roofing-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-roofing-services",
                                                "anchor_text": "All Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Kesov Roofing",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Westmead, NSW (13.5km from Westmead)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We specialise in metal roof replacement, gutter installation and all types of roof repair.\nKesov roofing is a local business we servicing Sydney Eastern Suburb and Western suburb. We are highly professional - fully qualified and fully insured service will help put your mind at ease with your roofing job. All quotes are free.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Kesov Roofing",
                                        "url": "https://www.oneflare.com.au/b/kesov-roof-fix",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/kesov-roof-fix",
                                                "anchor_text": "Kesov Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ajm Roofing & Guttering Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Chester Hill, NSW (10.0km from Chester Hill)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "AJM Roofing and Guttering specialise in the installation of all metal roofing, fascia and guttering and water leaks. Wether it is a new roof or repairs to an existing house, we will be able to assist. Please feel free to contact us for to arrange a quote for your job.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ajm Roofing & Guttering Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/ajm-roofing-and-guttering",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/ajm-roofing-and-guttering",
                                                "anchor_text": "Ajm Roofing & Guttering Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Render My Home Pty Ltd",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Waterloo, NSW (9.9km from Waterloo)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Render My Home is your one-stop design and building service that Renovates, Rejuvenates and Restores your home facade. We only deal with quality products and systems from trusted suppliers. Render My Home are accredited and use products by Dulux and CSR.\nRender My Home \u2013 Exterior Fa\u00e7ade Home Improvement Specialists, can dramatically boost your home\u2019s value by transforming your home into a vibrant and intriguing reflection of your own personal style and individualism. For all small and large jobs, Render My Home specialises in restoring and rejuvenating your homes facade, by using renders, coatings, wall panels, paints, landscaping, tiling, balustrade upgrades, roof restorations, awnings and shutters to breathe new life into your home.\nThe Render My Home design team are",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Render My Home Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/render-my-home-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/render-my-home-pty-ltd",
                                                "anchor_text": "Render My Home Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Apexlineroofing",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Yagoona, NSW (8.3km from Yagoona)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Apexline Roofing is a Sydney-based roofing company delivering high-quality residential and commercial roofing solutions. Founded last year, the business combines skilled craftsmanship, premium Australian materials, and modern installation techniques to produce durable, weather-resistant roofs suited to Sydney\u2019s climate. Apexline Roofing is known for its reliable scheduling, clear and honest pricing, fast response times, and a strong focus on customer satisfaction. Every project is approached with attention to detail, safety, and long-term performance, making Apexline Roofing a trusted choice for dependable roofing services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Apexlineroofing",
                                        "url": "https://www.oneflare.com.au/b/apexlineroofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/apexlineroofing",
                                                "anchor_text": "Apexlineroofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aus Topline Roofing",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "South Granville, NSW (8.9km from South Granville)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Aus Topline Roofing is owned and operated by Gaz who is a Licensed Tradie with over 7 years industry experience.\nOur aim is to provide professional, quality service at affordable prices. Over 7 years experience in the Roofing and Guttering industry. I guarantee to provide the best customer service to all my customers and in the past 7 years! Our clients are our number one priority, and we will go the extra mile to make sure they're completely satisfied with the work. Contact me today for a free quote and inquiry!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aus Topline Roofing",
                                        "url": "https://www.oneflare.com.au/b/austopline-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/austopline-roofing",
                                                "anchor_text": "Aus Topline Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Care Roof Services",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield, NSW (2.4km from Ashfield)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All Care Roofing specialise in Roof Restoration and all roof maintenance work. Servicing all areas of Sydney we strive to provide top quality roof services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Care Roof Services",
                                        "url": "https://www.oneflare.com.au/b/all-care-roof-services-508",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-care-roof-services-508",
                                                "anchor_text": "All Care Roof Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Strong Shield Roofing",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Mount Lewis, NSW (6.7km from Mount Lewis)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are dedicated roofing professionals committed to delivering high-quality workmanship on every project, regardless of size or complexity. Our focus is on precision, durability, and long-term performance. You can trust us with your roof, as we take pride in providing reliable, compliant solutions\u2014because strong homes require strong roofs, and that is exactly what we deliver",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Strong Shield Roofing",
                                        "url": "https://www.oneflare.com.au/b/strong-shield-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/strong-shield-roofing",
                                                "anchor_text": "Strong Shield Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Khn Roofing Pty Ltd",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "North Parramatta, NSW (12.5km from North Parramatta)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Specialising in: colour bond guttering and fascia, roofing & downpipes , skylight, Over 20 years experience in the industry. Fully Licensed and insured company with all tradesmen individually licensed for your peace of mind. All products and profiles available to us. Deal direct and cut out the middle man saves you money.\nSome of our major services include: \u2022 Guttering \u2022 Fascia \u2022 Downpipes \u2022 Leaf Protection \u2022 Colour bond roofing \u2022 Roofing * Gutter Replacement * Re-Roofing\nRoofs are prone to damage for exposure to harsh weather conditions such as snow, heavy rain, ice, hail, hurricanes, sun damage and storms. Sometimes leaks and other forms of damage start small and eventually become a bigger problem that needs to be",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Khn Roofing Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/khn-roofing-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/khn-roofing-pty-ltd",
                                                "anchor_text": "Khn Roofing Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Nicos Building Services",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Wentworthville, NSW (14.6km from Wentworthville)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Licensed and insured home renovation and maintenance specialists. Call today for a free quote.\nLicense no: 223788C. Servicing Penrith to Katoomba, NSW",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Nicos Building Services",
                                        "url": "https://www.oneflare.com.au/b/nicos-building-services-672",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/nicos-building-services-672",
                                                "anchor_text": "Nicos Building Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Abu-suleiman, Abdel-hamid Yousef Verified Business",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Chipping Norton, NSW (14.3km from Chipping Norton)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof restoration, stop leaking, fix roof leaking, all home maintenance.\nRoof cleaning Clean gutters Install new roofs\nMetal and tiles roof\nRoof painting Roof repointing Fix ridge capping Install flashing Seal windows Install skylights\nMaintain skylights leaking Emergency services\nMake safe services\nFix doors and windows\nCover all areas of sydney",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Abu-suleiman, Abdel-hamid Yousef Verified Business",
                                        "url": "https://www.oneflare.com.au/b/handy-roofer",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/handy-roofer",
                                                "anchor_text": "Abu-suleiman, Abdel-hamid Yousef"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing And Cladding",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Wetherill Park, NSW (18.1km from Wetherill Park)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our Team of Professionals specializes in METAL ROOFING ands WALL CLADDING installations, which basically adds value and beautifies your house, provided with a longer lifespan, depending the type of material you select from our wide range of exquisite stylish materials.\nOur team works professionally with great attention to detail & enthusiasm.\nApart from wall cladding we provide services such as Re-roofing, new roofing, guttering, skylights, whirlybird and other roofing services.\nInstalling Metal Wall Cladding is an ELEGANT and BREATH TAKING feature, suitable indoor or outdoor and is completely waterproof, plus it comes in a variety of exquisite colours which will leave your staring.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing And Cladding",
                                        "url": "https://www.oneflare.com.au/b/roofing-and-cladding",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roofing-and-cladding",
                                                "anchor_text": "Roofing And Cladding"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Popular roofing jobs in Burwood",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Job Description: Hi, We want to fix the roof with tile and metal. please find attached pics.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified Verified Information Phone number has been verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified Mobile Phone number has been verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Job Description: - Remove and replace pointing on ridge lines.\n- Install storm seals to all valleys on the roof.\n- Clean out gutters around the roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Job Description: recent bad weather caused rain water leaked to ground and level one wall and doors, detail what happen on roof not know",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing service required: Fix leaking water | Type of roof: Steel / metal / colourbond | Type of building: Multi-level home / building",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Handyman job",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Posted by Shruti",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing job",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Posted by Mike",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing job",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Posted by Lisa",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get the right price for your job",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Oneflare Cost Guide Centre is your one-stop shop to help you set your budget; from smaller tasks to larger projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Top Burwood roofing experts near you",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Browse top Roofing Expert experts with top ratings and reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best roofing experts in Burwood",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "View more roofing experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Truss costs",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Truss costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Roof Truss costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $9,000 - $15,000",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Average price $9,000 - $15,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof costs",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roof costs",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Colorbond Roof costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $15,000 - $25,000",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Average price $15,000 - $25,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling costs",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Roof Tiling costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $35 - $140 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Average price $35 - $140 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing costs",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing costs",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Roofing costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $45 - $90 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Average price $45 - $90 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse roofing experts by suburb",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular searches on Oneflare",
                                "main_title": "Best roofing experts in Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.8,
                                "max_rating_value": 5,
                                "rating_count": 268,
                                "relative_rating": 0.96
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}