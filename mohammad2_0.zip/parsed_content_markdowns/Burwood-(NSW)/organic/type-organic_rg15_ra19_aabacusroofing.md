{
    "id": "01191136-1132-0216-0000-198e869bcdaf",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0140 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://aabacusroofing.com.au/roof-restoration-burwood/",
        "target": "aabacusroofing.com.au",
        "start_url": "https://aabacusroofing.com.au/roof-restoration-burwood/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": false,
        "load_resources": false,
        "enable_browser_rendering": false,
        "enable_xhr": false,
        "disable_cookie_popup": false,
        "browser_preset": "desktop",
        "tag": "parsed_content_markdowns\\Burwood-(NSW)\\organic\\type-organic_rg15_ra19_aabacusroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 07:37:13 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Roof Restoration, Maintenance and Repair Specialists in Sydney",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "0404 397 198",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://aabacusroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://aabacusroofing.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://aabacusroofing.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://aabacusroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "High Pressure Cleaning",
                                    "url": "https://aabacusroofing.com.au/high-pressure-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/high-pressure-cleaning-sydney/",
                                            "anchor_text": "High Pressure Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://aabacusroofing.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://aabacusroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "You can be confident that you are working with a qualified, professional, and experienced tradesman when you contact Aabacus Roofing Solutions. We offer a free inspection and quote that is not obligated.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2025 Aabacus Roofing Solutions All Rights Reserved.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Aabacus Roofing Solutions",
                                    "url": "https://maps.app.goo.gl/QDWnRsGth58o1WKM7",
                                    "urls": [
                                        {
                                            "url": "https://maps.app.goo.gl/QDWnRsGth58o1WKM7",
                                            "anchor_text": "Aabacus Roofing Solutions"
                                        }
                                    ]
                                },
                                {
                                    "text": "0404 397 198",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://aabacusroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://aabacusroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://aabacusroofing.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://aabacusroofing.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://aabacusroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "High Pressure Cleaning",
                                    "url": "https://aabacusroofing.com.au/high-pressure-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/high-pressure-cleaning-sydney/",
                                            "anchor_text": "High Pressure Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning North Shore",
                                    "url": "https://aabacusroofing.com.au/gutter-cleaning-north-shore/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/gutter-cleaning-north-shore/",
                                            "anchor_text": "Gutter Cleaning North Shore"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://aabacusroofing.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://aabacusroofing.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Term & Conditions",
                                    "url": "https://aabacusroofing.com.au/terms-and-conditions-of-use/",
                                    "urls": [
                                        {
                                            "url": "https://aabacusroofing.com.au/terms-and-conditions-of-use/",
                                            "anchor_text": "Term & Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Thanks for sharing!",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "How Can Our Roof Restoration Team in Burwood Help You?",
                                "main_title": "Roof Restoration Burwood",
                                "author": "ROOF REPAIRS SYDNEY",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Repair Leaks and flashing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guttering and valley replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Re-bed loose ridge capping",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Re-point all ridge capping",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whirly Bird (roof ventilators)",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Besides improving the appearance of your roof, our team will ensure it protects your family from external elements. Your home is a significant asset, and you would want it to remain functional. You also want your home to look beautiful if you wish to sell it in the future. The roof plays a significant role in the overall appearance of your home. For this reason, our roof restoration team in Burwood is ready to help you achieve the roof you want.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof restoration depends on the type of roof you have. Not all roofs require significant repairs. Some need a thorough cleaning, while others require cleaning and resealing. Fortunately, our team can handle any restoration service. Here are the roof restoration services we can help you with.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacing broken tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "High-pressure Cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Re-colouring and glazing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Restoration Burwood",
                                "main_title": "Roof Restoration Burwood",
                                "author": "ROOF REPAIRS SYDNEY",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Experienced Roof Restoration Experts in Burwood",
                                "main_title": "Roof Restoration Burwood",
                                "author": "ROOF REPAIRS SYDNEY",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "With over 15 years of experience, you can trust our roof restoration experts in Burwood to provide quality services. Aabacus Roofing Solutions consists of professional, experienced, and fully qualified tradespeople. We specialise in roof repair, restoration, painting, and high-pressure cleaning. Hiring us guarantees that you will have a beautiful and functional roof. Our team provides honest and reliable work. We will not charge you for non-existing work and will complete it as if we were doing it at our own home.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Having a functional and resistant roof is essential for the safety of your family, property, and home. A poorly installed or maintained roof could lead to expensive repairs. Our qualified team can help you eliminate this risk. We will get your roof back to looking its best and give you peace of mind about the quality of your roofing. Call us to experience our difference.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contacting Our Roof Restoration Experts in Burwood",
                                "main_title": "Roof Restoration Burwood",
                                "author": "ROOF REPAIRS SYDNEY",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Are you tired of searching for a reliable roof restoration team in Burwood? Worry no more. Aabacus Roofing Solutions is experienced and will not leave your home until you are satisfied. We offer free, no-obligation inspections and quotes to ensure you can afford our services. We also know that cost is a concern for everybody. So, we strive to offer the best prices without cutting corners on the materials or quality of the work. Our work and excellent customer service have earned us many positive reviews, including;",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201cWe had our roof restored. They were very helpful and gave us a great quote. They came and did the job, the roof look amazing and I have no more leaks. I have so far had them do two jobs for me. They recently came and painted a flat roof. I know they are the only roofers that I need to call if I ever have a problem. If its and emergency he would even come out in the rain. Great guy and great service. I highly recommend them.\u201d",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Mary Epping NSW.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Let the roof restoration experts in Burwood help you get a durable and functional roof. Call us today for a free inspection and quote.",
                                "main_title": "Roof Restoration Burwood",
                                "author": "ROOF REPAIRS SYDNEY",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0404 397 198",
                                "0404397198",
                                "+61404397198"
                            ],
                            "emails": [
                                "aabacusroofing1@gmail.com"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}