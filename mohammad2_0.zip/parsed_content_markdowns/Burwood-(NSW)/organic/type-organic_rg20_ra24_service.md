{
    "id": "01190728-1132-0216-0000-c87445fdf47d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0399 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.service.com.au/find/roofing/burwood-2765-nsw?page=4",
        "target": "www.service.com.au",
        "start_url": "https://www.service.com.au/find/roofing/burwood-2765-nsw?page=4",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg20_ra24_service.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:24 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Sign in",
                                    "url": "https://www.service.com.au/login",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/login",
                                            "anchor_text": "Sign in"
                                        }
                                    ]
                                },
                                {
                                    "text": "How it works",
                                    "url": "https://www.service.com.au/how-it-works/its-so-easy",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/how-it-works/its-so-easy",
                                            "anchor_text": "How it works"
                                        }
                                    ]
                                },
                                {
                                    "text": "List your business",
                                    "url": "https://www.service.com.au/businesses/join",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/businesses/join",
                                            "anchor_text": "List your business"
                                        }
                                    ]
                                },
                                {
                                    "text": "Post a job",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Service.com.au is Australia\u2019s leading platform for connecting anyone looking\nfor local trades and service providers, to top quality, verified, small to medium-sized\nservice businesses.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://www.service.com.au/about",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/about",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://www.service.com.au/privacy",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/privacy",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://www.service.com.au/terms",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/terms",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "List Your Business",
                                    "url": "https://www.service.com.au/why-us",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/why-us",
                                            "anchor_text": "List Your Business"
                                        }
                                    ]
                                },
                                {
                                    "text": "How It Works",
                                    "url": "https://www.service.com.au/how-it-works",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/how-it-works",
                                            "anchor_text": "How It Works"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get The App",
                                    "url": "https://www.service.com.au/app",
                                    "urls": [
                                        {
                                            "url": "https://www.service.com.au/app",
                                            "anchor_text": "Get The App"
                                        }
                                    ]
                                },
                                {
                                    "text": "\u00a9 2026 Service.com.au",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Find trusted and local Roofing in Burwood",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Looking for a roofer that meets or exceeds your needs doesn\u2019t have to be a difficult task. Service.com.au is the perfect tool to match you with a premier roofing specialist in Burwood, NSW. If you need someone who\u2019s dedicated to completing your job to the highest of standards, the local roofers on our site are committed to doing just that. Request a quote and let these skilled professionals tender for your project today. Extra perks include:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Safety first",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Choose from the great list of high-quality, pre-vetted roofers on Service.com.au. Rest assured, only reputable professionals committed to safety and quality feature on our platform, guaranteeing a secure renovation experience for your family or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing\nin Burwood",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roofing by state",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing by suburb",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "List your business for free",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Have your own roofing business?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Be found online and start receiving qualified leads today.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Choose the business that suits you",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free to use with no obligation to hire",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Dawes Point",
                                        "url": "https://www.service.com.au/find/roofing/dawes-point-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/dawes-point-nsw",
                                                "anchor_text": "Dawes Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Forest Lodge",
                                        "url": "https://www.service.com.au/find/roofing/forest-lodge-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/forest-lodge-nsw",
                                                "anchor_text": "Forest Lodge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Get multiple quotes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "3 step verification process",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Find trusted and local Roofing in Burwood",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Looking for a roofer that meets or exceeds your needs doesn\u2019t have to be a difficult task. Service.com.au is the perfect tool to match you with a premier roofing specialist in Burwood, NSW. If you need someone who\u2019s dedicated to completing your job to the highest of standards, the local roofers on our site are committed to doing just that. Request a quote and let these skilled professionals tender for your project today. Extra perks include:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Safety first",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Choose from the great list of high-quality, pre-vetted roofers on Service.com.au. Rest assured, only reputable professionals committed to safety and quality feature on our platform, guaranteeing a secure renovation experience for your family or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Personalised expertise",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Our quoting system ensures you receive quotes exclusively from roofers equipped to handle your specific requirements. Save time and frustration by obtaining tailored quotes from the right experts.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Safe practices",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Our roofers will always prioritise safety and quality during your roofing project to prevent danger and ensure positive outcomes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fitted to your budget",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Enjoy competitive pricing without ever compromising on quality, as our listed roofers deliver exceptional service at affordable rates.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing\nin Burwood",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Average rating\nof 4.83",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Top 10 results for Roofing in Burwood",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a Quote",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "GRR Building Construction Group Pty Ltd",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Quality workmanship that is guaranteed.\nGRR Building Construction Group Pty Ltd is a we",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "GRR Building Construction Group Pty Ltd",
                                        "url": "https://www.service.com.au/listing/builder-parramatta-2150-nsw-grr-building-construction-group-pty-ltd?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/builder-parramatta-2150-nsw-grr-building-construction-group-pty-ltd?rc=Roofing",
                                                "anchor_text": "GRR Building Construction Group Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "12km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "TillowBuilt",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Having the support and backing of other professionals in the industry, is the key to guaranteeing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "TillowBuilt",
                                        "url": "https://www.service.com.au/listing/partitions-ceilings-dover-heights-2030-nsw-tillowbuilt?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/partitions-ceilings-dover-heights-2030-nsw-tillowbuilt?rc=Roofing",
                                                "anchor_text": "TillowBuilt"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "17km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Uplift Building Pty Ltd",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Quality workmanship that is guaranteed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Uplift Building Pty Ltd",
                                        "url": "https://www.service.com.au/listing/builder-gymea-bay-2227-nsw-uplift-building?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/builder-gymea-bay-2227-nsw-uplift-building?rc=Roofing",
                                                "anchor_text": "Uplift Building Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "20km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Australian Licensed Electricians and Plumbers",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Australian Licensed Electricians and Plumbers",
                                        "url": "https://www.service.com.au/listing/electricians-kiama-2533-nsw-australian-licensed-electricians-and-plumbers?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/electricians-kiama-2533-nsw-australian-licensed-electricians-and-plumbers?rc=Roofing",
                                                "anchor_text": "Australian Licensed Electricians and Plumbers"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Committed to",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "43km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "COASTWORKS ROOFING",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Your #1 Roofing Business!\nAt Coastworks Roofing, we specialise in hi",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "COASTWORKS ROOFING",
                                        "url": "https://www.service.com.au/listing/roof-repairs-gosford-2250-nsw-coastworks-roofing?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/roof-repairs-gosford-2250-nsw-coastworks-roofing?rc=Roofing",
                                                "anchor_text": "COASTWORKS ROOFING"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "50km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tradeworx Solutions",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "CARPENTRY | HANDYMAN | PLUMBING | LIGHT ELECTRICAL WATERPROOFING TILING DECK",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tradeworx Solutions",
                                        "url": "https://www.service.com.au/listing/handyman-kogarah-2217-nsw-tradeworks-australia-pty-ltd?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/handyman-kogarah-2217-nsw-tradeworks-australia-pty-ltd?rc=Roofing",
                                                "anchor_text": "Tradeworx Solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "10km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "B4 & After Construction",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We are a renovation company with over 15 years experience we help our customers achieve the",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "B4 & After Construction",
                                        "url": "https://www.service.com.au/listing/carpenters-liverpool-south-2170-nsw-b4-after-construction?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/carpenters-liverpool-south-2170-nsw-b4-after-construction?rc=Roofing",
                                                "anchor_text": "B4 & After Construction"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "18km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Sydney Gutter Vacuum",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "\" We respect and value your time. We understand that life is stressfu",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Sydney Gutter Vacuum",
                                        "url": "https://www.service.com.au/listing/gutter-cleaning-strathfield-south-2136-nsw-sydney-gutter-vacuum?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/gutter-cleaning-strathfield-south-2136-nsw-sydney-gutter-vacuum?rc=Roofing",
                                                "anchor_text": "All Sydney Gutter Vacuum"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "4km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "ChadCorp Building PTY LTD",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "ChadCorp Building PTY LTD is a family owned business.\nA father with a building an",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "ChadCorp Building PTY LTD",
                                        "url": "https://www.service.com.au/listing/builders-canterbury-2193-nsw-chadcorp-building-pty-ltd?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/builders-canterbury-2193-nsw-chadcorp-building-pty-ltd?rc=Roofing",
                                                "anchor_text": "ChadCorp Building PTY LTD"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "5km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Kangaroof",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Kangaroof is a family owned and operated business. We are big enough to provide our customers wit",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Kangaroof",
                                        "url": "https://www.service.com.au/listing/roofing-parramatta-2150-nsw-kangaroof?rc=Roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/listing/roofing-parramatta-2150-nsw-kangaroof?rc=Roofing",
                                                "anchor_text": "Kangaroof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "6km away",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Personalised expertise",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Our quoting system ensures you receive quotes exclusively from roofers equipped to handle your specific requirements. Save time and frustration by obtaining tailored quotes from the right experts.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Safe practices",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Our roofers will always prioritise safety and quality during your roofing project to prevent danger and ensure positive outcomes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fitted to your budget",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Enjoy competitive pricing without ever compromising on quality, as our listed roofers deliver exceptional service at affordable rates.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Find trusted and local Roofing in Burwood",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Average reviews for Roofing in Burwood",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Based on 536 reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Recommended for you",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Read the article",
                                        "url": "https://www.service.com.au/articles/business/airtasker-alternatives-tradie-jobs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/business/airtasker-alternatives-tradie-jobs",
                                                "anchor_text": "Read the article"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Airtasker alternatives: finding the right platform for tradie jobs",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Airtasker alternatives: finding the right platform for tradie jobs",
                                        "url": "https://www.service.com.au/articles/business/airtasker-alternatives-tradie-jobs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/business/airtasker-alternatives-tradie-jobs",
                                                "anchor_text": "Airtasker alternatives: finding the right platform for tradie jobs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georgia Budden",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "09 Sep 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Read the article",
                                        "url": "https://www.service.com.au/articles/swimming-pools/how-much-does-a-pool-cost",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/swimming-pools/how-much-does-a-pool-cost",
                                                "anchor_text": "Read the article"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How Much Does a Pool Cost? 2025 Cost Guide",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How Much Does a Pool Cost? 2025 Cost Guide",
                                        "url": "https://www.service.com.au/articles/swimming-pools/how-much-does-a-pool-cost",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/swimming-pools/how-much-does-a-pool-cost",
                                                "anchor_text": "How Much Does a Pool Cost? 2025 Cost Guide"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Jared Jeffery",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "11 Feb 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Read the article",
                                        "url": "https://www.service.com.au/articles/general/how-much-does-asbestos-removal-cost",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/general/how-much-does-asbestos-removal-cost",
                                                "anchor_text": "Read the article"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How Much Does Asbestos Removal Cost? 2025 Cost Guide",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How Much Does Asbestos Removal Cost? 2025 Cost Guide",
                                        "url": "https://www.service.com.au/articles/general/how-much-does-asbestos-removal-cost",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/articles/general/how-much-does-asbestos-removal-cost",
                                                "anchor_text": "How Much Does Asbestos Removal Cost? 2025 Cost Guide"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Shreya Kulkarni",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "09 Feb 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse Roofing by State",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing in QLD",
                                        "url": "https://www.service.com.au/find/roofing/qld/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/qld/suburbs",
                                                "anchor_text": "Roofing in QLD"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in VIC",
                                        "url": "https://www.service.com.au/find/roofing/vic/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/vic/suburbs",
                                                "anchor_text": "Roofing in VIC"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in ACT",
                                        "url": "https://www.service.com.au/find/roofing/act/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/act/suburbs",
                                                "anchor_text": "Roofing in ACT"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in NSW",
                                        "url": "https://www.service.com.au/find/roofing/nsw/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/nsw/suburbs",
                                                "anchor_text": "Roofing in NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in WA",
                                        "url": "https://www.service.com.au/find/roofing/wa/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/wa/suburbs",
                                                "anchor_text": "Roofing in WA"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in TAS",
                                        "url": "https://www.service.com.au/find/roofing/tas/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/tas/suburbs",
                                                "anchor_text": "Roofing in TAS"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in SA",
                                        "url": "https://www.service.com.au/find/roofing/sa/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/sa/suburbs",
                                                "anchor_text": "Roofing in SA"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in NT",
                                        "url": "https://www.service.com.au/find/roofing/nt/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/nt/suburbs",
                                                "anchor_text": "Roofing in NT"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse Roofing by City",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing in Darwin",
                                        "url": "https://www.service.com.au/find/roofing/darwin-nt",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/darwin-nt",
                                                "anchor_text": "Roofing in Darwin"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Sydney",
                                        "url": "https://www.service.com.au/find/roofing/sydney-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/sydney-nsw",
                                                "anchor_text": "Roofing in Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Canberra",
                                        "url": "https://www.service.com.au/find/roofing/canberra-act",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/canberra-act",
                                                "anchor_text": "Roofing in Canberra"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Perth",
                                        "url": "https://www.service.com.au/find/roofing/perth-wa",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/perth-wa",
                                                "anchor_text": "Roofing in Perth"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Melbourne",
                                        "url": "https://www.service.com.au/find/roofing/melbourne-vic",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/melbourne-vic",
                                                "anchor_text": "Roofing in Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Brisbane",
                                        "url": "https://www.service.com.au/find/roofing/brisbane-qld",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/brisbane-qld",
                                                "anchor_text": "Roofing in Brisbane"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Adelaide",
                                        "url": "https://www.service.com.au/find/roofing/adelaide-sa",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/adelaide-sa",
                                                "anchor_text": "Roofing in Adelaide"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Hobart",
                                        "url": "https://www.service.com.au/find/roofing/hobart-tas",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/hobart-tas",
                                                "anchor_text": "Roofing in Hobart"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse Roofing by Region",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing in Dawes Point",
                                        "url": "https://www.service.com.au/find/roofing/dawes-point-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/dawes-point-nsw",
                                                "anchor_text": "Roofing in Dawes Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Broadway",
                                        "url": "https://www.service.com.au/find/roofing/broadway-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/broadway-nsw",
                                                "anchor_text": "Roofing in Broadway"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Chippendale",
                                        "url": "https://www.service.com.au/find/roofing/chippendale-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/chippendale-nsw",
                                                "anchor_text": "Roofing in Chippendale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Pyrmont",
                                        "url": "https://www.service.com.au/find/roofing/pyrmont-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/pyrmont-nsw",
                                                "anchor_text": "Roofing in Pyrmont"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Alexandria",
                                        "url": "https://www.service.com.au/find/roofing/alexandria-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/alexandria-nsw",
                                                "anchor_text": "Roofing in Alexandria"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Redfern",
                                        "url": "https://www.service.com.au/find/roofing/redfern-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/redfern-nsw",
                                                "anchor_text": "Roofing in Redfern"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Waterloo",
                                        "url": "https://www.service.com.au/find/roofing/waterloo-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/waterloo-nsw",
                                                "anchor_text": "Roofing in Waterloo"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Forest Lodge",
                                        "url": "https://www.service.com.au/find/roofing/forest-lodge-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/forest-lodge-nsw",
                                                "anchor_text": "Roofing in Forest Lodge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Annandale",
                                        "url": "https://www.service.com.au/find/roofing/annandale-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/annandale-nsw",
                                                "anchor_text": "Roofing in Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Rozelle",
                                        "url": "https://www.service.com.au/find/roofing/rozelle-nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/rozelle-nsw",
                                                "anchor_text": "Roofing in Rozelle"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Related categories",
                                "main_title": "Roofing\nin Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Painters in QLD",
                                        "url": "https://www.service.com.au/find/painters/qld/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/painters/qld/suburbs",
                                                "anchor_text": "Painters in QLD"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electricians in VIC",
                                        "url": "https://www.service.com.au/find/electrician/vic/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/electrician/vic/suburbs",
                                                "anchor_text": "Electricians in VIC"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Plumbers in ACT",
                                        "url": "https://www.service.com.au/find/plumbers-gasfitters/act/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/plumbers-gasfitters/act/suburbs",
                                                "anchor_text": "Plumbers in ACT"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Carpenters in NSW",
                                        "url": "https://www.service.com.au/find/carpenters/nsw/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/carpenters/nsw/suburbs",
                                                "anchor_text": "Carpenters in NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gardeners in WA",
                                        "url": "https://www.service.com.au/find/gardeners/wa/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/gardeners/wa/suburbs",
                                                "anchor_text": "Gardeners in WA"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in TAS",
                                        "url": "https://www.service.com.au/find/roofing/tas/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/roofing/tas/suburbs",
                                                "anchor_text": "Roofing in TAS"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Painters in SA",
                                        "url": "https://www.service.com.au/find/painters/sa/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/painters/sa/suburbs",
                                                "anchor_text": "Painters in SA"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electricians in NT",
                                        "url": "https://www.service.com.au/find/electrician/nt/suburbs",
                                        "urls": [
                                            {
                                                "url": "https://www.service.com.au/find/electrician/nt/suburbs",
                                                "anchor_text": "Electricians in NT"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.83,
                                "max_rating_value": 5,
                                "rating_count": 536,
                                "relative_rating": 0.966
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}