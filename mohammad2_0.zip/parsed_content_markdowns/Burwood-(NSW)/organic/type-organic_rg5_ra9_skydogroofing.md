{
    "id": "01190728-1132-0216-0000-9c4211d75619",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0168 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://skydogroofing.com.au/suburbs/roofing-in-burwood/",
        "target": "skydogroofing.com.au",
        "start_url": "https://skydogroofing.com.au/suburbs/roofing-in-burwood/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg5_ra9_skydogroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:26 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Unit 9C, 106 Old Pittwater Rd Brookvale, NSW, 2100",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "08:00AM - 4:30PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Leak Detection and Roof Repairs",
                                    "url": "https://skydogroofing.com.au/services/leak-detection-and-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/leak-detection-and-roof-repairs/",
                                            "anchor_text": "Leak Detection and Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacements",
                                    "url": "https://skydogroofing.com.au/services/roof-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/roof-replacements/",
                                            "anchor_text": "Roof Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://skydogroofing.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning and Maintenance",
                                    "url": "https://skydogroofing.com.au/services/gutter-cleaning-and-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/gutter-cleaning-and-maintenance/",
                                            "anchor_text": "Gutter Cleaning and Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Specialty Roofing",
                                    "url": "https://skydogroofing.com.au/services/specialty-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/specialty-roofing/",
                                            "anchor_text": "Specialty Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wall Cladding and External Makeovers",
                                    "url": "https://skydogroofing.com.au/services/wall-cladding-and-external-makeovers/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/wall-cladding-and-external-makeovers/",
                                            "anchor_text": "Wall Cladding and External Makeovers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://skydogroofing.com.au/services/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://skydogroofing.com.au/services/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inspections and Reports",
                                    "url": "https://skydogroofing.com.au/services/inspections-and-reports/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/inspections-and-reports/",
                                            "anchor_text": "Inspections and Reports"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Need Any Roofing Help?",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Unit 9C, 106 Old Pittwater Rd Brookvale,",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Call Now: 0414 011 888",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "NSW, 2100",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "0414 011 888",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Replacements",
                                    "url": "https://skydogroofing.com.au/services/roof-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/roof-replacements/",
                                            "anchor_text": "Roof Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://skydogroofing.com.au/services/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning and Maintenance",
                                    "url": "https://skydogroofing.com.au/services/gutter-cleaning-and-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/gutter-cleaning-and-maintenance/",
                                            "anchor_text": "Gutter Cleaning and Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wall Cladding and External Makeovers",
                                    "url": "https://skydogroofing.com.au/services/wall-cladding-and-external-makeovers/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/wall-cladding-and-external-makeovers/",
                                            "anchor_text": "Wall Cladding and External Makeovers"
                                        }
                                    ]
                                },
                                {
                                    "text": "Specialty Roofing",
                                    "url": "https://skydogroofing.com.au/services/specialty-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/specialty-roofing/",
                                            "anchor_text": "Specialty Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://skydogroofing.com.au/services/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://skydogroofing.com.au/services/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Inspections and Reports",
                                    "url": "https://skydogroofing.com.au/services/inspections-and-reports/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/inspections-and-reports/",
                                            "anchor_text": "Inspections and Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leak Detection and Roof Repairs",
                                    "url": "https://skydogroofing.com.au/services/leak-detection-and-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/services/leak-detection-and-roof-repairs/",
                                            "anchor_text": "Leak Detection and Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Job vacancies",
                                    "url": "https://skydogroofing.com.au/vacancies/",
                                    "urls": [
                                        {
                                            "url": "https://skydogroofing.com.au/vacancies/",
                                            "anchor_text": "Job vacancies"
                                        }
                                    ]
                                },
                                {
                                    "text": "Monday: 8:00 AM - 4:30 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Tuesday: 8:00 AM - 4:30 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Wednesday: 8:00 AM - 4:30 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Thursday: 8:00 AM - 4:30 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Friday: 8:00 AM - 4:30 PM",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Saturday: Closed",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Sunday: Closed",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Weather Damage",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Get in touch by calling us or filling out a form for detailed inspections are provided for free for homeowners by our team of expert techniclans",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Blocked Gutters",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our team of experts will come to your home and do a thorough inspection in order to get the most accurate estimate, budget and timeline for your project",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Aging Materials",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We will begin installation of your project at a mutually agreed fee. Our teams of factory trained installers work efficiently and put quality above all else",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking roof\nIssues",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our team of experts will come to your home and do a thorough inspection in order to get the most accurate estimate, budget and timeline for your project",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Solar Panel Installation Challenges",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We will begin installation of your project at a mutually agreed fee. Our teams of factory trained installers work efficiently and put quality above all else",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We Are Ready to Handle Your Roof!",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u201cI founded Sky Dog Roofing to meet the growing need for integrity of workmanship in the Australian roofing industry. I am fortunate that my team and the professionals we work with all share the same pride and commitment to our craft. It\u2019s great to be able to run and control our own projects, to do things the right way and at the end of the day do what is right for our clients.\u201d",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Mitch Diggins \u2013 Owner",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tommy S",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jenny Loughlin",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clive Hobson",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jenny Jeffress",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lyndsi Crowder",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sandra Gerardi",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Craig Smith",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Pierre Abrahamse",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Experience with all roof types",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "With decades of combined experience resolving all types of roofing, large and small, difficult, complex and hard to handle - there is not much we haven\u2019t seen.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Expertise with all types of projects",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Whether repairing your roof, replacing it with a new one, our goal is to make your roof function in all weather conditions and last as long as possible.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof repair and replacement\nin Burwood",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roofing in Burwood reflects the suburb\u2019s mix of old and new buildings, each with unique challenges. Older homes often need roof repair in Burwood due to aging tiled or metal roofs, while modern properties favor durable materials like Colorbond steel",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "WHAT WE DO",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Weather\nChallenges",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Harsh sun, heavy rain, and storms can cause cracks, leaks, or rust, making regular roof repair in Burwood essential",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Urban\nEnvironment",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Trees and green spaces lead to debris buildup, clogging gutters and drains. Flat roofs in commercial areas require proper drainage to prevent water pooling",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Meets\nModernization",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Historic buildings may need restoration, while newer homes focus on energy-efficient designs. Roofing in Burwood must balance aesthetics, durability, and functionality",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why\nTrust Us?",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "At \"Skydog Roofing\", we specialize in roofing in Burwood and provide expert roof repair in Burwood to ensure your property stays safe, stylish, and weatherproof year-round",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "From Small to Large -\nReal Roofing Services and Solutions!",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Sky Dog Roofing are a team of licensed and experienced roofing professionals specialising in correct diagnosis and real roofing solutions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Serving a wide area of Sydney from the Upper and Lower North Shore, Northern Beaches, Forest District, Inner West, Eastern Suburbs, Central Sydney and Inner South.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Urgent Repair",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Inspections and Reports",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For clients wanting repairs or roof replacements we offer free inspections and quotes. In addition to our free inspection and\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Inspections and Reports",
                                        "url": "https://skydogroofing.com.au/services/inspections-and-reports/",
                                        "urls": [
                                            {
                                                "url": "https://skydogroofing.com.au/services/inspections-and-reports/",
                                                "anchor_text": "Inspections and Reports"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Need robust roofing for your commercial property? No problem! We have extensive experience in commercial roofing of almost all applications\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Commercial Roofing",
                                        "url": "https://skydogroofing.com.au/services/commercial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://skydogroofing.com.au/services/commercial-roofing/",
                                                "anchor_text": "Commercial Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "With years experience in residential roofing under our belt we know that the fine details DO matter. It is not\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Residential Roofing",
                                        "url": "https://skydogroofing.com.au/services/residential-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://skydogroofing.com.au/services/residential-roofing/",
                                                "anchor_text": "Residential Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Wall Cladding and External Makeovers",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Is your exterior looking out of date or worse for wear? We can give it a whole new modern look.\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Wall Cladding and External Makeovers",
                                        "url": "https://skydogroofing.com.au/services/wall-cladding-and-external-makeovers/",
                                        "urls": [
                                            {
                                                "url": "https://skydogroofing.com.au/services/wall-cladding-and-external-makeovers/",
                                                "anchor_text": "Wall Cladding and External Makeovers"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Specialty Roofing",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "In addition to the more common materials we also install and repair specialty roof materials such as Copper, Zinc Panel,\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Specialty Roofing",
                                        "url": "https://skydogroofing.com.au/services/specialty-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://skydogroofing.com.au/services/specialty-roofing/",
                                                "anchor_text": "Specialty Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Cleaning and Maintenance",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The best way to prevent larger problems and make your roof last is by routinely cleaning the gutters and attending\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter Cleaning and Maintenance",
                                        "url": "https://skydogroofing.com.au/services/gutter-cleaning-and-maintenance/",
                                        "urls": [
                                            {
                                                "url": "https://skydogroofing.com.au/services/gutter-cleaning-and-maintenance/",
                                                "anchor_text": "Gutter Cleaning and Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roofing",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Known for its resistance to the harshest Australian weather conditions, Colorbond offers superior protection, energy efficiency, and a wide range\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roofing",
                                        "url": "https://skydogroofing.com.au/services/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://skydogroofing.com.au/services/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leak Detection and Roof Repairs",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Do you have roof problems? We provide thorough leak detection with effective solutions and repairs. No band aid fixes. We\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Leak Detection and Roof Repairs",
                                        "url": "https://skydogroofing.com.au/services/leak-detection-and-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://skydogroofing.com.au/services/leak-detection-and-roof-repairs/",
                                                "anchor_text": "Leak Detection and Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacements",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If your roof is beyond repair we can replace it with a new fully functional roof. Not only do we\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacements",
                                        "url": "https://skydogroofing.com.au/services/roof-replacements/",
                                        "urls": [
                                            {
                                                "url": "https://skydogroofing.com.au/services/roof-replacements/",
                                                "anchor_text": "Roof Replacements"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency repairs in\nBurwood",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We provide emergency roof repairs and makesafes to protect your home or business from further damage. Whether it\u2019s storm damage, leaks, or structural issues, our team is available to respond quickly and efficiently.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With years of experience and a commitment to quality,",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "we ensure your property is safe and secure.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Don\u2019t wait-contact us today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Fast service",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing in Burwood",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Common Roofing Problems\nBurwood",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Our core values",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "CALL FOR A QUOTE",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "0414 011 888",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Free estimate and measurement",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get Roofing Inspection",
                                "main_title": "Roofing in Burwood",
                                "author": "https://www.facebook.com/profile.php?id=61552392530306",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0414 011 888"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}