{
    "id": "01190728-1132-0216-0000-d3c91f3cb37f",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0230 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.ryboplumbing.com.au/roof-replacement-burwood",
        "target": "www.ryboplumbing.com.au",
        "start_url": "https://www.ryboplumbing.com.au/roof-replacement-burwood",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Burwood-(NSW)\\organic\\type-organic_rg14_ra18_ryboplumbing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:22 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Our Team",
                                    "url": "https://www.ryboplumbing.com.au/our-team",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/our-team",
                                            "anchor_text": "Our Team"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement Melbourne",
                                    "url": "https://www.ryboplumbing.com.au/roof-replacement-melbourne",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/roof-replacement-melbourne",
                                            "anchor_text": "Roof Replacement Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing Melbourne",
                                    "url": "https://www.ryboplumbing.com.au/roof-plumbing-melbourne",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/roof-plumbing-melbourne",
                                            "anchor_text": "Roof Plumbing Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumber Eastern Suburbs Melbourne",
                                    "url": "https://www.ryboplumbing.com.au/roof-plumber-eastern-suburbs-melbourne",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/roof-plumber-eastern-suburbs-melbourne",
                                            "anchor_text": "Roof Plumber Eastern Suburbs Melbourne"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement Burwood",
                                    "url": "https://www.ryboplumbing.com.au/roof-replacement-burwood",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/roof-replacement-burwood",
                                            "anchor_text": "Roof Replacement Burwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement Glen Waverley",
                                    "url": "https://www.ryboplumbing.com.au/roof-replacement-glen-waverley",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/roof-replacement-glen-waverley",
                                            "anchor_text": "Roof Replacement Glen Waverley"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement Ringwood",
                                    "url": "https://www.ryboplumbing.com.au/roof-replacement-ringwood",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/roof-replacement-ringwood",
                                            "anchor_text": "Roof Replacement Ringwood"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement Frankston",
                                    "url": "https://www.ryboplumbing.com.au/roof-replacement-frankston",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/roof-replacement-frankston",
                                            "anchor_text": "Roof Replacement Frankston"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "81-83 Canterbury Road, Kilsyth Vic 3137",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "03 9969 7948",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Our Team",
                                    "url": "https://www.ryboplumbing.com.au/our-team",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/our-team",
                                            "anchor_text": "Our Team"
                                        }
                                    ]
                                },
                                {
                                    "text": "General Enquiries",
                                    "url": "https://www.ryboplumbing.com.au/contact",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/contact",
                                            "anchor_text": "General Enquiries"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Inspection & Quote",
                                    "url": "https://www.ryboplumbing.com.au/contact",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/contact",
                                            "anchor_text": "Free Inspection & Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Custom Homes",
                                    "url": "https://www.ryboplumbing.com.au/services",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/services",
                                            "anchor_text": "Custom Homes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Townhouses & Units",
                                    "url": "https://www.ryboplumbing.com.au/services",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/services",
                                            "anchor_text": "Townhouses & Units"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wall Cladding",
                                    "url": "https://www.ryboplumbing.com.au/services",
                                    "urls": [
                                        {
                                            "url": "https://www.ryboplumbing.com.au/services",
                                            "anchor_text": "Wall Cladding"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Replacement Burwood Property Owners Trust for Lasting Quality",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When your roof starts to rust, leak, or sag, patch jobs won't cut it. Rybo Plumbing & Roofing offers complete roof replacement in Burwood, delivering flawless metal roofing built for decades of performance. Our team combines 10+ years of experience with premium materials and expert craftsmanship to provide roof replacements that are as durable as they are visually sharp.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether you're dealing with storm damage, an ageing roof, or planning a complete upgrade, we approach each job with precision and care. Every roof we replace is tailored to the property, professionally installed, and built to meet all compliance standards. We don't just swap out roofing\u2014we restore the value, structure, and protection of your home or building needs. Based in Melbourne, our 15-person team brings the skill, speed, and finish you expect from seasoned professionals. For reliable metal roofing in Burwood, Rybo is the name locals call when quality matters.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Burwood \u2013 Sleek, Strong, and Built to Endure",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Rybo, we specialise in metal roofing for Burwood homes, units, and light commercial sites, using materials that outperform traditional roofing in durability and maintenance. Whether you're replacing aged tiles or asbestos sheeting, our licensed roof plumbers provide a seamless finish with modern Colorbond or Zincalume options. Metal roofing isn't just more substantial; it looks sharper, lasts longer, and helps regulate indoor temperatures efficiently.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We work closely with builders, developers, and homeowners to deliver bespoke roof replacements that complement each structure's style. From custom homes to multi-unit townhouses, we handle it all in-house, with no subcontractors and no missed steps. Every job is completed to strict standards and backed by our commitment to clean, efficient service. If you're looking for roof replacement in Burwood that goes beyond the basics, we offer end-to-end solutions you can rely on. Rybo is the go-to team for roofing contractors in Burwood who care about detail as much as durability.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burwood Roof Plumbers Who Prioritise Craftsmanship and Clean Execution",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roofing isn't just about protection it's about presentation, precision, and performance. As trusted roof plumbers in Burwood, we combine expert skills with an eye for detail to deliver roofing solutions that exceed expectations. Whether replacing fascia, installing new gutters, or completing a full re-roof, we apply the same care and expertise throughout the process.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our roofing work is clean, compliant, and always tailored to the structure we're working on. With over 10 years of hands-on experience and a solid reputation across Melbourne, we've become the go-to team for roof replacements that last. We use only high-grade materials from trusted suppliers and always stay on schedule. No shortcuts. There were no rushed finishes. These seamless results protect your home and elevate its street appeal. For roof plumbing and replacement in Burwood done right the first time, trust the Rybo Plumbing & Roofing team.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Replacement Burwood",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Call Rybo Plumbing & Roofing today for expert roof replacement in Burwood. We deliver metal roofing solutions with precision, speed, and long-lasting value.",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our Services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Roofs",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Custom Homes",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Townhouses & Units",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Wall Cladding",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Sheds",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial",
                                "main_title": "Roof Replacement Burwood",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": [
                            {
                                "name": "Roof Replacement Burwood \u2014 RYBO Plumbing &amp; Roofing",
                                "price": 0,
                                "price_currency": null,
                                "price_valid_until": null
                            }
                        ],
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0399697948"
                            ],
                            "emails": [
                                "admin@ryboplumbing.com.au?subject=Enquiry"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}