# Type: people_also_ask | Rank: 12 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "12",
    "service": "roofer",
    "suburb": "Camperdown (NSW)",
    "title": "",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_ask"
}