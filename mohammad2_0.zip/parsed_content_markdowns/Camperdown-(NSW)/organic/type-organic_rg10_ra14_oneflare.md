{
    "id": "01190728-1132-0216-0000-065b2373dda7",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0311 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.oneflare.com.au/roofing/nsw/camperdown",
        "target": "www.oneflare.com.au",
        "start_url": "https://www.oneflare.com.au/roofing/nsw/camperdown",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Camperdown-(NSW)\\organic\\type-organic_rg10_ra14_oneflare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:37 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Best roofing experts in Camperdown",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Post a job now to get quotes from local roofing experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average rating of roofing experts in Camperdown based on 243 reviews of 26 businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oneflare /",
                                        "url": "https://www.oneflare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/",
                                                "anchor_text": "Oneflare"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Categories /",
                                        "url": "https://www.oneflare.com.au/directory",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/directory",
                                                "anchor_text": "Categories"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.oneflare.com.au/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NSW /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw",
                                                "anchor_text": "NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                                "anchor_text": "Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pipe Perfection Plumbers Drainage & Gas Fitting",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Marrickville, NSW (3.5km from Marrickville)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney\u2019s expert solution to your plumbing, drainage, gas problems. We\u2019ll fix it right or it\u2019s free! Inner West or Eastern Suburbs. Our customers describe us as reliable, thorough, punctual and knowledgeable and that\u2019s just the beginning! If you have a water, gas or roof leak, a blocked drain or need your plumbing repaired, you need Pipe Perfection Plumbers. Our work has a 6-year labour warranty plus 100% happiness guarantee. If you follow our advice but aren\u2019t 100% satisfied we will refund your money. Head to our website for your FREE copy of the Smart Consumer\u2019s Guide To Choosing the Right Plumber (and avoiding cowboys)",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pipe Perfection Plumbers Drainage & Gas Fitting",
                                        "url": "https://www.oneflare.com.au/b/pipe-perfection-plumbing-drainage-gas-fitting",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/pipe-perfection-plumbing-drainage-gas-fitting",
                                                "anchor_text": "Pipe Perfection Plumbers Drainage & Gas Fitting"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Au Roofing",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Forest Lodge, NSW (0.8km from Forest Lodge)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Written Warranty\nWe have built a reputation on doing exceptional quality work and giving our clients amazing customer service. We provide a full 10 year written guarantee on all Roof Restorations and roof replacements.\nFully Insured & Licensed\nWe are a team of fully qualified and experienced roofers. We are fully insured and licensed for your peace of mind. We are also members of Master Builders Association as well as the Housing Industry Australia.\nRoofing Services\n\u2713 Concrete & Terra Cotta Roof Restoration\n\u2713 Concrete & Terra Cotta Roof Painting\n\u2713 Concrete & Terra Cotta Roof Cleaning\n\u2713 Concrete & Terra Cotta Roof Repairs\n\u2713 Valley Repairs and Replacements\nAll Roofing Services\nRoof Restorations\nRoof Replacements & New Roof\nRoof",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Au Roofing",
                                        "url": "https://www.oneflare.com.au/b/au-roofing-122",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/au-roofing-122",
                                                "anchor_text": "Au Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Oce Roofing Verified Business",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "North Parramatta, NSW (18.2km from North Parramatta)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OCEANIA ROOFING delivers roofing services all across Sydney. OCE specialises in :\n\u2022 Roof Leaks\n\u2022 Gutter leaks \u2022 Tile replacement \u2022 Colorbond replacement\n\u2022 Gutter cleaning\n\u2022 Roof maintenance \u2022 Roof Inspections\n\u2022 Roof washing\nAll job provided comes with 7 years warranty. Feel free to reach out to us!!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oce Roofing Verified Business",
                                        "url": "https://www.oneflare.com.au/b/oce-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/oce-roofing",
                                                "anchor_text": "Oce Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "locals best handyman",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Stanmore, NSW (1.5km from Stanmore)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "hi I have been painting for the last well sinces age 16 I am now 52 years of age i learned from my father how was a painter in the past in my field did a lot of heritage homes and church ,s most of my work is in the mosman areas all up to Hornsby how it,s all over Sydney and some times outer Sydney and I can and will consider my self a very good painter I don't like to talk about my self but my work does speak for it self it does because of my prep work if your prep work is up to scrach then the paint will stand out in your face and it",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "locals best handyman",
                                        "url": "https://www.oneflare.com.au/b/best-builder-s-shire",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/best-builder-s-shire",
                                                "anchor_text": "locals best handyman"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Storey Roofing",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.4km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Storey Roofing are experts with years of experience in roofing repairs, roof restorations, maintenance and installations, metal roofing, colorbond roofing and more. We\u2019ll transform your roof to withstand the harsh Aussie climate and give it that new look and a new lease on life. Providing roofing services to residential and commercial buildings in Sydney and all throughout the coast and greater Sydney area. Check out our services and give us a call to see what we can do to help you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Storey Roofing",
                                        "url": "https://www.oneflare.com.au/b/james-storey-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/james-storey-roofing",
                                                "anchor_text": "Storey Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Render My Home Pty Ltd",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Waterloo, NSW (2.7km from Waterloo)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Render My Home is your one-stop design and building service that Renovates, Rejuvenates and Restores your home facade. We only deal with quality products and systems from trusted suppliers. Render My Home are accredited and use products by Dulux and CSR.\nRender My Home \u2013 Exterior Fa\u00e7ade Home Improvement Specialists, can dramatically boost your home\u2019s value by transforming your home into a vibrant and intriguing reflection of your own personal style and individualism. For all small and large jobs, Render My Home specialises in restoring and rejuvenating your homes facade, by using renders, coatings, wall panels, paints, landscaping, tiling, balustrade upgrades, roof restorations, awnings and shutters to breathe new life into your home.\nThe Render My Home design team are",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Render My Home Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/render-my-home-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/render-my-home-pty-ltd",
                                                "anchor_text": "Render My Home Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Orb It Roofing",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Marrickville, NSW (3.5km from Marrickville)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Orb It Roofing are skilled, professional and extremely reliable providing the very best roofing services. Metal Roofing - Reroofing - All Repairs & Guttering - Call Now Orb It Roofing provides Sydneys domestic and commercial properties with a reliable Metal roofing, roofing repair and re-roofing service. Services include; Metal Roofing Re-Roofs Leak Repairs Roof Repairs New Work Guttering Downpipes Tile and Slate Repairs 100% committed to the highest standard of workmanship, prompt, reliable, unrivalled service! Call Now for a Free Quote!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Orb It Roofing",
                                        "url": "https://www.oneflare.com.au/b/orb-it-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/orb-it-roofing",
                                                "anchor_text": "Orb It Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Roofing Services",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Croydon, NSW (6.2km from Croydon)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All Roofing Services has provided the Innerwest Sydney area with experienced, professional roof installation, repair maintenance advice and assessment, restoration and replacement for over 10 years. ARS specialise in Metal and Colorbond roof installation and replacement for residences and small businesses. We have expanded across Sydney with our Roof Replacements.\nAll Roofing Services also provide all aspects of services for roof plumbing and gutter installation, repair assessment and replacement and asbestos removal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Roofing Services",
                                        "url": "https://www.oneflare.com.au/b/all-roofing-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-roofing-services",
                                                "anchor_text": "All Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Infront roofing",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.4km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Over 10 years of experience within this trade!\nA very friendly and quality orientated service within the guttering trade. Very mobile and always on time! Contact me for any of your guttering needs, gutter guard or gutter cleaning jobs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Infront roofing",
                                        "url": "https://www.oneflare.com.au/b/moores-gutters",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/moores-gutters",
                                                "anchor_text": "Infront roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "MLR Slate Roofing Pty Ltd",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.4km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "MLR Slate roofing, specialises in traditional slate roofing, whether it's a small repair or a complete re-roof.\nAs a small business owner my aim is to provide and deliver top quality workmanship with a professional service.\nFor a no obligation quote please contact Matt",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "MLR Slate Roofing Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/mlr-slate-roofing-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/mlr-slate-roofing-pty-ltd",
                                                "anchor_text": "MLR Slate Roofing Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "OZWIDE Roofing",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.4km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OZWIDE ROOFING IS A WELL ESTABLISHED COMPANY WITH THE BEST TRADESMEN AND %100 workmanship attitude..the best rates on roof restorations call us now..",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "OZWIDE Roofing",
                                        "url": "https://www.oneflare.com.au/b/ausco-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/ausco-roofing",
                                                "anchor_text": "OZWIDE Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Star Roof Masters",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.1km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Star Roof Masters specialises in all metal roofing, exterior wall cladding, carports, and awnings for Sydney and the surrounding Sydney suburbs. Our services include: New Colorbond Metal Roofs, Gutters, Fascia Cover, Replacing Tiles and Colorbond with New Colorbond, Colorbond Roofing, Down Pipes, Roof Skylights, Roof Repairs, Wall Cladding, Carports, Awnings, Flashing, and Insulation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Star Roof Masters",
                                        "url": "https://www.oneflare.com.au/b/star-roof-masters",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/star-roof-masters",
                                                "anchor_text": "Star Roof Masters"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Suburbs Roofing & Repairs Pty Ltd",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.5km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a 3rd generation family company serving all of Sydney with high quality roofing repairs and all aspects of roofing we do Roofing leak repairs Valley repairs Roof washing and painting Sarkimg & battens Chimney repairs Flexi pointing Possum removal Rebedding Gutter repairs We give free estimates true out Sydney same day estimate We are fully registered & insured",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Suburbs Roofing & Repairs Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/all-suburbs-roofing-repairs-pty-ltd-568",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-suburbs-roofing-repairs-pty-ltd-568",
                                                "anchor_text": "All Suburbs Roofing & Repairs Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Blue Sky, Roofing And Property Maintenance",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.2km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are family owned and operated\nFully licensed and Insured\n20 years experience in Roofing We offer a warranty with all our work Free quote at a time suitable to you\nQuality service and peace of mind All our employees are respectful and we always keep a nice and tidy job site",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Blue Sky, Roofing And Property Maintenance",
                                        "url": "https://www.oneflare.com.au/b/blue-sky-roofing-and-property-maintenance",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/blue-sky-roofing-and-property-maintenance",
                                                "anchor_text": "Blue Sky, Roofing And Property Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pro Cut Sydney",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Zetland, NSW (3.5km from Zetland)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a family run roofing and property maintenance company. With over 20 years of experience as carpenters and roofers, we pride ourselves on honesty, hard work and reliability. With a wide range of services from carpentry and roofing to cleaning and garden maintenance, we guarantee you\u2019ll love our work.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pro Cut Sydney",
                                        "url": "https://www.oneflare.com.au/b/pro-cut-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/pro-cut-sydney",
                                                "anchor_text": "Pro Cut Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "RSG roofing",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.4km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality work is my preference for all the roofing jobs. Get your job done at good price.\nExperienced with jobs in city, suburban and regional where its hard to find tradies. good with\nRoof leaks Restoration Gutter clean\nRoof cleaning New Colorbond roof\nFascia\nGutter\nDownpipe\nSkylight Flashing Capping Roof exhaust fan, etc.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "RSG roofing",
                                        "url": "https://www.oneflare.com.au/b/rsg-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/rsg-roofing",
                                                "anchor_text": "RSG roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "M&T Roofing",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney, NSW (3.4km from Sydney)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "35 Years Roofing Experience. Call Now For Free Quote! If you are looking for reliable leaking roof repairs maintenance service Sydney.here at M&t roofing we provide all types of roofing and home maintenance services free call out charge we have a team of high Quality roofers and carpenters our team provide 7 professional roofers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "M&T Roofing",
                                        "url": "https://www.oneflare.com.au/b/m-t-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/m-t-roofing",
                                                "anchor_text": "M&T Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Metal Roofing Projects Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Surry Hills, NSW (2.8km from Surry Hills)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Trade Lic # 381129C\nFor all your metal roofing requirements, domestic & commercial New roofs, extensions, repairs, guttering & downpipes, box gutters. Zincalume & Colorbond\nFully qualified Roof Plumber with over 30years experience. Servicing eastern suburbs, inner west, southern suburbs & lower north shore Obligation free quote\nCompetitive pricing\nFully insured for your protection",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Sydney Metal Roofing Projects Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/sydney-metal-roofing-projects",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/sydney-metal-roofing-projects",
                                                "anchor_text": "Sydney Metal Roofing Projects Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get the right price for your job",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Oneflare Cost Guide Centre is your one-stop shop to help you set your budget; from smaller tasks to larger projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Top Camperdown roofing experts near you",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Browse top Roofing Expert experts with top ratings and reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best roofing experts in Camperdown",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "View more roofing experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Truss costs",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Truss costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Roof Truss costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $9,000 - $15,000",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Average price $9,000 - $15,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof costs",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roof costs",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Colorbond Roof costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $15,000 - $25,000",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Average price $15,000 - $25,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling costs",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Roof Tiling costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $35 - $140 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Average price $35 - $140 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing costs",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing costs",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Roofing costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $45 - $90 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Average price $45 - $90 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse roofing experts by suburb",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular searches on Oneflare",
                                "main_title": "Best roofing experts in Camperdown",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.7,
                                "max_rating_value": 5,
                                "rating_count": 243,
                                "relative_rating": 0.9400000000000001
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}