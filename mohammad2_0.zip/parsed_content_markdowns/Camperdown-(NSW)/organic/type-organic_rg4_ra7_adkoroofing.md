{
    "id": "01190728-1132-0216-0000-731d04b87476",
    "status_code": 40602,
    "status_message": "Task In Queue.",
    "time": "0.0064 sec.",
    "cost": 0,
    "result_count": 0,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://adkoroofing.com.au/locations/inner-west/roof-repairs-Camperdown/",
        "target": "adkoroofing.com.au",
        "start_url": "https://adkoroofing.com.au/locations/inner-west/roof-repairs-Camperdown/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Camperdown-(NSW)\\organic\\type-organic_rg4_ra7_adkoroofing.md"
    },
    "result": null
}