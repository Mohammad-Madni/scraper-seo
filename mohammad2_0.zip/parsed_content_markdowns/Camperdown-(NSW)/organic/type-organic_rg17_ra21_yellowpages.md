{
    "id": "01190728-1132-0216-0000-9adf5cb696bd",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0226 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/petersham-nsw-2049",
        "target": "www.yellowpages.com.au",
        "start_url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/petersham-nsw-2049",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Camperdown-(NSW)\\organic\\type-organic_rg17_ra21_yellowpages.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:38 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration & Repairs Near Me",
                                    "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/nsw",
                                    "urls": [
                                        {
                                            "url": "https://www.yellowpages.com.au/find/roof-restoration-repairs/nsw",
                                            "anchor_text": "Roof Restoration & Repairs Near Me"
                                        }
                                    ]
                                },
                                {
                                    "text": "Petersham NSW",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "A Aadworkin' Roofer",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Marrickville, NSW 2204",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have been in business for over 30 years specializing in replacement of old roofs with Color bond.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: Roof Services",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A Aadworkin' Roofer",
                                        "url": "https://www.yellowpages.com.au/nsw/marrickville/a-aadworkin-roofer-14019955-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/marrickville/a-aadworkin-roofer-14019955-listing.html",
                                                "anchor_text": "A Aadworkin' Roofer"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 5:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9559 1616",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "DJ Daisley & Sons",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Incredibly professional team. The fact these guys have been around a long time says a lot, especially with a lot of dodgy trades out there. DJ Daisleys were just so good to deal with.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What are the benefits of a roof restoration?",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The benefits from a roof restoration will depend on the type of roof you have. Some of the benefits of a metal roof restoration or roof repair include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Weatherproofing your home, making it safe in a storm and more secure in high winds",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Giving your home an updated and refreshed look",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of any sheets that are rusted beyond repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of rusty or lose nails",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Professional treatment of light rust",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Benefits of tile roof restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tiles are recoated, preventing them from becoming waterlogged in rainy seasons",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ridges are re-pointed which makes them safe in violent weather and high winds, dramatically reducing storm damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The quality of run-off water from your roof is improved. Here, the improved water quality in tank water is cleaner for other uses and applications.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Yellow, we\u2019re here to help. If you would like roof replacement services, get a quote by checking out our listings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Green Frog Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Marrickville, NSW 2204",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Legal ID: Fully licensed and insured",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Green Frog Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/marrickville/green-frog-roofing-15135792-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/marrickville/green-frog-roofing-15135792-listing.html",
                                                "anchor_text": "Green Frog Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "53 Victoria Rd, Marrickville, NSW, 2204",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=53+Victoria+Rd&context=undefined&directionMode=true&elat=-33.905555&elon=151.17157&ena=Green+Frog+Roofing&estr=53+Victoria+Rd&esu=Marrickville%2C+NSW%2C+2204&productVersion=14&productId=999015865041&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGreen+Frog+Roofing%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.905555%26lon%3D151.17157%26selectedViewMode%3Dlist&yellowId=15135792",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=53+Victoria+Rd&context=undefined&directionMode=true&elat=-33.905555&elon=151.17157&ena=Green+Frog+Roofing&estr=53+Victoria+Rd&esu=Marrickville%2C+NSW%2C+2204&productVersion=14&productId=999015865041&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGreen+Frog+Roofing%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.905555%26lon%3D151.17157%26selectedViewMode%3Dlist&yellowId=15135792",
                                                "anchor_text": "53 Victoria Rd, Marrickville, NSW, 2204"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9550 5490",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Gutter & Roof Restoration",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Slaters & Roof Tilers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Warning, Not All Roof Companies Are The Same",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "1300 654 884",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "42 Results for Roof Restorations Near You",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Petersham, NSW 2049",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aussie Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/petersham/aussie-roofing-services-1000002965105-listing.html?isTopOfList=true&premiumProductId=400009942718",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/petersham/aussie-roofing-services-1000002965105-listing.html?isTopOfList=true&premiumProductId=400009942718",
                                                "anchor_text": "Aussie Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, servicing Petersham",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Aussie Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/petersham/aussie-roofing-services-1000002965105-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/petersham/aussie-roofing-services-1000002965105-listing.html",
                                                "anchor_text": "Aussie Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "DJ Daisley & Sons",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Marrickville, NSW 2204",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "DJ Daisley & Sons",
                                        "url": "https://www.yellowpages.com.au/nsw/marrickville/dj-daisley-sons-12815220-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/marrickville/dj-daisley-sons-12815220-listing.html",
                                                "anchor_text": "DJ Daisley & Sons"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "G-Force Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Stanmore, NSW 2048",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "G-Force Roofing",
                                        "url": "https://www.yellowpages.com.au/sup/g-force-roofing-12957820-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/g-force-roofing-12957820-listing.html",
                                                "anchor_text": "G-Force Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Project One Contracting",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Lewisham, NSW 2049",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Project One Contracting",
                                        "url": "https://www.yellowpages.com.au/nsw/lewisham/project-one-contracting-13934959-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/lewisham/project-one-contracting-13934959-listing.html",
                                                "anchor_text": "Project One Contracting"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Project One Contracting",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Leichhardt, NSW 2040",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Project One Contracting",
                                        "url": "https://www.yellowpages.com.au/nsw/leichhardt/project-one-contracting-14683741-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/leichhardt/project-one-contracting-14683741-listing.html",
                                                "anchor_text": "Project One Contracting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9560 6274",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "A.S.A.P Roof Plumbing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Leichhardt, NSW 2040",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A.S.A.P Roof Plumbing",
                                        "url": "https://www.yellowpages.com.au/nsw/leichhardt/asap-roof-plumbing-12308603-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/leichhardt/asap-roof-plumbing-12308603-listing.html",
                                                "anchor_text": "A.S.A.P Roof Plumbing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0405 613 213",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Featured review",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Justine D.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Handy tips",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "A-Grade Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Ashfield, NSW 2131",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A-Grade Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/ashfield/a-grade-roofing-12820683-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ashfield/a-grade-roofing-12820683-listing.html",
                                                "anchor_text": "A-Grade Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open until 7:00pm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0430 070 149",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Bulli Roof Restorations",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Marrickville, NSW 2204",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Bulli Roof Restorations",
                                        "url": "https://www.yellowpages.com.au/nsw/marrickville/bulli-roof-restorations-1000002086797-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/marrickville/bulli-roof-restorations-1000002086797-listing.html",
                                                "anchor_text": "Bulli Roof Restorations"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Open by appt",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Black Cat Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Forest Lodge, NSW 2037",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Black Cat Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/forest-lodge/black-cat-roofing-13836186-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/forest-lodge/black-cat-roofing-13836186-listing.html",
                                                "anchor_text": "Black Cat Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9552 4806",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "A.G.C. Roof Maintenance P/L",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, St Peters, NSW 2044",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A.G.C. Roof Maintenance P/L",
                                        "url": "https://www.yellowpages.com.au/nsw/st-peters/agc-roof-maintenance-p-l-12039025-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/st-peters/agc-roof-maintenance-p-l-12039025-listing.html",
                                                "anchor_text": "A.G.C. Roof Maintenance P/L"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9892 4199",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Green Frog Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Marrickville, NSW 2204",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Green Frog Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/marrickville/green-frog-roofing-14693846-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/marrickville/green-frog-roofing-14693846-listing.html",
                                                "anchor_text": "Green Frog Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1300 566 522",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Global Roofing Services",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Leichhardt, NSW 2040",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Global Roofing Services",
                                        "url": "https://www.yellowpages.com.au/nsw/leichhardt/global-roofing-services-14560861-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/leichhardt/global-roofing-services-14560861-listing.html",
                                                "anchor_text": "Global Roofing Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1C Athol St, Leichhardt, NSW, 2040",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=1C+Athol+St&context=undefined&directionMode=true&elat=-33.87808&elon=151.149576&ena=Global+Roofing+Services&estr=1C+Athol+St&esu=Leichhardt%2C+NSW%2C+2040&productVersion=3&productId=999015539203&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGlobal+Roofing+Services%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.87808%26lon%3D151.149576%26selectedViewMode%3Dlist&yellowId=14560861",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=1C+Athol+St&context=undefined&directionMode=true&elat=-33.87808&elon=151.149576&ena=Global+Roofing+Services&estr=1C+Athol+St&esu=Leichhardt%2C+NSW%2C+2040&productVersion=3&productId=999015539203&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DGlobal+Roofing+Services%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.87808%26lon%3D151.149576%26selectedViewMode%3Dlist&yellowId=14560861",
                                                "anchor_text": "1C Athol St, Leichhardt, NSW, 2040"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1300 762 067",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "A Acclaimed Roofing Contractors",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Camperdown, NSW 2050",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A Acclaimed Roofing Contractors",
                                        "url": "https://www.yellowpages.com.au/nsw/camperdown/a-acclaimed-roofing-contractors-12793746-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/camperdown/a-acclaimed-roofing-contractors-12793746-listing.html",
                                                "anchor_text": "A Acclaimed Roofing Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "31 Gibbens St, Camperdown, NSW, 2050",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=31+Gibbens+St&context=undefined&directionMode=true&elat=-33.891385&elon=151.176857&ena=A+Acclaimed+Roofing+Contractors&estr=31+Gibbens+St&esu=Camperdown%2C+NSW%2C+2050&productVersion=3&productId=999901452288&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DA+Acclaimed+Roofing+Contractors%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.891385%26lon%3D151.176857%26selectedViewMode%3Dlist&yellowId=12793746",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=31+Gibbens+St&context=undefined&directionMode=true&elat=-33.891385&elon=151.176857&ena=A+Acclaimed+Roofing+Contractors&estr=31+Gibbens+St&esu=Camperdown%2C+NSW%2C+2050&productVersion=3&productId=999901452288&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DA+Acclaimed+Roofing+Contractors%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.891385%26lon%3D151.176857%26selectedViewMode%3Dlist&yellowId=12793746",
                                                "anchor_text": "31 Gibbens St, Camperdown, NSW, 2050"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9516 2727",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Green Frog Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Newtown, NSW 2042",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Green Frog Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/newtown/green-frog-roofing-12455495-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/newtown/green-frog-roofing-12455495-listing.html",
                                                "anchor_text": "Green Frog Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9550 5490",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ed Phillips Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Newtown, NSW 2042",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ed Phillips Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/newtown/ed-phillips-roofing-13270783-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/newtown/ed-phillips-roofing-13270783-listing.html",
                                                "anchor_text": "Ed Phillips Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0402 017 346",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ultimate Roof and Wall Systems",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Newtown, NSW 2042",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Ultimate Roof and Wall Systems",
                                        "url": "https://www.yellowpages.com.au/nsw/newtown/ultimate-roof-and-wall-systems-14513498-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/newtown/ultimate-roof-and-wall-systems-14513498-listing.html",
                                                "anchor_text": "Ultimate Roof and Wall Systems"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1300 055 901",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Newtown Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Newtown, NSW 2042",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Newtown Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/newtown/newtown-roofing-15609659-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/newtown/newtown-roofing-15609659-listing.html",
                                                "anchor_text": "Newtown Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0427 121 800",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Daisley D J &amp Sons Pty Ltd",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Ashfield, NSW 2131",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Daisley D J &amp Sons Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/ashfield/daisley-d-j-amp-sons-pty-ltd-1000001762464-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/ashfield/daisley-d-j-amp-sons-pty-ltd-1000001762464-listing.html",
                                                "anchor_text": "Daisley D J &amp Sons Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "162 Parramatta Rd, Ashfield, NSW, 2131",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=162+Parramatta+Rd&context=undefined&directionMode=true&elat=-33.883498&elon=151.133667&ena=Daisley+D+J+%26amp+Sons+Pty+Ltd&estr=162+Parramatta+Rd&esu=Ashfield%2C+NSW%2C+2131&productVersion=1&productId=1000001762464&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DDaisley+D+J+%26amp+Sons+Pty+Ltd%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.883498%26lon%3D151.133667%26selectedViewMode%3Dlist&yellowId=1000001762464",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=162+Parramatta+Rd&context=undefined&directionMode=true&elat=-33.883498&elon=151.133667&ena=Daisley+D+J+%26amp+Sons+Pty+Ltd&estr=162+Parramatta+Rd&esu=Ashfield%2C+NSW%2C+2131&productVersion=1&productId=1000001762464&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DDaisley+D+J+%26amp+Sons+Pty+Ltd%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.883498%26lon%3D151.133667%26selectedViewMode%3Dlist&yellowId=1000001762464",
                                                "anchor_text": "162 Parramatta Rd, Ashfield, NSW, 2131"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9799 2158",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Top Hat Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Newtown, NSW 2042",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Top Hat Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/newtown/top-hat-roofing-12574912-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/newtown/top-hat-roofing-12574912-listing.html",
                                                "anchor_text": "Top Hat Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "175 Lord St, Newtown, NSW, 2042",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=175+Lord+St&context=undefined&directionMode=true&elat=-33.908013&elon=151.175588&ena=Top+Hat+Roofing&estr=175+Lord+St&esu=Newtown%2C+NSW%2C+2042&productVersion=3&productId=474028402&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DTop+Hat+Roofing%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.908013%26lon%3D151.175588%26selectedViewMode%3Dlist&yellowId=12574912",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=175+Lord+St&context=undefined&directionMode=true&elat=-33.908013&elon=151.175588&ena=Top+Hat+Roofing&estr=175+Lord+St&esu=Newtown%2C+NSW%2C+2042&productVersion=3&productId=474028402&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DTop+Hat+Roofing%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.908013%26lon%3D151.175588%26selectedViewMode%3Dlist&yellowId=12574912",
                                                "anchor_text": "175 Lord St, Newtown, NSW, 2042"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0417 274 549",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Crown Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, St Peters, NSW 2044",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Crown Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/st-peters/crown-roofing-12425727-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/st-peters/crown-roofing-12425727-listing.html",
                                                "anchor_text": "Crown Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "50 Edith St, St Peters, NSW, 2044",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=50+Edith+St&context=undefined&directionMode=true&elat=-33.91358&elon=151.17399&ena=Crown+Roofing&estr=50+Edith+St&esu=St+Peters%2C+NSW%2C+2044&productVersion=4&productId=999901655112&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DCrown+Roofing%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.91358%26lon%3D151.17399%26selectedViewMode%3Dlist&yellowId=12425727",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=50+Edith+St&context=undefined&directionMode=true&elat=-33.91358&elon=151.17399&ena=Crown+Roofing&estr=50+Edith+St&esu=St+Peters%2C+NSW%2C+2044&productVersion=4&productId=999901655112&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DCrown+Roofing%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.91358%26lon%3D151.17399%26selectedViewMode%3Dlist&yellowId=12425727",
                                                "anchor_text": "50 Edith St, St Peters, NSW, 2044"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0414 777 881",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Efficient Property Solutions Pty Ltd",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Newtown, NSW 2042",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Efficient Property Solutions Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/newtown/efficient-property-solutions-pty-ltd-13469355-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/newtown/efficient-property-solutions-pty-ltd-13469355-listing.html",
                                                "anchor_text": "Efficient Property Solutions Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "89 Burren St, Newtown, NSW, 2042",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=89+Burren+St&context=undefined&directionMode=true&elat=-33.89616&elon=151.18533&ena=Efficient+Property+Solutions+Pty+Ltd&estr=89+Burren+St&esu=Newtown%2C+NSW%2C+2042&productVersion=3&productId=474066964&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DEfficient+Property+Solutions+Pty+Ltd%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.89616%26lon%3D151.18533%26selectedViewMode%3Dlist&yellowId=13469355",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=89+Burren+St&context=undefined&directionMode=true&elat=-33.89616&elon=151.18533&ena=Efficient+Property+Solutions+Pty+Ltd&estr=89+Burren+St&esu=Newtown%2C+NSW%2C+2042&productVersion=3&productId=474066964&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DEfficient+Property+Solutions+Pty+Ltd%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.89616%26lon%3D151.18533%26selectedViewMode%3Dlist&yellowId=13469355",
                                                "anchor_text": "89 Burren St, Newtown, NSW, 2042"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0402 017 346",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Stormproof Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, St Peters, NSW 2044",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Stormproof Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/st-peters/stormproof-roofing-11983772-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/st-peters/stormproof-roofing-11983772-listing.html",
                                                "anchor_text": "Stormproof Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0423 367 224",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Bulli Roof Restoration",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Newtown, NSW 2042",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Bulli Roof Restoration",
                                        "url": "https://www.yellowpages.com.au/sup/bulli-roof-restoration-14793224-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/bulli-roof-restoration-14793224-listing.html",
                                                "anchor_text": "Bulli Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 8084 8402",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Your Roof Repair",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Redfern, NSW 2016",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Your Roof Repair",
                                        "url": "https://www.yellowpages.com.au/sup/your-roof-repair-1000002043082-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/your-roof-repair-1000002043082-listing.html",
                                                "anchor_text": "Your Roof Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0420 434 752",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Roofing Services",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Croydon, NSW 2132",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Roofing Services",
                                        "url": "https://www.yellowpages.com.au/sup/all-roofing-services-1000002286940-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sup/all-roofing-services-1000002286940-listing.html",
                                                "anchor_text": "All Roofing Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 8086 2059",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Metal P/L",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Five Dock, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Metal P/L",
                                        "url": "https://www.yellowpages.com.au/nsw/five-dock/all-metal-p-l-12043144-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/five-dock/all-metal-p-l-12043144-listing.html",
                                                "anchor_text": "All Metal P/L"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0407 153 504",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Right Now Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Waterloo, NSW 2017",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Right Now Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/waterloo/right-now-roofing-15464740-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/waterloo/right-now-roofing-15464740-listing.html",
                                                "anchor_text": "Right Now Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0478 767 997",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "C.M.S. Roofing Pty Ltd",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Rozelle, NSW 2039",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "C.M.S. Roofing Pty Ltd",
                                        "url": "https://www.yellowpages.com.au/nsw/rozelle/cms-roofing-pty-ltd-12190702-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/rozelle/cms-roofing-pty-ltd-12190702-listing.html",
                                                "anchor_text": "C.M.S. Roofing Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "26C Mansfield St, Rozelle, NSW, 2039",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=26C+Mansfield+St&context=undefined&directionMode=true&elat=-33.864499&elon=151.178715&ena=C.M.S.+Roofing+Pty+Ltd&estr=26C+Mansfield+St&esu=Rozelle%2C+NSW%2C+2039&productVersion=4&productId=999999075911&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DC.M.S.+Roofing+Pty+Ltd%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.864499%26lon%3D151.178715%26selectedViewMode%3Dlist&yellowId=12190702",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=26C+Mansfield+St&context=undefined&directionMode=true&elat=-33.864499&elon=151.178715&ena=C.M.S.+Roofing+Pty+Ltd&estr=26C+Mansfield+St&esu=Rozelle%2C+NSW%2C+2039&productVersion=4&productId=999999075911&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DC.M.S.+Roofing+Pty+Ltd%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.864499%26lon%3D151.178715%26selectedViewMode%3Dlist&yellowId=12190702",
                                                "anchor_text": "26C Mansfield St, Rozelle, NSW, 2039"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "(02) 9555 8944",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "R R B Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Five Dock, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "R R B Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/five-dock/r-r-b-roofing-12462072-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/five-dock/r-r-b-roofing-12462072-listing.html",
                                                "anchor_text": "R R B Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0412 962 526",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Redfern Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Redfern, NSW 2016",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Redfern Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/redfern/redfern-roofing-12752559-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/redfern/redfern-roofing-12752559-listing.html",
                                                "anchor_text": "Redfern Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0402 017 346",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Auscity Roofing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Five Dock, NSW 2046",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Auscity Roofing",
                                        "url": "https://www.yellowpages.com.au/nsw/five-dock/auscity-roofing-1000002862535-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/five-dock/auscity-roofing-1000002862535-listing.html",
                                                "anchor_text": "Auscity Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "10 Kings Park Cct, Five Dock, NSW, 2046",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=10+Kings+Park+Cct&context=undefined&directionMode=true&elat=-33.867202&elon=151.120087&ena=Auscity+Roofing&estr=10+Kings+Park+Cct&esu=Five+Dock%2C+NSW%2C+2046&productVersion=1&productId=1000002862535&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DAuscity+Roofing%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.867202%26lon%3D151.120087%26selectedViewMode%3Dlist&yellowId=1000002862535",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=10+Kings+Park+Cct&context=undefined&directionMode=true&elat=-33.867202&elon=151.120087&ena=Auscity+Roofing&estr=10+Kings+Park+Cct&esu=Five+Dock%2C+NSW%2C+2046&productVersion=1&productId=1000002862535&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DAuscity+Roofing%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.867202%26lon%3D151.120087%26selectedViewMode%3Dlist&yellowId=1000002862535",
                                                "anchor_text": "10 Kings Park Cct, Five Dock, NSW, 2046"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0432 466 466",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "A Aadworkin Roofer",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs, Earlwood, NSW 2206",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "A Aadworkin Roofer",
                                        "url": "https://www.yellowpages.com.au/nsw/earlwood/a-aadworkin-roofer-14998589-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/earlwood/a-aadworkin-roofer-14998589-listing.html",
                                                "anchor_text": "A Aadworkin Roofer"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "37 Riverview Rd, Earlwood, NSW, 2206",
                                        "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=37+Riverview+Rd&context=undefined&directionMode=true&elat=-33.922579&elon=151.139359&ena=A+Aadworkin+Roofer&estr=37+Riverview+Rd&esu=Earlwood%2C+NSW%2C+2206&productVersion=3&productId=999015773359&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DA+Aadworkin+Roofer%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.922579%26lon%3D151.139359%26selectedViewMode%3Dlist&yellowId=14998589",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/external/dir.ext?path=https%3A%2F%2Fwww.whereis.com%2Fexternal%2Fdir.ext%3F&address=37+Riverview+Rd&context=undefined&directionMode=true&elat=-33.922579&elon=151.139359&ena=A+Aadworkin+Roofer&estr=37+Riverview+Rd&esu=Earlwood%2C+NSW%2C+2206&productVersion=3&productId=999015773359&ref=ypgd&referredBy=undefined&str=Petersham%2C+NSW+2049&xl=Back+to+Yellow+Pages&xu=https%3A%2F%2Fwww.yellowpages.com.au%2Fsearch%2Flistings%3Fclue%3DA+Aadworkin+Roofer%26locationClue%3DPetersham%2C+NSW+2049%26lat%3D-33.922579%26lon%3D151.139359%26selectedViewMode%3Dlist&yellowId=14998589",
                                                "anchor_text": "37 Riverview Rd, Earlwood, NSW, 2206"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0419 432 213",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "DEKFAST METAL ROOFING",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Construction & Services, Leichhardt, NSW 2040",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "DEKFAST METAL ROOFING",
                                        "url": "https://www.yellowpages.com.au/nsw/leichhhardt/dekfast-metal-roofing-1000002160511-listing.html",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/nsw/leichhhardt/dekfast-metal-roofing-1000002160511-listing.html",
                                                "anchor_text": "DEKFAST METAL ROOFING"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0405 705 625",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Average rating for Roof Restoration & Repairs in Petersham and surrounding suburbs",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Based on 767 reviews of 160 businesses on this page",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Articles",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Nearby Locations for Roof Restorations",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular Categories in Petersham",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Categories in Petersham",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Stratco",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You Bring The Dream, Stratco Will Bring The How To",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Guttering & Spouting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 556 541",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Regent Skylights",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Factory Direct Skylights, Energy Efficient Patented Press & Flashings",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "(07) 3274 3344",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Eco Wool Insulation Services",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Insulation Installers & Contractors",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "0481 845 529",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Sydney Gutter & Roof Restoration",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Warning, Not All Roof Companies Are The Same",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Guttering & Spouting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1300 654 884",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "A Class Plumbing",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Reliable, Professional Industrial & Commercial Specialists",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Plumbers & Gas Fitters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "(02) 9630 4227",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Related Articles",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our directory.",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Yellow Pages",
                                        "url": "https://www.yellowpages.com.au/pages/about-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/about-us",
                                                "anchor_text": "About Yellow Pages"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://www.yellowpages.com.au/pages/contact-us",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/contact-us",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Site Index",
                                        "url": "https://www.yellowpages.com.au/sitemap",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/sitemap",
                                                "anchor_text": "Site Index"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Order or cancel your book",
                                        "url": "https://www.directoryselect.com.au/action/home",
                                        "urls": [
                                            {
                                                "url": "https://www.directoryselect.com.au/action/home",
                                                "anchor_text": "Order or cancel your book"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://www.yellowpages.com.au/pages/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our advertising.",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Get a free listing",
                                        "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                                "anchor_text": "Get a free listing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Digital marketing solutions",
                                        "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                                "anchor_text": "Digital marketing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Business hub",
                                        "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                                "anchor_text": "Business hub"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "myYellow login",
                                        "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                                "anchor_text": "myYellow login"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Connect with us.",
                                "main_title": "35 BEST local Roof Restorations in Petersham NSW | Yellow Pages\u00ae",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About Thryv Australia",
                                        "url": "https://corporate.thryv.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/",
                                                "anchor_text": "About Thryv Australia"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://corporate.thryv.com/privacy/",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com/privacy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://corporate.thryv.com.au/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://corporate.thryv.com.au/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.2,
                                "max_rating_value": 5,
                                "rating_count": 767,
                                "relative_rating": 0.8400000000000001
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0485 800 063",
                                "(02) 9798 7075",
                                "(02) 9799 0065",
                                "1800 556 137",
                                "(02) 9560 6274",
                                "0405 613 213",
                                "(02) 9559 1616",
                                "0430 070 149",
                                "none",
                                "(02) 9552 4806",
                                "(02) 9550 5490",
                                "(02) 9892 4199",
                                "1300 566 522",
                                "1300 762 067",
                                "(02) 9516 2727",
                                "0402 017 346",
                                "1300 055 901",
                                "0427 121 800",
                                "(02) 9799 2158",
                                "0417 274 549",
                                "0414 777 881",
                                "0423 367 224",
                                "(02) 8084 8402",
                                "0420 434 752",
                                "(02) 8086 2059",
                                "0407 153 504",
                                "0478 767 997",
                                "(02) 9555 8944",
                                "0412 962 526",
                                "0432 466 466",
                                "0419 432 213",
                                "0405 705 625",
                                "0295606274",
                                "0405613213",
                                "0295591616",
                                "0430070149",
                                "0295524806",
                                "0295505490",
                                "0298924199",
                                "1300566522",
                                "1300762067",
                                "0295162727",
                                "0402017346",
                                "1300055901",
                                "0427121800",
                                "0297992158",
                                "0417274549",
                                "0414777881",
                                "0423367224",
                                "0280848402",
                                "0420434752",
                                "0280862059",
                                "0407153504",
                                "0478767997",
                                "0295558944",
                                "0412962526",
                                "0432466466",
                                "0419432213",
                                "0405705625",
                                "1300654884",
                                "1300556541",
                                "0732743344",
                                "0481845529",
                                "0296304227"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}