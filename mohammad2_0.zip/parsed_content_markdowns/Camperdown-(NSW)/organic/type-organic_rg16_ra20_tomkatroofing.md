{
    "id": "01190728-1132-0216-0000-43a6619b9b59",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0182 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://tomkatroofing.com.au/roofing-contractor/camperdown/",
        "target": "tomkatroofing.com.au",
        "start_url": "https://tomkatroofing.com.au/roofing-contractor/camperdown/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Camperdown-(NSW)\\organic\\type-organic_rg16_ra20_tomkatroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:30:43 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "\ud83c\udf84 Christmas Close-Out: Closed from 23 December \u2013 Back on 12 January \ud83c\udf81 | Wishing you a Merry Christmas & Happy New Year! \ud83c\udf85\u2728",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\ud83c\udf84 Christmas Close-Out: Closed from 23 December \u2013 Back on 12 January \ud83c\udf81 | Wishing you a Merry Christmas & Happy New Year! \ud83c\udf85\u2728",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Unit 4, 16 Bernera Road Prestons NSW 2170",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Project",
                                    "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                            "anchor_text": "New Roof Project"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters & Downpipes",
                                    "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                            "anchor_text": "Gutters & Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports & Inspections",
                                    "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                            "anchor_text": "Roof Reports & Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://tomkatroofing.com.au/service-area/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/service-area/",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://tomkatroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Project",
                                    "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                            "anchor_text": "New Roof Project"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters & Downpipes",
                                    "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                            "anchor_text": "Gutters & Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports & Inspections",
                                    "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                            "anchor_text": "Roof Reports & Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Service Areas",
                                    "url": "https://tomkatroofing.com.au/service-area/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/service-area/",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://tomkatroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://tomkatroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "1300 866 528",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Call Us Today!",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Roofing Contractor Camperdown",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Established roofing contractor in Camperdown providing superior roof repairs, restorations, and replacements. Count on our quality craftsmanship and reliable solutions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Company Camperdown",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "As an established roofing contractor serving Camperdown, we offer exceptional roofing services for both residential and commercial clients. Backed by substantial expertise and proven field experience, our team readily handles all your specific roofing requirements in this vibrant Inner West suburb.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We appreciate that your roof constitutes a critical property asset. Consequently, we exclusively use premium-quality materials and provide outstanding results for your space. Our committed team ensures rapid responses to urgent roofing problems and delivers solutions suited to Camperdown's mix of Victorian terraces and modern apartments.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Experiencing leaking roofs, fractured tiles, loose flashing, or storm-related issues in Camperdown? Our qualified roofing contractors resolve these problems quickly and effectively. We don't merely treat visible symptoms; we thoroughly investigate to uncover and rectify underlying causes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "When repairs throughout Camperdown no longer represent a cost-effective approach, we deliver a smooth, complete roof replacement service. Select from sturdy metal roofing such as Colorbond or premium tile alternatives. Our capable team manages removal, disposal, and compliant installation processes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "New Roof Projects",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Regular maintenance preserves your Camperdown roof's integrity and delivers substantial financial savings. Our services include comprehensive gutter cleaning, penetration resealing, flashing securement, and proactive identification of minor problems. A well-structured maintenance programme significantly prolongs roof lifespan.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspection & Reports",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing Contractor in Camperdown: Building new or expanding existing structures, our crew designs and installs roofs that align perfectly with your vision and budget. We collaborate closely with your builder to ensure efficient scheduling.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Downpipes",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For Camperdown homeowners, buyers, and strata managers, whether you're buying, selling, or managing insurance matters, our roofing contractor services deliver thorough and transparent roof assessments.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Let's Chat About Your Roofing Needs",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Safeguard your Camperdown home from water damage with appropriately sized gutters and downpipes. We address rust, leaks, and improper gradients, or install complete new systems. Select from leaf guard options to reduce blockages.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Workmanship",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We're your trusted roofing contractor for all residential or commercial roofing requirements in Camperdown. Contact us today and allow us to handle everything for you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Safety First",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Qualified roofing contractors in Camperdown bring substantial knowledge, technical proficiency, and keen attention to detail. With their accurate diagnostic capabilities, they effectively identify roofing issues and implement suitable fixes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Access to Quality Materials",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roofing work in Camperdown can present serious hazards without appropriate expertise and equipment. Reputable roofing contractors follow stringent safety protocols, employ premium equipment, and maintain comprehensive insurance coverage.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Time & Cost Efficiency",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Qualified roofing contractors in Camperdown have direct access to superior materials and possess the knowledge to select products that ideally suit the local climate and property types.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Engaging a professional Camperdown roofing contractor represents a prudent investment. Although DIY approaches may seem economical initially, they can generate unexpected expenses from mistakes, rework, or substandard materials.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From minor repairs to full roof installations, we keep Camperdown residences secure and dry. Specialising in tile and Colorbond roofing, we tailor services to match your preferences and budget.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repair",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Dependable roofing services for shops, commercial buildings, and strata across Camperdown. We carefully schedule work to accommodate business hours, minimising disruptions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Roofing",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Storm damage, unexpected leaks, or falling debris\u2014we act quickly in Camperdown. We secure sites, apply temporary protective measures, and complete permanent repairs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our expert team of Camperdown roofing contractors specialises in repairing, restoring, and replacing terracotta and concrete tiles to ensure your home remains watertight.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Flat & Low-Slope Roofing",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We focus on installing and maintaining superior metal roofs, especially Colorbond, recognised for durability, low maintenance, and extensive colour range. Metal roofing is lightweight and fire-resistant.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Initial Consultation",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We start with a detailed consultation and roof inspection. Our team reviews your needs, assesses the roof condition, and clearly explains possible solutions.",
                                        "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                                "anchor_text": "roof inspection"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Proposal and Quote",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You\u2019ll receive a transparent proposal with recommended solutions, material options, and a clear timeline \u2014 no jargon, just what you need to decide.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Project Execution",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Once approved, our licensed team completes the work according to the scheduled timeline. Most roof replacements finish within 3\u20137 days, with quality and safety at the core.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Completion and Follow-up",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "After finishing, we inspect the roof with you, ensure everything meets expectations, and leave your site spotless. We also share tips for ongoing care.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Tomkat Roofing for Your Next Project",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Flat and low-slope roofs in Camperdown need appropriate systems to prevent water accumulation and sun damage. Our expertise involves applying reliable membranes and coatings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "20+ Years of Industry Experience",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our Managing Director, Tom Stephens, brings over two decades of roofing expertise. Every project benefits from this leadership, ensuring work is completed to the highest standard.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Licensed, Insured and Certified",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We are fully licensed and insured, with all trades carrying certifications in working at heights, asbestos awareness, and elevated work platforms. Safety is never compromised.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Award-Winning\nBusiness",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Winners of the Australian Small Business Champion Awards 2024 and recognised finalists in local business awards, we are proud of our industry recognition.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Clear\nWarranties",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We back our work with a two-year workmanship guarantee, an additional five years for new builds and replacements, plus manufacturer warranties on all materials.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Kind Words from Our Customers",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I have had a fantastic experience with this business from start to finish. They are professional experienced, very fair and reasonable. We needed to replace the roof on our outdoor deck which was slightly tricky. Their advice and suggestions regarding product to use was sage. After a downpour there was a bit of a leak between the main building and the deck roof which they came out to fix which resolved the issue. There have been plenty of downpours since and everything is fine. I would highly recommend this company without hesitation. They are excellent.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tomkat did a great job and they were very pleasant to deal with.\nI\u2019d definitely preference them for any similar work in the future!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thankyou to TomKat Roofing and particulary Scott who did an excellent job repairing my roof.\nI had a water stain on the ceiling in one of my rooms, I called TomKat Roofing.\nThey sent out a technician (Tim I think his name was) to have a look at the roof and that was followed by a very clear & comprehensive quote with what work needed to be done. The quote was supported by photos of the roof showing the problem areas. Tim was very polite & knowledgeable. He explained to me what needed to be done as a matter of urgency and what would need to be done for maintenance purpose and he showed me the photos.\nThe price was very reasonable for the work that needed to be done.\nScott carried out the repair work. Scott is very pleasant to deal and he knew exactly what he was doing. He worked just about all day to finish the job for me and I was very happy with the results and my roof problems have now been solved.\nI was very impressed with everyone I dealt with, from the ladies in the office who prepared my quote to Scott who completed the job , they are all very friendly and most of all they know their stuff. I think they're an asset to TomKat.\nI highly recommend TomKat Roofing and I would definitely use them again.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tomkat Roofing was a great place to do business with from the initial phone call, to Gary who came out to give me a quote arrived on time and was very helpfull in his advise.The job was completed in a highly professional manner. I will have no problems using this company for any future roofing work. Great work to the whole team at Tomkat",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I contacted the team at TomKat roofing as I noticed a small leak in my daughters room during the recent storms and I was pleasantly greeted over the phone by the admin team who took down all my details and soon after I had the scheduling team call and arrange a suitable time to come out and review my concerns.\nThe team promptly identified what the issue was and fixed it promptly.\nI can\u2019t thank the team enough and whilst I hope I never need to call them again due to a roof issue, I would gladly recommend them to anyone looking for professional workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I highly recommend Tomkat Roofing for an efficient, well priced and solid quality roof replacement. My old, droopy and leaking terracotta tile roof is now straight and strong with a reinforced structure, new corrugated colorbond roof, gutters, facias, downpipes and leaf guard.\nSome of the key positive experiences I had with Tomkat Roofing are:\nThe efficient and friendly office staff always responded quickly and kept me informed of the progress and when the tradesmen would be onsite.\nAt the start of the job, within a single work day, they had a team of roofers and carpenters to get the old tiles off, the roof structure repaired/reinforced and the colorbond sheets with insulation secured so that my home was protected from the weather. Fortunately the weather was clear for a few days, but it was reassuring to know that they were prepared to work incredibly fast in the summer sun to keep my home safe.\nThe site supervisors were always friendly and took the time to explain everything to me and respond to any concerns or questions I had about the job. Being an older build home, I had a few items that needed particular attention and everything was completed to my satisfaction.\nA word of advice for home owners looking to get a roof replaced with Tomkat Roofing: Raise as many of your objectives and concerns as you can as early as possible. I found the Tomkat team very responsive to my overthinking mind and everything I wanted to get done was outlined in the quote and addressed during the job.\nAlso, they do tidy up and take away all the waste building material during and at the end of the job, which is great. But be prepared each evening to clean up smaller items that take time to find, like random screws or nails that were dropped, if you have children or pets accessing the area around your home in the evenings. It is unreasonable to expect the workers to find every dropped item each day if you also want the job done quickly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Helen O'Connor",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ali Bugeja",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lisa Anthony",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Christine Puckering",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Peter Thomas",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sully 71",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mike Cohen",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leading Roofing Contractors in Camperdown You Can Trust",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Finding the ideal roofing contractor in Camperdown involves more than just cost considerations. Tomkat Roofing stands out for our extensive expertise, transparent communication, and dedication to quality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How do I know if my roof needs repairs or a full replacement?",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Signs like leaks, sagging, missing tiles, or water stains often indicate the need for repair. However, if your roof is over 20 years old or has widespread damage, a full replacement may be more cost-effective.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Are you licensed and insured?",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Yes, we are fully licensed and insured, giving you confidence that all work is carried out to Australian standards and safety regulations. Our team is committed to delivering high-quality roofing services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long does a roof replacement take?",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The timeline depends on the size and complexity of the roof, weather conditions, and the materials used. Most residential roof replacements take between 2 to 5 days. We\u2019ll provide a clear timeline before the work begins.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you offer warranties on your work?",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Absolutely. We stand by the quality of our materials and workmanship. All our roofing work comes with a workmanship guarantee, and we use materials that are backed by manufacturer warranties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Get Your Free Roofing Quote Today!",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing Services We Offer",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Benefits of Hiring a Professional Roofing Contractor",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How We Help",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Types of Roofing We Work With",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How We Work",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "01",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "02",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "03",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "04",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Awards and Certificates",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Serving Sydney-Wide!",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "City Of Sydney",
                                        "url": "https://tomkatroofing.com.au/roofing-contractor-city-of-sydney",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roofing-contractor-city-of-sydney",
                                                "anchor_text": "City Of Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eastern Suburbs",
                                        "url": "https://tomkatroofing.com.au/roofing-contractor-eastern-suburbs",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roofing-contractor-eastern-suburbs",
                                                "anchor_text": "Eastern Suburbs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Shore",
                                        "url": "https://tomkatroofing.com.au/roofing-contractor-north-shore",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roofing-contractor-north-shore",
                                                "anchor_text": "North Shore"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Inner West",
                                        "url": "https://tomkatroofing.com.au/roofing-contractor-inner-west",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roofing-contractor-inner-west",
                                                "anchor_text": "Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hills Districts",
                                        "url": "https://tomkatroofing.com.au/roofing-contractor-hills-districts",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roofing-contractor-hills-districts",
                                                "anchor_text": "Hills Districts"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sutherland Shire",
                                        "url": "https://tomkatroofing.com.au/roofing-contractor-sutherland-shire",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roofing-contractor-sutherland-shire",
                                                "anchor_text": "Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lower Blue Mountain",
                                        "url": "https://tomkatroofing.com.au/roofing-contractor-lower-blue-mountain",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roofing-contractor-lower-blue-mountain",
                                                "anchor_text": "Lower Blue Mountain"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions (FAQs)",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get Finance In A Few Minutes",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "No Impact On Your Credit Score",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fast Pre-approval",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fortified Data Protection",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quick Links",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Services",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-repairs-sydney/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacements",
                                        "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-replacements-sydney/",
                                                "anchor_text": "Roof Replacements"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "New Roof Projects",
                                        "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-installation-sydney/",
                                                "anchor_text": "New Roof Projects"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspection & Reports",
                                        "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/roof-inspections-sydney/",
                                                "anchor_text": "Roof Inspection & Reports"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://tomkatroofing.com.au/gutters-installation-sydney/",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Details",
                                "main_title": "Roofing Contractor Camperdown",
                                "author": "Tomkat Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Unit 4, 16 Bernera Road Prestons NSW 2170",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Terms of Use | Privacy Policy",
                                        "url": "https://www.thryv.com/client-terms-of-use/",
                                        "urls": [
                                            {
                                                "url": "https://www.thryv.com/client-terms-of-use/",
                                                "anchor_text": "Terms of Use"
                                            },
                                            {
                                                "url": "https://www.thryv.com/client-privacy-policy/",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "\u00a9 2025 Tomkat Roofing. All Rights Reserved.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "1300866528"
                            ],
                            "emails": [
                                "%20info@tomkatroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}