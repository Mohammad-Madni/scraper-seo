{
    "id": "01190728-1132-0216-0000-235a00f4dde3",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0155 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://hipages.com.au/find/roofing/nsw/camperdown",
        "target": "hipages.com.au",
        "start_url": "https://hipages.com.au/find/roofing/nsw/camperdown",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Camperdown-(NSW)\\organic\\type-organic_rg3_ra6_hipages.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 0
            },
            "items_count": 0,
            "items": null
        }
    ]
}