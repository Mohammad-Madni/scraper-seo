{
    "id": "01190728-1132-0216-0000-4cd2de2a2c1d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0178 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofinginnerwest.com.au/",
        "target": "roofinginnerwest.com.au",
        "start_url": "https://roofinginnerwest.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Camperdown-(NSW)\\organic\\type-organic_rg18_ra22_roofinginnerwest.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:37 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Elevate Your Property with Zenith Roof Restorations & Replacements Inner West",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ROOFING INNER WEST",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Inner West, NSW 2204",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Open 24 hours a day, 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a92026\u00a0Roofing Inner West",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Phone: (02) 9167 0228",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email: [email\u00a0protected]",
                                    "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                            "anchor_text": "[email\u00a0protected]"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofinginnerwest.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofinginnerwest.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://roofinginnerwest.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://roofinginnerwest.com.au/terms-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/terms-conditions/",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Professional Roofing Experts for Homes and Businesses in Sydney\u2019s Inner West",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We service Sydney\u2019s Inner West and surrounding areas,",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "helping homeowners and local businesses protect what",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "matters most \u2014 your property and peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Shielding Your Home: A Strong Roof Starts Here",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Is your roof ready to weather the next season? At Roofing Inner West, we\u2019re Sydney Inner West\u2019s most trusted experts for all your roofing work. With years of experience and a team of skilled professionals, we specialise in roof restorations for all types of roofs, including tile and metal roofs, using premium materials and a sharp eye for detail.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We service Sydney\u2019s Inner West and surrounding areas, helping homeowners and local businesses protect what matters most \u2014 your property and peace of mind. From a full roof restoration to gutter work and skylight installation, our services boost durability, appearance and value, while keeping disruption to a minimum.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local knowledge of Inner West regulations and weather patterns ensures the right solutions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent pricing and reliable scheduling mean no surprises.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality workmanship backed by ongoing service and support.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Discover what we can do for your roof by exploring our services.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Roofing Inner West",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Led by Riley Alcorn, Roofing Inner West is a locally owned team delivering dependable roofing solutions across Sydney\u2019s Inner West and surrounding areas. With years of hands-on experience, we focus on quality, durability and service that stands up to the region\u2019s weather.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Specialising in roof restorations for tile and metal roofs, we use premium materials and a meticulous approach to protect your property and boost its value. Our work covers the full spectrum from inspections and cleaning to full restorations, patches, and paint finishing.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Licensed and insured professionals with deep local know-how in the Inner West.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent pricing and dependable scheduling to keep things straightforward.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ongoing support after project completion to protect your investment.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We service Sydney\u2019s Inner West and surrounding suburbs, including Annandale, Balmain, Marrickville, and more. For a full list of locations, visit the locations page.",
                                        "url": "https://roofinginnerwest.com.au/locations",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations",
                                                "anchor_text": "locations page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Weather-Ready Roofing Services for the Inner West",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Reliable roofing for homes and businesses across Sydney\u2019s Inner West starts with Roofing Inner West. We specialise in roof restorations for tile and metal roofs, using premium materials and a meticulous approach that keeps weather at bay. Led by Riley Alcorn, our licensed, insured team delivers results that protect properties and boost value.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "From full roof restorations to targeted fixes, we cover inspections, cleaning, repointing, flashing, guttering and skylight work. Our local knowledge of Inner West regulations and climate helps tailor solutions that perform with minimal disruption and maximum longevity.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Core services include:",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tile and metal roof restorations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guttering, downpipes, fascia and flashing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Skylight installation and repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof cleaning, painting and coating options",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ready to bolster your roof with proven, local expertise? Learn more about our full range of services.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Customer Testimonials",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Residents of Sydney\u2019s Inner West trust Roofing Inner West for reliable roof restorations on tile and metal roofs. We pair premium materials with a straightforward, no-nonsense approach to restore your roof quickly and minimise disruption. Here\u2019s what locals have said about our service:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "As a locally owned business led by Riley Alcorn, Roofing Inner West backs every project with a workmanship guarantee and ongoing support. We\u2019re committed to quality, transparent pricing and real results that protect your home through NSW weather.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201c The team arrived on time, explained every step and left a flawless finish on our tile roof \u2014 we\u2019ve noticed the difference straight away. \u201c",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2014 Marrickville resident",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u201c Our metal roof leak was fixed right the first time, and the coating revived the whole look of the house. Professional, friendly and great value. \u201c",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2014 Balmain East resident",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "The Inner West Advantage",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Choosing a roofer in Sydney\u2019s Inner West means trusting a team that truly understands the local climate, regulations, and homeowners\u2019 expectations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing Inner West, led by Riley Alcorn, brings practical, no-nonsense roofing know-how to tile and metal roof restorations. We use premium materials and meticulous workmanship to protect your home and boost its value\u2014without drama or delays.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local knowledge across Sydney\u2019s Inner West with prompt scheduling",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent pricing and clear warranties",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium materials and skilled trades delivering durable results",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Compared with others, we prioritise quality and lasting outcomes. Our team is licensed and insured, and every project comes with a workmanship guarantee and ongoing post-completion support. We tailor solutions that respect NSW regulations and the Inner West\u2019s weather, delivering minimal disruption and maximum longevity. Learn more at Roofing Inner West or email [email\u00a0protected].",
                                        "url": "https://riw.roofinginnerwest.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://riw.roofinginnerwest.com.au/",
                                                "anchor_text": "Roofing Inner West"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Process",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From the first call to the final handover, Roofing Inner West keeps the journey simple and transparent. Led by Riley Alcorn, our Inner West team follows a structured process designed to minimise disruption while delivering durable, high\u2011quality results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We align every step with NSW regulations and the local weather patterns to ensure the job is done right the first time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free on-site inspection with a clear, transparent quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Material selection using premium materials and a practical plan",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Scheduling and site protection plus any required permits",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "On-site execution with a dedicated supervisor, and daily updates",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Final clean-up, inspection and post-completion support",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We prioritise customer satisfaction and robust quality control. A dedicated supervisor oversees every project, with comprehensive checklists, safety compliance and a clear communication channel to neighbours, reducing disruption. After completion, we stand by our work with warranties and ongoing support to protect your investment.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For more detail on our offerings, browse our Services. If you\u2019re curious about the areas we serve in Sydney\u2019s Inner West, check our Locations.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations",
                                                "anchor_text": "Locations"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Learn more about our offerings on the Services page. For a free on-site inspection, call (02) 9167 0228.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FAQs",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Here are some common questions about roofing in Sydney\u2019s Inner West. Roofing Inner West, led by Riley Alcorn, keeps things clear and practical for homeowners and local businesses.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q: Do you offer roof restorations for tile and metal roofs?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A: Yes \u2014 we specialise in roof restorations for both tile and metal roofs across the Inner West and nearby suburbs, using premium materials and a meticulous approach.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q: What makes Roofing Inner West different?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A: We prioritise quality, durability and transparent pricing, with ongoing support after completion from a licensed, insured team that understands local climate and NSW regulations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "In terms of timing and guarantees, here\u2019s what you can expect from us:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q: How long does a typical roof restoration take, and will it disrupt my day?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A: Timelines vary by roof size and condition, but we aim for minimal disruption with clear scheduling and on-site protection.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q: What warranty do you offer?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A: We back our work with a workmanship guarantee and ongoing support to protect your investment.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you\u2019re ready to take the next step, these details cover booking and service areas:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Q: How do I book or get a quote, and do you service my area?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A: We offer free on-site inspections and a transparent quote to start. We service Sydney\u2019s Inner West, including suburbs like Annandale, Balmain and Marrickville.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Take Action: Lock In a Stronger Roof Today",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Ready to shield your home with a roof that lasts? Roofing Inner West, led by Riley Alcorn, delivers expert tile and metal roof restorations across Sydney\u2019s Inner West. Start with a free on-site inspection and a no-obligation quote. By using premium materials and meticulous workmanship, we help you gain lasting protection with minimal disruption.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With local know-how and a straightforward process, we tailor solutions for Inner West homes and businesses. Our services span inspections and cleaning through full restorations, ensuring clear pricing, reliable scheduling and ongoing support after completion.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free on-site inspection and transparent quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flexible scheduling with minimal disruption",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium materials and a workmanship guarantee",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ready to get started? Call 02 9167 0228 or [email\u00a0protected] to book your inspection.",
                                        "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We service Sydney\u2019s Inner West, including suburbs such as Annandale, Balmain, Marrickville and surrounding areas. Our local knowledge means clear pricing, practical solutions, and minimal disruption to your daily routine.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Stay in Touch with Roofing Inner West",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We\u2019re available 24/7 to support homeowners and businesses across Sydney\u2019s Inner West and nearby areas. Led by Riley Alcorn, our team delivers reliable roofing solutions\u2014from quick repairs to full roof restorations\u2014without the fuss. Bold, straight talk and solid results are what you get.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For quick, direct contact, use one of the options below.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Call us on (02) 9167 0228",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email us at:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019re ready to help you protect and refresh your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Closing Thoughts: A Roof That Stands With You",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "In Sydney\u2019s Inner West, Roofing Inner West is the trusted name for tile and metal roof restorations. Led by Riley Alcorn, our crew blends premium materials, practical service, and meticulous workmanship to protect homes and boost value. We\u2019re a locally owned, licensed and insured team that truly understands NSW weather and regulations, delivering durable results with minimal disruption.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our approach covers inspections, cleaning, repairs and full restorations, plus ongoing support after completion. With clear, upfront quotes and transparent pricing, you\u2019ll know what to expect\u2014no surprises. Every project carries a workmanship guarantee, so you\u2019ve got peace of mind long after the job is done.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local Inner West experts who know the climate and permits inside out.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium materials, meticulous finishes, and a workmanship guarantee that stands up to NSW weather.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ready to fortify your roof? Reach out via phone or email to arrange a free on-site inspection and a no-obligation quote. Call (02) 9167 0228 or [email\u00a0protected].",
                                        "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Latest Blog Post",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roofing Inner West Sydney, we\u2019re passionate about protecting homes and businesses with reliable, long-lasting roofing solutions. Our blog is here to share expert tips, industry insights, and practical advice to help you make informed decisions about roof care, maintenance, and restoration. Whether you\u2019re tackling a minor repair or planning a full upgrade, we\u2019ll guide you through the process with clarity and confidence.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Cleaning Inner West: Prevent Water Damage and Costly Repairs",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Why Regular Gutter Cleaning Protects Inner West Properties Gutter cleaning is one of the most important \u2014 yet often overlooked \u2014 parts of roof maintenance for homes and businesses across Sydney\u2019s Inner West. With leafy streets, older homes and seasonal downpours,\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter Cleaning Inner West: Prevent Water Damage and Costly Repairs",
                                        "url": "https://roofinginnerwest.com.au/blog/gutter-cleaning-inner-west-prevent-water-damage-and-costly-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/blog/gutter-cleaning-inner-west-prevent-water-damage-and-costly-repairs/",
                                                "anchor_text": "Gutter Cleaning Inner West: Prevent Water Damage and Costly Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://roofinginnerwest.com.au/blog/category/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/blog/category/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning Inner West: Restore and Protect Your Roof",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Why Roof Cleaning Matters for Inner West Homes Regular roof cleaning in the Inner West is one of the most effective ways to protect your property, improve street appeal, and extend the life of your roof. With Sydney\u2019s Inner West exposed to pollution, moisture, and\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Cleaning Inner West: Restore and Protect Your Roof",
                                        "url": "https://roofinginnerwest.com.au/blog/roof-cleaning-inner-west-restore-and-protect-your-roof/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/blog/roof-cleaning-inner-west-restore-and-protect-your-roof/",
                                                "anchor_text": "Roof Cleaning Inner West: Restore and Protect Your Roof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Cleaning",
                                        "url": "https://roofinginnerwest.com.au/blog/category/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/blog/category/roof-cleaning/",
                                                "anchor_text": "Roof Cleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Inner West: Fix Small Issues Before They Become Big Problems",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Why Early Roof Repairs Save Inner West Homeowners Thousands Small roofing issues can quickly escalate into serious and expensive problems if ignored. For property owners across Sydney\u2019s Inner West, timely roof repairs are essential to protect your home or business\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs Inner West: Fix Small Issues Before They Become Big Problems",
                                        "url": "https://roofinginnerwest.com.au/blog/roof-repairs-inner-west-fix-small-issues-before-they-become-big-problems/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/blog/roof-repairs-inner-west-fix-small-issues-before-they-become-big-problems/",
                                                "anchor_text": "Roof Repairs Inner West: Fix Small Issues Before They Become Big Problems"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://roofinginnerwest.com.au/blog/category/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/blog/category/roof-repairs/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacements in Inner West: When Is It Time for a New Roof?",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Signs Your Inner West Roof Has Reached the End of Its Life Every roof reaches a point where ongoing repairs are no longer cost-effective. For property owners across Sydney\u2019s Inner West, knowing when to move from repairs to a full roof replacement can save money,\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacements in Inner West: When Is It Time for a New Roof?",
                                        "url": "https://roofinginnerwest.com.au/blog/roof-replacements-in-inner-west-when-is-it-time-for-a-new-roof/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/blog/roof-replacements-in-inner-west-when-is-it-time-for-a-new-roof/",
                                                "anchor_text": "Roof Replacements in Inner West: When Is It Time for a New Roof?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacements",
                                        "url": "https://roofinginnerwest.com.au/blog/category/roof-replacements/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/blog/category/roof-replacements/",
                                                "anchor_text": "Roof Replacements"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Inner West",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "Roofing Inner West",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61291670228"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}