{
    "id": "01191143-1132-0216-0000-4a5902c0c32d",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0334 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.whereis.com/nsw/camperdown-2050/yellowId-1000002965103",
        "target": "whereis.com",
        "start_url": "https://www.whereis.com/nsw/camperdown-2050/yellowId-1000002965103",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": false,
        "load_resources": false,
        "enable_browser_rendering": false,
        "enable_xhr": false,
        "disable_cookie_popup": false,
        "browser_preset": "desktop",
        "tag": "parsed_content_markdowns\\Camperdown-(NSW)\\organic\\type-organic_rg14_ra18_whereis.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 07:44:43 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Aussie Roofing Services",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Sorry, maps are currently unavailable",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Map data \u00a9 OpenStreetMap contributors",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Loading map...",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services opening hours in CAMPERDOWN",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Aussie Roofing Services - Pic 1",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Products and Services",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "24/7 Emergency Service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24/7 Emergency Service",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "People Also Viewed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.whereis.com/find/roof-restoration-repairs/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-restoration-repairs/camperdown-nsw-2050",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.whereis.com/find/roof-restoration-repairs/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-restoration-repairs/camperdown-nsw-2050",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Acid Proofing",
                                        "url": "https://www.whereis.com/find/acid-proofing/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/acid-proofing/camperdown-nsw-2050",
                                                "anchor_text": "Acid Proofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Insulation Installers & Contractors",
                                        "url": "https://www.whereis.com/find/insulation-installers-contractors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/insulation-installers-contractors/camperdown-nsw-2050",
                                                "anchor_text": "Insulation Installers & Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": "https://www.whereis.com/find/roofing-construction-services/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roofing-construction-services/camperdown-nsw-2050",
                                                "anchor_text": "Roofing Construction & Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tiles",
                                        "url": "https://www.whereis.com/find/roof-tiles/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-tiles/camperdown-nsw-2050",
                                                "anchor_text": "Roof Tiles"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Popular Categories",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Plumbers in Camperdown",
                                        "url": "https://www.whereis.com/find/plumbers-gas-fitters/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/plumbers-gas-fitters/camperdown-nsw-2050",
                                                "anchor_text": "Plumbers in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electricians in Camperdown",
                                        "url": "https://www.whereis.com/find/electricians-electrical-contractors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/electricians-electrical-contractors/camperdown-nsw-2050",
                                                "anchor_text": "Electricians in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lawyers in Camperdown",
                                        "url": "https://www.whereis.com/find/lawyers-solicitors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/lawyers-solicitors/camperdown-nsw-2050",
                                                "anchor_text": "Lawyers in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pest Control in Camperdown",
                                        "url": "https://www.whereis.com/find/pest-control/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/pest-control/camperdown-nsw-2050",
                                                "anchor_text": "Pest Control  in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mechanics in Camperdown",
                                        "url": "https://www.whereis.com/find/mechanics-motor-engineers/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/mechanics-motor-engineers/camperdown-nsw-2050",
                                                "anchor_text": "Mechanics in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Locksmiths in Camperdown",
                                        "url": "https://www.whereis.com/find/locksmiths-locksmith-services/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/locksmiths-locksmith-services/camperdown-nsw-2050",
                                                "anchor_text": "Locksmiths in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Concreters in Camperdown",
                                        "url": "https://www.whereis.com/find/concrete-contractors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/concrete-contractors/camperdown-nsw-2050",
                                                "anchor_text": "Concreters in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Fencing Contractors in Camperdown",
                                        "url": "https://www.whereis.com/find/fencing-contractors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/fencing-contractors/camperdown-nsw-2050",
                                                "anchor_text": "Fencing Contractors in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Builders in Camperdown",
                                        "url": "https://www.whereis.com/find/builders-building-contractors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/builders-building-contractors/camperdown-nsw-2050",
                                                "anchor_text": "Builders in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Accountants in Camperdown",
                                        "url": "https://www.whereis.com/find/accountants-auditors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/accountants-auditors/camperdown-nsw-2050",
                                                "anchor_text": "Accountants in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "About Us",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Additional Locations",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "About Aussie Roofing Services",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roofing Services Sydney",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Upfront, Flat Rate Pricing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Your roof is your first line of defence against harsh weather, heat, and external elements.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether you need a roof repair, replacement, or a brand-new installation, ensuring quality craftsmanship is essential for long-lasting durability and protection.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Aussie Services, we offer\u00a0professional roofing services across Sydney, delivering strong, weather-resistant solutions tailored to your home or business. Whether you\u2019re dealing with leaks, damaged tiles, or need a full roof restoration, our experienced roofers provide fast, reliable, and high-quality roofing solutions\u00a0that stand the test of time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Your roof plays a critical role in protecting your home or business, and ensuring it\u2019s strong, weatherproof, and durable is essential. Whether you need minor repairs, a full roof replacement, or storm damage restoration, our expert roofers provide quality workmanship with long-lasting results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Trusted Sydney Roofers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24/7 Service & Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lifetime Labour Guarantee",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Us for Roofing",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "High-Quality Roofing Materials & Workmanship",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We use premium materials and expert craftsmanship to ensure your roof is strong, weatherproof, and built to last.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Full Range of Roofing Services",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "From roof repairs and maintenance to new roof installations, we provide complete roofing solutions for homes and businesses.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney\u2019s weather can be unpredictable, but our roofing solutions are designed to withstand heavy rain, wind, and heat, keeping your home safe and dry year-round.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local Sydney Roofing Experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team understands Sydney\u2019s unique climate and roofing challenges, ensuring we recommend the best solutions for long-term durability.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Weatherproof & Leak-Resistant Roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What to Expect from Our Roofing Services",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof Inspection & Assessment\u00a0\u2013 We evaluate your roof\u2019s condition, damage, and potential issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Professional Repairs or Installation \u2013 Whether it\u2019s\u00a0fixing leaks, replacing tiles, or installing a new roof, we use\u00a0top-quality materials for every job.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Weatherproofing & Sealing \u2013 We ensure\u00a0waterproof protection to safeguard your home from leaks and future damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Final Quality Check & Cleanup \u2013 We inspect every project to guarantee quality workmanship, leaving your property clean and safe.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hours of Operation",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "24hr Emergency Service, Flexible Hours, Open 24hrs, Open 365 Days, Open Evenings, Open Late, Open Monday - Friday, Open Saturdays, Open Sundays",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Downpipe Cleaning, Drain Cleaning, Emergencies, Extensions, Gutter Cleaning, High Pressure Cleaning, Installations, Leaf Screening, Maintenance, Moss Removal, Painting, Plumbing, Re-roofing, Rebedding, Renovations, Repairs, Replacements, Repointing, Rescrewing, Resealing, Restorations, Resurfacing, Roof Cleaning, Roofing, Sealing, Spouting, Tiling, Waterproofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Features",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Accredited, Australian Made, Australian Operated, Australian Owned, By Appointment, Consultations, Free Quotes, Guaranteed, Inspections, Insured, Licensed, Locally Operated, Locally Owned, Maintenance Contracts, Mobile Service, On-Site Services, Owner Operated, Quotes, Registered, Same Day Service, Standards Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Keywords",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "metal roof, Roof Inspection & Assessment, Local Sydney Roofing Experts, Emergency Service, new roof, Protecting Sydney Homes & Businesses, Trusted Sydney Roofers, professional roofing services, 24/7 Service & Repairs, all types of roofing, long-lasting durability and protection, roof tiles, weather resistant roofing solutions, High-Quality Roofing Materials & Workmanship, roof replacement, new installation, clean and safe roofing, Final Quality Check & Cleanup, Full Range of Roofing Services, Reliable Roofing Solutions, 24/7 Emergency Roofing Service, top-quality materials, Weatherproof & Leak-Resistant Roofing, Professional Repairs or Installation, Roofing Services Sydney, roof repair",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How do I know if my roof needs repairs or a full replacement?",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If your roof has minor leaks, cracked tiles, or minor rust spots, repairs may be enough. However, if there\u2019s widespread damage, sagging, or recurring leaks, a full replacement might be more cost-effective. Our experts will assess your roof and recommend the best solution for your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Can you work on all types of roofs?",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Yes! We specialise in tile, metal, Colorbond, and flat roofing for residential and commercial properties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you offer emergency roof repairs?",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Yes! If your roof has storm damage, sudden leaks, or structural issues, we provide emergency roofing services to secure and repair your home quickly.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How long does a roof repair or replacement take?",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Small repairs (fixing leaks, replacing a few tiles) usually take a few hours.\nRoof restoration (cleaning, repainting, resealing) takes 1\u20132 days.\nFull roof replacements typically take 3\u20135 days, depending on the size and materials used.\nWe\u2019ll provide a clear timeline before starting work so you know what to expect.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roofing work cost?",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "The cost depends on the size of your roof, the materials used, and the level of repairs needed. We provide transparent, upfront quotes so you know exactly what to expect with no hidden fees.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Restoration & Repairs",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Trusted Sydney Roofers \u2013 24/7 Service & Repairs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.whereis.com/find/roof-restoration-repairs/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-restoration-repairs/camperdown-nsw-2050",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0485 800 063",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Send Email",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Aussie Roofing Services opening hours in CAMPERDOWN",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "About Us",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Products and Services",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Offering",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Commercial, Residential",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Issues",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Blocked Drains, Broken Tiles, Leaks, Rust, Storm Damage",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Additional Locations",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Showing 244 locations in 1 states",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FAQs",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "FAQs",
                                "main_title": "Aussie Roofing Services",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Yellow Pages",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "People Also Viewed",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.whereis.com/find/roof-restoration-repairs/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-restoration-repairs/camperdown-nsw-2050",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration & Repairs",
                                        "url": "https://www.whereis.com/find/roof-restoration-repairs/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-restoration-repairs/camperdown-nsw-2050",
                                                "anchor_text": "Roof Restoration & Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Acid Proofing",
                                        "url": "https://www.whereis.com/find/acid-proofing/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/acid-proofing/camperdown-nsw-2050",
                                                "anchor_text": "Acid Proofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Insulation Installers & Contractors",
                                        "url": "https://www.whereis.com/find/insulation-installers-contractors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/insulation-installers-contractors/camperdown-nsw-2050",
                                                "anchor_text": "Insulation Installers & Contractors"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Construction & Services",
                                        "url": "https://www.whereis.com/find/roofing-construction-services/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roofing-construction-services/camperdown-nsw-2050",
                                                "anchor_text": "Roofing Construction & Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Tiles",
                                        "url": "https://www.whereis.com/find/roof-tiles/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/roof-tiles/camperdown-nsw-2050",
                                                "anchor_text": "Roof Tiles"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Popular Categories",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Plumbers in Camperdown",
                                        "url": "https://www.whereis.com/find/plumbers-gas-fitters/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/plumbers-gas-fitters/camperdown-nsw-2050",
                                                "anchor_text": "Plumbers in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Electricians in Camperdown",
                                        "url": "https://www.whereis.com/find/electricians-electrical-contractors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/electricians-electrical-contractors/camperdown-nsw-2050",
                                                "anchor_text": "Electricians in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lawyers in Camperdown",
                                        "url": "https://www.whereis.com/find/lawyers-solicitors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/lawyers-solicitors/camperdown-nsw-2050",
                                                "anchor_text": "Lawyers in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pest Control in Camperdown",
                                        "url": "https://www.whereis.com/find/pest-control/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/pest-control/camperdown-nsw-2050",
                                                "anchor_text": "Pest Control  in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mechanics in Camperdown",
                                        "url": "https://www.whereis.com/find/mechanics-motor-engineers/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/mechanics-motor-engineers/camperdown-nsw-2050",
                                                "anchor_text": "Mechanics in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Locksmiths in Camperdown",
                                        "url": "https://www.whereis.com/find/locksmiths-locksmith-services/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/locksmiths-locksmith-services/camperdown-nsw-2050",
                                                "anchor_text": "Locksmiths in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Concreters in Camperdown",
                                        "url": "https://www.whereis.com/find/concrete-contractors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/concrete-contractors/camperdown-nsw-2050",
                                                "anchor_text": "Concreters in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Fencing Contractors in Camperdown",
                                        "url": "https://www.whereis.com/find/fencing-contractors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/fencing-contractors/camperdown-nsw-2050",
                                                "anchor_text": "Fencing Contractors in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Builders in Camperdown",
                                        "url": "https://www.whereis.com/find/builders-building-contractors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/builders-building-contractors/camperdown-nsw-2050",
                                                "anchor_text": "Builders in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Accountants in Camperdown",
                                        "url": "https://www.whereis.com/find/accountants-auditors/camperdown-nsw-2050",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/find/accountants-auditors/camperdown-nsw-2050",
                                                "anchor_text": "Accountants in Camperdown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our directory.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "About Yellow Pages",
                                        "url": "https://www.whereis.com/pages/about-us",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/pages/about-us",
                                                "anchor_text": "About Yellow Pages"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us",
                                        "url": "https://www.whereis.com/pages/contact-us",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/pages/contact-us",
                                                "anchor_text": "Contact us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Site Index",
                                        "url": "https://www.whereis.com/sitemap",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/sitemap",
                                                "anchor_text": "Site Index"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Order or cancel your book",
                                        "url": "https://www.directoryselect.com.au/action/home",
                                        "urls": [
                                            {
                                                "url": "https://www.directoryselect.com.au/action/home",
                                                "anchor_text": "Order or cancel your book"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terms of use",
                                        "url": "https://www.whereis.com/pages/terms-of-use",
                                        "urls": [
                                            {
                                                "url": "https://www.whereis.com/pages/terms-of-use",
                                                "anchor_text": "Terms of use"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Our advertising.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get a free listing",
                                        "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/online-signup/?referrer=yp_footer",
                                                "anchor_text": "Get a free listing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Digital marketing solutions",
                                        "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/products/?referrer=yp_footer",
                                                "anchor_text": "Digital marketing solutions"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Business hub",
                                        "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://www.yellow.com.au/business-hub/?referrer=yp_footer",
                                                "anchor_text": "Business hub"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "myYellow login",
                                        "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                        "urls": [
                                            {
                                                "url": "https://my.yellow.com.au/login/?referrer=yp_footer",
                                                "anchor_text": "myYellow login"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Connect with us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": [
                            {
                                "name": "Aussie Roofing Services",
                                "price": 0,
                                "price_currency": null,
                                "price_valid_until": null
                            }
                        ],
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0485 800 063",
                                "0485800063"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}