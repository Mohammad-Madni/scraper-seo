{
    "id": "01190728-1132-0216-0000-72460ac8b7d3",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0208 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.airtasker.com/au/services/roofing/camperdown-nsw/",
        "target": "www.airtasker.com",
        "start_url": "https://www.airtasker.com/au/services/roofing/camperdown-nsw/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Camperdown-(NSW)\\organic\\type-organic_rg8_ra11_airtasker.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:36 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "What are you looking for?",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Pick a type of task.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "I'm looking for work in ...",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "I\u2019m looking to hire someone for ...",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "As a tasker",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "As a poster",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Auto Electricians",
                                    "url": "https://www.airtasker.com/au/services/auto-electrician/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/auto-electrician/",
                                            "anchor_text": "Auto Electricians"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bicycle Service",
                                    "url": "https://www.airtasker.com/au/services/bicycle/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/bicycle/",
                                            "anchor_text": "Bicycle Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Building & Construction",
                                    "url": "https://www.airtasker.com/au/services/building-construction/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/building-construction/",
                                            "anchor_text": "Building & Construction"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Body Work",
                                    "url": "https://www.airtasker.com/au/services/car-bodywork/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-bodywork/",
                                            "anchor_text": "Car Body Work"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Detailing",
                                    "url": "https://www.airtasker.com/au/services/car-detailing/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-detailing/",
                                            "anchor_text": "Car Detailing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Repair",
                                    "url": "https://www.airtasker.com/au/services/car-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-repair/",
                                            "anchor_text": "Car Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Service",
                                    "url": "https://www.airtasker.com/au/services/car-servicing/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-servicing/",
                                            "anchor_text": "Car Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cat Care",
                                    "url": "https://www.airtasker.com/au/services/cat-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/cat-care/",
                                            "anchor_text": "Cat Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Computers & IT",
                                    "url": "https://www.airtasker.com/au/services/computers/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/computers/",
                                            "anchor_text": "Computers & IT"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dog Care",
                                    "url": "https://www.airtasker.com/au/services/dog-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/dog-care/",
                                            "anchor_text": "Dog Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Furniture Assembly",
                                    "url": "https://www.airtasker.com/au/services/furniture-assembly/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/furniture-assembly/",
                                            "anchor_text": "Furniture Assembly"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gate Installation",
                                    "url": "https://www.airtasker.com/au/services/gate-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/gate-installation/",
                                            "anchor_text": "Gate Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heating & Cooling",
                                    "url": "https://www.airtasker.com/au/services/heating-cooling/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/heating-cooling/",
                                            "anchor_text": "Heating & Cooling"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Automation and Security",
                                    "url": "https://www.airtasker.com/au/services/home-automation-security/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/home-automation-security/",
                                            "anchor_text": "Home Automation and Security"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Theatre",
                                    "url": "https://www.airtasker.com/au/services/home-theatre/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/home-theatre/",
                                            "anchor_text": "Home Theatre"
                                        }
                                    ]
                                },
                                {
                                    "text": "Interior Designer",
                                    "url": "https://www.airtasker.com/au/services/interior-design/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/interior-design/",
                                            "anchor_text": "Interior Designer"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lawn Care",
                                    "url": "https://www.airtasker.com/au/services/lawn-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/lawn-care/",
                                            "anchor_text": "Lawn Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Makeup Artist",
                                    "url": "https://www.airtasker.com/au/services/makeup-artist/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/makeup-artist/",
                                            "anchor_text": "Makeup Artist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mobile Mechanic",
                                    "url": "https://www.airtasker.com/au/services/mobile-mechanic/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/mobile-mechanic/",
                                            "anchor_text": "Mobile Mechanic"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pest Control",
                                    "url": "https://www.airtasker.com/au/services/pest-control/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/pest-control/",
                                            "anchor_text": "Pest Control"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pet Care",
                                    "url": "https://www.airtasker.com/au/services/pet-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/pet-care/",
                                            "anchor_text": "Pet Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pool Maintenance",
                                    "url": "https://www.airtasker.com/au/services/pool-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/pool-maintenance/",
                                            "anchor_text": "Pool Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tattoo Artists",
                                    "url": "https://www.airtasker.com/au/services/tattoo-artist/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/tattoo-artist/",
                                            "anchor_text": "Tattoo Artists"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wall Hanging & Mounting",
                                    "url": "https://www.airtasker.com/au/services/wall-hanging-mounting/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/wall-hanging-mounting/",
                                            "anchor_text": "Wall Hanging & Mounting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wheel & Tyre Service",
                                    "url": "https://www.airtasker.com/au/services/wheel-tyre-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/wheel-tyre-service/",
                                            "anchor_text": "Wheel & Tyre Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "View all",
                                    "url": "https://www.airtasker.com/au/services/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/",
                                            "anchor_text": "View all"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Airtasker Limited 2011-2026 \u00a9, All rights reserved",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Airtasker Limited 2011-2026 \u00a9, All rights reserved",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Existing Members",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Popular Categories",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Popular Locations",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Find experienced local roofers in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Fill in a short form and get free quotes from local roofers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Great rating - 4.2/5 (11114+ reviews)",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get roofing contractors near me today",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Up to 50% cheaper than franchise dealers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No job too big or small",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Same day or next day service at no extra cost",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2026 or anything else",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free insurance coverage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Secure cashless payments",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Best rated roofers near me",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\" Joshua has been very helpful, professional and honest. Completed the task super fast and his communication is 10 out o... \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Great work, good attention to detail and nice guy \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Quick response and effectively completed the task \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Came as agreed neat and tidy As it\u2019s a roof repair put faith in his hands that it\u2019s fixed and he seems to be very exper... \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Piotre did a very good job for me. He is very professional and kind \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Good job all done great \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Great to deal with, work was excellent \"",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Joshua M",
                                        "url": "https://www.airtasker.com/users/ae475ccc94a0-p-30964211/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/ae475ccc94a0-p-30964211/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Joshua  M"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Redfern NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/redfern-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/redfern-nsw/",
                                                "anchor_text": "Redfern NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Neil P",
                                        "url": "https://www.airtasker.com/users/7c4e10276b29-p-27905835/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/7c4e10276b29-p-27905835/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Neil P"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Maroubra NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/maroubra-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/maroubra-nsw/",
                                                "anchor_text": "Maroubra NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lovepreet singh L",
                                        "url": "https://www.airtasker.com/users/b5934ba63556-p-17876571/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/b5934ba63556-p-17876571/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Lovepreet singh L"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Blacktown NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Joel D",
                                        "url": "https://www.airtasker.com/users/joel-d-26511288/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/joel-d-26511288/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Joel D"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St James NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/st-james-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/st-james-nsw/",
                                                "anchor_text": "St James NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Piotr A",
                                        "url": "https://www.airtasker.com/users/e6f2c03380a9-p-22866860/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/e6f2c03380a9-p-22866860/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Piotr A"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pearl Beach NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Police Check",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hong N",
                                        "url": "https://www.airtasker.com/users/jason-n-54103/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/jason-n-54103/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Hong N"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Moorebank NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Punctual, quality work \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Payment Method Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Christopher M",
                                        "url": "https://www.airtasker.com/users/christopher-m-5184108/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/christopher-m-5184108/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Christopher M"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "East Sydney NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/east-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/east-sydney-nsw/",
                                                "anchor_text": "East Sydney NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jarrod E",
                                        "url": "https://www.airtasker.com/users/jarrod-e-18181895/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/jarrod-e-18181895/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Jarrod E"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hornsby NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/hornsby-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/hornsby-nsw/",
                                                "anchor_text": "Hornsby NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing reviews in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Absolutely would hire Adam again. Friendly, professional and got the job done quickly.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clean Gutters - 2 story house",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jarrod did a great job for us. We will use him again next time. Thanks again.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Joshua went above and beyond the task set - also identified some potential roof leaks and sealed them. Very happy with the work and would recommend to anyone!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Remove guy wire from rooftop chimney + clean skylight",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Prompt, friendly and quick turn around. Would 100% use again.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Adam is very knowledgeable and just a really nice guy. Great communication, did a great job, and gave us practical advice",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clean gutters, remove garden debris/leaves,",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fantastic job. He turned up on the day, worked out what the problem was and fixed it... on a Sunday! Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Find leak in Colorbond roof flashing and fix",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Clean gutter",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get it done",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Choose the right person for your task and get it done.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get it done now. Pay later.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repay in 4 fortnightly instalments",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Available on payments up to $1,500",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "No interest",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Statistics from the most recent tasks on Airtasker over the last 4 years.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Airtasker has over 10 roofers in Camperdown NSW, with an average rating of 5.0 stars from 8 reviews. Get in touch with roofers such as Joshua M, Neil P, and Lovepreet singh L today to get a wide variety of Roofing jobs done.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We need an experienced pest/bird control professional to remove pigeons from a warehouse in Camperdown. The space has industrial-height ceilings and is shared by multiple users. Pigeons are inside, likely accessing via high and low-level openings or loading areas. There\u2019s roof work scheduled soon, so entry points may change. Looking for a humane, legal solution fully compliant with NSW regulations. Expected scope includes: safe removal of pigeons, inspection to identify all access points, recommendations or installation of deterrents/proofing (tall machinery access not available), and clear ongoing prevention advice. Must have proven commercial/warehouse bird control experience, own equipment, and knowledge of local regulations. Hygiene and disruption are key concerns. Warehouse operations can be paused if needed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Removal of guy wire from chimney on roof. The wire has come loose from its anchor point on the roof and the free end is swinging and banging against the chimney (picture 1). Require full removal of wire. Must have own ladder/ tools. Also require the exterior pane of an adjacent velux skylight window cleaned as there appears to be lichen growth on the outside. (Picture 2 taken from interior)\nRoof near chimney is flat and easy to access. Skylight is on pitched roof section and slightly higher up - it is difficult to photograph this from the outside as this would require climbing on the roof.\nIdeally available middays 12-2pm from Monday next week (8.12).",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Joshua went above and beyond the task set - also identified some potential roof leaks and sealed them. Very happy with the work and would recommend to anyone!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Weld aluminium, steel mesh or other appropriate light weight, non-rusting material to trailer rooftop perimeter so we can transport items on the roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I have a few speakers to install in the roof and an led panel tv system to be installed as well.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I need leaves removed from roof and top of gutters, branches cut from tree overhanging carport\nType of gardening: Other\nSize of garden: 50m\u00b2-100m\u00b2\nHas green waste bin: Yes",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Small back yard needs leaves blown down and removed, gutter cleaned and leaves removed and pavers cleaned. Have a green bin.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Job 1 - Remove metal roof from second floor of townhouse\n- Supply and install new roof (48 Colorbond 700 Clip lock roof sheeting with all new brackets - 6 metres by 5 metres)\n-Install 6m x 5m of 100MM wool foil insulation blanket including large side and rear flash.\n-Install new large insulated flash cut into wall - seal all holes and flash around vertical A/C duct - 6 metres\nJob 2\n-Remove flashing on second floor townhouse roof\n- Supply and install larger insulated flashing - 6 metres\n- Install new large insulated flash cut into brick wall in colorbond - 6 metres\nPlease quote for both jobs. Please also indicate quote if new woolfoil insulation is not installed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I have a leak at or near the edge of my Colorbond roof. My best guess is the flashing is sitting up. I want someone to find the point of water entry and fill the gap or make a simple repair. It's a single story Federation house with a 10 year old Colorbond roof. I want it fixed today because it's going to rain this week. There is rear lane access.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fantastic job. He turned up on the day, worked out what the problem was and fixed it... on a Sunday! Highly recommended.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clean gutters on a three storey townhouse. There are metal grills over the gutters which will need to be removed prior to cleaning and then reinstalled after cleaning",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Small leak probably from flashing on steel roof still in good condition single story",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "small leak occurred during downpour on weekend, will soon add picture of what could be the source. I put Weds 10th as due date but can be flexible, just like it done as soon as possible",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Check for leaks , repair leak in roof, clean gutters for single storey terrace, create a replacement individual permanent awning which is not joined with neighbour . Currently, awning is joined with neighbour.\nCheck leaks , clean gutters, fill very large vertical gap with waterproofing material or roof silicon in external walls under roof on double storey terrace.\n-\nDue date: Before Wednesday, 15 March 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whenever there is heavy rain, water leak through top of front hse window. It could be leakage at inner edge of roofing. Maybe need silicone to seal the leakage. Need a ladder to climb up. Thus is a single storey house.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Remove current roof bars and install Yakima Lock and Load Roof Platform and Tracks\n-\nDue date: Needs to be done on Monday, 29 January 2024",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Handyman services\n- Supply and replace a dozen or so timbre decking planks (ironbark)\n- Trim 4m high hedge (can supply hedge trimmer but tradie will need own ladder)\n- Clear gutters (tradie will need own ladder)\n- Help replace part of cabinetry in laundry -\nDue date: Before Friday, 15 December 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "This is a terrace home in 43-57 Mallet Street Camperdown. The Bathroom is supposedly venting via openable skylight window. Due to leakage, the strata sealed them off. Due to the profile of the roof & ceiling, we need help with roof cowl installation and we will do the inside grille ourselves. We are thinking of a dia.150mm roof cowl. However, please advise the appropriate model & size of this cowl. -\nDue date: Flexible",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have a leak in our roof along a join between a polycarbonate skylight and the standard corrugated metal. Price dependent on what needs to be done!\n-\nDue date: Before Sunday, 23 July 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "-dont have off street parking\n-roof lining can be reused\n-\nDue date: Flexible",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Need someone to clean the Gutter on the roof. -\nDue date: Needs to be done on Monday, 24 April 2023",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jarrod did a great job for us. We will use him again next time. Thanks again.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "repair roof lining Peugeot 407, 2007- no DVD in roof\n-\nDue date: Flexible",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Camperdown NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Last updated on 10th Jan 2026 10:54am",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Home /",
                                        "url": "https://www.airtasker.com/au/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/",
                                                "anchor_text": "Home"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Services /",
                                        "url": "https://www.airtasker.com/au/services/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/",
                                                "anchor_text": "Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.airtasker.com/au/services/roofing/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "What's the average cost of a roofer in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "What's the average cost of a roofer in Camperdown NSW",
                                        "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                                "anchor_text": "What's the average cost of a roofer in Camperdown NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "$200 - $310",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Average reviews for Roofing Services in Camperdown NSW",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "based on 8 reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Post your task",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tell us what you need, it's FREE to post.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Review offers",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Get offers from trusted Taskers and view profiles.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "12+",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tasks successfully completed",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "2",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Average amount of offers per task",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "11",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "mins",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Average time to receive offers",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Services near me",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Balcony Cleaning near me",
                                        "url": "https://www.airtasker.com/au/services/balcony-cleaning/camperdown-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/balcony-cleaning/camperdown-nsw/",
                                                "anchor_text": "Balcony Cleaning near me"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Waterproofing near me",
                                        "url": "https://www.airtasker.com/au/services/waterproofing/camperdown-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/waterproofing/camperdown-nsw/",
                                                "anchor_text": "Waterproofing near me"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Related Locations",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Glebe NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/glebe-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/glebe-nsw/",
                                                "anchor_text": "Glebe NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Taylor Square",
                                        "url": "https://www.airtasker.com/au/services/roofing/taylor-square-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/taylor-square-nsw/",
                                                "anchor_text": "Taylor Square"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "South Sydney Municipality",
                                        "url": "https://www.airtasker.com/au/services/roofing/south-sydney-municipality-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/south-sydney-municipality-nsw/",
                                                "anchor_text": "South Sydney Municipality"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydenham NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/sydenham-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sydenham-nsw/",
                                                "anchor_text": "Sydenham NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Glebe Point",
                                        "url": "https://www.airtasker.com/au/services/roofing/glebe-point-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/glebe-point-nsw/",
                                                "anchor_text": "Glebe Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mid North Coast",
                                        "url": "https://www.airtasker.com/au/services/roofing/mid-north-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/mid-north-coast/",
                                                "anchor_text": "Mid North Coast"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "HMAS Kuttabul",
                                        "url": "https://www.airtasker.com/au/services/roofing/hmas-kuttabul-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/hmas-kuttabul-nsw/",
                                                "anchor_text": "HMAS Kuttabul"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Peters NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/st-peters-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/st-peters-nsw/",
                                                "anchor_text": "St Peters NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Stanmore NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/stanmore-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/stanmore-nsw/",
                                                "anchor_text": "Stanmore NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney Central",
                                        "url": "https://www.airtasker.com/au/services/roofing/sydney-central-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sydney-central-nsw/",
                                                "anchor_text": "Sydney Central"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Missenden Road",
                                        "url": "https://www.airtasker.com/au/services/roofing/missenden-road-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/missenden-road-nsw/",
                                                "anchor_text": "Missenden Road"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Outer South West Sydney",
                                        "url": "https://www.airtasker.com/au/services/roofing/outer-south-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/outer-south-west-sydney/",
                                                "anchor_text": "Outer South West Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Newtown NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/newtown-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/newtown-nsw/",
                                                "anchor_text": "Newtown NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney South",
                                        "url": "https://www.airtasker.com/au/services/roofing/sydney-south-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sydney-south-nsw/",
                                                "anchor_text": "Sydney South"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rosebery NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/rosebery-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/rosebery-nsw/",
                                                "anchor_text": "Rosebery NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strawberry Hills",
                                        "url": "https://www.airtasker.com/au/services/roofing/strawberry-hills-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/strawberry-hills-nsw/",
                                                "anchor_text": "Strawberry Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kings Cross",
                                        "url": "https://www.airtasker.com/au/services/roofing/kings-cross-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/kings-cross-nsw/",
                                                "anchor_text": "Kings Cross"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Potts Point",
                                        "url": "https://www.airtasker.com/au/services/roofing/potts-point-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/potts-point-nsw/",
                                                "anchor_text": "Potts Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "East Sydney",
                                        "url": "https://www.airtasker.com/au/services/roofing/east-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/east-sydney-nsw/",
                                                "anchor_text": "East Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St James NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/st-james-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/st-james-nsw/",
                                                "anchor_text": "St James NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Surry Hills",
                                        "url": "https://www.airtasker.com/au/services/roofing/surry-hills-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/surry-hills-nsw/",
                                                "anchor_text": "Surry Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Australia Square",
                                        "url": "https://www.airtasker.com/au/services/roofing/australia-square-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/australia-square-nsw/",
                                                "anchor_text": "Australia Square"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Marrickville South",
                                        "url": "https://www.airtasker.com/au/services/roofing/marrickville-south-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/marrickville-south-nsw/",
                                                "anchor_text": "Marrickville South"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney City CBD",
                                        "url": "https://www.airtasker.com/au/services/roofing/sydney-city-cbd-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sydney-city-cbd-nsw/",
                                                "anchor_text": "Sydney City CBD"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Circular Quay",
                                        "url": "https://www.airtasker.com/au/services/roofing/circular-quay-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/circular-quay-nsw/",
                                                "anchor_text": "Circular Quay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Forest Lodge",
                                        "url": "https://www.airtasker.com/au/services/roofing/forest-lodge-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/forest-lodge-nsw/",
                                                "anchor_text": "Forest Lodge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Waterloo NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/waterloo-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/waterloo-nsw/",
                                                "anchor_text": "Waterloo NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Suggested reads about Roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Top Locations",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sunshine Coast Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/sunshine-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sunshine-coast/",
                                                "anchor_text": "Sunshine Coast Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Adelaide Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/adelaide/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/adelaide/",
                                                "anchor_text": "Adelaide Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Perth Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/perth/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/perth/",
                                                "anchor_text": "Perth Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hobart Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/hobart/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/hobart/",
                                                "anchor_text": "Hobart Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Central Coast Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/central-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/central-coast/",
                                                "anchor_text": "Central Coast Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wollongong Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/wollongong-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/wollongong-nsw/",
                                                "anchor_text": "Wollongong Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Newcastle Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/newcastle/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/newcastle/",
                                                "anchor_text": "Newcastle Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sydney/",
                                                "anchor_text": "Sydney Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Parramatta Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/parramatta/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/parramatta/",
                                                "anchor_text": "Parramatta Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Ballarat Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/ballarat/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/ballarat/",
                                                "anchor_text": "Ballarat Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Geelong Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/geelong/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/geelong/",
                                                "anchor_text": "Geelong Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Melbourne Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/melbourne/",
                                                "anchor_text": "Melbourne Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canberra Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/canberra/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/canberra/",
                                                "anchor_text": "Canberra Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Brisbane Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/brisbane/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/brisbane/",
                                                "anchor_text": "Brisbane Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gold Coast Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/gold-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/gold-coast/",
                                                "anchor_text": "Gold Coast Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does gutter cleaning cost in Australia?",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does gutter cleaning cost in Australia?",
                                        "url": "https://www.airtasker.com/au/costs/gutter-cleaning/gutter-cleaning-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/gutter-cleaning/gutter-cleaning-cost/",
                                                "anchor_text": "How much does gutter cleaning cost in Australia?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof plumbing cost?",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does roof plumbing cost?",
                                        "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                                "anchor_text": "How much does roof plumbing cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does a new roof cost in Australia?",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does a new roof cost in Australia?",
                                        "url": "https://www.airtasker.com/au/costs/roof-installation/new-roofing-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roof-installation/new-roofing-cost/",
                                                "anchor_text": "How much does a new roof cost in Australia?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does a chimney sweep cost?",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does a chimney sweep cost?",
                                        "url": "https://www.airtasker.com/au/costs/chimney-sweep/chimney-sweeping-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/chimney-sweep/chimney-sweeping-cost/",
                                                "anchor_text": "How much does a chimney sweep cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof cleaning cost?",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does roof cleaning cost?",
                                        "url": "https://www.airtasker.com/au/costs/roof-cleaning/roof-cleaner-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roof-cleaning/roof-cleaner-cost/",
                                                "anchor_text": "How much does roof cleaning cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Solar panel cleaning cost: What it takes to stay efficient in 2025",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Solar panel cleaning cost: What it takes to stay efficient in 2025",
                                        "url": "https://www.airtasker.com/au/costs/solar-panel-cleaning/solar-panel-cleaning-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/solar-panel-cleaning/solar-panel-cleaning-cost/",
                                                "anchor_text": "Solar panel cleaning cost: What it takes to stay efficient in 2025"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does insulation cost?",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does insulation cost?",
                                        "url": "https://www.airtasker.com/au/costs/insulation/insulation-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/insulation/insulation-cost/",
                                                "anchor_text": "How much does insulation cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How to fix a leaking roof",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to fix a leaking roof",
                                        "url": "https://www.airtasker.com/au/guides/roof-leak-repair/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/guides/roof-leak-repair/",
                                                "anchor_text": "How to fix a leaking roof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How to clean your gutters",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to clean your gutters",
                                        "url": "https://www.airtasker.com/au/guides/how-to-clean-gutters/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/guides/how-to-clean-gutters/",
                                                "anchor_text": "How to clean your gutters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How to fix your roof tiles",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to fix your roof tiles",
                                        "url": "https://www.airtasker.com/au/guides/how-to-fix-roof-tiles/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/guides/how-to-fix-roof-tiles/",
                                                "anchor_text": "How to fix your roof tiles"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pigeon removal & proofing needed inside warehouse \u2013 Camperdown",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW 2050, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "31st Dec 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Remove guy wire from rooftop chimney + clean skylight",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "6th Dec 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Weld aluminium/mesh to trailer rooftop perimeter to enclose the space",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW 2050, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "5th Jul 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Install two roof speakers and a led panels tv",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW 2050, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "18th May 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaves removed from roof, branches cut from tree overhanging carport.",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "1st Dec 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaves cleaned up, gutter cleaned, pavers cleaned.",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "University of Sydney NSW 2050, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "23rd Nov 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing repair and replacement",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "25th Jul 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Find leak in Colorbond roof flashing and fix",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "30th Jun 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Clean gutters",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "1st May 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing repair",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "10th Apr 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fix small roof leak",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "9th Apr 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Check, fix roof leaks replace new individual awning & gutter clean.",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "3rd Mar 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking close to edge of front patio roofing (sgl storey hse).",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "16th Feb 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Yakima Roof Rack Install",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "29th Jan 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Replace and repair decking boards; trim hedges; clear gutters",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "27th Nov 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cowl Supply & Installation",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "18th Sep 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof leak repair",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "10th Jun 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Car roof lining repair",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW 2050, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "10th May 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Clean gutter",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "23rd Apr 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Car repair roof lining repair",
                                "main_title": "Find experienced local roofers in Camperdown NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Camperdown NSW 2050, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "6th Jan 2023",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 8,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}