# Type: people_also_search | Rank: 28 | RG: 4
### Raw Row Data:
{
    "rank_group": "4",
    "rank_absolute": "28",
    "service": "roofer",
    "suburb": "Ashfield (NSW)",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}