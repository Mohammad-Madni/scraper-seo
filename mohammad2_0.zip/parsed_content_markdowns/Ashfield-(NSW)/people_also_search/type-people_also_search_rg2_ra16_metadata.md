# Type: people_also_search | Rank: 16 | RG: 2
### Raw Row Data:
{
    "rank_group": "2",
    "rank_absolute": "16",
    "service": "roofer",
    "suburb": "Ashfield (NSW)",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}