# Type: people_also_ask | Rank: 8 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "8",
    "service": "roofer",
    "suburb": "Ashfield (NSW)",
    "title": "",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_ask"
}