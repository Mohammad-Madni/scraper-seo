{
    "id": "01190727-1132-0216-0000-11c2c5cdef21",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0252 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.agraderoofing.com.au/",
        "target": "www.agraderoofing.com.au",
        "start_url": "https://www.agraderoofing.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Ashfield-(NSW)\\organic\\type-organic_rg3_ra7_agraderoofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 0,
            "items": null
        }
    ]
}