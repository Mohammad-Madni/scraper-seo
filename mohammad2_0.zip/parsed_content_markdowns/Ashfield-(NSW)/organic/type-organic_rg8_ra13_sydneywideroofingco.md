{
    "id": "01190727-1132-0216-0000-483cdf58bbd7",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0198 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneywideroofingco.com.au/inner-west/ashfield/",
        "target": "sydneywideroofingco.com.au",
        "start_url": "https://sydneywideroofingco.com.au/inner-west/ashfield/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Ashfield-(NSW)\\organic\\type-organic_rg8_ra13_sydneywideroofingco.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:56 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repair",
                                    "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                            "anchor_text": "Roof Leak Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutters and Downpipes",
                                    "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                            "anchor_text": "Gutters and Downpipes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Tile Pointing and Bedding",
                                    "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                            "anchor_text": "Roof Tile Pointing and Bedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Copper Roofing",
                                    "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/copper-roofing/",
                                            "anchor_text": "Copper Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Slate Roofing",
                                    "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/slate-roofing/",
                                            "anchor_text": "Slate Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Zinc Roofing",
                                    "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/zinc-roofing/",
                                            "anchor_text": "Zinc Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roofing",
                                    "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/heritage-roofing/",
                                            "anchor_text": "Heritage Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs in Randwick NSW",
                                    "url": "https://sydneywideroofingco.com.au/randwick/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/randwick/",
                                            "anchor_text": "Roof Repairs in Randwick NSW"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Georges River",
                                    "url": "https://sydneywideroofingco.com.au/georges-river/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/georges-river/",
                                            "anchor_text": "Georges River"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney Inner West Roof Repairs",
                                    "url": "https://sydneywideroofingco.com.au/inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/inner-west/",
                                            "anchor_text": "Sydney Inner West Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "City of Sydney",
                                    "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/city-of-sydney/",
                                            "anchor_text": "City of Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "GET QUOTE",
                                    "url": "https://sydneywideroofingco.com.au/get-quote/",
                                    "urls": [
                                        {
                                            "url": "https://sydneywideroofingco.com.au/get-quote/",
                                            "anchor_text": "GET QUOTE"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "95 Bellingara Rd, Miranda NSW 2228.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Monday \u2013 Saturday: 7:00 AM \u2013 6:00 PM",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "(02) 8294 4654",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Expert Roof Repair Ashfield",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Ashfield, with its harmonious blend of historic charm and contemporary vibrancy, stands out as one of Sydney\u2019s suburban gems. In this locale, roofing is not just about shelter but is a nod to its proud heritage and forward-thinking community. Sydney Wide Roofing Co, with its vast experience and unparalleled craftsmanship, understands Ashfield\u2019s unique character. Here in Ashfield, a roof symbolizes the perfect marriage of form and function, durability and beauty, past and present.",
                                        "url": "https://maps.app.goo.gl/BotVDKHyVGVqznhy8",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/BotVDKHyVGVqznhy8",
                                                "anchor_text": "Ashfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Premier Roofing Services Tailored for Ashfield",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement in Ashfield",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield homes, like its history, are diverse and layered. Our roof replacement service caters to this eclectic mix, combining modern technologies with timeless techniques. Rejuvenating the skyline of Ashfield, one roof at a time, our solutions ensure protection and aesthetic appeal that resonates with the local spirit.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Installation in Ashfield",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Building anew in Ashfield? Lean on our team\u2019s extensive know-how to provide roofing installations that complement Ashfield\u2019s unique urban fabric. We blend high-quality materials with expert craftsmanship to ensure a roof that is not just functional but also echoes Ashfield\u2019s essence.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leak Repair in Ashfield",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield\u2019s varying weather patterns demand robust roofing solutions. Our dedicated roof leak repair services harness the latest in diagnostic and repair methodologies. Promptly pinpointing vulnerabilities and ensuring surgical precision in repairs, we ensure every home remains a safe haven.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Leak Repair in Ashfield",
                                        "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-leak-repair/",
                                                "anchor_text": "Roof Leak Repair in Ashfield"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs in Ashfield",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From refining visual imperfections to reinforcing structural strength, our Ashfield-centric approach to roof repairs is unmatched. With each project, we ensure that roofs not only retain their initial allure but are also well-equipped to face the tests of time and elements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs in Ashfield",
                                        "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-repair/",
                                                "anchor_text": "Roof Repairs in Ashfield"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration in Ashfield",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield roofs tell tales of time. Our restoration services breathe new life into them. With meticulous cleaning, repair, and finishing touches, we restore roofs to their former glory, ensuring they stand as proud symbols of Ashfield\u2019s ever-evolving story.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration in Ashfield",
                                        "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration in Ashfield"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters and Downpipes in Ashfield",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Effective water management is crucial for Ashfield homes. Our customized solutions for gutters and downpipes ensure efficient drainage, preventing potential water damage and enhancing the longevity of each structure.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutters and Downpipes in Ashfield",
                                        "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/gutters-and-downpipes/",
                                                "anchor_text": "Gutters and Downpipes in Ashfield"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Pointing and Bedding in Ashfield",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield\u2019s roofs, given their exposure to the elements, occasionally require specialized care. Our tile pointing services provide that added layer of strength and aesthetic finesse, ensuring the roofs remain as much a guardian as a crowning jewel.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ashfield\u2019s Top Choice for Roofing Excellence",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A combination of our rich roofing legacy and an innate understanding of Ashfield\u2019s distinctiveness cements our esteemed reputation. Quality, dedication, and unmatched transparency have made us Ashfield\u2019s first choice in roofing solutions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For Ashfield\u2019s premium roofing experience, connect with Sydney Wide Roofing Co:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Address \u2013 [Insert Ashfield address]",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ashfield: A Tapestry of Time",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "From its Indigenous origins to its establishment in the 19th century, Ashfield\u2019s journey is rich and varied. Its transformation from farmlands to a thriving suburb is a testament to its resilience and adaptability.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Architectural Grandeur in Ashfield",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ashfield\u2019s architectural spectrum boasts Victorian and Federation homes alongside modern-day apartments, reflecting its journey through different eras. This architectural harmony makes Ashfield a living museum of structural evolution.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Pratten Park: Ashfield\u2019s Green Oasis",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Nestled in Ashfield, Pratten Park stands as a serene escape from urban hustle. It\u2019s a favorite among locals, offering recreational spaces, sporting facilities, and a touch of nature\u2019s tranquility.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Dive into Ashfield\u2019s Culture",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Beyond its historical and architectural allure, Ashfield is renowned for its culinary scene, particularly its Asian eateries, making it a gastronomic hotspot. Local shops, vibrant festivals, and community events further enrich its cultural tapestry, inviting residents and visitors to experience its multifaceted charm.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Tile Pointing and Bedding in Ashfield",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-pointing-bedding/",
                                                "anchor_text": "Tile Pointing and Bedding in Ashfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Connect With Us",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Phone \u2013 (02) 8294 4654",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email \u2013 [email\u00a0protected]",
                                        "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Website \u2013 https://sydneywideroofingco.com.au/",
                                        "url": "https://sydneywideroofingco.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/",
                                                "anchor_text": "https://sydneywideroofingco.com.au/"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are conveniently located next to Ashfields best attractions such as the Sydney Private Hospital.",
                                        "url": "https://goo.gl/maps/2aNEg1Hr9obYXnrg6",
                                        "urls": [
                                            {
                                                "url": "https://goo.gl/maps/2aNEg1Hr9obYXnrg6",
                                                "anchor_text": "Ashfields"
                                            },
                                            {
                                                "url": "https://goo.gl/maps/AerBPXm9C2soG6Gh6",
                                                "anchor_text": "Sydney Private Hospital"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Highly Rated Roofing Company servicing Ashfield, Inner West",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You can contact Sydney Wide Roofing Co at the following:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Servicing Ashfield and all of the Inner West",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For all your roofing needs, reach out to us today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Contact Information",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Phone \u2013 ( 02) 8806 1382",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email \u2013 [email\u00a0protected]",
                                        "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Website \u2013 https://sydneywideroofingco.com.au/",
                                        "url": "https://sydneywideroofingco.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/",
                                                "anchor_text": "https://sydneywideroofingco.com.au/"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Ashfield Roofing Service",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Portfolio",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Burraneer Bay Residential",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Burraneer Bay Residential",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/burraneer-bay-roofing-project/",
                                                "anchor_text": "Burraneer Bay Residential"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing Project Sydney",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing Project Sydney",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/slate-roofing-project-sydney/",
                                                "anchor_text": "Slate Roofing Project Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Project Eastern Suburbs",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Project Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/portfolio-items/metal-roofing-project-eastern-suburbs/",
                                                "anchor_text": "Metal Roofing Project Eastern Suburbs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Handy Tips About Roofing",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-proper-roof-repair/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leaks",
                                        "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/how-to-fix-a-roof-leak/",
                                                "anchor_text": "Roof Leaks"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/time-for-roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-roofing",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Re-roofing",
                                        "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-for-re-roofing-roof-installs/",
                                                "anchor_text": "Re-roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutters & Downpipes",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gutters & Downpipes",
                                        "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/tips-on-gutter-down-pipe-repair/",
                                                "anchor_text": "Gutters & Downpipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling",
                                        "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/roof-tile-repair/",
                                                "anchor_text": "Roof Tiling"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations We Service",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sutherland Shire",
                                        "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/sutherland-shire/",
                                                "anchor_text": "Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eastern Suburbs",
                                        "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/eastern-suburbs/",
                                                "anchor_text": "Eastern Suburbs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georges River",
                                        "url": "https://sydneywideroofingco.com.au/georges-river/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/georges-river/",
                                                "anchor_text": "Georges River"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Inner West",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/",
                                                "anchor_text": "Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Northern Beaches",
                                        "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/northern-beaches/",
                                                "anchor_text": "Northern Beaches"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "North Sydney",
                                        "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/north-sydney/",
                                                "anchor_text": "North Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Heritage Roofing",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Heritage Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/heritage-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/heritage-roofing/",
                                                "anchor_text": "Heritage Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Copper Roofing",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Copper Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/copper-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/copper-roofing/",
                                                "anchor_text": "Copper Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate Roofing",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Slate Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/slate-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/slate-roofing/",
                                                "anchor_text": "Slate Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Zinc Roofing",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Zinc Roofing",
                                        "url": "https://sydneywideroofingco.com.au/services/zinc-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/services/zinc-roofing/",
                                                "anchor_text": "Zinc Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Locations in the Inner West Council We Service",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Russell Lea",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/russell-lea/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/russell-lea/",
                                                "anchor_text": "Russell Lea"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/five-dock/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/five-dock/",
                                                "anchor_text": "Five Dock"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rodd Point",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/rodd-point/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/rodd-point/",
                                                "anchor_text": "Rodd Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/summer-hill/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/summer-hill/",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canada Bay",
                                        "url": "https://sydneywideroofingco.com.au/inner-west/canada-bay/",
                                        "urls": [
                                            {
                                                "url": "https://sydneywideroofingco.com.au/inner-west/canada-bay/",
                                                "anchor_text": "Canada Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Building Inspiring Roofs",
                                "main_title": "Ashfield Roofing Service",
                                "author": "https://www.facebook.com/sydneywideroofingco/",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Only takes a few seconds!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "61282944654",
                                "+61282944654",
                                "+61 (02) 8294 4654"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}