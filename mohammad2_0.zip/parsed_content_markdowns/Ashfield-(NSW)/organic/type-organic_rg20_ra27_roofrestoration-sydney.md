{
    "id": "01190727-1132-0216-0000-354fcbb16c6b",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0251 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrestoration-sydney.com/locations/canterbury-bankstown/expert-roofing-services-in-ashfield/",
        "target": "roofrestoration-sydney.com",
        "start_url": "https://roofrestoration-sydney.com/locations/canterbury-bankstown/expert-roofing-services-in-ashfield/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Ashfield-(NSW)\\organic\\type-organic_rg20_ra27_roofrestoration-sydney.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:57 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Whether it\u2019s a minor leak in Bondi or a full tile roof replacement in Parramatta, our local presence means we\u2019re on-site faster and more in tune with NSW building regulations.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ROOF RESTORATIONS & REPLACEMENTS SYDNEY",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Open 24 hours a day, 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a92026\u00a0Roof Restorations & Replacements Sydney",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Onslow Street",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Rose Bay NSW 2029",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Phone: (02) 8310 4161",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email: [email\u00a0protected]",
                                    "url": "https://roofrestoration-sydney.com/cdn-cgi/l/email-protection",
                                    "urls": [
                                        {
                                            "url": "https://roofrestoration-sydney.com/cdn-cgi/l/email-protection",
                                            "anchor_text": "[email\u00a0protected]"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofrestoration-sydney.com/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestoration-sydney.com/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofrestoration-sydney.com/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestoration-sydney.com/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://roofrestoration-sydney.com/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestoration-sydney.com/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://roofrestoration-sydney.com/terms-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://roofrestoration-sydney.com/terms-conditions/",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Professional Roofing Services in Ashfield",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roof Restorations & Replacements Sydney, we understand that Ashfield boasts a mix of Federation-style homes with classic terracotta tiles and newer metal-clad buildings. Our team specialises in roof restorations and roof replacements tailored to the suburb\u2019s unique architectural character. Whether it\u2019s a heritage cottage in Ashfield\u2019s leafy streets or a modern commercial fit-out, our spartan approach cuts out the fluff while delivering solid, long-lasting solutions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Common roofing issues in Ashfield often stem from the area\u2019s humid climate and mature tree coverage along Parramatta Road:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Cracked or slipped terracotta tiles after heavy rain",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Rust and corrosion on older metal roofs in shaded backstreets",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Blocked gutters leading to stormwater overflow and potential structural damage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With over a decade of local experience, our skilled professionals navigate Ashfield Council\u2019s regulations for heritage-listed properties and new installations alike. By combining premium materials with precise workmanship, we ensure every roof upgrade not only meets Australian Standards but also enhances your property\u2019s value and street appeal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tailored Roof Solutions for Ashfield Homes & Businesses",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roof Restorations & Replacements Sydney, we\u2019ve honed our craft to meet Ashfield\u2019s diverse roofing needs. From classic Federation-style terracotta tiles to sleek metal roofing on modern commercial units, our Sydney-based team covers every aspect of roof restorations, replacements and maintenance. Whether it\u2019s a heritage roof requiring gentle repointing or a brand-new metal roof installation to suit the suburb\u2019s climate, our expertise ensures durable, weather-proof results that respect Ashfield Council\u2019s heritage guidelines.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our streamlined process keeps things spartan yet thorough, delivering consistent quality with minimal fuss:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Comprehensive inspection : We assess tile integrity, flashings and gutter flow to pinpoint problem areas.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Materials selection : Premium color-bond steel, high-grade terracotta tiles or custom ridge capping \u2013 tailored to your property\u2019s style.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Precision installation : Licensed roof plumbers and qualified tilers execute each step, from underlay (sarking) to final seal.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Quality check & cleanup : Post-job inspection guarantees compliance with Australian Standards, and we leave your site spotless.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "By combining local know-how with top-tier materials, we safeguard Ashfield homes and businesses against leaks, corrosion and storm damage. Our goal isn\u2019t just a quick fix but a long-lasting roof solution that enhances both functionality and street appeal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Our Roofing Services in Ashfield?",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to Ashfield roofing, few match the blend of local know-how and spartan efficiency that Roof Restorations & Replacements Sydney delivers. Our team understands the suburb\u2019s mix of Federation-style terraces and modern townhouses\u2014and we tailor each job to tackle humidity, fallen foliage and storm-prone weather head-on. While some providers cut costs on materials or skip critical inspections, we insist on premium Colorbond steel, high-grade terracotta tiles and a rigorous final quality check.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local expertise under Ashfield Council\u2019s heritage guidelines ensures every job is compliant.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent, itemised quotes eliminate surprise costs\u2014what you see is what you pay.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast, fuss-free turnaround keeps disruption to a minimum on busy streets like Parramatta Road.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "On top of our no-nonsense approach, every roof restoration or replacement comes with a comprehensive workmanship warranty plus manufacturer guarantees on all materials. That means if a ridge cap loosens or a flashing needs tweaking, we\u2019re back out to sort it\u2014no questions asked. In a crowded Canterbury-Bankstown market, our blend of durability, value and honest service sets us firmly ahead of the pack.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Value-Driven Roofing in Ashfield",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Investing in a long-lasting roof shouldn\u2019t break the bank in Ashfield. At Roof Restorations & Replacements Sydney, our approach to roofing cost balances premium materials\u2014like Colorbond steel and high-grade terracotta\u2014with spartan, efficient labour. That means you get a durable, weather-proof solution built to withstand Sydney\u2019s humidity and storm cycles without hidden mark-ups or surprise fees.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Several factors shape your final quote:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Roof size & complexity : The pitch, number of valleys and access requirements",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Material selection : From heritage-style terracotta tiles to modern metal roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Compliance needs : Ashfield Council heritage approvals add specialist labour",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Existing roof condition : Repairs vs full replacement can alter labour and disposal costs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our transparent, itemised pricing ensures you know exactly where every dollar goes. Premium workmanship warranties and manufacturer guarantees are baked into every quote, so you\u2019re covered long after the crew packs up. Whether it\u2019s a minor tile replacement or a complete roof overhaul, Ashfield residents can rely on clear, value-driven estimates that respect both quality and budget.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Upholding Premier Roof Standards in Ashfield",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roof Restorations & Replacements Sydney, our commitment to quality isn\u2019t just a slogan\u2014it\u2019s baked into every project across Ashfield. We navigate Ashfield Council\u2019s heritage guidelines, ensuring Federation-style terraces and modern townhouses alike receive work that meets Australian Standards. From meticulous pre-work inspections through to final sign-off, our team uses only premium materials \u2014Colorbond steel, high-grade terracotta tiles and industry-approved underlays\u2014to deliver weather-proof, long-lasting roofs that enhance both durability and curb appeal.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our spartan yet thorough approach keeps the focus on what matters: flawless workmanship and customer satisfaction. Every roof restoration or replacement benefits from:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Rigorous on-site quality checks at each stage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Full compliance with local heritage and building regulations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Comprehensive workmanship warranties backed by manufacturer guarantees",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With over a decade of experience under the stewardship of Riley Alcorn, our licensed roof plumbers and qualified tilers tackle Ashfield\u2019s humid climate, storm seasons and tree-lined streets without compromise. Whether it\u2019s a minor tile repair or a full metal-roof overhaul, we stand by our promise: roofs done right, right here in Ashfield.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Key Advantages of Roofing Services in Ashfield",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "After a decade of serving the Canterbury-Bankstown area, Roof Restorations & Replacements Sydney has fine-tuned every step to deliver durable, weather-proof roofs for Ashfield homes and businesses. From tackling the suburb\u2019s humid climate to navigating Ashfield Council\u2019s heritage guidelines, our spartan approach ensures each project ticks all the boxes\u2014no hidden costs, no fluff.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Below are the core benefits you gain when choosing our team for roof restorations or replacements in Ashfield:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Local expertise : Deep knowledge of Parramatta Road conditions, mature tree cover and common tile or metal roofing issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Premium materials : High-grade terracotta tiles, Colorbond steel and industry-approved underlays for long-lasting performance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Transparent pricing : Itemised quotes that respect your budget and clarify every cost component.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Rigorous warranties : Comprehensive workmanship guarantees plus manufacturer cover on all materials.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Efficient, spartan process : Streamlined inspections, precise installations and final quality checks\u2014all with minimal disruption.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether it\u2019s a quick repointing on a Federation-style roof or a full metal roof overhaul, our no-nonsense service blends quality, value and local know-how to keep your property in top shape.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions for Roofing Services in Ashfield",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We\u2019ve compiled some of the most common queries about Roofing Services in Ashfield to help you understand our approach and what to expect when working with Roof Restorations & Replacements Sydney.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How often should I schedule a roof inspection in Ashfield?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ashfield\u2019s humid climate and tree-lined streets can accelerate wear. We recommend a professional roof inspection at least once a year, ideally before winter. Regular checks catch minor issues\u2014like slipped tiles or blocked gutters\u2014before they become costly headaches.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Which roofing materials work best in Ashfield\u2019s conditions?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ashfield homes range from Federation terraces to modern townhouses, so material choice depends on both style and durability. Our top picks include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Terracotta tiles for heritage charm and heat resistance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Colorbond steel for robust corrosion protection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 High-grade underlay to combat damp and wind-driven rain",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Can you handle heritage-listed roofs in Ashfield?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. We\u2019re well versed in Ashfield Council heritage regulations and carry out restorations that respect original profiles and colours. From gentle repointing of ridge caps to sourcing matching terracotta tiles, our team balances authenticity with modern performance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What factors influence the cost of roofing services in Ashfield?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Several elements shape your quote:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Roof size, pitch and access",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Material selection (tile, metal, custom ridge capping)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Heritage compliance or council approvals",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Scope of work (repair vs full replacement)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How long does a roof restoration or replacement take?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Timelines vary based on complexity and weather, but most Ashfield projects wrap up within 3\u20137 days. We streamline our spartan process\u2014inspection, material prep, installation and final quality check\u2014to minimise disruption while delivering a durable, weather-proof finish.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Expert Roofing Services in Ashfield",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Take the Next Step for Your Ashfield Roof",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roof Restorations & Replacements Sydney, our Ashfield crew is geared up to deliver durable, weather-proof roofs that comply with local heritage requirements and stand up to Sydney\u2019s humid climate. With 24/7 availability and a decade of experience under Riley Alcorn\u2019s watch, we\u2019ve streamlined everything from minor tile repairs to full metal-roof replacements\u2014no fluff, just solid results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Here\u2019s what you can expect when you\u2019re ready to kick off your Ashfield roofing project:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Round-the-clock support to handle urgent leaks or unexpected storm damage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Free, no-obligation inspection to pinpoint issues and advise on the best materials",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Transparent, itemised quotes so you know exactly where your investment goes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Comprehensive warranties that cover both workmanship and top-tier materials",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fancy a no-obligation chat about your roof? Ring (02) 8310 4161 or drop a line at [email\u00a0protected]. Our team is here to ensure your Ashfield property gets the robust, long-lasting roof it deserves.",
                                        "url": "https://roofrestoration-sydney.com/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Service Locations",
                                "main_title": "Expert Roofing Services in Ashfield",
                                "author": "Roof Restorations & Replacements Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Bellevue Hill",
                                        "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-bellevue-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-bellevue-hill/",
                                                "anchor_text": "Bellevue Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bondi Beach",
                                        "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-bondi-beach/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-bondi-beach/",
                                                "anchor_text": "Bondi Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bondi Junction",
                                        "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-bondi-junction/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-bondi-junction/",
                                                "anchor_text": "Bondi Junction"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Darling Point",
                                        "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-darling-point/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-darling-point/",
                                                "anchor_text": "Darling Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Double Bay",
                                        "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-double-bay/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-double-bay/",
                                                "anchor_text": "Double Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Point Piper",
                                        "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-point-piper/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/eastern-suburbs/expert-roofing-services-in-point-piper/",
                                                "anchor_text": "Point Piper"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Baulkham Hills",
                                        "url": "https://roofrestoration-sydney.com/locations/hills-district/expert-roofing-services-in-baulkham-hills/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/hills-district/expert-roofing-services-in-baulkham-hills/",
                                                "anchor_text": "Baulkham Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Beaumont Hills",
                                        "url": "https://roofrestoration-sydney.com/locations/hills-district/expert-roofing-services-in-beaumont-hills/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/hills-district/expert-roofing-services-in-beaumont-hills/",
                                                "anchor_text": "Beaumont Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bella Vista",
                                        "url": "https://roofrestoration-sydney.com/locations/hills-district/expert-roofing-services-in-bella-vista/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/hills-district/expert-roofing-services-in-bella-vista/",
                                                "anchor_text": "Bella Vista"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Castle Hill",
                                        "url": "https://roofrestoration-sydney.com/locations/hills-district/expert-roofing-services-in-castle-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/hills-district/expert-roofing-services-in-castle-hill/",
                                                "anchor_text": "Castle Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Castle Cove",
                                        "url": "https://roofrestoration-sydney.com/locations/lower-north-shore/expert-roofing-services-in-castle-cove/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/lower-north-shore/expert-roofing-services-in-castle-cove/",
                                                "anchor_text": "Castle Cove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Sydney",
                                        "url": "https://roofrestoration-sydney.com/locations/lower-north-shore/expert-roofing-services-in-north-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/lower-north-shore/expert-roofing-services-in-north-sydney/",
                                                "anchor_text": "North Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Blair Athol",
                                        "url": "https://roofrestoration-sydney.com/locations/macarthur-region/expert-roofing-services-in-blair-athol/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/macarthur-region/expert-roofing-services-in-blair-athol/",
                                                "anchor_text": "Blair Athol"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Allambie Heights",
                                        "url": "https://roofrestoration-sydney.com/locations/northern-beaches/expert-roofing-services-in-allambie-heights/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/northern-beaches/expert-roofing-services-in-allambie-heights/",
                                                "anchor_text": "Allambie Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Avalon Beach",
                                        "url": "https://roofrestoration-sydney.com/locations/northern-beaches/expert-roofing-services-in-avalon-beach/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/northern-beaches/expert-roofing-services-in-avalon-beach/",
                                                "anchor_text": "Avalon Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Balgowlah Heights",
                                        "url": "https://roofrestoration-sydney.com/locations/northern-beaches/expert-roofing-services-in-balgowlah-heights/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/northern-beaches/expert-roofing-services-in-balgowlah-heights/",
                                                "anchor_text": "Balgowlah Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hunters Hill",
                                        "url": "https://roofrestoration-sydney.com/locations/northern-beaches/expert-roofing-services-in-hunters-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/northern-beaches/expert-roofing-services-in-hunters-hill/",
                                                "anchor_text": "Hunters Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Palm Beach",
                                        "url": "https://roofrestoration-sydney.com/locations/northern-beaches/expert-roofing-services-in-palm-beach/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/northern-beaches/expert-roofing-services-in-palm-beach/",
                                                "anchor_text": "Palm Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dundas Valley",
                                        "url": "https://roofrestoration-sydney.com/locations/parramatta-region/expert-roofing-services-in-dundas-valley/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/parramatta-region/expert-roofing-services-in-dundas-valley/",
                                                "anchor_text": "Dundas Valley"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bass Hill",
                                        "url": "https://roofrestoration-sydney.com/locations/south-west-sydney/expert-roofing-services-in-bass-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/south-west-sydney/expert-roofing-services-in-bass-hill/",
                                                "anchor_text": "Bass Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Chester Hill",
                                        "url": "https://roofrestoration-sydney.com/locations/south-west-sydney/expert-roofing-services-in-chester-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofrestoration-sydney.com/locations/south-west-sydney/expert-roofing-services-in-chester-hill/",
                                                "anchor_text": "Chester Hill"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "(02) 8310 4161",
                                "+61283104161"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}