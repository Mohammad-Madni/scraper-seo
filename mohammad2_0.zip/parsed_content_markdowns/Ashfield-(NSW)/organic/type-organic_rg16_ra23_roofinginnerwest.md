{
    "id": "01190727-1132-0216-0000-9aadfe2a6a4a",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0149 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-ashfield/",
        "target": "roofinginnerwest.com.au",
        "start_url": "https://roofinginnerwest.com.au/locations/roofing-services-in-ashfield/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Ashfield-(NSW)\\organic\\type-organic_rg16_ra23_roofinginnerwest.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:57 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Elevate Your Property with Zenith Roof Restorations & Replacements Inner West",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ROOFING INNER WEST",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Inner West, NSW 2204",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Open 24 hours a day, 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a92026\u00a0Roofing Inner West",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Phone: (02) 9167 0228",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email: [email\u00a0protected]",
                                    "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                            "anchor_text": "[email\u00a0protected]"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://roofinginnerwest.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://roofinginnerwest.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://roofinginnerwest.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terms & Conditions",
                                    "url": "https://roofinginnerwest.com.au/terms-conditions/",
                                    "urls": [
                                        {
                                            "url": "https://roofinginnerwest.com.au/terms-conditions/",
                                            "anchor_text": "Terms & Conditions"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Our Specialised Roofing Services for Ashfield Homes and Businesses",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Residents across Ashfield and the broader Sydney Inner West deserve roofs that stand up to the region\u2019s weather. At Roofing Inner West, we deliver durable, weatherproof roofing with a focus on longevity and value. Whether it\u2019s traditional tile roofs or modern metal systems, our team handles restorations, replacements, and refreshes to keep your property protected and looking sharp.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With years of local experience, we understand the unique needs of Ashfield properties \u2014 from heritage homes to busy commercial sites. We offer a comprehensive range of services: roof restorations, tile roof replacements, metal roof installations, plus essential details like flashing, sarking, and guttering. Our workmanship uses premium materials and complies with NSW building codes and local guidelines to preserve character where needed.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our core capabilities in Ashfield include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Tile Roofs : repairs, replacements, and restorations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Metal Roofing : new roofs, coatings, and repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Heritage Roofs : respectful restorations that meet local guidelines",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "To see how we tailor solutions for Ashfield, explore our Services page. You can also reach us at [email\u00a0protected] for enquiries.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services page"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Specialised Roofing Services for Ashfield Homes and Businesses",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Residents across Ashfield and the broader Sydney Inner West trust Roofing Inner West for durable, weatherproof roofs. We specialise in roof restorations for all roof types, with a focus on longevity and value. Our local experience covers heritage homes and busy commercial sites, ensuring solutions that protect your property while respecting character where it matters.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our core capabilities in Ashfield include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Tile Roofs : repairs, replacements, and restorations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Metal Roofing : new roofs, coatings, and repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Heritage Roofs : restorations that meet local guidelines",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We prioritise premium materials and compliance with NSW building codes and Inner West council guidelines to keep your roof performing well for years to come. For more detail on options, explore our Services page and reach out if you have questions. For enquiries, email [email\u00a0protected].",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services page"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Roofing Inner West in Ashfield",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Residents across Ashfield and the broader Sydney Inner West rely on Roofing Inner West for roofs that endure our climate. With deep local knowledge, Riley Alcorn and the team tailor solutions for heritage homes and busy commercial sites, keeping properties watertight and compliant with NSW building codes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local, Ashfield-first expertise that understands NSW regulations and Inner West guidelines",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Premium materials and meticulous workmanship for tile and metal roofs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Heritage-conscious restorations that protect character while meeting council requirements",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent communication and a straightforward, efficient process",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our service promise is simple: durable roofs, honest scheduling, and value that protects your property\u2019s long-term worth. Explore the breadth of options on our Services page.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Understanding Roofing Costs in Ashfield: Value Before Price",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roofing Inner West, pricing is driven by what your project needs. We offer transparent quotes after a thorough inspection of your Ashfield roof. Our focus is on long-term durability and quality materials, which can reduce ongoing maintenance and future costs. Ashfield properties range from heritage terraces to modern commercial spaces, and our pricing recognises local requirements, including NSW building codes and Inner West guidelines.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Several factors influence the cost of a roof job. Here are the key elements we consider when preparing a quote:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Roof type and materials (tile vs metal) and their lifespans",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Current roof condition and whether we\u2019re doing repairs, restoration, or a full replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Access, height, scaffolding needs, and safety requirements",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Heritage considerations and council guidelines for older homes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Warranties, workmanship guarantees, and material warranties",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Although we don\u2019t publish fixed prices here, the value is clear: high\u2011quality work that protects your home or business, plus itemised, honest quotes and predictable timelines. This approach helps you realise the ROI of a solid roof\u2014improved insulation, reduced maintenance, and enhanced curb appeal. For a detailed assessment, our local team can provide a transparent quote after inspecting your Ashfield roof; you can reach us via [email\u00a0protected] or explore our Services page.",
                                        "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Commitment to Quality Roofing Services in Ashfield",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Roofing Inner West, we back our work with a steadfast commitment to quality across Ashfield and the broader Sydney Inner West. Led by Riley Alcorn, our team blends local knowledge with skilled craftsmanship to deliver roof restorations that withstand NSW weather and council guidelines. Whether it\u2019s tile or metal roofs, we aim for durable results for homes and small businesses.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We use premium materials and meticulous workmanship to ensure every job meets NSW building codes and Inner West guidelines. Our approach respects heritage where needed, delivering restorations that preserve character while improving performance, insulation, and longevity. We prioritise safety and minimising disruption to you and your property during works.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent, itemised quotes with no hidden costs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Warranties and workmanship guarantees for long-term peace of mind",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For enquiries, browse our Services page for details, or email us at [email\u00a0protected] with any questions.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services page"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ashfield Roofing Benefits That Stand Up",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Ashfield homeowners and businesses deserve roofs that stand up to NSW weather. At Roofing Inner West, led by Riley Alcorn, we deliver durable, weatherproof roofs for both tile and metal systems across the Inner West. Our work blends premium materials, meticulous workmanship, and local knowledge to protect your property and boost its value.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Here are the key benefits you can expect:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Long\u2011term durability and reliable weather protection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Heritage-conscious solutions that meet NSW guidelines",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Premium materials and meticulous workmanship",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Increased property value and curb appeal",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2013 Transparent warranties and service guarantees",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We tailor solutions to each site, whether it\u2019s a heritage terrace or a modern commercial space in Ashfield. Our services cover restorations, replacements, and ongoing maintenance, all aligned with NSW building codes and Inner West guidelines. Learn more about options on our Services page.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions for Roofing Services in Ashfield",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Here are the FAQs that come up most for roofing in Ashfield and the wider Sydney Inner West. Roofing Inner West, led by Riley Alcorn, specialises in roof restorations for tile and metal roofs on homes and small businesses. If you\u2019ve got questions, you can email [email\u00a0protected] and we\u2019ll help you out.",
                                        "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We service a broad spread of the Inner West\u2014from Annandale to Marrickville and beyond\u2014always aligning with NSW building codes and Inner West guidelines. We also handle heritage-conscious restorations where required, keeping character intact while improving performance. For more details on options, see our Services page.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Kick-Starting Your Ashfield Roofing Project",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Based in the Sydney Inner West, Ashfield clients turn to Roofing Inner West for practical, lasting roof solutions. Led by Riley Alcorn, our team brings genuine local knowledge to tile and metal roofs, heritage considerations, and NSW building guidelines. The starting point is a practical, no-obligation inspection to identify leaks, wear, or insulation gaps, followed by a clear discussion of what matters most to you. For a concise overview of options, see our Services page.",
                                        "url": "https://roofinginnerwest.com.au/services/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/services/",
                                                "anchor_text": "Services page"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "After that, you\u2019ll receive a transparent, itemised quote and a straightforward plan for materials and timing. We prioritise premium materials, careful sequencing, and minimal disruption to your day. We also manage heritage requirements where needed and ensure every job stays compliant with NSW building codes and Inner West guidelines.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent quote and material selection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Scheduling with quality workmanship and warranties",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "From proposal to completion, the process is designed to be easy and predictable. With Roofing Inner West, you\u2019re choosing local expertise that keeps Ashfield roofs watertight and property values strong, while respecting the character of the Inner West.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Inspection and assessment",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get in Touch with Us Today",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "For a comprehensive overview of our services, call us today on (02) 9167 0228. For more information about us, visit our homepage or for more information on our other areas we service, please visit our locations page.",
                                        "url": "https://roofinginnerwest.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/",
                                                "anchor_text": "homepage"
                                            },
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/",
                                                "anchor_text": "locations page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roofing Services in Ashfield",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ashfield Roofing Mastery: Trusted Inner West Solutions",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Service Locations",
                                "main_title": "Roofing Services in Ashfield",
                                "author": "Roofing Inner West",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Balmain East",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-balmain-east/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-balmain-east/",
                                                "anchor_text": "Balmain East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canada Bay",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-canada-bay/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-canada-bay/",
                                                "anchor_text": "Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-croydon-park/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-croydon-park/",
                                                "anchor_text": "Croydon Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-five-dock/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-five-dock/",
                                                "anchor_text": "Five Dock"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Peters",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-st-peters/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-st-peters/",
                                                "anchor_text": "St Peters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-summer-hill/",
                                        "urls": [
                                            {
                                                "url": "https://roofinginnerwest.com.au/locations/roofing-services-in-summer-hill/",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61291670228"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}