{
    "id": "01190727-1132-0216-0000-da26ae2cde72",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0324 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://puremetalroofing.com.au/roof-repairs-ashfield/",
        "target": "puremetalroofing.com.au",
        "start_url": "https://puremetalroofing.com.au/roof-repairs-ashfield/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Ashfield-(NSW)\\organic\\type-organic_rg15_ra22_puremetalroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:30:59 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Pure Metal Roofing Pty Ltd",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Quick Links",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://puremetalroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://puremetalroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://puremetalroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Newtown NSW 2042",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Berala NSW 2141",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN: 18 664 818 357",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Lic No. 388625C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "100% Satisfaction Guaranteed",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repairs in Ashfield",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Protect your home or business with expert roof repairs backed by over 30 years of experience in Sydney\u2019s diverse conditions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fixing Leaks, Rust, Storm Damage and More",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Dealing with a leaking or damaged roof? Whether it\u2019s a tiled roof showing signs of wear or a Colorbond roof affected by storm damage, acting quickly can help you avoid more costly repairs down the track. For over 30 years, Pure Metal Roofing has been the trusted choice for Ashfield locals in need of high-quality roof repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We specialise in everything from cracked tiles and rusted valleys to damaged ridge capping, loose sheets, and water ingress. No matter the extent of the damage, our licensed team responds promptly, using premium materials designed to withstand Sydney\u2019s harsh conditions. We ensure every repair is carried out to the highest standard, restoring your roof\u2019s integrity and preventing future issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We proudly service residential, commercial, and strata properties throughout Ashfield and surrounding suburbs. Whether it\u2019s restoring a classic federation home, repairing a modern apartment block, or fixing a retail premises, we tailor every solution to your roof\u2019s structure and condition\u2014always with honest advice and no subcontractors.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With Pure Metal Roofing, you\u2019ll receive clear communication, fast turnaround, and workmanship that lasts. Your roof is in expert hands\u2014and we\u2019ll make sure it stays that way for years to come.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Request a Roof Inspection",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Contact us to schedule your roof inspection at a time that suits you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Assessment",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We assess your roof, identify any issues, and recommend the most effective repair solution.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quote & Approval",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "You\u2019ll receive a clear, itemised quote with no hidden costs. Once approved, we lock in a time for the repair.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Repair Work Begins",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Our in-house team carries out all repairs using premium materials to ensure lasting quality.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Final Inspection",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We complete a final check to confirm your roof is fully secure and watertight, and leave you completely satisfied.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Benefits of Choosing Pure Metal Roofing",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Rapid response to leaks and damage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repairs completed by qualified, licensed roofing professionals",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Suitable for tile, metal, Colorbond, and combination roof systems",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Seamless repairs that blend with existing materials for a uniform look",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Long-lasting results that fix the root cause, not just the surface",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Storm damage and insurance work managed efficiently",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Servicing Ashfield and surrounding suburbs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10-Year Workmanship Guarantee on all repair work",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Clients Who Trust Us in Ashfield",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We\u2019ve delivered trusted roof repair services to:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Homeowners, from federation houses to modern townhouses",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Strata buildings with shared or private roof issues",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Commercial properties, including retail spaces and caf\u00e9s",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Builders and developers needing reliable roofing partners",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Insurance companies handling storm damage claims",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter the property type, we bring the same level of care and professionalism to every job.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "How quickly can you respond to a roof leak in Ashfield?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We prioritise urgent repairs and typically schedule standard inspections within a few business days, depending on availability.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you repair all types of roofing materials?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we specialise in repairs for tile, metal, Colorbond, and mixed roof systems commonly found across Ashfield.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Will the repair materials match my existing roof?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. We source materials that match your current roof to ensure a consistent and seamless finish.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you assist with insurance claims for storm damage?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we support clients by providing the necessary documentation and reports for storm damage insurance claims.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What warranty do you offer on roof repairs?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All our repair work comes with a 10-year workmanship guarantee for your peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Testimonials",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Binbin Liang",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How It Works",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gallery",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Areas We Serve",
                                "main_title": "Roof Repairs in Ashfield",
                                "author": "",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park",
                                        "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://puremetalroofing.com.au/roof-repairs-dulwich-hill/",
                                                "anchor_text": "Croydon Park"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0422088256"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}