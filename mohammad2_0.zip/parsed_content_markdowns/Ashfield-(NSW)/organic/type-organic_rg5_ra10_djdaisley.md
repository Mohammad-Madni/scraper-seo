{
    "id": "01190727-1132-0216-0000-21115d6f3a9a",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0255 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.djdaisley.com.au/",
        "target": "www.djdaisley.com.au",
        "start_url": "https://www.djdaisley.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Ashfield-(NSW)\\organic\\type-organic_rg5_ra10_djdaisley.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:54 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "DJ Daisley & Sons",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "to arrange an obligation free quote",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "est 1912",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "\u00a9 2024 DJ DAISLEY & SONS PTY LTD. All rights reserved.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": null,
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Repair Services in Sydney",
                                "main_title": "Roof Repair Services in Sydney",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "For over 100 years, DJ Daisley & Sons have repaired roofs in Sydney\u2019s Inner West region. Our family-owned business has been passed down through the generations, giving us a wealth of experience. When you need roof repairs, we have the expertise you can trust and because we\u2019ve been involved in the roofing industry for so long, we\u2019ve seen every roofing problem imaginable.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roofing Services",
                                "main_title": "Roof Repair Services in Sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "DJ Daisley & Sons offers a variety of roofing services, which include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repairs to existing roofs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal, slate and tile roofs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For more information on the work we offer and the methods we use, check out our\u00a0services page.",
                                        "url": "https://www.djdaisley.com.au/services",
                                        "urls": [
                                            {
                                                "url": "https://www.djdaisley.com.au/services",
                                                "anchor_text": "services page"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "New roof installations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guttering and downpipes",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Commitment to Our Customers",
                                "main_title": "Roof Repair Services in Sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With all the different types of weather Sydney has, you need to have a roofing expert you can trust. Here at DJ Daisley & Sons, we\u2019re dedicated to earning that trust, so all of our work is completed to a high standard of excellence. Our company is committed to customer satisfaction, which is why we communicate with our clients and build long-term relationships with them. We\u2019re confident you\u2019ll be happy with our work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "When you\u2019re in need of roof repairs in the Sydney area, give DJ Daisley & Sons a call on (02) 9516 3514 or send us a message by filling out our online\u00a0form.",
                                        "url": "https://www.djdaisley.com.au/contact",
                                        "urls": [
                                            {
                                                "url": "https://www.djdaisley.com.au/contact",
                                                "anchor_text": "form"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair Services in Sydney",
                                "main_title": "Roof Repair Services in Sydney",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "\" DJ Daisley and Sons were recommended by a friend of mine who was impressed with their work. And now I can see why. Not only did the team turn up on time, they did the job a day earlier than they said they would. I\u2019ll be recommending them to others.\" \u200b",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sienna Marcos, Haberfield NSW",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": null,
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0412611000"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}