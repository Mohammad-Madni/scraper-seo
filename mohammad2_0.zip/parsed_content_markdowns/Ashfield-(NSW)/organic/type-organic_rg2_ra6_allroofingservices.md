{
    "id": "01190727-1132-0216-0000-b6cbf298443b",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0257 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.allroofingservices.com.au/roof-replacement-ashfield/",
        "target": "www.allroofingservices.com.au",
        "start_url": "https://www.allroofingservices.com.au/roof-replacement-ashfield/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Ashfield-(NSW)\\organic\\type-organic_rg2_ra6_allroofingservices.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:58 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "About ARS",
                                    "url": "https://www.allroofingservices.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/about-us/",
                                            "anchor_text": "About ARS"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Specialist",
                                    "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-specialist/",
                                            "anchor_text": "Roof Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Know Your Rights",
                                    "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/know-your-rights/",
                                            "anchor_text": "Know Your Rights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Plumbing",
                                    "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-plumbing/",
                                            "anchor_text": "Roof Plumbing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Free Quote",
                                    "url": "https://www.allroofingservices.com.au/free-quote/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/free-quote/",
                                            "anchor_text": "Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.allroofingservices.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "ARS are local roofing contractors owned and operated by Julian Dirou. Julian is a very experienced and licensed metal roof plumber who believes in doing things properly the first time, without short cuts and never compromising on quality.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright \u00a9 2026 All Roofing Services",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "On Time And On Budget.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "We Never Compromise On Quality.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Fully Insured And Licensed.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "A Great Team Of Experienced, Friendly & Competent Roofers.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Free Inspections, Consultations And Quotes.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Voted Top Roofing Business For 3 Years.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roof",
                                    "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                            "anchor_text": "Colorbond Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.allroofingservices.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://www.allroofingservices.com.au/metal-roof/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "618 Parramatta Road,",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Croydon NSW 2132 Australia",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Office: 02 8086 2059",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mobile: 0406 969 061",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "info@allroofingservices. com.au",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Website by Nasyana Marketing",
                                    "url": "https://www.nasyana.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://www.nasyana.com.au/",
                                            "anchor_text": "Nasyana Marketing"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Expert Roof Replacements for Reliable and Beautiful Roofs",
                                "main_title": "All Roofing Services: Premier Roof Replacements in Ashfield and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Welcome to All Roofing Services, the trusted roofing contractor serving Ashfield and the greater Sydney area. With our expertise in premier roof replacements, including re-roofing and Colorbond roof replacements, we are dedicated to enhancing the durability, functionality, and visual appeal of your property. Our team of fully licensed and insured roofers takes pride in delivering top-quality services to both residential and commercial clients.",
                                        "url": "https://www.allroofingservices.com.au/roofing-contractors/",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/roofing-contractors/",
                                                "anchor_text": "roofing contractor"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/roof-replacement/",
                                                "anchor_text": "roof replacements"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/re-roofing/",
                                                "anchor_text": "re-roofing"
                                            },
                                            {
                                                "url": "https://www.allroofingservices.com.au/colorbond-roof/",
                                                "anchor_text": "Colorbond roof replacements"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs: Restoring the Integrity of Your Roof",
                                "main_title": "All Roofing Services: Premier Roof Replacements in Ashfield and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At All Roofing Services, we prioritize roof repairs, maintenance, and leak fixes to ensure the long-lasting integrity of your roof. Our skilled and friendly roofers possess the knowledge and tools to handle a wide range of repair tasks promptly, protecting your property from potential damage and preserving the structural soundness of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose All Roofing Services?",
                                "main_title": "All Roofing Services: Premier Roof Replacements in Ashfield and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When you choose All Roofing Services, you benefit from:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Uncompromising Quality: We uphold the highest standards of workmanship and utilize premium materials to ensure exceptional results that stand the test of time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Professionalism and Expertise: Our experienced roofers are not only skilled craftsmen but also friendly professionals who are dedicated to understanding your unique roofing needs and providing tailored solutions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Peace of Mind: We are fully licensed and insured, giving you the confidence and assurance that your roofing project is in capable hands.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free Consultations and Estimates: We offer complimentary consultations and detailed estimates, allowing you to make informed decisions and have a clear understanding of the scope and cost of your roofing project.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Serving Ashfield, Inner West, and Surrounding Areas",
                                "main_title": "All Roofing Services: Premier Roof Replacements in Ashfield and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "While our primary service area is Ashfield, we proudly extend our exceptional roofing services to surrounding suburbs in the Inner West and the wider Sydney region. Whether you reside in Ashfield or a neighboring community, our team is ready to deliver top-notch roof replacements and repairs for both residential and commercial properties.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recognized for Excellence",
                                "main_title": "All Roofing Services: Premier Roof Replacements in Ashfield and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "All Roofing Services has earned recognition for our unwavering commitment to excellence within the roofing industry. We are proud recipients of accolades for our outstanding reputation and professionalism, solidifying our position as a leader among Sydney\u2019s roofing companies. This recognition speaks to our relentless dedication to delivering superior results and exceeding customer expectations.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact All Roofing Services Today",
                                "main_title": "All Roofing Services: Premier Roof Replacements in Ashfield and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "For reliable and professional roofing services in Ashfield and the wider Sydney area, contact All Roofing Services today at 02 8086 2059. Our friendly and knowledgeable team is eager to assist you with a complimentary inspection, in-depth consultation, and a personalized quote tailored to your specific roofing needs. Trust us to provide you with a high-quality, durable, and visually appealing roof that will safeguard your property for years to come.",
                                        "url": "https://www.allroofingservices.com.au/contact-us/",
                                        "urls": [
                                            {
                                                "url": "https://www.allroofingservices.com.au/contact-us/",
                                                "anchor_text": "contact"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "All Roofing Services: Premier Roof Replacements in Ashfield and Sydney",
                                "main_title": "All Roofing Services: Premier Roof Replacements in Ashfield and Sydney",
                                "author": "All Roofing Services",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "02 8086 2059",
                                "0406%20969%20061",
                                "0280862059"
                            ],
                            "emails": [
                                "info@allroofingservices.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}