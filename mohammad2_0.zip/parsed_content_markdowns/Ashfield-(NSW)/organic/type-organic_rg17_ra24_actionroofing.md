{
    "id": "01190727-1132-0216-0000-cc761526cd3f",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0348 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://actionroofing.com.au/roof-resurfacing-ashfield/",
        "target": "actionroofing.com.au",
        "start_url": "https://actionroofing.com.au/roof-resurfacing-ashfield/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Ashfield-(NSW)\\organic\\type-organic_rg17_ra24_actionroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:56 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Areas We Service",
                                    "url": "https://actionroofing.com.au/areas-we-service/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/areas-we-service/",
                                            "anchor_text": "Areas We Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Near Me",
                                    "url": "https://actionroofing.com.au/roofers-near-me/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roofers-near-me/",
                                            "anchor_text": "Roofers Near Me"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://actionroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://actionroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://actionroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://actionroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://actionroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://actionroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://actionroofing.com.au/gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/gutter-replacement/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://actionroofing.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof",
                                    "url": "https://actionroofing.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof/",
                                            "anchor_text": "Metal Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repair",
                                    "url": "https://actionroofing.com.au/metal-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-repair/",
                                            "anchor_text": "Metal Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://actionroofing.com.au/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Installation Sydney",
                                    "url": "https://actionroofing.com.au/metal-roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-installation-sydney/",
                                            "anchor_text": "Metal Roof Installation Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Cleaning",
                                    "url": "https://actionroofing.com.au/tile-roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-cleaning/",
                                            "anchor_text": "Tile Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Replacement",
                                    "url": "https://actionroofing.com.au/tile-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-replacement/",
                                            "anchor_text": "Tile Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repair",
                                    "url": "https://actionroofing.com.au/tile-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-repair/",
                                            "anchor_text": "Tile Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://actionroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Areas We Service",
                                    "url": "https://actionroofing.com.au/areas-we-service/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/areas-we-service/",
                                            "anchor_text": "Areas We Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Near Me",
                                    "url": "https://actionroofing.com.au/roofers-near-me/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roofers-near-me/",
                                            "anchor_text": "Roofers Near Me"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://actionroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://actionroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://actionroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://actionroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://actionroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://actionroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://actionroofing.com.au/gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/gutter-replacement/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://actionroofing.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof",
                                    "url": "https://actionroofing.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof/",
                                            "anchor_text": "Metal Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repair",
                                    "url": "https://actionroofing.com.au/metal-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-repair/",
                                            "anchor_text": "Metal Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://actionroofing.com.au/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Installation Sydney",
                                    "url": "https://actionroofing.com.au/metal-roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-installation-sydney/",
                                            "anchor_text": "Metal Roof Installation Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Cleaning",
                                    "url": "https://actionroofing.com.au/tile-roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-cleaning/",
                                            "anchor_text": "Tile Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Replacement",
                                    "url": "https://actionroofing.com.au/tile-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-replacement/",
                                            "anchor_text": "Tile Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repair",
                                    "url": "https://actionroofing.com.au/tile-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-repair/",
                                            "anchor_text": "Tile Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://actionroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Areas We Service",
                                    "url": "https://actionroofing.com.au/areas-we-service/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/areas-we-service/",
                                            "anchor_text": "Areas We Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Near Me",
                                    "url": "https://actionroofing.com.au/roofers-near-me/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roofers-near-me/",
                                            "anchor_text": "Roofers Near Me"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://actionroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://actionroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://actionroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://actionroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://actionroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://actionroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://actionroofing.com.au/gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/gutter-replacement/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://actionroofing.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof",
                                    "url": "https://actionroofing.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof/",
                                            "anchor_text": "Metal Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repair",
                                    "url": "https://actionroofing.com.au/metal-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-repair/",
                                            "anchor_text": "Metal Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://actionroofing.com.au/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Installation Sydney",
                                    "url": "https://actionroofing.com.au/metal-roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-installation-sydney/",
                                            "anchor_text": "Metal Roof Installation Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Cleaning",
                                    "url": "https://actionroofing.com.au/tile-roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-cleaning/",
                                            "anchor_text": "Tile Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Replacement",
                                    "url": "https://actionroofing.com.au/tile-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-replacement/",
                                            "anchor_text": "Tile Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repair",
                                    "url": "https://actionroofing.com.au/tile-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-repair/",
                                            "anchor_text": "Tile Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://actionroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Areas We Service",
                                    "url": "https://actionroofing.com.au/areas-we-service/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/areas-we-service/",
                                            "anchor_text": "Areas We Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Near Me",
                                    "url": "https://actionroofing.com.au/roofers-near-me/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roofers-near-me/",
                                            "anchor_text": "Roofers Near Me"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://actionroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://actionroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://actionroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://actionroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://actionroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://actionroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://actionroofing.com.au/gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/gutter-replacement/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://actionroofing.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof",
                                    "url": "https://actionroofing.com.au/metal-roof/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof/",
                                            "anchor_text": "Metal Roof"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repair",
                                    "url": "https://actionroofing.com.au/metal-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-repair/",
                                            "anchor_text": "Metal Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://actionroofing.com.au/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Installation Sydney",
                                    "url": "https://actionroofing.com.au/metal-roof-installation-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/metal-roof-installation-sydney/",
                                            "anchor_text": "Metal Roof Installation Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Cleaning",
                                    "url": "https://actionroofing.com.au/tile-roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-cleaning/",
                                            "anchor_text": "Tile Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Replacement",
                                    "url": "https://actionroofing.com.au/tile-roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-replacement/",
                                            "anchor_text": "Tile Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repair",
                                    "url": "https://actionroofing.com.au/tile-roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/tile-roof-repair/",
                                            "anchor_text": "Tile Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://actionroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Copyright\u00a92025- Action Roofing Pvt Ltd. All Rights Reserved. E&EO | License Number: 176125C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright\u00a92025- Action Roofing Pvt Ltd.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "All Rights Reserved. E&EO | License Number: 176125C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Get Your Free Roofing Quote Today",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "PO Box 7459, Baulkham Hills Business Centre",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "PO Box 7459, Baulkham Hills Business Centre, NSW 2153",
                                    "url": "https://goo.gl/maps/JJ1Hv5nmbNabqYth6",
                                    "urls": [
                                        {
                                            "url": "https://goo.gl/maps/JJ1Hv5nmbNabqYth6",
                                            "anchor_text": "PO Box 7459, Baulkham Hills Business Centre, NSW 2153"
                                        }
                                    ]
                                },
                                {
                                    "text": "Quick Links",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://actionroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Areas we serve",
                                    "url": "https://actionroofing.com.au/areas-we-service/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/areas-we-service/",
                                            "anchor_text": "Areas we serve"
                                        }
                                    ]
                                },
                                {
                                    "text": "HTML Sitemap",
                                    "url": "https://actionroofing.com.au/html-sitemap/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/html-sitemap/",
                                            "anchor_text": "HTML Sitemap"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://actionroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://actionroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Re Roofing",
                                    "url": "https://actionroofing.com.au/re-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/re-roofing/",
                                            "anchor_text": "Re Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://actionroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://actionroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://actionroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "PO Box 7459, Baulkham Hills",
                                    "url": "https://goo.gl/maps/JJ1Hv5nmbNabqYth6",
                                    "urls": [
                                        {
                                            "url": "https://goo.gl/maps/JJ1Hv5nmbNabqYth6",
                                            "anchor_text": "PO Box 7459, Baulkham Hills Business Centre, NSW 2153"
                                        }
                                    ]
                                },
                                {
                                    "text": "Business Centre, NSW 2153",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Quick Links",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://actionroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Areas we serve",
                                    "url": "https://actionroofing.com.au/areas-we-service/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/areas-we-service/",
                                            "anchor_text": "Areas we serve"
                                        }
                                    ]
                                },
                                {
                                    "text": "HTML Sitemap",
                                    "url": "https://actionroofing.com.au/html-sitemap/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/html-sitemap/",
                                            "anchor_text": "HTML Sitemap"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Services",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://actionroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://actionroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Re Roofing",
                                    "url": "https://actionroofing.com.au/re-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/re-roofing/",
                                            "anchor_text": "Re Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://actionroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://actionroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://actionroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "02 8883 1488",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Resurfacing Ashfield",
                                "main_title": "Roof Resurfacing Ashfield",
                                "author": "Action Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We do Roof Resurfacing\u00a0on:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Action Roofing provides Roof Resurfacing in Ashfield. Go to the Contact Us page to get in touch with us for your Roof Resurfacing.",
                                        "url": "https://actionroofing.com.au/roof-ventilators-and-skylights",
                                        "urls": [
                                            {
                                                "url": "https://actionroofing.com.au/roof-ventilators-and-skylights",
                                                "anchor_text": "Roof Resurfacing"
                                            },
                                            {
                                                "url": "https://actionroofing.com.au/site/contact-us",
                                                "anchor_text": "Contact Us"
                                            },
                                            {
                                                "url": "https://actionroofing.com.au/roof-ventilators-and-skylights",
                                                "anchor_text": "Roof Resurfacing."
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Resurfacing is available in all areas that we\u00a0service, please visit the Areas Serviced page to find all areas where we provide Roof Repair, Re-Roofing and Roof Cleaning.",
                                        "url": "https://actionroofing.com.au/roof-ventilators-and-skylights",
                                        "urls": [
                                            {
                                                "url": "https://actionroofing.com.au/roof-ventilators-and-skylights",
                                                "anchor_text": "Roof Resurfacing"
                                            },
                                            {
                                                "url": "https://actionroofing.com.au/areas-serviced",
                                                "anchor_text": "Areas Serviced"
                                            },
                                            {
                                                "url": "https://actionroofing.com.au/roofing-repair",
                                                "anchor_text": "Roof Repair"
                                            },
                                            {
                                                "url": "https://actionroofing.com.au/re-roofing",
                                                "anchor_text": "Re-Roofing"
                                            },
                                            {
                                                "url": "https://actionroofing.com.au/site/roof-cleaning",
                                                "anchor_text": "Roof Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terracotta Roof Tile",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Concrete Roof Tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Resurfacing Ashfield",
                                "main_title": "Roof Resurfacing Ashfield",
                                "author": "Action Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Written By: Peter actionroofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Action Roofing are Roof Resurfacing\u00a0specialists and can assist you in choosing the most efficient, functional and attractive ventilation to suit your roof. There are many products on the market, however we strive to use the best quality products for a number of different situations. Please visit our Roof Resurfacing page to find further information on our products.",
                                "main_title": "Roof Resurfacing Ashfield",
                                "author": "Action Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Action Roofing are Roof Resurfacing\u00a0specialists and can assist you in choosing the most efficient, functional and attractive ventilation to suit your roof. There are many products on the market, however we strive to use the best quality products for a number of different situations. Please visit our Roof Resurfacing page to find further information on our products.",
                                        "url": "https://actionroofing.com.au/roof-ventilators-and-skylights",
                                        "urls": [
                                            {
                                                "url": "https://actionroofing.com.au/roof-ventilators-and-skylights",
                                                "anchor_text": "Roof Resurfacing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Request a Quote",
                                "main_title": "Roof Resurfacing Ashfield",
                                "author": "Action Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61288831488",
                                "02%208883%201488"
                            ],
                            "emails": [
                                "sales@actionroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}