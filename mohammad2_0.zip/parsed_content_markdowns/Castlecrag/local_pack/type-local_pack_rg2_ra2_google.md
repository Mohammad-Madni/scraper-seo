# Type: local_pack | Rank: 2 | RG: 2
### Raw Row Data:
{
    "rank_group": "2",
    "rank_absolute": "2",
    "service": "roofer",
    "suburb": "Castlecrag",
    "title": "Group of Roofers",
    "domain": "www.google.com",
    "url": "https://www.google.com/viewer/place?sca_esv=ed956a20e7b48028&hl=en&gl=AU&output=search&mid=/g/11wtl3yyql&pip=CgZyb29mZXIQAg%3D%3D",
    "description": "Open \u00b7 Northbridge NSW",
    "type": "local_pack"
}