{
    "id": "01190728-1132-0216-0000-c13b6a73b222",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0295 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://mcbrideroofing.com.au/",
        "target": "mcbrideroofing.com.au",
        "start_url": "https://mcbrideroofing.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castlecrag\\organic\\type-organic_rg10_ra13_mcbrideroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:49 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Home Improvement",
                                    "url": "https://mcbrideroofing.com.au/category/home-improvement/",
                                    "urls": [
                                        {
                                            "url": "https://mcbrideroofing.com.au/category/home-improvement/",
                                            "anchor_text": "Home Improvement"
                                        }
                                    ]
                                },
                                {
                                    "text": "tel: 0435 682 600",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "tel: 0435 682 600",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Home Improvement",
                                    "url": "https://mcbrideroofing.com.au/category/home-improvement/",
                                    "urls": [
                                        {
                                            "url": "https://mcbrideroofing.com.au/category/home-improvement/",
                                            "anchor_text": "Home Improvement"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Areas We Service : We are Sydney based and service the Lower North Shore and Inner West Sydney. Including Artarmon, Chatswood, Inner West Sydney, Clifton Gardens, Mosman, Killara, Lindfield, Lower North Shore, Roseville, Willoughby, Lane Cove, Castle Cove, St Ives, Gladesville, Gordon, Middle Cove, Turramurra, Hunters Hill, Naremburn, Crows Nest, Castlecrag, Cremorne, Lane Cove North, East Killara, East Lindfield, Roseville Chase, Willoughby North, Northbridge, Cammeray, Five Dock, Concord, Balwgowlah,\u00a0Chatswood East, Chatswood West, Clontarf, Cremorne Point, Curl Curl, Dee Why, Denistone, Marsfield, Drummoyne, East Killara, Forestville, Frenchs Forest, Freshwater, Greenwich, Killarney Heights, Lane Cove East, Lane Cove West, Longueville, Macquarie Park, Mosman, Manly, Neutral Bay, North Balgowlah, North Curl Curl, North Ryde, North Sydney, Northwood, Riverview, Putney, Pymble, Ryde, Seaforth, St Ives, South Turramurra, St Leonards, Stanmore, Wahroonga, Warrawee, Waverton, Willoughby East, Wollstonecraft West Pymble\u00a0and more.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "McBride Roofing Family Owned Local Business",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN 99 642 158 549 | Licence No. 384832C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Neve | Powered by WordPress",
                                    "url": "https://themeisle.com/themes/neve/",
                                    "urls": [
                                        {
                                            "url": "https://themeisle.com/themes/neve/",
                                            "anchor_text": "Neve"
                                        },
                                        {
                                            "url": "https://wordpress.org/",
                                            "anchor_text": "WordPress"
                                        }
                                    ]
                                },
                                {
                                    "text": "mob 0435 682 600 admin@mcbrideroofing.com.au",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "6 Norfolk Way North Ryde NSW 2113",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Home Improvement",
                                    "url": "https://mcbrideroofing.com.au/category/home-improvement/",
                                    "urls": [
                                        {
                                            "url": "https://mcbrideroofing.com.au/category/home-improvement/",
                                            "anchor_text": "Home Improvement"
                                        }
                                    ]
                                },
                                {
                                    "text": "McBride Roofing Family Owned Local Business",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "ABN 99 642 158 549 | Licence No. 384832C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Neve | Powered by WordPress",
                                    "url": "https://themeisle.com/themes/neve/",
                                    "urls": [
                                        {
                                            "url": "https://themeisle.com/themes/neve/",
                                            "anchor_text": "Neve"
                                        },
                                        {
                                            "url": "https://wordpress.org/",
                                            "anchor_text": "WordPress"
                                        }
                                    ]
                                },
                                {
                                    "text": "mob 0435 682 600 admin@mcbrideroofing.com.au",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "6 Norfolk Way North Ryde NSW 2113",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Home Improvement",
                                    "url": "https://mcbrideroofing.com.au/category/home-improvement/",
                                    "urls": [
                                        {
                                            "url": "https://mcbrideroofing.com.au/category/home-improvement/",
                                            "anchor_text": "Home Improvement"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Residential Roofing",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "From roof replacements, restorations, and maintenance. McBride Roofing are the experts in residential roofing.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Workmanship Guarantee",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "McBride Roofing are qualified, certified roofing specialists with a 7-year workmanship guarantee.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fully Insured and Licenced",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "McBride Roofing, roofing services are fully insured and licenced specialists in all your roofing needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roof & Reroofs",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Complete or partial commercial, residential or strata metal roof restorations, reroofs, and roof replacements. Add value to your property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roofing Service in Sydney",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "At McBride Roofing, we\u2019re experts in metal roofing for Sydney. We provide top-tier roofing solutions for residential and commercial properties, offering a blend of durability, energy efficiency, and aesthetic appeal. McBride Roofing uses Colorbond\u00ae metal roofing in all its metal roofing and reroofing projects\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing Service in Sydney",
                                        "url": "https://mcbrideroofing.com.au/flat-metal-roofing-service-in-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://mcbrideroofing.com.au/flat-metal-roofing-service-in-sydney/",
                                                "anchor_text": "Metal Roofing Service in Sydney"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement for Sydney Commercial & Industrial Businesses",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Commercial and industrial businesses have unique needs when it comes to their buildings. One of the most critical aspects is the roof. At McBride Roofing, we specialise in roof replacement for Sydney commercial and industrial businesses, ensuring your property is protected, and your business can grow",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement for Sydney Commercial & Industrial Businesses",
                                        "url": "https://mcbrideroofing.com.au/roof-replacement-for-sydney-commercial-industrial-businesses/",
                                        "urls": [
                                            {
                                                "url": "https://mcbrideroofing.com.au/roof-replacement-for-sydney-commercial-industrial-businesses/",
                                                "anchor_text": "Roof Replacement for Sydney Commercial & Industrial Businesses"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "The Superiority of Colorbond Guttering and Roofing",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "McBride Roofing is proud to offer Colorbond guttering and roofing solutions as a trusted and professional roofing company. This popular and reliable choice of material supports our commitment to quality and dedication to providing outstanding roofing services\u2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "The Superiority of Colorbond Guttering and Roofing",
                                        "url": "https://mcbrideroofing.com.au/the-superiority-of-colorbond-guttering-and-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://mcbrideroofing.com.au/the-superiority-of-colorbond-guttering-and-roofing/",
                                                "anchor_text": "The Superiority of Colorbond Guttering and Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Quality Assured",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "McBride Roofing are proud members of the Master Builders Association.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team of roofing specialists are experts in metal roofing, especially\u00a0flat metal roofing. We use premium\u00a0Colorbond\u00ae metal to ensure all our residential and commercial roofing and reroofing projects are\u00a0durable,\u00a0energy-efficient, and aesthetic.",
                                        "url": "http://mcbrideroofing.com.au/the-superiority-of-colorbond-guttering-and-roofing/",
                                        "urls": [
                                            {
                                                "url": "http://mcbrideroofing.com.au/the-superiority-of-colorbond-guttering-and-roofing/",
                                                "anchor_text": "Colorbond\u00ae metal"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact us for your project now",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Sydney\u2019s Metal Roofing Specialists",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "McBride Roofing. Family-owned roofing professionals",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Metal Roofing",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial and Industrial reroofing",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Superior Materials",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Testimonials",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Paul Lennox",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clinton Lollback",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Chris Allan",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "lisa krieger",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Andros Walsh",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "catie sully",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tania Black",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Suzanne Chahinian",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Joel Stephenson",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Book your free quote today.",
                                "main_title": "Sydney\u2019s Metal Roofing Specialists",
                                "author": "McBride Roofing",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Book your free, no-obligation quote to fix, restore, replace or maintain roofs, gutters, downpipes, gutter guards, and whirlybirds.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "You agree to receive email communication by submitting this form and understand that your contact information will be stored with us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61435682600"
                            ],
                            "emails": [
                                "admin@mcbrideroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}