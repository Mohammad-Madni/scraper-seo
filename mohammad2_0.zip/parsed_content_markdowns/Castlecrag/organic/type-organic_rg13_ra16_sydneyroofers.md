{
    "id": "01190728-1132-0216-0000-4ba6276440c3",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0199 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.sydneyroofers.net.au/roof-repairs-castlecrag",
        "target": "www.sydneyroofers.net.au",
        "start_url": "https://www.sydneyroofers.net.au/roof-repairs-castlecrag",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castlecrag\\organic\\type-organic_rg13_ra16_sydneyroofers.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:46 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "If you require assistance due to storm emergencies, please phone 1800 044 055",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "1800 793 766",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.sydneyroofers.net.au/roof-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/roof-repairs",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration & Cleaning",
                                    "url": "https://www.sydneyroofers.net.au/roof-restoration",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/roof-restoration",
                                            "anchor_text": "Roof Restoration & Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://www.sydneyroofers.net.au/metal-roofing",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/metal-roofing",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Guttering Services",
                                    "url": "https://www.sydneyroofers.net.au/guttering-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/guttering-sydney",
                                            "anchor_text": "Guttering Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.sydneyroofers.net.au/roof-painting",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/roof-painting",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Vents",
                                    "url": "https://www.sydneyroofers.net.au/roof-vents",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/roof-vents",
                                            "anchor_text": "Roof Vents"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Repairs",
                                    "url": "https://www.sydneyroofers.net.au/roof-leak-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/roof-leak-repairs",
                                            "anchor_text": "Roof Leak Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bedding and Pointing",
                                    "url": "https://www.sydneyroofers.net.au/bedding-and-pointing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/bedding-and-pointing-sydney",
                                            "anchor_text": "Bedding and Pointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Valleys",
                                    "url": "https://www.sydneyroofers.net.au/roof-valley-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/roof-valley-repairs-sydney",
                                            "anchor_text": "Roof Valleys"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashings",
                                    "url": "https://www.sydneyroofers.net.au/roof-flashings-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/roof-flashings-repairs-sydney",
                                            "anchor_text": "Roof Flashings"
                                        }
                                    ]
                                },
                                {
                                    "text": "Chimney Flashings",
                                    "url": "https://www.sydneyroofers.net.au/chimney-flashing-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/chimney-flashing-repairs-sydney",
                                            "anchor_text": "Chimney Flashings"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Sarkings",
                                    "url": "https://www.sydneyroofers.net.au/roof-sarking-installation-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/roof-sarking-installation-sydney",
                                            "anchor_text": "Roof Sarkings"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Repairs",
                                    "url": "https://www.sydneyroofers.net.au/skylight-repairs",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/skylight-repairs",
                                            "anchor_text": "Skylight Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing Sydney",
                                    "url": "https://www.sydneyroofers.net.au/commercial-roofing-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/commercial-roofing-sydney",
                                            "anchor_text": "Commercial Roofing Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wet And Forget",
                                    "url": "https://www.sydneyroofers.net.au/wet-and-forget-roof-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/wet-and-forget-roof-cleaning-sydney",
                                            "anchor_text": "Wet And Forget"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning Sydney",
                                    "url": "https://www.sydneyroofers.net.au/roof-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/roof-cleaning-sydney",
                                            "anchor_text": "Roof Cleaning Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Cleaning",
                                    "url": "https://www.sydneyroofers.net.au/solar-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/solar-cleaning",
                                            "anchor_text": "Solar Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.sydneyroofers.net.au/gutter-cleaning",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/gutter-cleaning",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Colors",
                                    "url": "https://www.sydneyroofers.net.au/colorbond-colors",
                                    "urls": [
                                        {
                                            "url": "https://www.sydneyroofers.net.au/colorbond-colors",
                                            "anchor_text": "Colorbond Colors"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "ROOF REPAIRS CASTLECRAG",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Is your roof in need of urgent roof repairs in Castlecrag NSW? A leaking roof during a storm is something no home owner ever wants to face. However, all too often we notice that leaking or damaged roofs don\u2019t get noticed until it becomes a harsh reality. Perhaps due to fallen branches or hail stones, lack of regular maintenance or even due to foam insulation absorbing moisture and hiding the problem. When this happens, the damage caused onto the house ceiling can lead to significant roof repair costs. The main lesson from this is that leaky or damaged roofs should be dealt with before the problem get large",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Sydney Roofers we provide the most professional & affordable roof repair in Castlecrag. With more than two decades providing roof repair services, you can be rest assured that your roof will be in safe hands with Sydney Roofers. Quality of workmanship is something we take extremely seriously, as we know how important it is to have a roof that\u2019s in perfect condition. Sydney Roofers guarantee to have your roof in perfect condition and even provide free Castlecrag roofing inspections and quotes.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "The importance of Castlecrag roof maintenance & repair?",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roofs are very susceptible to damage from all kinds of environmental influences. Leaves from nearby trees are one of the leading causes of premature aging. Excessive moisture caused by lack of roof slope or improper drainage is also a critical factor. Other influences could be animals, high winds and people walking on the roof who do not know the proper procedures.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Keeping your roof properly and professionally maintained will give you peace of mind in the event of heavy storms and rainfall. You\u2019ll find severe storm damage can be significantly reduced if roof repairs and maintenance are carried out beforehand and on a regular basis",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof bedding & Pointing Castlecrag",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Many of Sydney Roofers customers in Castlecrag don't realise that the most important aspect in a tiled roof restoration, is rebedding and repointing the roof tiles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "- Roof bedding and pointing are important parts of your roof\u2019s structure. The bedding holds the roof tiles in place and the pointing helps create a stronger hold and tighter seal.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "- Roof bedding and pointing is a crucial task that must be done on a regular basis in order to ensure the long-term stability of your roof and to keep your home protected.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "- When either of these components (Bedding & Pointing) becomes damaged or worn, you may experience roof leaks and other types of roof damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "- Broken or cracked bedding may cause roof tiles to shift or loosen. Left unchecked, the loose tiles can become a safety hazard. The tiles may potentially slide off the roof and cause injury.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Bedding Castlecrag",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof bedding is the concrete mortar that keeps roofing materials (Roof tiles & Ridge Caps) in place over many years. As with any materials when exposed on a regular basis roof bedding begins to wear down over time. When it wears down, roof tiles and ridge caps can become loose and fall from the roof, which can lead to numerous issues including roof damage and roof leaking.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Pointing Castlecrag",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Roof pointing is a strong second layer that goes over the initial roof bedding and helps to further add protection to the roof. It is incredibly important to have an expert who is aware of the specific needs of those in the Castlecrag area to perform this task, as the wrong materials will not offer the same protection as those chosen for optimal performance in Sydney weather conditions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repointing roof tiles is commonly recommended to replace the cement mortar used for pointing before 1995. The cement is prone to cracking and shifting. Flexible pointing material helps to eliminate these drawbacks.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Castlecrag homeowners who haven't had roof rebedding or roof repointing to their homes in the past ten years should contact a Castlecrag roofing repair specialist or us at Sydney Roofers\u00a0Castlecrag to schedule this important maintenance task.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What is the process involved in rebedding or repointing?",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Rebedding requires removal of the old existing bedding and pointing material. Bedding mix is then applied by trowel to the roof tiles to be covered by the ridge capping. A ridge rack is used to keep the ridges straight and the bedding applied in the right spot for the ridge caps to sit on. The bedding is then trowelled up to a neat up & down finish slightly inwards from the ridge. This provides a good solid surface for the flexible pointing to adhere to.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Once the bedding has dried the flexible pointing is then applied to the sides of the ridge at a thickness of 3 \u2013 5mm and the collars where the ridges overlap are also pointed. The ridges are now fully secure from wind uplift and waterproof. The flexible pointing also flexes in harmony with normal roof movement which stops future cracking of the ridge capping.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Rusted Valley Iron Replacement Castlecrag",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Roof valleys play an important role in diverting water from your roof and into your gutter system, and therefore are necessary in keeping water out of your home.Roof Valley irons need to be maintained to function correctly, but natural wear & tear may also occur. Over time, the metal can simply wear away, get damaged, or succumb to rusting, causing water to leak into the house. Water in the home often leads to structural problems and other costly, stressful repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our Roof valley replacement Castlecrag\u00a0service includes removing your old, leaking, or rusted valley irons and replacing them with new modern valley irons. Sydney Roofers specialists use the new COLORBOND\u00ae\u00a0or ZINCALUME\u00ae\u00a0valley irons. Better materials mean a longer lifespan and more protection for your home. Our roof valleys are available in several different colors and styles to fit your home's aesthetic.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Chimney Flashing Repair Castlecrag",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Homes with chimneys require more maintenance than homes without. If you\u2019ve recently encountered a chimney leak or noticed rust stains inside your firebox, you may need to repair your chimney flashing. Chimney flashing is a type of roof flashing that creates a waterproof seal to protect your chimney and roof from water damage and penetration.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Chimney flashing can become weakened over time. When it does, it\u2019s important to hire a roofing repair contractor who will be able to replace chimney flashing to ensure your roof continues to be protected to the level it needs to be. Sometimes all it will take is a minor repair applied at the right time to save the repair bill from growing into the thousands.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Signs You Need to Repair Your Chimney Flashing",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Properly installed chimney or roof flashing can last up to 30 years. Lifespan is determined by surrounding details like where you live, shape and size of your chimney, and the materials used to make it. Knowing what year your house was constructed helps keep track of the life of your chimney.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Signs it is time for a chimney flashing replacement include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaking from the inside or outside of the chimney",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sounds and evidence of dripping, like puddles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Water stains on interior ceilings or walls adjoining the chimney",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Visible gaps in the caulking around the flashing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "If you believe your roof flashing requires some attention, it\u2019s best to call in an expert. An experienced Castlecrag roof professional will be able to save you time and money in the long run by installing flashing that\u2019s up to the task of protecting your roof, your home and your family.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Discolored bricks",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rust stains",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Cleaning Castlecrag",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Leaf-blocked gutters may not seem like a big deal but ensuring this part of your home is in good working order has far reaching benefits.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutters essentially manage the flow of rain water away from your home during a downpour or storm. Blockages in your gutters can lead to extensive water damage throughout your property. Eliminate the risk of blocked gutters by utilising our cost-efficient services. That\u2019s why ensuring your gutters are free from leaves, sticks and other debris is an important part of your regular maintenance and a vital risk mitigation step.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney Roofers are here to provide you with professional gutter cleaning of both, residential and commercial properties. Sydney Roofers gutter cleaners have the expertise and special equipment to remove all loose debris and fallen leaves. We are here to take care of all your guttering needs. book your free quote today!",
                                        "url": "https://www.sydneyroofers.net.au/quote",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyroofers.net.au/quote",
                                                "anchor_text": "book your free quote today!"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Ridge weep holes Castlecrag",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Weep holes are made in the lowest point in the base of the tile. weep holes are used to allow water to escape from behind the bedding and pointing of the ridge cap. Water back-flowing occurs if there are no weep holes, and the water rises up toward the highest point and then into your roof resulting in staining of ceilings etc.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "- All ridge tiles on concrete roofs need to have weep holes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "- Terracotta roof tiles need weep holes when the top course under the ridge cap has been cut short to fit neatly and have full coverage under the ridge cap. A full length terracotta tile that is laid under the ridge cap will not require weep holes as a full terracotta tile has a water course at the top edge to prevent it from pooling back.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Here at Sydney Roofers we ensure all our work is of a high quality, and we definitely make sure weep holes are present in all work we do.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "OUR CASTLECRAG\u00a0ROOF REPAIR SERVICES",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Maintenance",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Inspection",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Ridge Bedding",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Ridge Pointing",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Attic Cleaning",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Battens Replacement",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Sarking Replacement",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Valley Gutter Replacement",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Broken Tiles Replacement",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Flat Metal Roof Replacement",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roof Repair",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tile Roof Repair",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Rust Treatment",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Box Gutter Replacement",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Cleaning",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ridge Bedding Weep Holes",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Flashing",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Lead Flashing",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Chimney Repairs",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roof Repairs",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leak Detection",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Temporarily Roof Repairs",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tarping",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Replacement",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Downpipe Replacement",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Ventilation & Whirlybirds",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Insulation",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "ROOF REPAIRS CASTLECRAG",
                                "main_title": "ROOF REPAIRS CASTLECRAG",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "\u00a9 2025 Sydney Roofers Group",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://www.sydneyroofers.net.au/metal-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyroofers.net.au/metal-roofing",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://www.sydneyroofers.net.au/roof-repairs",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyroofers.net.au/roof-repairs",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://www.sydneyroofers.net.au/roof-restoration",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyroofers.net.au/roof-restoration",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Vents",
                                        "url": "https://www.sydneyroofers.net.au/roof-vents",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyroofers.net.au/roof-vents",
                                                "anchor_text": "Roof Vents"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "About Zip",
                                        "url": "https://www.sydneyroofers.net.au/zip-own-it-now-pay-later",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyroofers.net.au/zip-own-it-now-pay-later",
                                                "anchor_text": "About Zip"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": "https://www.sydneyroofers.net.au/_files/ugd/85d81a_5d571f79ebc14c02a9632c714e2f2c0b.pdf",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyroofers.net.au/_files/ugd/85d81a_5d571f79ebc14c02a9632c714e2f2c0b.pdf",
                                                "anchor_text": "Privacy Policy"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Book A Quote",
                                        "url": "https://www.sydneyroofers.net.au/quote",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyroofers.net.au/quote",
                                                "anchor_text": "Book A Quote"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Free Inspection",
                                        "url": "https://www.sydneyroofers.net.au/quote",
                                        "urls": [
                                            {
                                                "url": "https://www.sydneyroofers.net.au/quote",
                                                "anchor_text": "Free Inspection"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://g.page/r/CbM5EPdHfRoyEAE",
                                        "urls": [
                                            {
                                                "url": "https://g.page/r/CbM5EPdHfRoyEAE",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Neutral Bay",
                                        "url": "https://g.page/r/CaYjnjHwdjE8EAE",
                                        "urls": [
                                            {
                                                "url": "https://g.page/r/CaYjnjHwdjE8EAE",
                                                "anchor_text": "Neutral Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Contact Us:",
                                        "url": "https://g.page/r/CXPfuqKBuUGpEAE",
                                        "urls": [
                                            {
                                                "url": "https://g.page/r/CXPfuqKBuUGpEAE",
                                                "anchor_text": "Contact Us:"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1800 793 766",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "1800 044 055",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Follow Us",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "1800793766"
                            ],
                            "emails": [
                                "sales@sydneyroofers.net.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}