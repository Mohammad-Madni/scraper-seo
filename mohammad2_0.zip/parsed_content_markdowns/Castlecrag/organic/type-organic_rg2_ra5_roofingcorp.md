{
    "id": "01191221-1132-0216-0000-74772da8bb85",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0097 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofingcorp.net.au/roof-repairs/roof-repairs-castlecrag/",
        "target": "roofingcorp.net.au",
        "start_url": "https://roofingcorp.net.au/roof-repairs/roof-repairs-castlecrag/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "enable_javascript": true,
        "switch_pool": true,
        "load_resources": true,
        "enable_browser_rendering": true,
        "enable_xhr": true,
        "disable_cookie_popup": true,
        "browser_preset": "desktop",
        "custom_js": "window.scrollTo(0, document.body.scrollHeight);",
        "tag": "parsed_content_markdowns\\Castlecrag\\organic\\type-organic_rg2_ra5_roofingcorp.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 0,
            "items": null
        }
    ]
}