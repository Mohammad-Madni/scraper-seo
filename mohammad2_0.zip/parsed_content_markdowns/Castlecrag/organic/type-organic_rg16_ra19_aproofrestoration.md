{
    "id": "01190728-1132-0216-0000-233c2fcc4177",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0355 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://aproofrestoration.com.au/locations/castlecrag/",
        "target": "aproofrestoration.com.au",
        "start_url": "https://aproofrestoration.com.au/locations/castlecrag/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castlecrag\\organic\\type-organic_rg16_ra19_aproofrestoration.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:51 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "All Pro Roofing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "All Pro Roofing",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Dulux Accredited HIA Member",
                                    "url": "https://aproofrestoration.com.au/contact/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/contact/",
                                            "anchor_text": "Dulux Accredited HIA Member"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://aproofrestoration.com.au/roofing-quote/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/roofing-quote/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roofs",
                                    "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                            "anchor_text": "New Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Work",
                                    "url": "https://aproofrestoration.com.au/our-work/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/our-work/",
                                            "anchor_text": "Our Work"
                                        }
                                    ]
                                },
                                {
                                    "text": "Get a Free Quote",
                                    "url": "https://aproofrestoration.com.au/roofing-quote/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/roofing-quote/",
                                            "anchor_text": "Get a Free Quote"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roofs",
                                    "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                            "anchor_text": "New Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Our Work",
                                    "url": "https://aproofrestoration.com.au/our-work/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/our-work/",
                                            "anchor_text": "Our Work"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roofs",
                                    "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                            "anchor_text": "New Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roofs",
                                    "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                            "anchor_text": "New Roofs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard",
                                    "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                    "urls": [
                                        {
                                            "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                            "anchor_text": "Gutter Guard"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Simply fill out the contact form and we will be in touch with you to schedule a suitable date and time to assess your roofing requirements.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "All Pro Roofing",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Quality workmanship for all of your roofing needs in Castlecrag since 2005.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Contact Us",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Phone: 0406 620 352",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Email: david.allroofing@gmail.com",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Social: Facebook",
                                    "url": "https://www.facebook.com/allproroofing.com.au",
                                    "urls": [
                                        {
                                            "url": "https://www.facebook.com/allproroofing.com.au",
                                            "anchor_text": "Facebook"
                                        }
                                    ]
                                },
                                {
                                    "text": "License: 178790c",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Roof Restoration Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "David at All Pro Roofing is a professional and fully licensed roofing specialist. Providing roofing repair, roof restoration, roof painting, roof installation and roof cleaning services in Castlecrag.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Call David anytime on\u00a00406 620 352",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality workmanship at unbeatable prices since 2005.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "David did a great job on our roof; cleaned, repaired, repointed, painted and replaced our whirlybirds. Very professional, punctual, fair, and personable. Thanks.\nHighly recommended.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I can't say enough good things about All Pro Roofing! Their team was incredibly thorough in restoring my roof, and the results were nothing short of outstanding. From the initial consultation to the final inspection, their attention to detail and commitment to quality were evident every step of the way.\nNot only did they address all of my roof's issues, but they also provided excellent customer service throughout the process. The crew was professional, punctual, and kept the work site clean, which I greatly appreciated.\nI'm thrilled with the outcome of their work. My roof looks brand new, and I have the utmost confidence in its durability. If you're looking for a roofing company that delivers top-notch results and a stress-free experience, All Pro Roofing is the way to go!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Highly recommended. David did a roof restoration and did a really great job. Really good communicator - courteous and explained things well and kept us informed throughout. Impressive attention to detail - very happy with the final result. Go with David, you won\u2019t regret it.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "David, repaired and resprayed our roof to a top quality finish ,he explained the process in full and was very professional in all aspects of his work. I would highly recommend him.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We had our concrete tiled roof recoated by them almost 10 years ago and it still looks good. I was reminded of this when a neighbour, interested in having his roof done asked me for the contractor's details. David Millard is the contractor - recommended",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "David provided a full roof restoration, the team were very personable and professional ,we are extremely happy with the entire job,we would highly recommend All Pro Roofing to anyone considering a roof restoration. David arrived on time and kept us up to date with every step of the restoration.\nMany thanks to David and his wonderful team .",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "David came out to paint our neighbours roof so we spoke to him at that time and asked for a quote for our own roof. He shows up when he says he is going to, and his communication is second to none, plus he pays very close attention to detail (no overspray in any areas) and we are so happy with how it turned out. He did a wonderful job on our roof (washing, pointing, replacing cracked tiles and painting). I would highly recommend David to anyone, and would use him again if I ever needed another roof done.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "David completed our roof restoration 4 days ago and was very professional and friendly and did a great job. He was well priced and I wouldn't hesitate in recommending David to anyone looking to get their roof restored.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Highly recommend David from All Pro Roofing, he did an outstanding job on our roof, total professional from start to finish, we can not be any happier with the job he did",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Workmanship was great and we're extremely pleased with the result.\nWould definitely recommend David to anyone.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our Castlecrag Roofing Services",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Madonna Petridis",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sam Gibson",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Andrew Hayes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Michael White",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Peter Ballantyne",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Wayne Ewart",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Miranda Williams",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gregory Simon",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Jono graham",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Lachlan Gorrie",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Why Choose Us",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our Work",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing FAQ's",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Still have questions?",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Professional Roofing Services Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "If you are looking for professional roof repairs, a roof replacement or a new roof installation, All Pro Roofing is your #1 choice in Castlecrag.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs Castlecrag",
                                        "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                                "anchor_text": "Roof Repairs Castlecrag"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We provide maintenance services including re-bedding, repoint of ridge capping, roof flashing, valley iron repairs and inspections for storm damage & insurance quotes.",
                                        "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/roof-repairs/",
                                                "anchor_text": "We provide maintenance services including re-bedding, repoint of ridge capping, roof flashing, valley iron repairs and inspections for storm damage & insurance quotes."
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration Castlecrag",
                                        "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof Restoration Castlecrag"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof restorations are the most affordable solution to transform an existing roof surface. They are also the most cost-effective solution to protect and add value to your home.",
                                        "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/roof-restoration/",
                                                "anchor_text": "Roof restorations are the most affordable solution to transform an existing roof surface. They are also the most cost-effective solution to protect and add value to your home."
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting Castlecrag",
                                        "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                                "anchor_text": "Roof Painting Castlecrag"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof painting will revitalise your roof and give a fresh look to your home. We are accredited to use premium Acra-Tex Dulux paint which provides optimum protection for your roof.",
                                        "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/roof-painting/",
                                                "anchor_text": "Roof painting will revitalise your roof and give a fresh look to your home. We are accredited to use premium Acra-Tex Dulux paint which provides optimum protection for your roof."
                                            }
                                        ]
                                    },
                                    {
                                        "text": "New Roofs Castlecrag",
                                        "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                                "anchor_text": "New Roofs Castlecrag"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We are experienced in Spanish and Welsh slate, concrete, terracotta, monier, metal and colorbond roofing & can complete the job from start to finish.",
                                        "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/new-roofs/",
                                                "anchor_text": "We are experienced in Spanish and Welsh slate, concrete, terracotta, monier, metal and colorbond roofing & can complete the job from start to finish."
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Cleaning Castlecrag",
                                        "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                                "anchor_text": "Roof Cleaning Castlecrag"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "No harmful chemicals are used for our roof cleaning service. We take time and care to ensure all of your roof is cleaned, including gutters and drain pipes.",
                                        "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/roof-cleaning/",
                                                "anchor_text": "No harmful chemicals are used for our roof cleaning service. We take time and care to ensure all of your roof is cleaned, including gutters and drain pipes."
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Guard Castlecrag",
                                        "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                                "anchor_text": "Gutter Guard Castlecrag"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We Install high quality All Steel Gutter Protection. Critical to ensuring low maintenance and protects the value of your home for the long term.",
                                        "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/services/gutter-guard/",
                                                "anchor_text": "We Install high quality All Steel Gutter Protection. Critical to ensuring low maintenance and protects the value of your home for the long term."
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Castlecrag Roof Repairs",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "All Pro Roofing provides quality roofing services at unbeatable prices in Castlecrag. We have helped thousands of homeowners in Castlecrag add value and protect their property with our expert roofing service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Unbeatable prices & quality workmanship for all your roofing needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have been trading using the same licence number since 2005.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Great Value for Money",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We guarantee that your roof will be better than ever before.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All of our employees have years of experience working on roofs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We only use the best products available for our roofing projects.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We always provide our customers with an outstanding experience.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Established Since 2005",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully Licensed & Insured",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Qualified Tradesmen",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Top Quality Products",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Exceptional Customer Service",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roof Repairs Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Painting Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "New Roofs Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Cleaning Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Guard Castlecrag",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Roof Repairs Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Repairing roof leaks quickly and effectively is critical to protecting the exterior and interior of your house or business. All Pro Roofing Castlecrag has a thorough damage detection process to find the cause of leaks. We will not try to sell you a complete roof replacement when only a roof repair is required.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "All Pro Roofing have developed a detailed eight stage roof restoration process which leaves your old tired roof looking like new at a fraction of the replacement cost. With a wide range of colours and a 10 year Dulux manufacturers guarantee we can assure your roof has been restored to the highest possible standard.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "All Pro Roofing recommends and uses Dulux AcraTex. With a wide range of colours and a 10 year Dulux manufacturers guarantee we can assure your roof has been restored to the highest possible standard. Dulux AcraTex offers an extended range of traditional roofing colours plus a selection of popular tile and Colorbond roofing colours \u2013 all with Dulux durability.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "New Roofs Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Do you require a new roof installation in Diamond Beach? There\u2019s no need to worry about having to source the tiles or any other materials yourself. All Pro Roofing will supply all materials required to complete the job from start to finish. You choose the type and colour tiles you want and we will order them as part of your brand new roof installation.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Cleaning Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We clean using a petrol, high-pressure washing machine that will clean your roof with 4,000psi of water. No need to worry about the quality of the water we clean with; it comes straight from your garden tap. No harmful chemicals; we use only regular water for our high-pressure cleaning services, for the benefit of our clients and the environment.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Guard Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Installing high quality All Steel Gutter Protection is critical to ensuring low maintenance and protects the value of your home for the long term. We supply & install high quality gutter mesh, leaf screening & gutter guard options for all types of residential, commercial & strata gutter protection.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Castlecrag Roof Restoration Process",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "There\u2019s no use having a roof over your head if it\u2019s not a good one. That\u2019s why we guarantee the quality of our workmanship. We choose the best materials, assembled by our expert tradesmen, in order to give you a roof that will last a long time in many different conditions",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Dulux Acratex Colour Card PDF",
                                        "url": "https://aproofrestoration.com.au/wp-content/uploads/2024/08/Dulux-Acratex-Colour-Card.pdf",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/wp-content/uploads/2024/08/Dulux-Acratex-Colour-Card.pdf",
                                                "anchor_text": "Dulux Acratex Colour Card PDF"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulux Infracool Cool Roof PDF",
                                        "url": "https://aproofrestoration.com.au/wp-content/uploads/2024/08/Dulux-Infracool-Cool-Roof.pdf",
                                        "urls": [
                                            {
                                                "url": "https://aproofrestoration.com.au/wp-content/uploads/2024/08/Dulux-Infracool-Cool-Roof.pdf",
                                                "anchor_text": "Dulux Infracool Cool Roof PDF"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Local service since 2005",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Being owner-operated, you can count on quality workmanship and excellent customer service. You deal with David, a licensed tradesman with over 30 years of experience who has restored thousands of residential and commercial roofs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We offer a comprehensive range of services, including roof restoration, roof painting, roof tiling and slating, heritage roof repairs, cement and terracotta tile roofing, high-pressure cleaning and much more.\u200b",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "With nearly two decades of experience in the roofing industry, our team has the knowledge and skills to handle all your roofing needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We take pride in our meticulous attention to detail. Our workmanship is second to none, ensuring that your roof looks great and is built to last.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our reputation in Castlecrag is built on trust. We stand by our work and our word, delivering projects on time and within budget.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Your satisfaction is our priority. We listen to your needs, offer tailored solutions, and go the extra mile to ensure you\u2019re happy with the results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Castlecrag Roof Repair Services",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roofing Experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Specialists in All Types of Roofs",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We bring our expertise to a wide variety of roofing materials, ensuring that your roof receives the specialised care it deserves.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Terracotta Roof Repairs\u00a0Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team has extensive experience in cleaning, repairing, and restoring terracotta tiles in Castlecrag, ensuring that each tile is preserved to its original condition while extending the lifespan of your roof. Whether it\u2019s replacing cracked tiles, addressing moss build-up, or restoring the roof\u2019s vibrant colour, we deliver comprehensive services that enhance both the beauty and functionality of your terracotta roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Concrete Roof Tile Roof Repairs Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We specialise in the meticulous maintenance and restoration of tile roofs in Castlecrag, addressing common issues such as cracked or broken tiles, leaks, and water damage. Our process involves a thorough inspection to identify potential problems, followed by precise repairs and treatments that restore your roof\u2019s durability and appearance. Whether your tile roof needs a minor touch-up or a complete overhaul, we ensure it remains a strong and visually appealing shield for your home.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal Roof Repairs Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our expertise in metal roofing includes everything from cleaning and repainting to repairing and replacing sections of Colorbond roofs in Castlecrag. We use high-quality materials and techniques to ensure your metal roof remains rust-free, energy-efficient, and visually striking for years to come. Whether you need to fix a leak, restore the colour, or improve the overall condition of your metal roof, we provide solutions that are both durable and cost-effective.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Slate Roof Repairs Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team is highly skilled in working with slate, from minor repairs to full-scale restorations in Castlecrag. We carefully select matching slates to replace any that are damaged, ensuring a seamless and aesthetically pleasing finish. Additionally, we provide cleaning and maintenance services that preserve the natural beauty of your slate roof while enhancing its protective qualities. Whether you\u2019re dealing with cracked slates, slipping tiles, or general wear and tear, we ensure your slate roof continues to be a defining feature of your home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair Services Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "All Pro Roofing operates in Castlecrag.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Leaks Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Repointing Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Rebedding Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Valley Replacement Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Broken Tile Replacement Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Heritage Slate Repairs Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Barge Capping Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Replacement Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Repairs Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Extensions Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Cleaning Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaf Guard Installation Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Tiled Roof Repairs Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Respraying Castlecrag",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal Roof Repairs Castlecrag",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We are the expert in all things roofing, from new roof installations to re-roofing solutions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Recen Castlecrag Roofing Project Photos",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Here are some photos from our recently completed roofing projects from All Pro Roofing Team for our customers in Castlecrag.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Can't find the answer to your question? Give David a call on 0406 620 352 and he will be happy to answer any questions you have.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you service Castlecrag?",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Yes! We proudly serve all suburbs in North Sydney, including Castlecrag. No matter where you\u2019re located within this region, our team is ready to assist with your roofing needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How quickly can you start work in Castlecrag?",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We aim to schedule inspections and start work in Castlecrag as quickly as possible, often within a few days. Availability can vary depending on the scope of the project and our current schedule, but we always strive to accommodate your needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Will there be extra travel costs for Castlecrag?",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "No, we do not charge extra for travel to Castlecrag or any other area within North Sydney. All costs will be outlined in your initial quote, with no hidden fees.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Can you handle local roofing regulations and requirements in Castlecrag?",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Absolutely. We are fully knowledgeable about local roofing regulations in Castlecrag and ensure all our work complies with the relevant standards and requirements.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "How do I get started if I\u2019m in Castlecrag?",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Simply contact us to schedule a free inspection and quote in Castlecrag. We\u2019ll come to your location, assess your roof, and provide you with all the information you need to get started.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Restoration Castlecrag",
                                "main_title": "Roof Restoration Castlecrag",
                                "author": "All Pro Roofing North Sydney",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Trading off the same licence number since 2005!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Unbeatable prices & quality workmanship for all your roofing needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Licence No: 178790c",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Dulux Acratex",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0406620352"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}