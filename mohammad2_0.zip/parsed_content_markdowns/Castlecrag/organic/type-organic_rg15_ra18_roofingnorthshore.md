{
    "id": "01190728-1132-0216-0000-4046df38a488",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0184 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofingnorthshore.com.au/services/castlecrag-nsw-2068/",
        "target": "roofingnorthshore.com.au",
        "start_url": "https://roofingnorthshore.com.au/services/castlecrag-nsw-2068/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castlecrag\\organic\\type-organic_rg15_ra18_roofingnorthshore.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:29:49 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://roofingnorthshore.com.au/roofing-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/roofing-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting and Sealing",
                                    "url": "https://roofingnorthshore.com.au/painting-sealing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/painting-sealing/",
                                            "anchor_text": "Roof Painting and Sealing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement & Reroofing",
                                    "url": "https://roofingnorthshore.com.au/replacement-installation-reroofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/replacement-installation-reroofing/",
                                            "anchor_text": "Roof Replacement & Reroofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://roofingnorthshore.com.au/repointing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair & Replacement",
                                    "url": "https://roofingnorthshore.com.au/gutter-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/gutter-repair-replacement/",
                                            "anchor_text": "Gutter Repair & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation Systems",
                                    "url": "https://roofingnorthshore.com.au/roofing-ventilation-systems/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/roofing-ventilation-systems/",
                                            "anchor_text": "Roof Ventilation Systems"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://roofingnorthshore.com.au/roofing-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/roofing-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting and Sealing",
                                    "url": "https://roofingnorthshore.com.au/painting-sealing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/painting-sealing/",
                                            "anchor_text": "Roof Painting and Sealing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://roofingnorthshore.com.au/repointing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://roofingnorthshore.com.au/roofing-ventilation-systems/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/roofing-ventilation-systems/",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair & Replacement",
                                    "url": "https://roofingnorthshore.com.au/gutter-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/gutter-repair-replacement/",
                                            "anchor_text": "Gutter Repair & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hunters Hill",
                                    "url": "https://roofingnorthshore.com.au/services/hunters-hill-nsw-2110/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/services/hunters-hill-nsw-2110/",
                                            "anchor_text": "Hunters Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lane Cove",
                                    "url": "https://roofingnorthshore.com.au/services/lane-cove-nsw-2066/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/services/lane-cove-nsw-2066/",
                                            "anchor_text": "Lane Cove"
                                        }
                                    ]
                                },
                                {
                                    "text": "Neutral Bay",
                                    "url": "https://roofingnorthshore.com.au/services/neutral-bay-nsw-2089/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/services/neutral-bay-nsw-2089/",
                                            "anchor_text": "Neutral Bay"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Sydney",
                                    "url": "https://roofingnorthshore.com.au/services/north-sydney-nsw-2060/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/services/north-sydney-nsw-2060/",
                                            "anchor_text": "North Sydney"
                                        }
                                    ]
                                },
                                {
                                    "text": "Unit 6/9 Hill St, Roseville NSW 2069",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2026 North Shore Roofing Experts, all rights reserved.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Privacy Policy | Terms and Conditions",
                                    "url": "https://roofingnorthshore.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        },
                                        {
                                            "url": "https://roofingnorthshore.com.au/terms-and-conditions/",
                                            "anchor_text": "Terms and Conditions"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://roofingnorthshore.com.au/roofing-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/roofing-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting and Sealing",
                                    "url": "https://roofingnorthshore.com.au/painting-sealing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/painting-sealing/",
                                            "anchor_text": "Roof Painting and Sealing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement & Reroofing",
                                    "url": "https://roofingnorthshore.com.au/replacement-installation-reroofing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/replacement-installation-reroofing/",
                                            "anchor_text": "Roof Replacement & Reroofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://roofingnorthshore.com.au/repointing/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repair & Replacement",
                                    "url": "https://roofingnorthshore.com.au/gutter-repair-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/gutter-repair-replacement/",
                                            "anchor_text": "Gutter Repair & Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation Systems",
                                    "url": "https://roofingnorthshore.com.au/roofing-ventilation-systems/",
                                    "urls": [
                                        {
                                            "url": "https://roofingnorthshore.com.au/roofing-ventilation-systems/",
                                            "anchor_text": "Roof Ventilation Systems"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "The Best Roof Restoration Contractor In Castlecrag 2068",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We guarantee that you\u2019ll love the results of North Shore Roofing Experts!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We are expert Castlecrag roof restorers",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "[We are an expert roof restoration business servicing clients in all areas of Castlecrag. We are a one-stop shop for all things roof restoration. From broken roof tiles to rusty metal sheets, or severely damaged roofs, we can tackle it all. We work with all types of roofs \u2013 metal, tiled, colorbond, terracotta and more.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter Repair and Replacement",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "If your roof is in poor condition, give us a call! We can discuss a tailored solution for your property that is unlikely to involve a brand-new roof. You\u2019d be amazed at how a restored roof looks very much like a brand new one\u00a0\u2013 at a much more affordable price!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "North Shore Roofing Experts can provide a comprehensive assessment of the current status of your roof and suggest the most cost-effective solution for you.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter Repair and Replacement",
                                        "url": "https://roofingnorthshore.com.au/gutter-repair-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://roofingnorthshore.com.au/gutter-repair-replacement/",
                                                "anchor_text": "Gutter Repair and Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "About Our Roof Restoration Company",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With over 10 years of experience in the roofing sector, North Shore Roofing Experts is proud of outstanding outcomes and many happy customers.\u00a0Our extensive experience includes all sorts of roofing materials: tiled, metal, colorbond, terracotta and more.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a local Castlecrag family-owned small business. We have up-to-date equipment and strictly follow industry best practice and safety standards. We are fully certified and have comprehensive insurance. We employ fully trained and qualified staff including:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof plumbers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof carpenters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof tilers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof painters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof installers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have the finest roof restoration professionals in Castlecrag!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Castlecrag Roof Repair & Restoration \u2013 Our Approach",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We conduct a comprehensive roof assessment",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Report explaining the most cost-efficient and appropriate solution for your house",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We\u2019ll discuss a quote and the required timeframes for restoring your roof",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Upon acceptance of our quotation, we will arrange a suitable date and time to perform the restoration service.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Clean up \u2013 we make sure no mess is left behind!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What type of roof do you restore?",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "We can restore it all! The most common types of roofing found in Castlecrag are tiled roofs, metal, colorbond and terracotta, however, we have repaired innovative roof materials such as rubber or very old material such as shingles. It\u2019s very rare that we\u2019ll find a roof that we can\u2019t tackle. If that happens, there are good chances we can direct your enquiry to other roofing professionals.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Is roof restoration just for traditional roofs?",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "No! Although the word restoration is often associated with historical buildings, antiques and ancient objects; roof restoration applies to modern and sometimes fairly new roofs. In summary, roof restoration is about repairing, re-coating, re-pointing and, more generally, performing jobs that will bring a malfunctional roof to a point where it\u2019s like a brand new one.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Is it better to restore a roof than re-roof?",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "A newlybuilt roof is more expensive. In that sense, roof restoration offers a cost-effective alternative compared to re-roofing. However, when a roof presents structural problems and is in very poor conditions, re-roofing is often the best and only solution. North Shore Roofing Experts usually recommends re-roofing as a \u2018last-resort\u2019 option.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you do storm damage roof inspection and repairs?",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes, we sure do! Storms are easily one of your roof\u2019s most feared enemies! North Shore Roofing Experts can assess your roof and look for any possible damage that may not be visible. We can also restore, repair and wash your roof post-storm.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do you replace roofs that contain asbestos?",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Yes, we sure do! In this case, the first step is to get all asbestos materials safely removed before we lay and fix a new roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Castlecrag Roof Restoration Specialists",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Professional roof restoration in Castlecrag and surrounds. Call North Shore Roofing Experts today!",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Get a FREE Quote Today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We are a one-stop-solution roofing company and our services include all aspects of roof restorations in Castlecrag:",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repair",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": "https://roofingnorthshore.com.au/roofing-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofingnorthshore.com.au/roofing-repairs/",
                                                "anchor_text": "Roof Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Painting and Sealing",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Painting and Sealing",
                                        "url": "https://roofingnorthshore.com.au/painting-sealing/",
                                        "urls": [
                                            {
                                                "url": "https://roofingnorthshore.com.au/painting-sealing/",
                                                "anchor_text": "Roof Painting and Sealing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Roofing (brand new roof)",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Re-Roofing (brand new roof)",
                                        "url": "https://roofingnorthshore.com.au/replacement-installation-reroofing/",
                                        "urls": [
                                            {
                                                "url": "https://roofingnorthshore.com.au/replacement-installation-reroofing/",
                                                "anchor_text": "Re-Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Ventilation Systems",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Ventilation Systems",
                                        "url": "https://roofingnorthshore.com.au/roofing-ventilation-systems/",
                                        "urls": [
                                            {
                                                "url": "https://roofingnorthshore.com.au/roofing-ventilation-systems/",
                                                "anchor_text": "Roof Ventilation Systems"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Re-pointing",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Re-pointing",
                                        "url": "https://roofingnorthshore.com.au/repointing/",
                                        "urls": [
                                            {
                                                "url": "https://roofingnorthshore.com.au/repointing/",
                                                "anchor_text": "Roof Re-pointing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "We Restore Roofs in Castlecrag 2068",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\u2026 and surrounding areas, including:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Willoughby East",
                                        "url": "https://roofingnorthshore.com.au/services/willoughby-east-nsw-2068/",
                                        "urls": [
                                            {
                                                "url": "https://roofingnorthshore.com.au/services/willoughby-east-nsw-2068/",
                                                "anchor_text": "Willoughby East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Middle Cove",
                                        "url": "https://roofingnorthshore.com.au/services/middle-cove-nsw-2068/",
                                        "urls": [
                                            {
                                                "url": "https://roofingnorthshore.com.au/services/middle-cove-nsw-2068/",
                                                "anchor_text": "Middle Cove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Willoughby",
                                        "url": "https://roofingnorthshore.com.au/services/north-willoughby-nsw-2068/",
                                        "urls": [
                                            {
                                                "url": "https://roofingnorthshore.com.au/services/north-willoughby-nsw-2068/",
                                                "anchor_text": "North Willoughby"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Castle Cove",
                                        "url": "https://roofingnorthshore.com.au/services/castle-cove-nsw-2069/",
                                        "urls": [
                                            {
                                                "url": "https://roofingnorthshore.com.au/services/castle-cove-nsw-2069/",
                                                "anchor_text": "Castle Cove"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Other Castlecrag Roofing Services:",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof repairs",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof painting & sealing",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Re-Roofing",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof ventilation systems",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof repointing",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter repairs",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions About Roof Restorations",
                                "main_title": "Castlecrag Roof Restoration Specialists",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61295387320"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}