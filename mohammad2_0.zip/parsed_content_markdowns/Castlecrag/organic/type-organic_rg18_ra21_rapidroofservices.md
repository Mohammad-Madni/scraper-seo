{
    "id": "01190728-1132-0216-0000-829d05afacb6",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0284 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.rapidroofservices.com.au/",
        "target": "www.rapidroofservices.com.au",
        "start_url": "https://www.rapidroofservices.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castlecrag\\organic\\type-organic_rg18_ra21_rapidroofservices.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:47 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.rapidroofservices.com.au/roof-painting-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.rapidroofservices.com.au/roof-painting-sydney",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.rapidroofservices.com.au/leaking-roof-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.rapidroofservices.com.au/leaking-roof-repairs-sydney",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.rapidroofservices.com.au/roof-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.rapidroofservices.com.au/roof-cleaning-sydney",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports",
                                    "url": "https://www.rapidroofservices.com.au/roof-inspections-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.rapidroofservices.com.au/roof-inspections-sydney",
                                            "anchor_text": "Roof Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.rapidroofservices.com.au/roof-painting-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.rapidroofservices.com.au/roof-painting-sydney",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://www.rapidroofservices.com.au/leaking-roof-repairs-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.rapidroofservices.com.au/leaking-roof-repairs-sydney",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.rapidroofservices.com.au/roof-cleaning-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.rapidroofservices.com.au/roof-cleaning-sydney",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports",
                                    "url": "https://www.rapidroofservices.com.au/roof-inspections-sydney",
                                    "urls": [
                                        {
                                            "url": "https://www.rapidroofservices.com.au/roof-inspections-sydney",
                                            "anchor_text": "Roof Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "0423 798 263",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Modern roof restorations in sydney",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "GRAB YOUR FREE QUOTE",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The first step towards increasing your home\u2019s value.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Welcome To Rapid Roof Services",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "As a family-owned business with over 30 years of combined experience, we take pride in delivering unbeatable workmanship and only using industry-leading products.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All our quotes are fully itemised for transparency, and we\u2019ll never push you into work you don\u2019t need - giving you the freedom to ultimately choose the final work carried out. Whether it\u2019s restoring your roof, fixing leaks or installing gutter guards, we\u2019re here to help keep your most valuable asset protected.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "At Rapid Roof Services, we provide professional roof restorations, roof repairs, gutter guard installation, whirlybird installation, roof painting and roof cleaning across Sydney and the Southern Highlands.",
                                        "url": "https://www.rapidroofservices.com.au/leaking-roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.rapidroofservices.com.au/leaking-roof-repairs-sydney",
                                                "anchor_text": "roof repairs"
                                            },
                                            {
                                                "url": "https://www.rapidroofservices.com.au/gutter-guard-installation-sydney",
                                                "anchor_text": "gutter guard installation"
                                            },
                                            {
                                                "url": "https://www.rapidroofservices.com.au/whirlybird-installation-sydney",
                                                "anchor_text": "whirlybird installation"
                                            },
                                            {
                                                "url": "https://www.rapidroofservices.com.au/roof-painting-sydney",
                                                "anchor_text": "roof painting"
                                            },
                                            {
                                                "url": "https://www.rapidroofservices.com.au/roof-cleaning-sydney",
                                                "anchor_text": "roof cleaning"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Our Sydney Roof Restoration Services",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We offer a full range of roofing services to keep your home in optimal condition. Whether you need minor repairs or a complete Sydney roof restoration, our services include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ROOF RESTORATIONS",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ROOF INSPECTIONS & REPORTS",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No matter the size or scope of the job, we use high-quality materials and offer 7-year workmanship on anything we replenish.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "GUTTER GUARD INSTALLATION",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ROOF REPAIRS & CLEANING",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ROOF MAINTENANCE",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "The Sydney Roof Restoration Process",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We\u2019ll inspect your roof, discuss your requirements and provide a free, fully itemised quote, giving you complete control to choose what works are carried out.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Deposit For Larger Jobs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "For bigger projects, we take a deposit to lock in your booking and secure the materials needed to get started.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our experienced team gets to work restoring your roof, which can include, pressure cleaning and making any necessary repairs before sealing and painting your roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Once the job\u2019s complete, we\u2019ll walk you through the finished work and send the final invoice. Your roof is now ready to protect your home.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Site Visit & Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get To Work",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Handover & Final Invoice",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fully Licensed & Insured Roofers In Sydney",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Rapid Roof Services, we\u2019re fully licensed and insured for your complete peace of mind. Choosing a licensed roofer means your home is in safe hands, and you can trust that all work meets industry standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sadly, not all roofers are properly qualified, which can lead to costly mistakes and even roof damage. With us, you\u2019ll get quality workmanship, reliable service and results that stand the test of time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration Before & Afters",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Some recent roofing transformations for local homes around Sydney:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Rapid Roof Services?",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Here\u2019s why Sydney locals choose us for their roof restoration requirements:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Over 30 years of combined roofing experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Family-owned and proudly servicing Sydney and the Southern Highlands",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free, fully itemised quotes for complete transparency. The final decision on what works are carried out is up to you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Honest advice & fair pricing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Industry-leading products with 15\u201320 year warranties on restorations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7-year workmanship guarantee on all replenishment work",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Down-to-earth, reliable service you can trust",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Meet Ryan",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "With over 15 years of roofing experience, Ryan is committed to delivering high-quality results for every client. As the owner and director of Rapid Roof Services, he takes pride in honest advice, unbeatable workmanship and ensuring every roof is restored to the highest standard.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Insurance Roof Restorations & Repairs Sydney",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At Rapid Roof Services, we specialise in insurance roof restorations and insurance roof repairs across Sydney and the Southern Highlands. If your roof has been damaged by storms, hail, fallen trees, or other insured events, we\u2019ll work with you and your insurer to get it fixed fast.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team provides detailed roof inspections, comprehensive reports for your claim, and high-quality repairs or full restorations using durable materials. We make the process simple and stress-free\u2014get in touch today to find out how we can help with your insurance roof repair.",
                                        "url": "https://www.rapidroofservices.com.au/roof-inspections-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.rapidroofservices.com.au/roof-inspections-sydney",
                                                "anchor_text": "roof inspections"
                                            },
                                            {
                                                "url": "https://www.rapidroofservices.com.au/roof-inspections-sydney",
                                                "anchor_text": "comprehensive reports"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "OUR PARTNERS \ufeff",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Top quality.",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We strictly use the best products to ensure quality isn't left to chance.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Hear From Our Sydney Roofing Clients.",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Real reviews from Sydney customers who trust Rapid Roof Services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "\ufeff On Our Instagram",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Back at it for 2026! Currently taking restore bookings for March & April onwards this year \ud83c\udfa8If you\u2019re interested in your roof going from Zero to Hero \ud83d\udcaa contact us via contact info in our bio. 10% off any restores booked for March onwards \ud83d\udcdd",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Restore Complete \u2705 Affected tiles replaced \u2714\ufe0f\nRoof Washed \u2714\ufe0f Ridging repointed and starters rebedded \u2714\ufe0f Spray one coat of RTR Terracotta Roof primer \u2714\ufe0f Spray two coats of RTR 15 year warranty membrane \u2714\ufe0f \ud83d\udee1\ufe0f MONUMENT FINISH \ud83c\udfa8 Sydney and the highlands #1 roof restorers Call OR email today for your quote \ud83d\udcde 0423798263 \ud83d\udce7 ryan@rapidroofservices.com.au",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Restore Complete \u2705 Affected tiles replaced \u2714\ufe0f\nRoof Washed \u2714\ufe0f Ridging repointed and starters receded \u2714\ufe0f Skylight protective sheeted \u2714\ufe0f Spray one coat of RTR Roof primer \u2714\ufe0f Spray two coats of RTR 15 year warranty membrane \u2714\ufe0f \ud83d\udee1\ufe0f SHALE GREY FINISH \ud83c\udfa8 Sydney and the highlands #1 roof restorers Call OR email today for your quote \ud83d\udcde 0423798263 \ud83d\udce7 ryan@rapidroofservices.com.au",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Terracotta clean, point and repair on point \ud83d\udc4c",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "1 (current)",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How long does a roof restoration take?",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "Most roof restorations take between 2\u20134 days, depending on the size and condition of your roof. Weather conditions and the scope of work, such as repairs or painting, can also affect the timeline. We\u2019ll give you a clear schedule before starting so you know what to expect.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Do I need to leave my home during the restoration?",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "No, you can stay in your home while we complete the restoration. Our team works safely and efficiently to minimise disruption. We\u2019ll let you know if there are times when access might be limited, like during cleaning or painting.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What\u2019s included in a roof restoration?",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "A roof restoration can involve cleaning, repairing, and repainting your roof to restore its condition and extend its life. All work is outlined in a fully itemised quote, with the final decision about what work will be completed left up to the client.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best Roof Paint Colours",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Discover the best roof paint colours for Australian homes, including modern, coastal and classic options, plus tips for choosing the right shade.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Best Roof Paint Colours",
                                        "url": "https://www.rapidroofservices.com.au/best-roof-paint-colours",
                                        "urls": [
                                            {
                                                "url": "https://www.rapidroofservices.com.au/best-roof-paint-colours",
                                                "anchor_text": "Best Roof Paint Colours"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How Often Should You Clean Your Roof?",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "How often should you clean your roof? Learn the ideal cleaning frequency, key benefits, and when to book professional roof cleaning in Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "How Often Should You Clean Your Roof?",
                                        "url": "https://www.rapidroofservices.com.au/how-often-should-you-clean-your-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.rapidroofservices.com.au/how-often-should-you-clean-your-roof",
                                                "anchor_text": "How Often Should You Clean Your Roof?"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How to clean a Colorbond roof",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Discover how to safely clean a Colorbond roof, remove dirt and mould, and protect your steel roofing with proper washing and maintenance tips.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "How to clean a Colorbond roof",
                                        "url": "https://www.rapidroofservices.com.au/how-to-clean-a-colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.rapidroofservices.com.au/how-to-clean-a-colorbond-roof",
                                                "anchor_text": "How to clean a Colorbond roof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "1 (current)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "FOLLOW US ON SOCIAL MEDIA",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "License Number: 245603C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "License Number: 288398C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "SERVICE AREAS",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Moss Vale",
                                        "url": "https://www.rapidroofservices.com.au/roof-restoration-moss-vale",
                                        "urls": [
                                            {
                                                "url": "https://www.rapidroofservices.com.au/roof-restoration-moss-vale",
                                                "anchor_text": "Moss Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Castle Hill",
                                        "url": "https://www.rapidroofservices.com.au/roof-repairs-castle-hill",
                                        "urls": [
                                            {
                                                "url": "https://www.rapidroofservices.com.au/roof-repairs-castle-hill",
                                                "anchor_text": "Castle Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "QUICK LINKS",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OUR SERVICES \ufeff",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://www.rapidroofservices.com.au/roof-painting-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.rapidroofservices.com.au/roof-painting-sydney",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://www.rapidroofservices.com.au/leaking-roof-repairs-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.rapidroofservices.com.au/leaking-roof-repairs-sydney",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Reports",
                                        "url": "https://www.rapidroofservices.com.au/roof-inspections-sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.rapidroofservices.com.au/roof-inspections-sydney",
                                                "anchor_text": "Roof Reports"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "CONTACT INFORMATION",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Address: Sydney, NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email: ryan@rapidroofservices.com.au",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Phone: 0423 798 263",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u00a9 2025 All Rights Reserved | Rapid Roof Services",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Contact Us",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "30 +",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Years of Experience",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Best brands.",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Check Out A Few Roof Restorations",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Answers to Common Questions",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration FAQs",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Check Out Our Roof Restoration Blog",
                                "main_title": "Modern roof restorations in sydney",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0423 798 263"
                            ],
                            "emails": [
                                "ryan@rapidroofservices.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}