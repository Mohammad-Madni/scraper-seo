{
    "id": "01190728-1132-0216-0000-5c2babbc7169",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0219 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://bakerroofing.com.au/roofers-in-castlecrag/",
        "target": "bakerroofing.com.au",
        "start_url": "https://bakerroofing.com.au/roofers-in-castlecrag/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castlecrag\\organic\\type-organic_rg5_ra8_bakerroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:50 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://bakerroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://bakerroofing.com.au/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Installation",
                                    "url": "https://bakerroofing.com.au/new-roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/new-roof-installation/",
                                            "anchor_text": "New Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://bakerroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://bakerroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://bakerroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://bakerroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://bakerroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://bakerroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://bakerroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Make Safes",
                                    "url": "https://bakerroofing.com.au/make-safes/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/make-safes/",
                                            "anchor_text": "Make Safes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Rebedding",
                                    "url": "https://bakerroofing.com.au/roof-rebedding/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-rebedding/",
                                            "anchor_text": "Roof Rebedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Insulation",
                                    "url": "https://bakerroofing.com.au/roof-insulation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-insulation/",
                                            "anchor_text": "Roof Insulation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panel Roofing",
                                    "url": "https://bakerroofing.com.au/solar-panel-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/solar-panel-roofing/",
                                            "anchor_text": "Solar Panel Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://bakerroofing.com.au/roof-ventilation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-ventilation/",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Waterproofing",
                                    "url": "https://bakerroofing.com.au/roof-waterproofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-waterproofing/",
                                            "anchor_text": "Roof Waterproofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://bakerroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://bakerroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://bakerroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://bakerroofing.com.au/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roof Restoration",
                                    "url": "https://bakerroofing.com.au/terracotta-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roof-restoration/",
                                            "anchor_text": "Terracotta Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://bakerroofing.com.au/tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roof-restoration/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roof Repairs",
                                    "url": "https://bakerroofing.com.au/terracotta-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roof-repairs/",
                                            "anchor_text": "Terracotta Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repairs",
                                    "url": "https://bakerroofing.com.au/metal-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roof-repairs/",
                                            "anchor_text": "Metal Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://bakerroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pressure Cleaning",
                                    "url": "https://bakerroofing.com.au/roof-pressure-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-pressure-cleaning/",
                                            "anchor_text": "Roof Pressure Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://bakerroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://bakerroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://bakerroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Safety Inspections",
                                    "url": "https://bakerroofing.com.au/roof-safety-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-safety-inspections/",
                                            "anchor_text": "Roof Safety Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard Installation",
                                    "url": "https://bakerroofing.com.au/gutter-guard-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-guard-installation/",
                                            "anchor_text": "Gutter Guard Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fascia and Soffit Installation",
                                    "url": "https://bakerroofing.com.au/fascia-soffit-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/fascia-soffit-installation/",
                                            "anchor_text": "Fascia and Soffit Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repairs",
                                    "url": "https://bakerroofing.com.au/downpipe-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/downpipe-repairs/",
                                            "anchor_text": "Downpipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Installation",
                                    "url": "https://bakerroofing.com.au/downpipe-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/downpipe-installation/",
                                            "anchor_text": "Downpipe Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://bakerroofing.com.au/gutter-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-repairs/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://bakerroofing.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://bakerroofing.com.au/gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-replacement/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://bakerroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://bakerroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://bakerroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roof Restoration",
                                    "url": "https://bakerroofing.com.au/heritage-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/heritage-roof-restoration/",
                                            "anchor_text": "Heritage Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata Roofing",
                                    "url": "https://bakerroofing.com.au/strata-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/strata-roofing/",
                                            "anchor_text": "Strata Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Industrial Roofing",
                                    "url": "https://bakerroofing.com.au/industrial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/industrial-roofing/",
                                            "anchor_text": "Industrial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Chimney Repairs",
                                    "url": "https://bakerroofing.com.au/chimney-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/chimney-repairs/",
                                            "anchor_text": "Chimney Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing Installation",
                                    "url": "https://bakerroofing.com.au/roof-flashing-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-flashing-installation/",
                                            "anchor_text": "Roof Flashing Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports",
                                    "url": "https://bakerroofing.com.au/roof-reports/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-reports/",
                                            "anchor_text": "Roof Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ridge Capping",
                                    "url": "https://bakerroofing.com.au/roof-ridge-capping/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-ridge-capping/",
                                            "anchor_text": "Roof Ridge Capping"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Safety Rails",
                                    "url": "https://bakerroofing.com.au/roof-safety-rails/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-safety-rails/",
                                            "anchor_text": "Roof Safety Rails"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Sarking Installation",
                                    "url": "https://bakerroofing.com.au/roof-sarking-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-sarking-installation/",
                                            "anchor_text": "Roof Sarking Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://bakerroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://bakerroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Renovation",
                                    "url": "https://bakerroofing.com.au/roof-renovation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-renovation/",
                                            "anchor_text": "Roof Renovation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://bakerroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://bakerroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://bakerroofing.com.au/roofing-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Hills District",
                                    "url": "https://bakerroofing.com.au/roofing-the-hills-district/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-the-hills-district/",
                                            "anchor_text": "The Hills District"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://bakerroofing.com.au/roofing-northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hunters Hill",
                                    "url": "https://bakerroofing.com.au/roofers-in-hunters-hill/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-hunters-hill/",
                                            "anchor_text": "Hunters Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney CBD",
                                    "url": "https://bakerroofing.com.au/roofing-sydney-cbd/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-sydney-cbd/",
                                            "anchor_text": "Sydney CBD"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://bakerroofing.com.au/roofing-sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balwyn North",
                                    "url": "https://bakerroofing.com.au/roofers-in-balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-balwyn-north/",
                                            "anchor_text": "Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Hill South",
                                    "url": "https://bakerroofing.com.au/roofers-in-box-hill-south/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-box-hill-south/",
                                            "anchor_text": "Box Hill South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Brighton East",
                                    "url": "https://bakerroofing.com.au/roofers-in-brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-brighton-east/",
                                            "anchor_text": "Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Glen Iris",
                                    "url": "https://bakerroofing.com.au/roofers-in-glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-glen-iris/",
                                            "anchor_text": "Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surrey Hill",
                                    "url": "https://bakerroofing.com.au/roofers-in-surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-surrey-hills/",
                                            "anchor_text": "Surrey Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Inner City Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-inner-city-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-inner-city-brisbane/",
                                            "anchor_text": "Roofers Inner City Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wavell Heights",
                                    "url": "https://bakerroofing.com.au/roofers-in-wavell-heights/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-wavell-heights/",
                                            "anchor_text": "Wavell Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers South Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-south-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-south-brisbane/",
                                            "anchor_text": "Roofers South Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fig Tree Pocket",
                                    "url": "https://bakerroofing.com.au/roofers-in-fig-tree-pocket/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-fig-tree-pocket/",
                                            "anchor_text": "Fig Tree Pocket"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North West Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-north-west-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-north-west-brisbane/",
                                            "anchor_text": "Roofers North West Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://bakerroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://bakerroofing.com.au/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Installation",
                                    "url": "https://bakerroofing.com.au/new-roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/new-roof-installation/",
                                            "anchor_text": "New Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://bakerroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://bakerroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://bakerroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://bakerroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://bakerroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://bakerroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://bakerroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Make Safes",
                                    "url": "https://bakerroofing.com.au/make-safes/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/make-safes/",
                                            "anchor_text": "Make Safes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Rebedding",
                                    "url": "https://bakerroofing.com.au/roof-rebedding/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-rebedding/",
                                            "anchor_text": "Roof Rebedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Insulation",
                                    "url": "https://bakerroofing.com.au/roof-insulation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-insulation/",
                                            "anchor_text": "Roof Insulation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panel Roofing",
                                    "url": "https://bakerroofing.com.au/solar-panel-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/solar-panel-roofing/",
                                            "anchor_text": "Solar Panel Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://bakerroofing.com.au/roof-ventilation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-ventilation/",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Waterproofing",
                                    "url": "https://bakerroofing.com.au/roof-waterproofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-waterproofing/",
                                            "anchor_text": "Roof Waterproofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://bakerroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://bakerroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://bakerroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://bakerroofing.com.au/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roof Restoration",
                                    "url": "https://bakerroofing.com.au/terracotta-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roof-restoration/",
                                            "anchor_text": "Terracotta Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://bakerroofing.com.au/tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roof-restoration/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roof Repairs",
                                    "url": "https://bakerroofing.com.au/terracotta-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roof-repairs/",
                                            "anchor_text": "Terracotta Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repairs",
                                    "url": "https://bakerroofing.com.au/metal-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roof-repairs/",
                                            "anchor_text": "Metal Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://bakerroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pressure Cleaning",
                                    "url": "https://bakerroofing.com.au/roof-pressure-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-pressure-cleaning/",
                                            "anchor_text": "Roof Pressure Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://bakerroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://bakerroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://bakerroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Safety Inspections",
                                    "url": "https://bakerroofing.com.au/roof-safety-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-safety-inspections/",
                                            "anchor_text": "Roof Safety Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard Installation",
                                    "url": "https://bakerroofing.com.au/gutter-guard-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-guard-installation/",
                                            "anchor_text": "Gutter Guard Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fascia and Soffit Installation",
                                    "url": "https://bakerroofing.com.au/fascia-soffit-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/fascia-soffit-installation/",
                                            "anchor_text": "Fascia and Soffit Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repairs",
                                    "url": "https://bakerroofing.com.au/downpipe-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/downpipe-repairs/",
                                            "anchor_text": "Downpipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Installation",
                                    "url": "https://bakerroofing.com.au/downpipe-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/downpipe-installation/",
                                            "anchor_text": "Downpipe Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://bakerroofing.com.au/gutter-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-repairs/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://bakerroofing.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://bakerroofing.com.au/gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-replacement/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://bakerroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://bakerroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://bakerroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roof Restoration",
                                    "url": "https://bakerroofing.com.au/heritage-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/heritage-roof-restoration/",
                                            "anchor_text": "Heritage Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata Roofing",
                                    "url": "https://bakerroofing.com.au/strata-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/strata-roofing/",
                                            "anchor_text": "Strata Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Industrial Roofing",
                                    "url": "https://bakerroofing.com.au/industrial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/industrial-roofing/",
                                            "anchor_text": "Industrial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Chimney Repairs",
                                    "url": "https://bakerroofing.com.au/chimney-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/chimney-repairs/",
                                            "anchor_text": "Chimney Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing Installation",
                                    "url": "https://bakerroofing.com.au/roof-flashing-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-flashing-installation/",
                                            "anchor_text": "Roof Flashing Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports",
                                    "url": "https://bakerroofing.com.au/roof-reports/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-reports/",
                                            "anchor_text": "Roof Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ridge Capping",
                                    "url": "https://bakerroofing.com.au/roof-ridge-capping/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-ridge-capping/",
                                            "anchor_text": "Roof Ridge Capping"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Safety Rails",
                                    "url": "https://bakerroofing.com.au/roof-safety-rails/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-safety-rails/",
                                            "anchor_text": "Roof Safety Rails"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Sarking Installation",
                                    "url": "https://bakerroofing.com.au/roof-sarking-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-sarking-installation/",
                                            "anchor_text": "Roof Sarking Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://bakerroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://bakerroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Renovation",
                                    "url": "https://bakerroofing.com.au/roof-renovation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-renovation/",
                                            "anchor_text": "Roof Renovation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://bakerroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://bakerroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://bakerroofing.com.au/roofing-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Hills District",
                                    "url": "https://bakerroofing.com.au/roofing-the-hills-district/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-the-hills-district/",
                                            "anchor_text": "The Hills District"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://bakerroofing.com.au/roofing-northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hunters Hill",
                                    "url": "https://bakerroofing.com.au/roofers-in-hunters-hill/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-hunters-hill/",
                                            "anchor_text": "Hunters Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney CBD",
                                    "url": "https://bakerroofing.com.au/roofing-sydney-cbd/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-sydney-cbd/",
                                            "anchor_text": "Sydney CBD"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://bakerroofing.com.au/roofing-sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balwyn North",
                                    "url": "https://bakerroofing.com.au/roofers-in-balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-balwyn-north/",
                                            "anchor_text": "Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Hill South",
                                    "url": "https://bakerroofing.com.au/roofers-in-box-hill-south/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-box-hill-south/",
                                            "anchor_text": "Box Hill South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Brighton East",
                                    "url": "https://bakerroofing.com.au/roofers-in-brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-brighton-east/",
                                            "anchor_text": "Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Glen Iris",
                                    "url": "https://bakerroofing.com.au/roofers-in-glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-glen-iris/",
                                            "anchor_text": "Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surrey Hill",
                                    "url": "https://bakerroofing.com.au/roofers-in-surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-surrey-hills/",
                                            "anchor_text": "Surrey Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Inner City Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-inner-city-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-inner-city-brisbane/",
                                            "anchor_text": "Roofers Inner City Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wavell Heights",
                                    "url": "https://bakerroofing.com.au/roofers-in-wavell-heights/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-wavell-heights/",
                                            "anchor_text": "Wavell Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers South Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-south-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-south-brisbane/",
                                            "anchor_text": "Roofers South Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fig Tree Pocket",
                                    "url": "https://bakerroofing.com.au/roofers-in-fig-tree-pocket/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-fig-tree-pocket/",
                                            "anchor_text": "Fig Tree Pocket"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North West Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-north-west-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-north-west-brisbane/",
                                            "anchor_text": "Roofers North West Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://bakerroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://bakerroofing.com.au/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Installation",
                                    "url": "https://bakerroofing.com.au/new-roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/new-roof-installation/",
                                            "anchor_text": "New Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://bakerroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://bakerroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://bakerroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://bakerroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://bakerroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://bakerroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://bakerroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Make Safes",
                                    "url": "https://bakerroofing.com.au/make-safes/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/make-safes/",
                                            "anchor_text": "Make Safes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Rebedding",
                                    "url": "https://bakerroofing.com.au/roof-rebedding/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-rebedding/",
                                            "anchor_text": "Roof Rebedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Insulation",
                                    "url": "https://bakerroofing.com.au/roof-insulation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-insulation/",
                                            "anchor_text": "Roof Insulation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panel Roofing",
                                    "url": "https://bakerroofing.com.au/solar-panel-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/solar-panel-roofing/",
                                            "anchor_text": "Solar Panel Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://bakerroofing.com.au/roof-ventilation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-ventilation/",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Waterproofing",
                                    "url": "https://bakerroofing.com.au/roof-waterproofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-waterproofing/",
                                            "anchor_text": "Roof Waterproofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://bakerroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://bakerroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://bakerroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://bakerroofing.com.au/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roof Restoration",
                                    "url": "https://bakerroofing.com.au/terracotta-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roof-restoration/",
                                            "anchor_text": "Terracotta Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://bakerroofing.com.au/tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roof-restoration/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roof Repairs",
                                    "url": "https://bakerroofing.com.au/terracotta-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roof-repairs/",
                                            "anchor_text": "Terracotta Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repairs",
                                    "url": "https://bakerroofing.com.au/metal-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roof-repairs/",
                                            "anchor_text": "Metal Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://bakerroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pressure Cleaning",
                                    "url": "https://bakerroofing.com.au/roof-pressure-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-pressure-cleaning/",
                                            "anchor_text": "Roof Pressure Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://bakerroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://bakerroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://bakerroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Safety Inspections",
                                    "url": "https://bakerroofing.com.au/roof-safety-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-safety-inspections/",
                                            "anchor_text": "Roof Safety Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard Installation",
                                    "url": "https://bakerroofing.com.au/gutter-guard-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-guard-installation/",
                                            "anchor_text": "Gutter Guard Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fascia and Soffit Installation",
                                    "url": "https://bakerroofing.com.au/fascia-soffit-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/fascia-soffit-installation/",
                                            "anchor_text": "Fascia and Soffit Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repairs",
                                    "url": "https://bakerroofing.com.au/downpipe-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/downpipe-repairs/",
                                            "anchor_text": "Downpipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Installation",
                                    "url": "https://bakerroofing.com.au/downpipe-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/downpipe-installation/",
                                            "anchor_text": "Downpipe Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://bakerroofing.com.au/gutter-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-repairs/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://bakerroofing.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://bakerroofing.com.au/gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-replacement/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://bakerroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://bakerroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://bakerroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roof Restoration",
                                    "url": "https://bakerroofing.com.au/heritage-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/heritage-roof-restoration/",
                                            "anchor_text": "Heritage Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata Roofing",
                                    "url": "https://bakerroofing.com.au/strata-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/strata-roofing/",
                                            "anchor_text": "Strata Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Industrial Roofing",
                                    "url": "https://bakerroofing.com.au/industrial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/industrial-roofing/",
                                            "anchor_text": "Industrial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Chimney Repairs",
                                    "url": "https://bakerroofing.com.au/chimney-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/chimney-repairs/",
                                            "anchor_text": "Chimney Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing Installation",
                                    "url": "https://bakerroofing.com.au/roof-flashing-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-flashing-installation/",
                                            "anchor_text": "Roof Flashing Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports",
                                    "url": "https://bakerroofing.com.au/roof-reports/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-reports/",
                                            "anchor_text": "Roof Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ridge Capping",
                                    "url": "https://bakerroofing.com.au/roof-ridge-capping/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-ridge-capping/",
                                            "anchor_text": "Roof Ridge Capping"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Safety Rails",
                                    "url": "https://bakerroofing.com.au/roof-safety-rails/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-safety-rails/",
                                            "anchor_text": "Roof Safety Rails"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Sarking Installation",
                                    "url": "https://bakerroofing.com.au/roof-sarking-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-sarking-installation/",
                                            "anchor_text": "Roof Sarking Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://bakerroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://bakerroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Renovation",
                                    "url": "https://bakerroofing.com.au/roof-renovation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-renovation/",
                                            "anchor_text": "Roof Renovation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://bakerroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://bakerroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://bakerroofing.com.au/roofing-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Hills District",
                                    "url": "https://bakerroofing.com.au/roofing-the-hills-district/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-the-hills-district/",
                                            "anchor_text": "The Hills District"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://bakerroofing.com.au/roofing-northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hunters Hill",
                                    "url": "https://bakerroofing.com.au/roofers-in-hunters-hill/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-hunters-hill/",
                                            "anchor_text": "Hunters Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney CBD",
                                    "url": "https://bakerroofing.com.au/roofing-sydney-cbd/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-sydney-cbd/",
                                            "anchor_text": "Sydney CBD"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://bakerroofing.com.au/roofing-sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balwyn North",
                                    "url": "https://bakerroofing.com.au/roofers-in-balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-balwyn-north/",
                                            "anchor_text": "Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Hill South",
                                    "url": "https://bakerroofing.com.au/roofers-in-box-hill-south/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-box-hill-south/",
                                            "anchor_text": "Box Hill South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Brighton East",
                                    "url": "https://bakerroofing.com.au/roofers-in-brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-brighton-east/",
                                            "anchor_text": "Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Glen Iris",
                                    "url": "https://bakerroofing.com.au/roofers-in-glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-glen-iris/",
                                            "anchor_text": "Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surrey Hill",
                                    "url": "https://bakerroofing.com.au/roofers-in-surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-surrey-hills/",
                                            "anchor_text": "Surrey Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Inner City Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-inner-city-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-inner-city-brisbane/",
                                            "anchor_text": "Roofers Inner City Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wavell Heights",
                                    "url": "https://bakerroofing.com.au/roofers-in-wavell-heights/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-wavell-heights/",
                                            "anchor_text": "Wavell Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers South Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-south-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-south-brisbane/",
                                            "anchor_text": "Roofers South Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fig Tree Pocket",
                                    "url": "https://bakerroofing.com.au/roofers-in-fig-tree-pocket/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-fig-tree-pocket/",
                                            "anchor_text": "Fig Tree Pocket"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North West Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-north-west-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-north-west-brisbane/",
                                            "anchor_text": "Roofers North West Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://bakerroofing.com.au/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Inspections",
                                    "url": "https://bakerroofing.com.au/roof-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-inspections/",
                                            "anchor_text": "Roof Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "New Roof Installation",
                                    "url": "https://bakerroofing.com.au/new-roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/new-roof-installation/",
                                            "anchor_text": "New Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://bakerroofing.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Colorbond Roofing",
                                    "url": "https://bakerroofing.com.au/colorbond-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/colorbond-roofing/",
                                            "anchor_text": "Colorbond Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roofing",
                                    "url": "https://bakerroofing.com.au/terracotta-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roofing/",
                                            "anchor_text": "Terracotta Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roofing",
                                    "url": "https://bakerroofing.com.au/tile-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roofing/",
                                            "anchor_text": "Tile Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://bakerroofing.com.au/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://bakerroofing.com.au/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://bakerroofing.com.au/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Make Safes",
                                    "url": "https://bakerroofing.com.au/make-safes/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/make-safes/",
                                            "anchor_text": "Make Safes"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Rebedding",
                                    "url": "https://bakerroofing.com.au/roof-rebedding/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-rebedding/",
                                            "anchor_text": "Roof Rebedding"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Insulation",
                                    "url": "https://bakerroofing.com.au/roof-insulation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-insulation/",
                                            "anchor_text": "Roof Insulation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Panel Roofing",
                                    "url": "https://bakerroofing.com.au/solar-panel-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/solar-panel-roofing/",
                                            "anchor_text": "Solar Panel Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ventilation",
                                    "url": "https://bakerroofing.com.au/roof-ventilation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-ventilation/",
                                            "anchor_text": "Roof Ventilation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Waterproofing",
                                    "url": "https://bakerroofing.com.au/roof-waterproofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-waterproofing/",
                                            "anchor_text": "Roof Waterproofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://bakerroofing.com.au/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Storm Damage Repairs",
                                    "url": "https://bakerroofing.com.au/storm-damage-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/storm-damage-repairs/",
                                            "anchor_text": "Storm Damage Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Skylight Installation",
                                    "url": "https://bakerroofing.com.au/skylight-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/skylight-installation/",
                                            "anchor_text": "Skylight Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Restoration",
                                    "url": "https://bakerroofing.com.au/metal-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roof-restoration/",
                                            "anchor_text": "Metal Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roof Restoration",
                                    "url": "https://bakerroofing.com.au/terracotta-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roof-restoration/",
                                            "anchor_text": "Terracotta Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Restoration",
                                    "url": "https://bakerroofing.com.au/tile-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roof-restoration/",
                                            "anchor_text": "Tile Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Terracotta Roof Repairs",
                                    "url": "https://bakerroofing.com.au/terracotta-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/terracotta-roof-repairs/",
                                            "anchor_text": "Terracotta Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roof Repairs",
                                    "url": "https://bakerroofing.com.au/metal-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/metal-roof-repairs/",
                                            "anchor_text": "Metal Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tile Roof Repairs",
                                    "url": "https://bakerroofing.com.au/tile-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/tile-roof-repairs/",
                                            "anchor_text": "Tile Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Pressure Cleaning",
                                    "url": "https://bakerroofing.com.au/roof-pressure-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-pressure-cleaning/",
                                            "anchor_text": "Roof Pressure Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://bakerroofing.com.au/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://bakerroofing.com.au/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Maintenance",
                                    "url": "https://bakerroofing.com.au/roof-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-maintenance/",
                                            "anchor_text": "Roof Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Safety Inspections",
                                    "url": "https://bakerroofing.com.au/roof-safety-inspections/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-safety-inspections/",
                                            "anchor_text": "Roof Safety Inspections"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Guard Installation",
                                    "url": "https://bakerroofing.com.au/gutter-guard-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-guard-installation/",
                                            "anchor_text": "Gutter Guard Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fascia and Soffit Installation",
                                    "url": "https://bakerroofing.com.au/fascia-soffit-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/fascia-soffit-installation/",
                                            "anchor_text": "Fascia and Soffit Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repairs",
                                    "url": "https://bakerroofing.com.au/downpipe-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/downpipe-repairs/",
                                            "anchor_text": "Downpipe Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Installation",
                                    "url": "https://bakerroofing.com.au/downpipe-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/downpipe-installation/",
                                            "anchor_text": "Downpipe Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Repairs",
                                    "url": "https://bakerroofing.com.au/gutter-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-repairs/",
                                            "anchor_text": "Gutter Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://bakerroofing.com.au/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Replacement",
                                    "url": "https://bakerroofing.com.au/gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-replacement/",
                                            "anchor_text": "Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Installation",
                                    "url": "https://bakerroofing.com.au/gutter-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/gutter-installation/",
                                            "anchor_text": "Gutter Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://bakerroofing.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roofing",
                                    "url": "https://bakerroofing.com.au/residential-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/residential-roofing/",
                                            "anchor_text": "Residential Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heritage Roof Restoration",
                                    "url": "https://bakerroofing.com.au/heritage-roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/heritage-roof-restoration/",
                                            "anchor_text": "Heritage Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Strata Roofing",
                                    "url": "https://bakerroofing.com.au/strata-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/strata-roofing/",
                                            "anchor_text": "Strata Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Industrial Roofing",
                                    "url": "https://bakerroofing.com.au/industrial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/industrial-roofing/",
                                            "anchor_text": "Industrial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Chimney Repairs",
                                    "url": "https://bakerroofing.com.au/chimney-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/chimney-repairs/",
                                            "anchor_text": "Chimney Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Flashing Installation",
                                    "url": "https://bakerroofing.com.au/roof-flashing-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-flashing-installation/",
                                            "anchor_text": "Roof Flashing Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Reports",
                                    "url": "https://bakerroofing.com.au/roof-reports/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-reports/",
                                            "anchor_text": "Roof Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Ridge Capping",
                                    "url": "https://bakerroofing.com.au/roof-ridge-capping/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-ridge-capping/",
                                            "anchor_text": "Roof Ridge Capping"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Safety Rails",
                                    "url": "https://bakerroofing.com.au/roof-safety-rails/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-safety-rails/",
                                            "anchor_text": "Roof Safety Rails"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Sarking Installation",
                                    "url": "https://bakerroofing.com.au/roof-sarking-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-sarking-installation/",
                                            "anchor_text": "Roof Sarking Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Whirlybird Installation",
                                    "url": "https://bakerroofing.com.au/whirlybird-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/whirlybird-installation/",
                                            "anchor_text": "Whirlybird Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://bakerroofing.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Renovation",
                                    "url": "https://bakerroofing.com.au/roof-renovation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-renovation/",
                                            "anchor_text": "Roof Renovation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Installation",
                                    "url": "https://bakerroofing.com.au/roof-installation/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roof-installation/",
                                            "anchor_text": "Roof Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://bakerroofing.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Eastern Suburbs",
                                    "url": "https://bakerroofing.com.au/roofing-eastern-suburbs/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-eastern-suburbs/",
                                            "anchor_text": "Eastern Suburbs"
                                        }
                                    ]
                                },
                                {
                                    "text": "The Hills District",
                                    "url": "https://bakerroofing.com.au/roofing-the-hills-district/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-the-hills-district/",
                                            "anchor_text": "The Hills District"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://bakerroofing.com.au/roofing-northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hunters Hill",
                                    "url": "https://bakerroofing.com.au/roofers-in-hunters-hill/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-hunters-hill/",
                                            "anchor_text": "Hunters Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney CBD",
                                    "url": "https://bakerroofing.com.au/roofing-sydney-cbd/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-sydney-cbd/",
                                            "anchor_text": "Sydney CBD"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://bakerroofing.com.au/roofing-sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofing-sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Balwyn North",
                                    "url": "https://bakerroofing.com.au/roofers-in-balwyn-north/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-balwyn-north/",
                                            "anchor_text": "Balwyn North"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Hill South",
                                    "url": "https://bakerroofing.com.au/roofers-in-box-hill-south/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-box-hill-south/",
                                            "anchor_text": "Box Hill South"
                                        }
                                    ]
                                },
                                {
                                    "text": "Brighton East",
                                    "url": "https://bakerroofing.com.au/roofers-in-brighton-east/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-brighton-east/",
                                            "anchor_text": "Brighton East"
                                        }
                                    ]
                                },
                                {
                                    "text": "Glen Iris",
                                    "url": "https://bakerroofing.com.au/roofers-in-glen-iris/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-glen-iris/",
                                            "anchor_text": "Glen Iris"
                                        }
                                    ]
                                },
                                {
                                    "text": "Surrey Hill",
                                    "url": "https://bakerroofing.com.au/roofers-in-surrey-hills/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-surrey-hills/",
                                            "anchor_text": "Surrey Hill"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers Inner City Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-inner-city-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-inner-city-brisbane/",
                                            "anchor_text": "Roofers Inner City Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wavell Heights",
                                    "url": "https://bakerroofing.com.au/roofers-in-wavell-heights/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-wavell-heights/",
                                            "anchor_text": "Wavell Heights"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers South Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-south-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-south-brisbane/",
                                            "anchor_text": "Roofers South Brisbane"
                                        }
                                    ]
                                },
                                {
                                    "text": "Fig Tree Pocket",
                                    "url": "https://bakerroofing.com.au/roofers-in-fig-tree-pocket/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-in-fig-tree-pocket/",
                                            "anchor_text": "Fig Tree Pocket"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roofers North West Brisbane",
                                    "url": "https://bakerroofing.com.au/roofers-north-west-brisbane/",
                                    "urls": [
                                        {
                                            "url": "https://bakerroofing.com.au/roofers-north-west-brisbane/",
                                            "anchor_text": "Roofers North West Brisbane"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Expert Roofers in Castlecrag: Quality Roofing Solutions",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Castlecrag, with its distinct homes and variable weather conditions, requires the expertise of seasoned roofers who understand the local landscape. Baker Roofing stands out as the go-to provider of quality roofing solutions in the area. Our team of expert roofers in Castlecrag is equipped with the knowledge and experience to handle roofing projects of any scale, ensuring that your home remains protected and looks great throughout the year.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our services are comprehensive, covering everything from routine maintenance to complete roof overhauls. Whether it\u2019s repairing leaks, replacing shingles, or installing entirely new roofing systems, our professionals work with precision and care. Utilizing the best materials in the industry, we guarantee durability and efficiency. Baker Roofing\u2019s commitment to excellence makes us the preferred choice among homeowners in Castlecrag.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Understanding the importance of your home\u2019s appearance and safety, our team conducts thorough assessments to identify potential issues before they escalate. This proactive approach allows us to offer tailored solutions that meet the unique needs of each Castlecrag residence. From contemporary designs to traditional aesthetics, our roofing projects are completed with an eye for detail and a commitment to customer satisfaction.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Comprehensive Roofing Services by Castlecrag\u2019s Best Roofers",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to securing premium roofing services in Castlecrag, Baker Roofing stands as the unequivocal leader. Our team of seasoned professionals is committed to providing a full spectrum of roofing services, ensuring that every client receives a solution perfectly tailored to their needs. From routine inspections and maintenance to complete roof overhauls, our expertise encompasses all aspects of roofing, making us the go-to choice for homeowners and businesses alike.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our comprehensive roofing services are designed to address the unique challenges presented by the Castlecrag climate. Whether you\u2019re dealing with the aftermath of a storm, looking to improve your property\u2019s energy efficiency, or simply aiming to enhance the aesthetic appeal of your home or business, our roofers have the skills and tools to achieve outstanding results. Maintenance, repair, installation, and emergency services are just a glimpse into what we offer, ensuring your roofing needs are met with the highest standards of quality and professionalism.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Baker Roofing, we pride ourselves on our meticulous attention to detail and our unwavering commitment to customer satisfaction. Our team is not only highly skilled in the latest roofing techniques but also deeply understands the importance of a roof in protecting your property. This dual focus on technical proficiency and client care sets us apart as Castlecrag\u2019s best roofers, ready to tackle any challenge with efficiency and expertise.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Baker Roofing for Your Castlecrag Roofing Needs?",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Choosing the right roofing company for your Castlecrag home or business is critical to ensure the long-term health and aesthetics of your property. Baker Roofing stands out in the Sydney roofing market, providing unparalleled expertise, quality, and customer service that align perfectly with the unique needs of Castlecrag residents. Our commitment to excellence in every project, big or small, sets us apart from the competition.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "One key factor that distinguishes Baker Roofing is our deep understanding of local Castlecrag roofing requirements. The Sydney region presents its own set of challenges, from salty coastal air to unpredictable weather patterns, which can take a toll on roofing materials. Our team is not only well-versed in addressing these challenges but also excels in selecting and implementing the most suitable roofing solutions that promise durability and aesthetic appeal. Our expertise ensures your roof is not just about protection, but also about enhancing the overall value and beauty of your property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Moreover, customer satisfaction lies at the heart of everything we do at Baker Roofing. From the initial consultation to the completion of your roofing project, our dedicated team provides transparent communication, quality craftsmanship, and a personalized approach to meet your specific needs and preferences. Our responsiveness and attention to detail have earned us a reputation as a trusted partner for homeowners and businesses throughout Castlecrag and beyond. With Baker Roofing, you\u2019re not just hiring a roofing contractor; you\u2019re partnering with a team that genuinely cares about protecting and enhancing your property.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Castlecrag Roofers: Your Guide to Roof Installation and Repairs",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When it comes to maintaining the integrity and aesthetics of your home or business in Castlecrag, the roof plays a pivotal role. Whether you\u2019re in need of a complete roof installation, minor repairs, or regular maintenance, understanding the essential aspects of roofing can ensure the longevity and durability of your structure. Castlecrag roofers specialize in a multitude of services designed to address the unique challenges and weather conditions this area presents.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rapid Response to Roof Repairs: In Castlecrag, sudden weather changes can cause unexpected damage to your roof. Prompt professional assessments and repairs are crucial to prevent minor issues from escalating into major problems. This includes leaks, loose tiles, and damage from debris. Local Castlecrag roofers are adept at quickly diagnosing issues and executing repairs with precision, using materials and techniques that match your existing roof for seamless restoration.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive Roof Installation Services: Whether you\u2019re undertaking new construction or replacing an old, worn-out roof, selecting the right materials and styles is vital for both functionality and curb appeal. Castlecrag roofing experts will guide you through the process, from material selection to installation. They provide detailed consultations to understand your aesthetic preferences and practical requirements, ensuring the end result not only enhances the beauty of your property but also provides maximum protection against the local climate conditions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof maintenance is another crucial aspect that Castlecrag roofers address with great care. Regular inspections and maintenance can significantly extend the life of your roof, prevent leaks, and identify potential issues before they require costly repairs. This proactive approach is recommended to keep your roof in top condition, ensuring it continues to protect your home or business effectively year after year.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Get in Touch with the Top Roofers in Castlecrag Today!",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Finding the right team for your roofing needs in Castlecrag has never been easier. At Baker Roofing, we pride ourselves on being the leading experts in roofing services, catering to both residential and commercial properties. Our team of professional roofers has extensive experience and knowledge in all things roofing, from repairs and maintenance to full roof replacements. If you\u2019re looking for reliability, efficiency, and top-quality workmanship, look no further. Contact us today to discuss how we can help you with your roofing project.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our commitment to excellence and customer satisfaction sets us apart in the Castlecrag community. We understand the importance of your home or business\u2019s roof in protecting your property, which is why we use only the highest-quality materials and the latest techniques in all our projects. Whether you\u2019re dealing with the aftermath of a fierce storm, noticing signs of wear and tear, or simply aiming for an aesthetic upgrade, our team is equipped to handle it all. Don\u2019t let roofing issues stress you out any longer; let the top roofers in Castlecrag take care of it for you!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Getting in touch with us is easy and convenient. You can reach out to us through our contact form on our website, give us a call at (02) 5564 4609, or even visit our local office for a face-to-face consultation. Our friendly staff is eager to assist you, answering any questions you might have and guiding you through our process, from the initial consultation to the completion of your roofing project. We\u2019re here to ensure that your roofing experience is smooth, efficient, and exceeds your expectations.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Baker Roofing provides expert roofing services in Melbourne, Sydney, and Brisbane. From repairs to full roof replacements, we deliver durable, high-quality solutions tailored to your needs. Get in touch today!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Melbourne Office Address: Unit 29/2 Cobham St, Reservoir VIC 3073",
                                        "url": "https://maps.app.goo.gl/6kJCuB7UYh6Cfeo8A",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/6kJCuB7UYh6Cfeo8A",
                                                "anchor_text": "Melbourne Office Address: Unit 29/2 Cobham St, Reservoir VIC 3073"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney Office Address: 67 Victoria Rd, Rozelle NSW 2039",
                                        "url": "https://maps.app.goo.gl/gewUy2ZDegrjTWjU9",
                                        "urls": [
                                            {
                                                "url": "https://maps.app.goo.gl/gewUy2ZDegrjTWjU9",
                                                "anchor_text": "Sydney Office Address: 67 Victoria Rd, Rozelle NSW 2039"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "June 11, 2025",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Written By: John Baker",
                                        "url": "https://bakerroofing.com.au/author/john-baker/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/author/john-baker/",
                                                "anchor_text": "Written By:\n\t\t\t\t\t\t\t\t\t\tJohn Baker"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "0 Comments",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Table of Contents",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leave a Reply",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Your email address will not be published. Required fields are marked *",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Save my name, email, and website in this browser for the next time I comment.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Leave a Reply",
                                        "url": "https://bakerroofing.com.au/roofers-in-castlecrag/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-castlecrag/",
                                                "anchor_text": "Cancel reply"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Comment *",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Name *",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email *",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "You Might Also Be Interested In",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Top Roofers in Fig Tree Pocket | Baker Roofing Services",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Top Roofers in Fig Tree Pocket | Baker Roofing Services",
                                        "url": "https://bakerroofing.com.au/roofers-in-fig-tree-pocket/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-fig-tree-pocket/",
                                                "anchor_text": "Top Roofers in Fig Tree Pocket | Baker Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Top-Quality Roofers in Wavell Heights | Baker Roofing Experts",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Top-Quality Roofers in Wavell Heights | Baker Roofing Experts",
                                        "url": "https://bakerroofing.com.au/roofers-in-wavell-heights/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-wavell-heights/",
                                                "anchor_text": "Top-Quality Roofers in Wavell Heights | Baker Roofing Experts"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Top Roofers in Taringa: Expert Services by Baker Roofing",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Top Roofers in Taringa: Expert Services by Baker Roofing",
                                        "url": "https://bakerroofing.com.au/roofers-in-taringa/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-taringa/",
                                                "anchor_text": "Top Roofers in Taringa: Expert Services by Baker Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Roofers in Hendra | Baker Roofing \u2013 Your Local Specialists",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Expert Roofers in Hendra | Baker Roofing \u2013 Your Local Specialists",
                                        "url": "https://bakerroofing.com.au/roofers-in-hendra/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-hendra/",
                                                "anchor_text": "Expert Roofers in Hendra | Baker Roofing \u2013 Your Local Specialists"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pages",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing in Melbourne",
                                        "url": "https://bakerroofing.com.au/roofing-in-melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-in-melbourne/",
                                                "anchor_text": "Roofing in Melbourne"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Sydney",
                                        "url": "https://bakerroofing.com.au/roofing-in-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-in-sydney/",
                                                "anchor_text": "Roofing in Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "About Us",
                                        "url": "https://bakerroofing.com.au/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/about-us/",
                                                "anchor_text": "About Us"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Home Baker Roofing",
                                        "url": "https://bakerroofing.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/",
                                                "anchor_text": "Home Baker Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing in Brisbane",
                                        "url": "https://bakerroofing.com.au/roofing-in-brisbane/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-in-brisbane/",
                                                "anchor_text": "Roofing in Brisbane"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Installation",
                                        "url": "https://bakerroofing.com.au/roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-installation/",
                                                "anchor_text": "Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Renovation",
                                        "url": "https://bakerroofing.com.au/roof-renovation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-renovation/",
                                                "anchor_text": "Roof Renovation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Repair",
                                        "url": "https://bakerroofing.com.au/gutter-repair/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/gutter-repair/",
                                                "anchor_text": "Gutter Repair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Commercial Roofing",
                                        "url": "https://bakerroofing.com.au/commercial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/commercial-roofing/",
                                                "anchor_text": "Commercial Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Residential Roofing",
                                        "url": "https://bakerroofing.com.au/residential-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/residential-roofing/",
                                                "anchor_text": "Residential Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://bakerroofing.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-repairs/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers Inner City Brisbane",
                                        "url": "https://bakerroofing.com.au/roofers-inner-city-brisbane/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-inner-city-brisbane/",
                                                "anchor_text": "Roofers Inner City Brisbane"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers North Brisbane",
                                        "url": "https://bakerroofing.com.au/roofers-north-brisbane/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-north-brisbane/",
                                                "anchor_text": "Roofers North Brisbane"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers East Brisbane",
                                        "url": "https://bakerroofing.com.au/roofers-east-brisbane/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-east-brisbane/",
                                                "anchor_text": "Roofers East Brisbane"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers South Brisbane",
                                        "url": "https://bakerroofing.com.au/roofers-south-brisbane/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-south-brisbane/",
                                                "anchor_text": "Roofers South Brisbane"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers West Brisbane",
                                        "url": "https://bakerroofing.com.au/roofers-west-brisbane/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-west-brisbane/",
                                                "anchor_text": "Roofers West Brisbane"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers North West Brisbane",
                                        "url": "https://bakerroofing.com.au/roofers-north-west-brisbane/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-north-west-brisbane/",
                                                "anchor_text": "Roofers North West Brisbane"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://bakerroofing.com.au/roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-restoration/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emergency Roof Repairs",
                                        "url": "https://bakerroofing.com.au/emergency-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/emergency-roof-repairs/",
                                                "anchor_text": "Emergency Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roofing",
                                        "url": "https://bakerroofing.com.au/metal-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/metal-roofing/",
                                                "anchor_text": "Metal Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tile Roofing",
                                        "url": "https://bakerroofing.com.au/tile-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/tile-roofing/",
                                                "anchor_text": "Tile Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terracotta Roofing",
                                        "url": "https://bakerroofing.com.au/terracotta-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/terracotta-roofing/",
                                                "anchor_text": "Terracotta Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Colorbond Roofing",
                                        "url": "https://bakerroofing.com.au/colorbond-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/colorbond-roofing/",
                                                "anchor_text": "Colorbond Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://bakerroofing.com.au/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-replacement/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "New Roof Installation",
                                        "url": "https://bakerroofing.com.au/new-roof-installation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/new-roof-installation/",
                                                "anchor_text": "New Roof Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Inspections",
                                        "url": "https://bakerroofing.com.au/roof-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-inspections/",
                                                "anchor_text": "Roof Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repointing",
                                        "url": "https://bakerroofing.com.au/roof-repointing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-repointing/",
                                                "anchor_text": "Roof Repointing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Skylight Installation",
                                        "url": "https://bakerroofing.com.au/skylight-installation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/skylight-installation/",
                                                "anchor_text": "Skylight Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Storm Damage Repairs",
                                        "url": "https://bakerroofing.com.au/storm-damage-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/storm-damage-repairs/",
                                                "anchor_text": "Storm Damage Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Leak Detection",
                                        "url": "https://bakerroofing.com.au/roof-leak-detection/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-leak-detection/",
                                                "anchor_text": "Roof Leak Detection"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Waterproofing",
                                        "url": "https://bakerroofing.com.au/roof-waterproofing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-waterproofing/",
                                                "anchor_text": "Roof Waterproofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Ventilation",
                                        "url": "https://bakerroofing.com.au/roof-ventilation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-ventilation/",
                                                "anchor_text": "Roof Ventilation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Solar Panel Roofing",
                                        "url": "https://bakerroofing.com.au/solar-panel-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/solar-panel-roofing/",
                                                "anchor_text": "Solar Panel Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Insulation",
                                        "url": "https://bakerroofing.com.au/roof-insulation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-insulation/",
                                                "anchor_text": "Roof Insulation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Rebedding",
                                        "url": "https://bakerroofing.com.au/roof-rebedding/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-rebedding/",
                                                "anchor_text": "Roof Rebedding"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Make Safes",
                                        "url": "https://bakerroofing.com.au/make-safes/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/make-safes/",
                                                "anchor_text": "Make Safes"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tile Roof Repairs",
                                        "url": "https://bakerroofing.com.au/tile-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/tile-roof-repairs/",
                                                "anchor_text": "Tile Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roof Repairs",
                                        "url": "https://bakerroofing.com.au/metal-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/metal-roof-repairs/",
                                                "anchor_text": "Metal Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terracotta Roof Repairs",
                                        "url": "https://bakerroofing.com.au/terracotta-roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/terracotta-roof-repairs/",
                                                "anchor_text": "Terracotta Roof Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tile Roof Restoration",
                                        "url": "https://bakerroofing.com.au/tile-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/tile-roof-restoration/",
                                                "anchor_text": "Tile Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terracotta Roof Restoration",
                                        "url": "https://bakerroofing.com.au/terracotta-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/terracotta-roof-restoration/",
                                                "anchor_text": "Terracotta Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Metal Roof Restoration",
                                        "url": "https://bakerroofing.com.au/metal-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/metal-roof-restoration/",
                                                "anchor_text": "Metal Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting",
                                        "url": "https://bakerroofing.com.au/roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-painting/",
                                                "anchor_text": "Roof Painting"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Cleaning",
                                        "url": "https://bakerroofing.com.au/roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-cleaning/",
                                                "anchor_text": "Roof Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Maintenance",
                                        "url": "https://bakerroofing.com.au/roof-maintenance/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-maintenance/",
                                                "anchor_text": "Roof Maintenance"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Safety Inspections",
                                        "url": "https://bakerroofing.com.au/roof-safety-inspections/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-safety-inspections/",
                                                "anchor_text": "Roof Safety Inspections"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Pressure Cleaning",
                                        "url": "https://bakerroofing.com.au/roof-pressure-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-pressure-cleaning/",
                                                "anchor_text": "Roof Pressure Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Installation",
                                        "url": "https://bakerroofing.com.au/gutter-installation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/gutter-installation/",
                                                "anchor_text": "Gutter Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Replacement",
                                        "url": "https://bakerroofing.com.au/gutter-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/gutter-replacement/",
                                                "anchor_text": "Gutter Replacement"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": "https://bakerroofing.com.au/gutter-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/gutter-cleaning/",
                                                "anchor_text": "Gutter Cleaning"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Repairs",
                                        "url": "https://bakerroofing.com.au/gutter-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/gutter-repairs/",
                                                "anchor_text": "Gutter Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Downpipe Installation",
                                        "url": "https://bakerroofing.com.au/downpipe-installation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/downpipe-installation/",
                                                "anchor_text": "Downpipe Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Downpipe Repairs",
                                        "url": "https://bakerroofing.com.au/downpipe-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/downpipe-repairs/",
                                                "anchor_text": "Downpipe Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Fascia and Soffit Installation",
                                        "url": "https://bakerroofing.com.au/fascia-soffit-installation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/fascia-soffit-installation/",
                                                "anchor_text": "Fascia and Soffit Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Guard Installation",
                                        "url": "https://bakerroofing.com.au/gutter-guard-installation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/gutter-guard-installation/",
                                                "anchor_text": "Gutter Guard Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Industrial Roofing",
                                        "url": "https://bakerroofing.com.au/industrial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/industrial-roofing/",
                                                "anchor_text": "Industrial Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strata Roofing",
                                        "url": "https://bakerroofing.com.au/strata-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/strata-roofing/",
                                                "anchor_text": "Strata Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Heritage Roof Restoration",
                                        "url": "https://bakerroofing.com.au/heritage-roof-restoration/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/heritage-roof-restoration/",
                                                "anchor_text": "Heritage Roof Restoration"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Flashing Installation",
                                        "url": "https://bakerroofing.com.au/roof-flashing-installation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-flashing-installation/",
                                                "anchor_text": "Roof Flashing Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Chimney Repairs",
                                        "url": "https://bakerroofing.com.au/chimney-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/chimney-repairs/",
                                                "anchor_text": "Chimney Repairs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Ridge Capping",
                                        "url": "https://bakerroofing.com.au/roof-ridge-capping/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-ridge-capping/",
                                                "anchor_text": "Roof Ridge Capping"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Safety Rails",
                                        "url": "https://bakerroofing.com.au/roof-safety-rails/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-safety-rails/",
                                                "anchor_text": "Roof Safety Rails"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Reports",
                                        "url": "https://bakerroofing.com.au/roof-reports/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-reports/",
                                                "anchor_text": "Roof Reports"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whirlybird Installation",
                                        "url": "https://bakerroofing.com.au/whirlybird-installation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/whirlybird-installation/",
                                                "anchor_text": "Whirlybird Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Sarking Installation",
                                        "url": "https://bakerroofing.com.au/roof-sarking-installation/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roof-sarking-installation/",
                                                "anchor_text": "Roof Sarking Installation"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Sydney CBD",
                                        "url": "https://bakerroofing.com.au/roofing-sydney-cbd/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-sydney-cbd/",
                                                "anchor_text": "Roofing Sydney CBD"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Canterbury-Bankstown",
                                        "url": "https://bakerroofing.com.au/roofing-canterbury-bankstown/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-canterbury-bankstown/",
                                                "anchor_text": "Roofing Canterbury-Bankstown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Inner West",
                                        "url": "https://bakerroofing.com.au/roofing-inner-west/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-inner-west/",
                                                "anchor_text": "Roofing Inner West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Upper North Shore",
                                        "url": "https://bakerroofing.com.au/roofing-upper-north-shore/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-upper-north-shore/",
                                                "anchor_text": "Roofing Upper North Shore"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Lower North Shore",
                                        "url": "https://bakerroofing.com.au/roofing-lower-north-shore/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-lower-north-shore/",
                                                "anchor_text": "Roofing Lower North Shore"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Parramatta",
                                        "url": "https://bakerroofing.com.au/roofing-parramatta/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-parramatta/",
                                                "anchor_text": "Roofing Parramatta"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Northern Beaches",
                                        "url": "https://bakerroofing.com.au/roofing-northern-beaches/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-northern-beaches/",
                                                "anchor_text": "Roofing Northern Beaches"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing The Hills District",
                                        "url": "https://bakerroofing.com.au/roofing-the-hills-district/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-the-hills-district/",
                                                "anchor_text": "Roofing The Hills District"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Eastern Suburbs",
                                        "url": "https://bakerroofing.com.au/roofing-eastern-suburbs/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-eastern-suburbs/",
                                                "anchor_text": "Roofing Eastern Suburbs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Ryde",
                                        "url": "https://bakerroofing.com.au/roofing-ryde/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-ryde/",
                                                "anchor_text": "Roofing Ryde"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing Sutherland Shire",
                                        "url": "https://bakerroofing.com.au/roofing-sutherland-shire/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofing-sutherland-shire/",
                                                "anchor_text": "Roofing Sutherland Shire"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers In Newtown",
                                        "url": "https://bakerroofing.com.au/roofers-in-newtown/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-newtown/",
                                                "anchor_text": "Roofers In Newtown"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers In Marrickville",
                                        "url": "https://bakerroofing.com.au/roofers-in-marrickville/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-marrickville/",
                                                "anchor_text": "Roofers In Marrickville"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers In Annandale",
                                        "url": "https://bakerroofing.com.au/roofers-in-annandale/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-annandale/",
                                                "anchor_text": "Roofers In Annandale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers In Balmain",
                                        "url": "https://bakerroofing.com.au/roofers-in-balmain/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-balmain/",
                                                "anchor_text": "Roofers In Balmain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers In Leichhardt",
                                        "url": "https://bakerroofing.com.au/roofers-in-leichhardt/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-leichhardt/",
                                                "anchor_text": "Roofers In Leichhardt"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers In Petersham",
                                        "url": "https://bakerroofing.com.au/roofers-in-petersham/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-petersham/",
                                                "anchor_text": "Roofers In Petersham"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers In Ashfield",
                                        "url": "https://bakerroofing.com.au/roofers-in-ashfield/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-ashfield/",
                                                "anchor_text": "Roofers In Ashfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers In Summer Hill",
                                        "url": "https://bakerroofing.com.au/roofers-in-summer-hill/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-summer-hill/",
                                                "anchor_text": "Roofers In Summer Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofers In Stanmore",
                                        "url": "https://bakerroofing.com.au/roofers-in-stanmore/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/roofers-in-stanmore/",
                                                "anchor_text": "Roofers In Stanmore"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Categories",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Services",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repair",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Company",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "About us",
                                        "url": "https://bakerroofing.com.au/about-us/",
                                        "urls": [
                                            {
                                                "url": "https://bakerroofing.com.au/about-us/",
                                                "anchor_text": "About us"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Copyright \u00a9 2025 Baker Roofing, All rights reserved.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Privacy Policy",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get in touch",
                                "main_title": "Expert Roofers in Castlecrag | Baker Roofing | Top-Quality Service",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Opening Hours: Monday to Sunday - 24 hours",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0255644609",
                                "0391260431"
                            ],
                            "emails": [
                                "info@bakerroofing.com.au,customersupport@yourlocalroofers.com.au,%20jorge@clientconnectaustralia.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}