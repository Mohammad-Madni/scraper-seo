{
    "id": "01190728-1132-0216-0000-523cd9ffd711",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0212 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.attractiveroofingsolutions.com.au/",
        "target": "www.attractiveroofingsolutions.com.au",
        "start_url": "https://www.attractiveroofingsolutions.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castlecrag\\organic\\type-organic_rg19_ra22_attractiveroofingsolutions.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:49 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "ABOUT US",
                                    "url": "https://www.attractiveroofingsolutions.com.au/repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.attractiveroofingsolutions.com.au/repairs/",
                                            "anchor_text": "ABOUT US"
                                        }
                                    ]
                                },
                                {
                                    "text": "NEW ROOFS",
                                    "url": "https://www.attractiveroofingsolutions.com.au/new-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://www.attractiveroofingsolutions.com.au/new-roofs/",
                                            "anchor_text": "NEW ROOFS"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF TILES",
                                    "url": "https://www.attractiveroofingsolutions.com.au/roof-tiles/",
                                    "urls": [
                                        {
                                            "url": "https://www.attractiveroofingsolutions.com.au/roof-tiles/",
                                            "anchor_text": "ROOF TILES"
                                        }
                                    ]
                                },
                                {
                                    "text": "CONTACT US",
                                    "url": "https://www.attractiveroofingsolutions.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.attractiveroofingsolutions.com.au/contact-us/",
                                            "anchor_text": "CONTACT US"
                                        }
                                    ]
                                },
                                {
                                    "text": "ABOUT US",
                                    "url": "https://www.attractiveroofingsolutions.com.au/repairs/",
                                    "urls": [
                                        {
                                            "url": "https://www.attractiveroofingsolutions.com.au/repairs/",
                                            "anchor_text": "ABOUT US"
                                        }
                                    ]
                                },
                                {
                                    "text": "NEW ROOFS",
                                    "url": "https://www.attractiveroofingsolutions.com.au/new-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://www.attractiveroofingsolutions.com.au/new-roofs/",
                                            "anchor_text": "NEW ROOFS"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF TILES",
                                    "url": "https://www.attractiveroofingsolutions.com.au/roof-tiles/",
                                    "urls": [
                                        {
                                            "url": "https://www.attractiveroofingsolutions.com.au/roof-tiles/",
                                            "anchor_text": "ROOF TILES"
                                        }
                                    ]
                                },
                                {
                                    "text": "CONTACT US",
                                    "url": "https://www.attractiveroofingsolutions.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.attractiveroofingsolutions.com.au/contact-us/",
                                            "anchor_text": "CONTACT US"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Attractive Roofing Solutions has completed thousands of roofing projects.",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Attractive Roofing Solutions has been proudly serving homeowners and builders for over 16 years. Whether you\u2019re building a new home, adding an extension, or need a roof replacement, we deliver quality workmanship on time and on budget.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Some of the Services we offer include:",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roof replacements and re-roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "New roof installations (tile and metal)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Commercial tile and metal roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof extensions and additions",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guttering and fascia installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repairs and leak detection",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofing for granny flats",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof inspections and reports",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether it\u2019s a new build, a renovation, or a quick repair, we\u2019re here to deliver high-quality roofing work that lasts.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof restorations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaf guards",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "We\u2019re fully licensed for roof tiling, metal and gutter works (Licence No. 265306C) and committed to providing Sydney homeowners and businesses with reliable, long-lasting, complete roofing solutions.",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Specialising in Roof Replacements, New Roof Installations, and Repairs Across the Greater Sydney Region",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Reroofing Sydney-wide",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Your Local Roof Tile and Metal Roof Replacement Specialists",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Fully Licensed Roof Tilers and Roof Plumbers",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Over 16 years\u2019 experience. Company Established 2013",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Trusted and choice for roofing services across the wider Sydney area",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Licensed with NSW Fair Trading to carry out Roof tiling, metal and gutter works",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Attractive Roofing Solutions has a large team of professional, talented tradesmen who complete projects quickly and to a high standard.",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "One-stop shop for comprehensive roofing solutions across the wider Sydney area. Roof replacements, new roofs, roof repairs",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Transparent, upfront fixed pricing with no hidden fees",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "No matter your roofing job, Attractive Roofing Solutions has you covered.",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Attractive Roofing always uses and sources the highest quality roofing materials on the market from the leading brands. Attractive Roofing uses Monier, Bristile, Colorbond,\u00a0Ace, Leaf-stopper\u00a0and Velux",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our experts will advise on the best materials to suit the environment and appearance of your home.",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Attractive Roofing, your local expert roofers, provide complete roofing solutions that will stand the test of time and make your house the best on the street.",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Choose Attractive Roofing Solutions to complete your roofing project for peace of mind today.",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Free, No-Obligation, Comprehensive All All-Exclusive Quotation",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Call owner\u00a0Eddie 0415 715 255, email eddie@Attractiveroofingsolutions.com.au or fill in the contact form below today.",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "contact\nName *\nEmail Address *\nBest contact phone Number\nMessage and/ or job details\nPhone This field is for validation purposes and should be left unchanged.",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "contact",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Best contact phone Number",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Message and/ or job details",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "This field is for validation purposes and should be left unchanged.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Experienced Professionals \u2013 Established in 2013, our team has installed thousands of roofs across Sydney and the surrounding areas.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "One\u2011Stop Roofing Service \u2013 Licensed roof tilers and roof plumbers in-house, offering complete, full-service packages",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Top\u2011Quality Materials \u2013 Proudly partnering with major brands like Monier, Boral, Bristile, Colourbond, and Lysaght.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Commitment to Safety \u2013 We use safety rails, scaffolding, harnesses, and follow all OH&S regulations throughout every project.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparent, Hassle\u2011Free Process \u2013 From site inspection and quoting to installation and handover, you\u2019ll enjoy a seamless service experience led by owner Eddie Appleby",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Contact us to request a quote",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Name *",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email Address *",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Why Choose Us?",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Choose Attractive Roofing Solutions to complete your roofing project for peace of mind today.",
                                "main_title": "Sydney\u2019s Trusted Roofing Experts for Builders & Homeowners",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "License Number: 265306C",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ABN: 63 166 163 891",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10/10 John Hines Avenue Minchinbury NSW 2770",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": [
                                    {
                                        "header": null,
                                        "body": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "SOME OF THE\u00a0AREAS\u00a0WE\u00a0SERVICE \u2013 WE GO ANYWHERE\u00a0IN WIDER SYDNEY",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "North Shore (Upper & Lower)",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Artarmon",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Beecroft",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Berowra",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Chatswood",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Cheltenham",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Cows Nest",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Cremorne",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Gladesville",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Epping",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Hornsby",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Hunters Hill",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Ku-ring-gai",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Lane Cove",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Lindfield",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Neutral Bay",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Normanhurst",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Pymble",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "St Ives",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Wollstonecraft",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Willoughby",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Sydney Eastern Suburbs",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Alexandrea",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Bellevue Hill",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Bondi",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Bronte",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Coogee",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Double BayEdgecliff",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Kingsford",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Maroubra",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Moore Park",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Mosman",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Rose Bay",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Randwick",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Matraville",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Vaucluse",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Waverly",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Waterloo",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Central Sydney",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Erskineville",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Glebe",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Newtown",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Redfern",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Inner West Sydney",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Abbotsford",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Annandale",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Ashfield",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Balmain",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Canterbury",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Concord West",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Croydon",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Drummoyne",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Five Dock",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Enfield",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Glebe",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Haberfield",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Marrickville",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Rhodes",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Strathfield",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Summer Hill",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Tempe",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Wareemba",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Hills District & North West",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Annangrove",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Baulkham Hills",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Bella Vista",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Castle Hill",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Carlingford",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Cherrybrook",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Dural",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "North Parramatta",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Northmead",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Winston Hills",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Oatlands",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Rouse Hill",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Winston Hills",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Wisemans Ferry",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Western Sydney and surrounds",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Blacktown",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Camden",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Campbelltown",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Fairfield",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Hawksbury",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Holroyd",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Liverpool",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "MacArthur",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Penrith",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Windsor",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "St George & Sutherland Shire",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Arncliffe",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Beverly Hills",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Bexley",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Blakehurst",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Brighton-Le-Sands",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Caringbah",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Cronulla",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Carlton",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Hurstville Grove",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Kogarah Bay",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Miranda",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Monterey",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Mortdale",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Peakhurst",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Rockdale",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Sylvania",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            }
                                        ],
                                        "footer": null
                                    }
                                ]
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+61415715255"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}