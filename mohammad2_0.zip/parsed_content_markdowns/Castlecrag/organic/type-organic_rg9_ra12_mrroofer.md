{
    "id": "01190728-1132-0216-0000-9351c7ff1a25",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0294 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.mrroofer.com.au/castlecrag-roof-restoration/",
        "target": "www.mrroofer.com.au",
        "start_url": "https://www.mrroofer.com.au/castlecrag-roof-restoration/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Castlecrag\\organic\\type-organic_rg9_ra12_mrroofer.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:33:00 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "Sydney Roof Restoration company that caters to residential customers across Sydney.",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.mrroofer.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "CONTACT PHONE",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Mon - Sat 8:00 - 18:00",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "OPEN HOURS",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://www.mrroofer.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Mr. Roofer is a premier, Sydney Roof Restoration company that caters to residential customers across Sydney. We have been in this business for over 20 years and provide excellent roofing services.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright 2021 Mr Roofer, All Right Reserved",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-restoration-sydney/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/roof-cleaning-sydney/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/gutter-cleaning-sydney/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Site Map",
                                    "url": "https://www.mrroofer.com.au/site-map/",
                                    "urls": [
                                        {
                                            "url": "https://www.mrroofer.com.au/site-map/",
                                            "anchor_text": "Site Map"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sydney NSW. 2200",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Castlecrag Roof Restoration",
                                "main_title": "Castlecrag Roof Restoration",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roofs that are built using top quality products can last for decades and may not need Castlecrag roof restoration. But we at Mr Roof have seen that exposure to the elements, the UV rays of the sun, seasonal storms and regular wear and tear take their toll on the roof structures. Over time, even the best-maintained roofs can begin to look dated and dull.",
                                        "url": "https://www.mrroofer.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/",
                                                "anchor_text": "Mr Roof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We offer professional roof restoration Castlecrag services that can help bring back the appeal and glory of your roof. Once we are done, not only will your roof look great, but it will also be structurally stronger and will last for a number of years. There are various residential and commercial Castlecrag roof restoration services that we offer.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Castlecrag Roof Restoration",
                                "main_title": "Castlecrag Roof Restoration",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "As mentioned earlier, roof restoration significantly improves the appearance and integrity of your roof, and it\u2019s one of the best ways to reduce future repair and replacement costs. The process of modern roof restoration involves a number of aspects such as:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Detailed inspections \u2013 Our expert roofers will thoroughly inspect all the features and areas of your roof to determine where the vulnerabilities lie. Post the inspection, they will provide a comprehensive report with a supporting quote for the solutions they have recommended. The solutions could be structural or cosmetic in nature; when used in combination, they will help improve the condition and appearance of the roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "High-quality roof restoration in Castlecrag \u2013 Once we receive an approval from you, our professional technicians will commence the restoration work on the pre-decided date. They will clean the roofing, point it and paint it in high-quality paints and colours of your choice. Before the painting job, the team will complete all minor repairs and fixes which help strengthen the roof and increase its lifespan. The repointing adds dimension to the structure and lends it a more natural appearance. We never compromise on quality although we maintain very low roof restoration cost.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Types of Residential Roof Restoration Castlecrag",
                                "main_title": "Castlecrag Roof Restoration",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Over the years, we\u2019ve worked with all types of roofing materials and handle every single job skilfully and professionally. Our team uses specialised cleaning methods based on the type of materials on the roof. This detailed approach helps ensure that the roof isn\u2019t impacted in any way and that its beauty is maintained. The range of services we offer include:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Terracotta tiles Castlecrag Roof Restoration",
                                "main_title": "Castlecrag Roof Restoration",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "These tiles have a very stunning look and add to the charm of a property. The tile roof restoration process for these tiles is as follows:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The technicians will clean the roof thoroughly and remove all the moss, lichen and mildew build-up.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Eco-friendly, yet effective cleaning agents will be used in the work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Once the moss, mildew,and lichen have dried up, it will all be removed using trowels.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The roof will then be pressure-cleaned using the right pressure.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The team will remove the ridge caps and re-bed the roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The repointing work will be completed.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A seal-coat or primer coat application will follow after which the repainting work will be completed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Concrete Tiles Castlecrag Roof Restoration",
                                "main_title": "Castlecrag Roof Restoration",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Concrete is an extremely strong material that\u2019s used in various types of construction. It\u2019s easy to maintain and very long lasting too which makes concrete roofs a very popular option across the region. Our professional Castlecrag roof restoration team has the expertise to handle all types of restoration works and this is the process we follow:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We will pressure-wash the roof thoroughly.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The technicians will remove the ridge caps and complete the re-bedding work.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "They will remove all the old mortar and repoint the ridge caps.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A primer coat will be applied to the roof before it is painted.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Castlecrag Roof Restoration",
                                "main_title": "Castlecrag Roof Restoration",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Metal Colorbond roofs are used in residential and commercial buildings and these last for a number of years if they are maintained well. If your roof is showing signs of wear and tear, simply give us a call. We offer custom metal roof restoration Castlecrag services and follow a very detailed work process:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The technicians will grind the metal surface in order to remove all signs of corrosion and rust.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "They will apply a rust converter and this provides a moisture-resistant barrier on the sheet\u2019s surface.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Severely damaged sheets will be replaced.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Rusted nails and hardware will be replaced.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The roof will then be cleaned, primed and painted.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Affordable Roof Restoration in Castlecrag",
                                "main_title": "Castlecrag Roof Restoration",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Today, there are a number of roof restoration Castlecrag contractors that state they provide cheap services. But the fact is that they also compromise on quality and cut corners in their work.Many also add fees to the quote provided and this escalates the cost of the project for you. This is where we are different.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Other Castlecrag Roofing Services",
                                "main_title": "Castlecrag Roof Restoration",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We also offer other roofing services to suit any roof you may have. These services include:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Cleaning Castlecrag",
                                        "url": "https://www.mrroofer.com.au/Castlecrag-roof-cleaning/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/Castlecrag-roof-cleaning/",
                                                "anchor_text": "Roof Cleaning Castlecrag"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Painting Castlecrag",
                                        "url": "https://www.mrroofer.com.au/Castlecrag-roof-painting/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/Castlecrag-roof-painting/",
                                                "anchor_text": "Roof Painting Castlecrag"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Repair Castlecrag",
                                        "url": "https://www.mrroofer.com.au/Castlecrag-roof-repair/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/Castlecrag-roof-repair/",
                                                "anchor_text": "Roof Repair Castlecrag"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gutter Cleaning Castlecrag",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Ask our Castlecrag Roof Restoration Team",
                                "main_title": "Castlecrag Roof Restoration",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We offer top-notch tile roof restoration and installation at very reasonable costs. All our services are guaranteed and that means you can rest assured we will handle the job right the first time around. For any more information about our cheap Castlecrag roof restoration services or for a free inspection and quote, call Mr Roofer at 0405 804 804. You can also send us your queries and quote requests via our online form.",
                                        "url": "https://www.mrroofer.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.mrroofer.com.au/",
                                                "anchor_text": "Mr Roofer"
                                            },
                                            {
                                                "url": "https://www.mrroofer.com.au/contact-us/",
                                                "anchor_text": "online form"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roof Restorations",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Years Experience",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roofs Painted",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": null,
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0405804804"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}