# Type: people_also_search | Rank: 23 | RG: 2
### Raw Row Data:
{
    "rank_group": "2",
    "rank_absolute": "23",
    "service": "roofer",
    "suburb": "Breakfast Point",
    "title": "People also search for",
    "domain": "",
    "url": "",
    "description": "",
    "type": "people_also_search"
}