{
    "id": "01190728-1132-0216-0000-8331f1fdeb85",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0209 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.auscityplumbing.com.au/services/roof-repairs-breakfast-point/",
        "target": "www.auscityplumbing.com.au",
        "start_url": "https://www.auscityplumbing.com.au/services/roof-repairs-breakfast-point/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Breakfast-Point\\organic\\type-organic_rg13_ra18_auscityplumbing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:24 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "WE'RE OPEN NOW",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Sydney - 4:28 pm (Open)",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "AUSCITY PLUMBING",
                                    "url": "https://www.auscityplumbing.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://www.auscityplumbing.com.au/",
                                            "anchor_text": "AUSCITY PLUMBING"
                                        }
                                    ]
                                },
                                {
                                    "text": "ABOUT US",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "WHY CHOOSE US",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "CONTACT US",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "AUSCITY PLUMBING",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "0432 466 466",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Sydney - 4:28 pm (Open)",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 AUSCITY PLUMBING - 2019. All Rights Reserved. Service Areas",
                                    "url": "http://www.auscityplumbing.com.au/",
                                    "urls": [
                                        {
                                            "url": "http://www.auscityplumbing.com.au/",
                                            "anchor_text": "AUSCITY PLUMBING"
                                        },
                                        {
                                            "url": "http://www.auscityplumbing.com.au/services",
                                            "anchor_text": "Service Areas"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Auscity Roof Repairs Breakfast Point",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Do you have a leaking roof in Breakfast Point? Our team of licensed & experienced plumbers and roofers are local to Breakfast Point and can be with you in under an hour. You will find transparency and consistency with our quotes and nothing short of the best quality with all jobs completed.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We offer our roofing services for both Commercial and Residential clients in Breakfast Point with no job too big or small.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Communication is very important for us, therefore we like to keep you informed at every step of the task we are working on.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Grant Joyce",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "George did a great job, very professional, punctual and a lovely gent, very prompt and provided first class service. I would have no problems recommending George and will use his services if I need a plumber again",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Harry Tsoukalas",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "George was very quick to respond in a very complex problem and he gave me a very good price. He completed the job very quick and while he had to do some around for special material needed he didn\u2019t charge me extra money. I will highly recommend him and will be using him all the time from now on. Thank you George",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Auscity Roof Repairs Breakfast Point",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sheet Roof Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Concrete Tile Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Maintenance",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Terracotta Tile Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal Roof Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "OUR SERVICES",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Guttering Services",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Guttering Services",
                                        "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-1-1.png",
                                        "urls": [
                                            {
                                                "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-1-1.png",
                                                "anchor_text": "Guttering Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Leaks",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Leaks",
                                        "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-2.png",
                                        "urls": [
                                            {
                                                "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-2.png",
                                                "anchor_text": "Roof Leaks"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Bathroom Renovations",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Bathroom Renovations",
                                        "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-3.png",
                                        "urls": [
                                            {
                                                "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-3.png",
                                                "anchor_text": "Bathroom Renovations"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Hot Water",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Hot Water",
                                        "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-4.png",
                                        "urls": [
                                            {
                                                "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-4.png",
                                                "anchor_text": "Hot Water"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gas installation / Repair",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Gas installation / Repair",
                                        "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-5.png",
                                        "urls": [
                                            {
                                                "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-5.png",
                                                "anchor_text": "Gas installation / Repair"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Burst Pipes",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Burst Pipes",
                                        "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-6.png",
                                        "urls": [
                                            {
                                                "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-6.png",
                                                "anchor_text": "Burst Pipes"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "CCTV Camera Inspections",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "CCTV Camera Inspections",
                                        "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-7.png",
                                        "urls": [
                                            {
                                                "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-7.png",
                                                "anchor_text": "CCTV Camera Inspections"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pipe Locating",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Pipe Locating",
                                        "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-8.png",
                                        "urls": [
                                            {
                                                "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-8.png",
                                                "anchor_text": "Pipe Locating"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Leaking Taps or Toilets",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Leaking Taps or Toilets",
                                        "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-9.png",
                                        "urls": [
                                            {
                                                "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-9.png",
                                                "anchor_text": "Leaking Taps or Toilets"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Blocked Drains",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Blocked Drains",
                                        "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-10.png",
                                        "urls": [
                                            {
                                                "url": "https://www.auscityplumbing.com.au/wp-content/uploads/2019/07/service-icon-10.png",
                                                "anchor_text": "Blocked Drains"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "WHY CHOOSE US",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "WE\u2019RE HONEST",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "All quote are provide up front on site so there\u2019s no nasty surprises!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "WE ARE THERE WITHIN AN HOUR",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "We believe in a quick service that is punctual. Our team is close to Breakfast Point and will be at your job within an hour of receiving the job request.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "WE ARE 24/7",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Our phones are never off. We are available 24 hours, 7 days a week for all your plumbing and roofing needs in Breakfast Point.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "OUR TESTIMONIALS",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Kevin Cullen",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Quick responses, great communication and good price. Arrived on time and completed job in full. Would use George again",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Donna Revenscroft",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Fast service, competent plumber..good advice",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Virginia Flitcroft",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "George proves a fabulous service, professional and prompt. I would his plumbing service again",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Roof Repair Services in Breakfast Point",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Whatever your roofing needs in Breakfast Point. Auscity Plumbing and roofing has the solution to solve your problems.",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Give us a call today for an obligation free quote.",
                                "main_title": "Auscity Roof Repairs Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "CALL US NOW",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0432466466",
                                "1300 561 857",
                                "0431471471",
                                "0432 466 466"
                            ],
                            "emails": [
                                "info@auscityplumbing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}