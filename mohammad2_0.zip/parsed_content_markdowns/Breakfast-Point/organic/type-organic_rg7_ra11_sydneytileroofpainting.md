{
    "id": "01190728-1132-0216-0000-ffaf4346698a",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0292 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://sydneytileroofpainting.com.au/suburbs/roof-repairs-breakfast-point/",
        "target": "sydneytileroofpainting.com.au",
        "start_url": "https://sydneytileroofpainting.com.au/suburbs/roof-repairs-breakfast-point/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Breakfast-Point\\organic\\type-organic_rg7_ra11_sydneytileroofpainting.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:22 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "About Us",
                                    "url": "https://sydneytileroofpainting.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Condition Reports",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-condition-reports/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-condition-reports/",
                                            "anchor_text": "Roof Condition Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flat Metal Roofing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/flat-metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/flat-metal-roofing/",
                                            "anchor_text": "Flat Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Asbestos Roof Removal",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/asbestos-roof-removal/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/asbestos-roof-removal/",
                                            "anchor_text": "Asbestos Roof Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Pigeon Proofing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/solar-pigeon-proofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/solar-pigeon-proofing/",
                                            "anchor_text": "Solar Pigeon Proofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Asbestos Roof Removal",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/asbestos-roof-removal/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/asbestos-roof-removal/",
                                            "anchor_text": "Asbestos Roof Removal"
                                        }
                                    ]
                                },
                                {
                                    "text": "Flat Metal Roofing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/flat-metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/flat-metal-roofing/",
                                            "anchor_text": "Flat Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacement",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-replacement/",
                                            "anchor_text": "Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restoration",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-restoration/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-restoration/",
                                            "anchor_text": "Roof Restoration"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-painting-sydney/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-painting-sydney/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repair",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-repair/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-repair/",
                                            "anchor_text": "Roof Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Condition Reports",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-condition-reports/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-condition-reports/",
                                            "anchor_text": "Roof Condition Reports"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Solar Pigeon Proofing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/solar-pigeon-proofing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/solar-pigeon-proofing/",
                                            "anchor_text": "Solar Pigeon Proofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repointing",
                                    "url": "https://sydneytileroofpainting.com.au/our-services/roof-repointing/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/our-services/roof-repointing/",
                                            "anchor_text": "Roof Repointing"
                                        }
                                    ]
                                },
                                {
                                    "text": "What Are The Consequences Of Not Fixing A Leaking Roof?",
                                    "url": "https://sydneytileroofpainting.com.au/what-are-the-consequences-of-not-fixing-a-leaking-roof/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/what-are-the-consequences-of-not-fixing-a-leaking-roof/",
                                            "anchor_text": "What Are The Consequences Of Not Fixing A Leaking Roof?"
                                        }
                                    ]
                                },
                                {
                                    "text": "How Can You Make Sure Your Metal Roof Is Properly Flashed?",
                                    "url": "https://sydneytileroofpainting.com.au/how-can-you-make-sure-your-metal-roof-is-properly-flashed/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/how-can-you-make-sure-your-metal-roof-is-properly-flashed/",
                                            "anchor_text": "How Can You Make Sure Your Metal Roof Is Properly Flashed?"
                                        }
                                    ]
                                },
                                {
                                    "text": "Why Is Metal Roofing Better Than Other Roofing Materials?",
                                    "url": "https://sydneytileroofpainting.com.au/why-is-metal-roofing-better-than-other-roofing-materials/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/why-is-metal-roofing-better-than-other-roofing-materials/",
                                            "anchor_text": "Why Is Metal Roofing Better Than Other Roofing Materials?"
                                        }
                                    ]
                                },
                                {
                                    "text": "What Are The Causes Of A Roof Leak?",
                                    "url": "https://sydneytileroofpainting.com.au/what-are-the-causes-of-a-roof-leak/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/what-are-the-causes-of-a-roof-leak/",
                                            "anchor_text": "What Are The Causes Of A Roof Leak?"
                                        }
                                    ]
                                },
                                {
                                    "text": "What Happens If Your Roof Leaks Around A Vent Pipe?",
                                    "url": "https://sydneytileroofpainting.com.au/what-happens-if-your-roof-leaks-around-a-vent-pipe/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/what-happens-if-your-roof-leaks-around-a-vent-pipe/",
                                            "anchor_text": "What Happens If Your Roof Leaks Around A Vent Pipe?"
                                        }
                                    ]
                                },
                                {
                                    "text": "About Us",
                                    "url": "https://sydneytileroofpainting.com.au/about-us/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/about-us/",
                                            "anchor_text": "About Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Privacy Policy",
                                    "url": "https://sydneytileroofpainting.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        }
                                    ]
                                },
                                {
                                    "text": "Call: 0492 000 020",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 [y] Sydney Tile Roof Painting by Nifty Marketing Australia",
                                    "url": "https://sydneytileroofpainting.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://sydneytileroofpainting.com.au/",
                                            "anchor_text": "Sydney Tile Roof Painting"
                                        },
                                        {
                                            "url": "https://niftymarketing.com.au/",
                                            "anchor_text": "Nifty Marketing Australia"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Professional Tile Roof Repair Services In Breakfast Point",
                                "main_title": "Roof Repairs Breakfast Point",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "While tile roofs are pleasing to the eye, they need professional care to maintain their function and charm. At Sydney Tile Roof Painting, we offer services that increase your roof\u2019s durability and preserve its appearance. Our expert repairs and maintenance ensure your roof is operational and enhances your home\u2019s overall worth.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Expert leak detection and fixes",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacement of cracked or missing tiles",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Cleaning and resealing to protect tiles from weather damage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ridge capping repairs to prevent water ingress",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our tile roof repair services are centred around long-term durability and aesthetic appeal. Contact us today to protect your tile roof\u2019s beauty and integrity, so it can continue to safeguard your home for years.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "We offer:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Breakfast Point\u2019s Trusted Roofing Repairs",
                                "main_title": "Roof Repairs Breakfast Point",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "When searching for Breakfast Point roofing repairs, trust the experts at Sydney Tile Roof Painting. We specialise in delivering top-notch roofing solutions to protect your home from the elements. Here\u2019s what you can expect when you choose us:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fast response times for fast repairs, ensuring minimal interference.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive inspections to pinpoint any potential problems, avoiding expensive repairs down the line.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repairs tailored to your roofing material, providing precise and dependable outcomes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Long-lasting results ensuring longevity and satisfaction with the use of premium materials.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "In Breakfast Point, Sydney Tile Roof Painting is your partner for maintaining sturdy, durable roofs. Our commitment to quality ensures your home withstands the elements. Don\u2019t delay\u2014reach out for dependable roofing repair services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Metal Roof Repair Services In Breakfast Point",
                                "main_title": "Roof Repairs Breakfast Point",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "While metal roofs are durable, they can encounter problems as they age. Sydney Tile Roof Painting is your trusted provider for metal roofing repair to ensure long-lasting protection.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "To keep your roof strong, we remove rust and corrosion that can weaken it. We repair or replace panels to ensure your roof stays functional and secure. Gaps are sealed to stop leaks from causing water damage. Repainting brings back your roof\u2019s appearance and safeguards it. Using expert methods, we ensure your roof lasts for many years.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney Tile Roof Painting provides consistent, top-notch results for all your cost-effective and reliable metal roof repair needs.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Breakfast Point\u2019s Reliable Emergency Roof Repairs",
                                "main_title": "Roof Repairs Breakfast Point",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sudden roof damage can occur at any moment. For urgent assistance, Sydney Tile Roof Painting delivers dependable roof emergency repair services. We provide:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Immediate attention to leaks or storm damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Temporary fixes to minimise further damage.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Comprehensive evaluations to identify and address underlying issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Assistance with insurance claims for a hassle-free experience.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Sydney Tile Roof Painting\u2019s expert team is committed to quick, efficient, and dependable emergency roof repairs. When you need urgent roofing solutions, trust us to protect your home. Get in touch with us now for fast and professional service!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs Breakfast Point",
                                "main_title": "Roof Repairs Breakfast Point",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Offering top-tier roof repair services at the most affordable rates in nearby areas such as:",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs Cabarita, Roof Repairs Mortlake",
                                        "url": "https://sydneytileroofpainting.com.au/suburbs/roof-repairs-cabarita/",
                                        "urls": [
                                            {
                                                "url": "https://sydneytileroofpainting.com.au/suburbs/roof-repairs-cabarita/",
                                                "anchor_text": "Roof Repairs Cabarita"
                                            },
                                            {
                                                "url": "https://sydneytileroofpainting.com.au/suburbs/roof-repairs-mortlake/",
                                                "anchor_text": "Roof Repairs Mortlake"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What Is The Process Of Boarding A Roof Repair Specialist At Breakfast Point?",
                                "main_title": "Roof Repairs Breakfast Point",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Our roof repair approach is designed for efficiency, transparency, and minimal stress. We keep you well-informed from start to finish to make sure you\u2019re satisfied with the service. This is our method:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Initial inspection to identify all issues.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Detailed cost estimate with no hidden fees.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Scheduling repairs at a convenient time for you.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Completing repairs with high-quality workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Final inspection to ensure your satisfaction.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Enjoy a smooth roof repair experience with us. Sydney Tile Roof Painting provides transparent, dependable, and professional roofing services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions",
                                "main_title": "Roof Repairs Breakfast Point",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 5,
                                "primary_content": [
                                    {
                                        "text": "How much time is needed for a roof repair?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A minor repair typically takes 1\u20132 days, whereas significant repairs might require a full week.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you provide emergency roof repair services in Breakfast Point?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Definitely, we offer emergency roof repair services for all parts of Breakfast Point.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "What kind of materials are used for tile roof repairs?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We select premium tiles and sealants that ensure a perfect match with your existing roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Do you provide replacement services for damaged metal roofing?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Absolutely. We repair or replace damaged metal roofing panels.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "How much do roof repairs cost in Breakfast Point?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The price depends on the extent of the damage and the materials used. Get in touch with us for a free quote.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Breakfast Point",
                                "main_title": "Roof Repairs Breakfast Point",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Keeping your roof intact is crucial for shielding your home from unpredictable weather. At Sydney Tile Roof Painting, we provide dependable roof repairs in Breakfast Point NSW, 2137. Whether you\u2019re dealing with a small leak or extensive damage, we make sure your roof remains durable and aesthetically pleasing. Our skilled team uses premium materials to restore and extend your roof\u2019s lifespan.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With extensive experience in all roofing repairs, we are your reliable partner in ensuring your home stays safe and secure.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Submit Your Details for a FREE Inspection & Quote",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OPTIONAL: You may upload some images to describe your enquiry",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Our Reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Why Choose Sydney Tile Roof Painting As Your Roof Repairer?",
                                "main_title": "Roof Repairs Breakfast Point",
                                "author": "Sydney Tile Roof Painting",
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "Here\u2019s why customers trust Sydney Tile Roof Painting for their roof repairs & maintenance needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With over a decade of industry experience, we have built a solid reputation for excellent service. We use superior materials and perform detailed craftsmanship to ensure every repair is completed with precision. Known for being dependable, our team communicates transparently and offers timely service to keep you informed. Furthermore, we provide a warranty on our work, ensuring lasting quality.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "When you choose us, you\u2019re partnering with the best for all roofing repairs in the area.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "OPTIONAL: You may upload some images to describe your enquiry",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Best Pricing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "7 Days",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Top Quality Paints",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "10 Yr Warranty",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 5,
                                "max_rating_value": 5,
                                "rating_count": 1289,
                                "relative_rating": 1
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0492 000 020",
                                "+61 492 000 020"
                            ],
                            "emails": [
                                "info@sydneytileroofpainting.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}