{
    "id": "01190728-1132-0216-0000-d8392efe5433",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0149 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://mzrooflogic.com.au/",
        "target": "mzrooflogic.com.au",
        "start_url": "https://mzrooflogic.com.au/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Breakfast-Point\\organic\\type-organic_rg15_ra20_mzrooflogic.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:22 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "#1 Premium Metal Roofers in Sydney",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "0475 052 327",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Residential Roof Replacement",
                                    "url": "https://mzrooflogic.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/roof-replacement/",
                                            "anchor_text": "Residential Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bushfire-Rated Roofing",
                                    "url": "https://mzrooflogic.com.au/bushfire-rated-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/bushfire-rated-roofing/",
                                            "anchor_text": "Bushfire-Rated Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://mzrooflogic.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "COLORBOND\u00ae Roof Installer",
                                    "url": "https://mzrooflogic.com.au/colorbond-roof-installer/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/colorbond-roof-installer/",
                                            "anchor_text": "COLORBOND\u00ae Roof Installer"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hail Damage",
                                    "url": "https://mzrooflogic.com.au/insurance/hail-damaged-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/insurance/hail-damaged-roofs/",
                                            "anchor_text": "Hail Damage"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blue Mountains",
                                    "url": "https://mzrooflogic.com.au/locations/blue-mountains/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/locations/blue-mountains/",
                                            "anchor_text": "Blue Mountains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://mzrooflogic.com.au/locations/northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/locations/northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Shore",
                                    "url": "https://mzrooflogic.com.au/locations/north-shore/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/locations/north-shore/",
                                            "anchor_text": "North Shore"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://mzrooflogic.com.au/locations/sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/locations/sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                },
                                {
                                    "text": "Residential Roof Replacement",
                                    "url": "https://mzrooflogic.com.au/roof-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/roof-replacement/",
                                            "anchor_text": "Residential Roof Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bushfire-Rated Roofing",
                                    "url": "https://mzrooflogic.com.au/bushfire-rated-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/bushfire-rated-roofing/",
                                            "anchor_text": "Bushfire-Rated Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Commercial Roofing",
                                    "url": "https://mzrooflogic.com.au/commercial-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/commercial-roofing/",
                                            "anchor_text": "Commercial Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "COLORBOND\u00ae Roof Installer",
                                    "url": "https://mzrooflogic.com.au/colorbond-roof-installer/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/colorbond-roof-installer/",
                                            "anchor_text": "COLORBOND\u00ae Roof Installer"
                                        }
                                    ]
                                },
                                {
                                    "text": "Hail Damage",
                                    "url": "https://mzrooflogic.com.au/insurance/hail-damaged-roofs/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/insurance/hail-damaged-roofs/",
                                            "anchor_text": "Hail Damage"
                                        }
                                    ]
                                },
                                {
                                    "text": "Blue Mountains",
                                    "url": "https://mzrooflogic.com.au/locations/blue-mountains/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/locations/blue-mountains/",
                                            "anchor_text": "Blue Mountains"
                                        }
                                    ]
                                },
                                {
                                    "text": "Northern Beaches",
                                    "url": "https://mzrooflogic.com.au/locations/northern-beaches/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/locations/northern-beaches/",
                                            "anchor_text": "Northern Beaches"
                                        }
                                    ]
                                },
                                {
                                    "text": "North Shore",
                                    "url": "https://mzrooflogic.com.au/locations/north-shore/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/locations/north-shore/",
                                            "anchor_text": "North Shore"
                                        }
                                    ]
                                },
                                {
                                    "text": "Sutherland Shire",
                                    "url": "https://mzrooflogic.com.au/locations/sutherland-shire/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/locations/sutherland-shire/",
                                            "anchor_text": "Sutherland Shire"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Sydney\u2019s most trusted metal roofing specialists, passionate about quality craftsmanship, honesty, and exceptional service.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "\u00a9 2026 MZ Roof Logic. All rights reserved. Web Design by Parramatta Web Design",
                                    "url": "https://parramattawebdesign.com.au/",
                                    "urls": [
                                        {
                                            "url": "https://parramattawebdesign.com.au/",
                                            "anchor_text": "Parramatta Web Design"
                                        }
                                    ]
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "ABN: 54 604 900 281",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "LIC #: 335510C",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Privacy Policy Terms of Use",
                                    "url": "https://mzrooflogic.com.au/privacy-policy/",
                                    "urls": [
                                        {
                                            "url": "https://mzrooflogic.com.au/privacy-policy/",
                                            "anchor_text": "Privacy Policy"
                                        },
                                        {
                                            "url": "https://mzrooflogic.com.au/terms-of-use/",
                                            "anchor_text": "Terms of Use"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Boutique, Caring Craftsmanship",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Skilled workmanship.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Replacements and repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Attractive, durable, and bushfire-rated products.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Wide choice of colours, styles, and finishes.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Previously Trading As MZ\u00b2 Roofing Pty Ltd",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Residential Roof Replacement",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Transform your home with a new metal roof \u2014 whether to boost kerb appeal, safeguard your property against bushfires, or upgrade from an existing damaged roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Bushfire-Rated Roofing",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Defend your home and loved ones with bushfire-rated roofing \u2014 enhancing safety, ensuring building compliance, and adherence to insurance conditions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Metal Roofing Services",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Schedule Your Free Roof Inspection NOW With MZ Roof Logic",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Commercial Roofing",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Safeguard your property, stock, staff, and customers with a new metal roof \u2014 for retail outlets, factories, warehouses, and offices.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Elegant Roofs, Expert Craftsmanship, & Exceptional Service",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At MZ Roof Logic, we\u2019re passionate metal roofers. Our team of skilled specialists are dedicated to providing you with premium-quality roofing solutions that stand the test of time.",
                                        "url": "https://mzrooflogic.com.au/projects/metal-roofing-central-coast/",
                                        "urls": [
                                            {
                                                "url": "https://mzrooflogic.com.au/projects/metal-roofing-central-coast/",
                                                "anchor_text": "metal roofers"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whether you\u2019re looking to defend your property, replace a damaged roof, or boost its kerb appeal \u2014 MZ Roof Logic gives you the perfect cover for your home or business.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "MZ Roof Logic \u2014 Driven by Excellence",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Restoring pride and craftsmanship in Australia\u2019s roofing sector \u2014 that\u2019s the driving force behind your local roofer, MZ Roof Logic.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Drawing on over 15 years of experience and guaranteeing care and precision from start to finish, we will continually exceed your expectations \u2014 giving you a stress-free experience and a beautiful roof that lasts.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "From commercial repairs to residential roof replacements, you always receive the same exceptional level of customer service. We work with you to select the ideal roofing style \u2014 from classic to contemporary \u2014 providing you with a roof that complements your property.",
                                        "url": "https://mzrooflogic.com.au/commercial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://mzrooflogic.com.au/commercial-roofing/",
                                                "anchor_text": "commercial repairs"
                                            },
                                            {
                                                "url": "https://mzrooflogic.com.au/roof-replacement/",
                                                "anchor_text": "residential roof replacements"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "The Benefits of Metal Roofing",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our metal roofing offers a wide range of benefits \u2014 making it the perfect choice for homes and businesses across Sydney:",
                                        "url": "https://mzrooflogic.com.au/projects/eastern-suburbs-roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://mzrooflogic.com.au/projects/eastern-suburbs-roof-replacement/",
                                                "anchor_text": "metal roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "\uf14a Boosts your property\u2019s structural strength.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Defends against Australia's challenging climate.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Increases kerb appeal and heightens market value.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Provides safeguarding against bushfires with compliant products.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Available in a wide variety of finishes, colours, and styles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Impressive thermal efficiency properties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Long manufacturer warranties.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Meets insurance and building code requirements.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Long lifespan and exemplary durability.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Low maintenance requirements.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Searching Online for the Best Roofers Near Me? You\u2019ve Found Us!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Speak to MZ Roof Logic",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Transforming Roofs, Enhancing Homes and Businesses",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "At MZ Roof Logic, we offer comprehensive metal roofing services for both residences and commercial buildings \u2014 always focussing on giving you the ultimate professional and worry-free experience.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our areas of expertise include:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Residential Roof Replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bushfire-Rated Roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Commercial Roofing",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We use premium materials and masterful craftsmanship to give your most valuable asset a roof that not only protects, but also elevates your home's beauty and value. Working closely with you to choose the perfect style, colour, and finish \u2014 you\u2019ll enjoy a roof you'll love for a lifetime.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our quality metal roofs, with the support of our bushfire-rated products, offer bushfire protection \u2014 defending your property and loved ones. Low maintenance and thermally efficient, we will transform your existing roof \u2014 shingle, slate, tile, asbestos, etc., \u2014 into a new, durable, and metal roof.",
                                        "url": "https://mzrooflogic.com.au/projects/metal-roofing-central-coast/",
                                        "urls": [
                                            {
                                                "url": "https://mzrooflogic.com.au/projects/metal-roofing-central-coast/",
                                                "anchor_text": "metal roofs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Protect your home and loved ones with a bushfire-rated roof professionally installed by MZ Roof Logic. Our roofs meet Australian Standards - complying with AS3959 and AS1530.8.2 - and satisfy your property's specific BAL rating \u2014 ensuring you remain insurance and building code compliant and giving you maximum safeguarding and reassurance.",
                                        "url": "https://ablis.business.gov.au/service/wa/australian-standard-as-3959-construction-of-buildings-in-bushfire-prone-areas/38414",
                                        "urls": [
                                            {
                                                "url": "https://ablis.business.gov.au/service/wa/australian-standard-as-3959-construction-of-buildings-in-bushfire-prone-areas/38414",
                                                "anchor_text": "AS3959"
                                            },
                                            {
                                                "url": "https://www.standards.org.au/standards-catalogue/standard-details?designation=as-1530-8-2-2018",
                                                "anchor_text": "AS1530.8.2"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "We use high-quality COLORBOND\u00ae steel combined with TBA Firefly products \u2014 known for exceptional fire resistance and ability to withstand ember attack and radiant heat. Every part of the installation process is precise and exhaustive, including addressing ingress areas around skylights, chimneys, and gutters, depending on your BAL rating.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether you operate a factory, warehouse, retail outlet, or healthcare facility \u2014 MZ Roof Logic will provide your enterprise with a high-quality metal roof. Not only defending your property, stock, machinery, staff and customers \u2014 it will also project a reassuring, professional image.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Furthermore, we fully understand the daily challenges faced by businesses \u2014 that\u2019s why we strive ceaselessly to limit downtime and cause the minimum of disruption. And, from minor maintenance to major overhauls, we offer a full repair service \u2014 including collaboration with other contractors where necessary.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Enjoy a Safer, More Attractive, and Energy-Efficient Home \u2014 Learn More",
                                        "url": "https://mzrooflogic.com.au/roof-replacement/",
                                        "urls": [
                                            {
                                                "url": "https://mzrooflogic.com.au/roof-replacement/",
                                                "anchor_text": "Enjoy a Safer, More Attractive, and Energy-Efficient Home \u2014 Learn More"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Protect Your Home and Family, and Ensure Compliance With a Bushfire Roof \u2014 Learn More",
                                        "url": "https://mzrooflogic.com.au/bush-fire-rated-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://mzrooflogic.com.au/bush-fire-rated-roofing/",
                                                "anchor_text": "Protect Your Home and Family, and Ensure Compliance With a Bushfire Roof \u2014 Learn More"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "A Replacement Metal Roof Is a Strategic Investment for Your Business \u2014 Learn More",
                                        "url": "https://mzrooflogic.com.au/commercial-roofing/",
                                        "urls": [
                                            {
                                                "url": "https://mzrooflogic.com.au/commercial-roofing/",
                                                "anchor_text": "A Replacement Metal Roof Is a Strategic Investment for Your Business \u2014 Learn More"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "The MZ Roof Logic Difference",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Experience the quality, care, and customer-focussed approach that puts you first \u2014 setting MZ Roof Logic apart from our competitors:",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Exceptional craftsmanship \u2014 high-quality steel roofing and skilled specialists \u2014 ensuring the quality workmanship promised.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Satisfaction is a priority \u2014\u00a0a tailored service with clear communication.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Integrity \u2014 throughout the project, you enjoy honesty, trust, and frank communication.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Attention to detail \u2014 working carefully around chimneys, flashings, and skylights.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Regulation compliance \u2014 ensuring you\u2019re always on the right side of regulations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Keeping our promises \u2014 completing projects on time, within budget, and to the specifications.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Local expertise \u2014 as roofers in Sydney, we understand the unique challenges of our climate and bushfire risk.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bushfire protection expertise \u2014 full understanding of BAL requirements and Australian Standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Speak to MZ Roof Logic TODAY",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Start Your Metal Roof Journey Today With MZ Roof Logic",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "From the initial free measure and quote to project completion, we ensure you enjoy a worry-free and reassuring experience. Combining skilled workmanship with premium materials, your property benefits from a long-lasting, protective, and compliant roof.",
                                        "url": "https://mzrooflogic.com.au/projects/",
                                        "urls": [
                                            {
                                                "url": "https://mzrooflogic.com.au/projects/",
                                                "anchor_text": "project completion"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "With your roof in expert and knowledgeable hands, you\u2019ll discover why MZ Roof Logic is the trusted choice for businesses and homeowners across Sydney.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "With MZ Roof Logic, You Gain the Benefits Of:",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "\uf14a Trusted local roofers with over 15 years of experience.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Transparency, integrity, and honesty.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a A company that keeps its promises.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Insurance and building code compliance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Having the job done right, the first time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Expert bushfire protection where required.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Safety and protection for you, your family, or your business.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Precise and skilled existing roof removal.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\uf14a Preservation of existing roof furniture, features, and fittings.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Trusted local roofers with over 15 years of experience.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Transparency, integrity, and honesty.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "A company that keeps its promises.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Having the job done right, the first time.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Expert bushfire protection where required.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Safety and protection for you, your family, or your business.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Precise and skilled existing roof removal.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Preservation of existing roof furniture, features, and fittings.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Insurance and building code compliance.",
                                        "url": "https://www.sa.gov.au/topics/business-and-trade/building-industry/building-rules-regulations-and-information/the-building-code-of-australia",
                                        "urls": [
                                            {
                                                "url": "https://www.sa.gov.au/topics/business-and-trade/building-industry/building-rules-regulations-and-information/the-building-code-of-australia",
                                                "anchor_text": "building code compliance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Metal Roofing Services",
                                "main_title": "MZ Roof Logic \u2014\nYour Premium Metal Roofers",
                                "author": "mzrooflogic.com.au",
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0475052327",
                                "0485854336"
                            ],
                            "emails": null
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}