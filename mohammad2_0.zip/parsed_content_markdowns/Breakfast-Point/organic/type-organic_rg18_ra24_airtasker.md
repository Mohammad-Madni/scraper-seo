{
    "id": "01190728-1132-0216-0000-8466337bad1a",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0390 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.airtasker.com/au/services/roofing/ashfield-nsw/",
        "target": "www.airtasker.com",
        "start_url": "https://www.airtasker.com/au/services/roofing/ashfield-nsw/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Breakfast-Point\\organic\\type-organic_rg18_ra24_airtasker.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:28:19 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": [
                                {
                                    "text": "What are you looking for?",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Pick a type of task.",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "I'm looking for work in ...",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "I\u2019m looking to hire someone for ...",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "As a tasker",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "As a poster",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Auto Electricians",
                                    "url": "https://www.airtasker.com/au/services/auto-electrician/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/auto-electrician/",
                                            "anchor_text": "Auto Electricians"
                                        }
                                    ]
                                },
                                {
                                    "text": "Bicycle Service",
                                    "url": "https://www.airtasker.com/au/services/bicycle/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/bicycle/",
                                            "anchor_text": "Bicycle Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Building & Construction",
                                    "url": "https://www.airtasker.com/au/services/building-construction/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/building-construction/",
                                            "anchor_text": "Building & Construction"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Body Work",
                                    "url": "https://www.airtasker.com/au/services/car-bodywork/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-bodywork/",
                                            "anchor_text": "Car Body Work"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Detailing",
                                    "url": "https://www.airtasker.com/au/services/car-detailing/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-detailing/",
                                            "anchor_text": "Car Detailing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Repair",
                                    "url": "https://www.airtasker.com/au/services/car-repair/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-repair/",
                                            "anchor_text": "Car Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Car Service",
                                    "url": "https://www.airtasker.com/au/services/car-servicing/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/car-servicing/",
                                            "anchor_text": "Car Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "Cat Care",
                                    "url": "https://www.airtasker.com/au/services/cat-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/cat-care/",
                                            "anchor_text": "Cat Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Computers & IT",
                                    "url": "https://www.airtasker.com/au/services/computers/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/computers/",
                                            "anchor_text": "Computers & IT"
                                        }
                                    ]
                                },
                                {
                                    "text": "Dog Care",
                                    "url": "https://www.airtasker.com/au/services/dog-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/dog-care/",
                                            "anchor_text": "Dog Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Furniture Assembly",
                                    "url": "https://www.airtasker.com/au/services/furniture-assembly/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/furniture-assembly/",
                                            "anchor_text": "Furniture Assembly"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gate Installation",
                                    "url": "https://www.airtasker.com/au/services/gate-installation/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/gate-installation/",
                                            "anchor_text": "Gate Installation"
                                        }
                                    ]
                                },
                                {
                                    "text": "Heating & Cooling",
                                    "url": "https://www.airtasker.com/au/services/heating-cooling/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/heating-cooling/",
                                            "anchor_text": "Heating & Cooling"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Automation and Security",
                                    "url": "https://www.airtasker.com/au/services/home-automation-security/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/home-automation-security/",
                                            "anchor_text": "Home Automation and Security"
                                        }
                                    ]
                                },
                                {
                                    "text": "Home Theatre",
                                    "url": "https://www.airtasker.com/au/services/home-theatre/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/home-theatre/",
                                            "anchor_text": "Home Theatre"
                                        }
                                    ]
                                },
                                {
                                    "text": "Interior Designer",
                                    "url": "https://www.airtasker.com/au/services/interior-design/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/interior-design/",
                                            "anchor_text": "Interior Designer"
                                        }
                                    ]
                                },
                                {
                                    "text": "Lawn Care",
                                    "url": "https://www.airtasker.com/au/services/lawn-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/lawn-care/",
                                            "anchor_text": "Lawn Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Makeup Artist",
                                    "url": "https://www.airtasker.com/au/services/makeup-artist/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/makeup-artist/",
                                            "anchor_text": "Makeup Artist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Mobile Mechanic",
                                    "url": "https://www.airtasker.com/au/services/mobile-mechanic/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/mobile-mechanic/",
                                            "anchor_text": "Mobile Mechanic"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pest Control",
                                    "url": "https://www.airtasker.com/au/services/pest-control/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/pest-control/",
                                            "anchor_text": "Pest Control"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pet Care",
                                    "url": "https://www.airtasker.com/au/services/pet-care/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/pet-care/",
                                            "anchor_text": "Pet Care"
                                        }
                                    ]
                                },
                                {
                                    "text": "Pool Maintenance",
                                    "url": "https://www.airtasker.com/au/services/pool-maintenance/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/pool-maintenance/",
                                            "anchor_text": "Pool Maintenance"
                                        }
                                    ]
                                },
                                {
                                    "text": "Tattoo Artists",
                                    "url": "https://www.airtasker.com/au/services/tattoo-artist/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/tattoo-artist/",
                                            "anchor_text": "Tattoo Artists"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wall Hanging & Mounting",
                                    "url": "https://www.airtasker.com/au/services/wall-hanging-mounting/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/wall-hanging-mounting/",
                                            "anchor_text": "Wall Hanging & Mounting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Wheel & Tyre Service",
                                    "url": "https://www.airtasker.com/au/services/wheel-tyre-service/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/wheel-tyre-service/",
                                            "anchor_text": "Wheel & Tyre Service"
                                        }
                                    ]
                                },
                                {
                                    "text": "View all",
                                    "url": "https://www.airtasker.com/au/services/",
                                    "urls": [
                                        {
                                            "url": "https://www.airtasker.com/au/services/",
                                            "anchor_text": "View all"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "Airtasker Limited 2011-2026 \u00a9, All rights reserved",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Airtasker Limited 2011-2026 \u00a9, All rights reserved",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Existing Members",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Popular Categories",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Popular Locations",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "Find experienced local roofers in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Fill in a short form and get free quotes from local roofers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Great rating - 4.2/5 (11114+ reviews)",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get roofing contractors near me today",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Up to 50% cheaper than franchise dealers",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "No job too big or small",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Same day or next day service at no extra cost",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Gutter cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\u2026 or anything else",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Free insurance coverage",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Secure cashless payments",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Best rated roofers near me",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\" Good communication helped fix leaky roof came on a rainy day \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Nice work, great service \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" 5 stars. Blake was great with communication and professionalism. Excellent with gardening of property. \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Very reliable, did a great job & Chris was very nice to deal with. Highly recommend. \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Great work and effecient \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Friendly prompt and straightforward. I will continue to use him \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Shadi is good on what he is doing, straight forward and knowledgeable \"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\" Thank you. Went far and beyond to sort out the problem. Highly recommended. \"",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Lovepreet singh L",
                                        "url": "https://www.airtasker.com/users/b5934ba63556-p-17876571/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/b5934ba63556-p-17876571/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Lovepreet singh L"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Blacktown NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Alexander V",
                                        "url": "https://www.airtasker.com/users/be6594bb3c0f-p-33259377/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/be6594bb3c0f-p-33259377/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Alexander V"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Breakfast Point NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Blake R",
                                        "url": "https://www.airtasker.com/users/ba5d0df5e59e-p-32251252/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/ba5d0df5e59e-p-32251252/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Blake R"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Maroubra NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/maroubra-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/maroubra-nsw/",
                                                "anchor_text": "Maroubra NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Chris D",
                                        "url": "https://www.airtasker.com/users/chris-d-14219960/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/chris-d-14219960/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Chris D"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Macquarie Park NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Bilal H",
                                        "url": "https://www.airtasker.com/users/bilal-h-15858453/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/bilal-h-15858453/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Bilal H"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Druitt NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/mount-druitt-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/mount-druitt-nsw/",
                                                "anchor_text": "Mount Druitt NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hugh H",
                                        "url": "https://www.airtasker.com/users/f3550ba302e6-p-28069060/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/f3550ba302e6-p-28069060/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Hugh H"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gosford NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Shadi A",
                                        "url": "https://www.airtasker.com/users/shadi-a-17287493/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/shadi-a-17287493/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Shadi A"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Sydney NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/north-sydney-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/north-sydney-nsw/",
                                                "anchor_text": "North Sydney NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mouhamad F",
                                        "url": "https://www.airtasker.com/users/4dbba83d197e-p-29513853/?initiatedFrom=Category%20Landing%20Page",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/users/4dbba83d197e-p-29513853/?initiatedFrom=Category%20Landing%20Page",
                                                "anchor_text": "Mouhamad F"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St James NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/st-james-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/st-james-nsw/",
                                                "anchor_text": "St James NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Latest Review",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Verified Badges",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "ID Verified",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Mobile Verified",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing reviews in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Quick and easy! Job left clean and tidy",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Did an amazing job cleaning my gutters ! Went above and beyond to make them clean. Will definitely use Aidans service again",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter cleaning for house and carport",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Incredible quality of work and attention to detail. We couldn\u2019t be happier with the new insulation and walls in our garden office. Thank you, Tommy!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Prompt and knows his stuff. Quickly fixed my gutter issue.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Put approx 15m flashing on roof area",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Shadi was on time. Cleaned the gutters with a powerful blower. Took pictures after cleaning.\nCleaned the mess made by cleaning gutters around the house. Will engage him again for next leaning..",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hong does what he says he\u2019s going to do. Good communicator and knows what he\u2019s talking about with roof repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaking sky light in Skillion roof. Need the leak located and sealed.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Clean gutters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Insulation and gyprocking",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter cleaning",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get it done",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Choose the right person for your task and get it done.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Get it done now. Pay later.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Repay in 4 fortnightly instalments",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Available on payments up to $1,500",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "No interest",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Statistics from the most recent tasks on Airtasker over the last 3 years.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Airtasker has over 17 roofers in Ashfield NSW, with an average rating of 4.88 stars from 16 reviews. Get in touch with roofers such as Lovepreet singh L, Alexander V, and Blake R today to get a wide variety of Roofing jobs done.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The single-story slate roof requires resetting slipped slats and repointing the ridge cap.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The slate roof requires re-fixing some slats and re-pointing the ridge cap.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "One section of the carport roof is damaged and sticking out (see photo \u2013 circled in red).\nI need someone to either:\nproperly secure and fix it, or\ncut off the part that\u2019s sticking out to make it safe.\nThe roof material is corrugated sheeting (possibly fibro or tin).\nPlease bring your own tools and a ladder.\n\ud83d\udccd Location: Ashfield NSW 2131\n\ud83d\udd52 Time: Flexible \u2013 I\u2019m available any day/time that suits you.\n\ud83d\ude97 Easy access & parking available.\nPlease let me know your quote and availability.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Hi there, we need someone experienced in roofing to have a look at the back awning of our property as there\u2019s water coming into our kitchen when it rains and also around the back door so I suspect either blocked gutters or a small leak. This happened if few years ago and we had the roof patched. May need to touch up.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "There is a rusting pipe needs to be replaced , the flashing around pipe is also broken causing water leakage from the roof.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thank you Alex ! It was a difficult job but he did it perfectly and efficiently. Highly recommended his services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Seeking a profession to sound proof window. The dimensions of the window are 170 x 145 cm",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "roof leak in several places, on an old town house in Ashfield",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I just need someone to bring a ladder to clean a small section of my gutter.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Need someone who can clean gutter for a double storey, block of 6 unit, non strata. Must have insurance and provide receipt.\nLocation: Ashfield 2131",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Re-attach existing 5m metal gutter to back porch ( approximately 5m high ) .",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hello, I'm just getting prices for budgeting. How much would it be to get insulation installed in approx 160m2 roof space. There is no existing insulation, but there is air con ducting to work around. Tile roof, open, downlights, sarking, high pitch roof. I think I'm interested in, EWR4-580, Earthwool R4.0 Thermal Ceiling\nInsulation (580mm)",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Single level house, flat block: all gutters",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof repointing, sections ridge caps",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "I need a price to replace and install a roofling for a 1985 landcruiser 70 series bundera hardtop.\nOr just to install the one I already have give me a price for both thanks.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hello Airtaskers,\nMy home in Ashfield needs some roof repair and maintenance work to make it watertight. Please see below for the details.\nAbout the home:\n1) Single Storey Home\n2) There are no observable leaks\nAttached are a few photos FYI\nWork needed:\nRepointing Roof caps pictures attached Fix/replace damaged/broken/loose/misplaced tiles where necessary. I have some spare tiles.\nUnblock downpipes around the house where deemed necessary\nWhat I expect from you:\nYou have valid licence and insurance\nI need a specific quote including:\nscope of work\ncost\nwarranty period\nThe roof should still look consistent after the work done:\nComplete the job on a sunny day\nDon\u2019t damage existing tiles, TV antenna, walls, windows, etc\nThere should be no leak after the work done\nMisc: I am at home most of the time and am flexible for appointments.\nThanks very much.\nRegards, BA",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We have a leak.\nWater is coming through around a vent pipe through a tiled roof. The water is tracking along a rafter, and is appearing in multiple locations through the ceiling.\nWe need the leak stopped ASAP, and a professional opinion on what caused this leak.\nRecent renovations may have damaged the flashing or tiles.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thank you for coming so quickly and fixing the hole in our roof!! Lifesaver. Recommend",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hi, I'm looking for someone who can replace/reinforce some timber planks lining the rear edge of the roof which seems to be worn. Some pieces have fallen off from recent strong winds.\nMust be able to supply timber pieces.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The roofs is single level It needs a pressure clean. The gutters need to be cleared of leaf matter. The house is single storey, and garage is seperate from house.\nBoth house and garage roofs need pressure cleaning and gutter cleaning.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Best roof cleaners, professional, on time, and they have delivered through service. Highly recommended",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "In a two-story building, water drips into the building due to electrical wiring in the corner.\nI'm looking for someone who can repair it urgently.\nroof around 6.5m-7meters from ground no extra option please !!!!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Thank you Sh\nSo quick and correct service",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Recent Roofing tasks in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Hello,\nWe have a potential possum or rat(s) living in our roof, a two-storey house in Ashfield. There's access to the roof internally, from the top floor, through an access hole in the ceiling. We've noticed sounds of scratching and movement over the last few weeks, getting noisier in the last few days (disturbing our sleep!)\nWe'd love some assistance determining where the noise is coming from and removing the living pest. We've tracked it to a particular room where the noise is heard the most overnight. Thank you!\nEdward",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Prompt & informative inspection - thanks!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Ashfield NSW",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Last updated on 18th Jan 2026 5:39am",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Home /",
                                        "url": "https://www.airtasker.com/au/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/",
                                                "anchor_text": "Home"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Services /",
                                        "url": "https://www.airtasker.com/au/services/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/",
                                                "anchor_text": "Services"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.airtasker.com/au/services/roofing/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "What's the average cost of a roofer in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "What's the average cost of a roofer in Ashfield NSW",
                                        "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                                "anchor_text": "What's the average cost of a roofer in Ashfield NSW"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "$186 - $422",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Average reviews for Roofing Services in Ashfield NSW",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "based on 16 reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Post your task",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Tell us what you need, it's FREE to post.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Review offers",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Get offers from trusted Taskers and view profiles.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "20+",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Tasks successfully completed",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "3",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Average amount of offers per task",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "5",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "mins",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Average time to receive offers",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Related Services near me",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Waterproofing near me",
                                        "url": "https://www.airtasker.com/au/services/waterproofing/ashfield-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/waterproofing/ashfield-nsw/",
                                                "anchor_text": "Waterproofing near me"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Related Locations",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Homebush South",
                                        "url": "https://www.airtasker.com/au/services/roofing/homebush-south-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/homebush-south-nsw/",
                                                "anchor_text": "Homebush South"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://www.airtasker.com/au/services/roofing/summer-hill-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/summer-hill-nsw/",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Abbotsford NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/abbotsford-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/abbotsford-nsw/",
                                                "anchor_text": "Abbotsford NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mid North Coast",
                                        "url": "https://www.airtasker.com/au/services/roofing/mid-north-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/mid-north-coast/",
                                                "anchor_text": "Mid North Coast"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Enfield NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/enfield-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/enfield-nsw/",
                                                "anchor_text": "Enfield NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lewisham NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/lewisham-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/lewisham-nsw/",
                                                "anchor_text": "Lewisham NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Burwood North",
                                        "url": "https://www.airtasker.com/au/services/roofing/burwood-north-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/burwood-north-nsw/",
                                                "anchor_text": "Burwood North"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://www.airtasker.com/au/services/roofing/dulwich-hill-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/dulwich-hill-nsw/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/croydon-park-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/croydon-park-nsw/",
                                                "anchor_text": "Croydon Park NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strathfield South",
                                        "url": "https://www.airtasker.com/au/services/roofing/strathfield-south-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/strathfield-south-nsw/",
                                                "anchor_text": "Strathfield South"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Homebush West",
                                        "url": "https://www.airtasker.com/au/services/roofing/homebush-west-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/homebush-west-nsw/",
                                                "anchor_text": "Homebush West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Concord West",
                                        "url": "https://www.airtasker.com/au/services/roofing/concord-west-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/concord-west-nsw/",
                                                "anchor_text": "Concord West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": "https://www.airtasker.com/au/services/roofing/five-dock-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/five-dock-nsw/",
                                                "anchor_text": "Five Dock"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Burwood NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/burwood-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/burwood-nsw/",
                                                "anchor_text": "Burwood NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Homebush NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/homebush-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/homebush-nsw/",
                                                "anchor_text": "Homebush NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dobroyd Point",
                                        "url": "https://www.airtasker.com/au/services/roofing/dobroyd-point-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/dobroyd-point-nsw/",
                                                "anchor_text": "Dobroyd Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Annandale NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/annandale-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/annandale-nsw/",
                                                "anchor_text": "Annandale NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leichhardt NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/leichhardt-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/leichhardt-nsw/",
                                                "anchor_text": "Leichhardt NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strathfield NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/strathfield-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/strathfield-nsw/",
                                                "anchor_text": "Strathfield NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Inner West Sydney",
                                        "url": "https://www.airtasker.com/au/services/roofing/inner-west-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/inner-west-sydney/",
                                                "anchor_text": "Inner West Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Russell Lea",
                                        "url": "https://www.airtasker.com/au/services/roofing/russell-lea-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/russell-lea-nsw/",
                                                "anchor_text": "Russell Lea"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon NSW",
                                        "url": "https://www.airtasker.com/au/services/roofing/croydon-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/croydon-nsw/",
                                                "anchor_text": "Croydon NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What is Airtasker?",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Suggested reads about Roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Top Locations",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Sunshine Coast Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/sunshine-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sunshine-coast/",
                                                "anchor_text": "Sunshine Coast Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Adelaide Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/adelaide/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/adelaide/",
                                                "anchor_text": "Adelaide Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Perth Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/perth/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/perth/",
                                                "anchor_text": "Perth Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hobart Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/hobart/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/hobart/",
                                                "anchor_text": "Hobart Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Central Coast Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/central-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/central-coast/",
                                                "anchor_text": "Central Coast Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wollongong Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/wollongong-nsw/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/wollongong-nsw/",
                                                "anchor_text": "Wollongong Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Newcastle Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/newcastle/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/newcastle/",
                                                "anchor_text": "Newcastle Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/sydney/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/sydney/",
                                                "anchor_text": "Sydney Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Parramatta Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/parramatta/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/parramatta/",
                                                "anchor_text": "Parramatta Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Ballarat Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/ballarat/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/ballarat/",
                                                "anchor_text": "Ballarat Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Geelong Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/geelong/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/geelong/",
                                                "anchor_text": "Geelong Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Melbourne Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/melbourne/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/melbourne/",
                                                "anchor_text": "Melbourne Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canberra Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/canberra/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/canberra/",
                                                "anchor_text": "Canberra Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Brisbane Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/brisbane/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/brisbane/",
                                                "anchor_text": "Brisbane Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gold Coast Roofing",
                                        "url": "https://www.airtasker.com/au/services/roofing/gold-coast/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/services/roofing/gold-coast/",
                                                "anchor_text": "Gold Coast Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "View more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does gutter cleaning cost in Australia?",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does gutter cleaning cost in Australia?",
                                        "url": "https://www.airtasker.com/au/costs/gutter-cleaning/gutter-cleaning-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/gutter-cleaning/gutter-cleaning-cost/",
                                                "anchor_text": "How much does gutter cleaning cost in Australia?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof plumbing cost?",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does roof plumbing cost?",
                                        "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roofing/roof-plumbing-cost/",
                                                "anchor_text": "How much does roof plumbing cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does a new roof cost in Australia?",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does a new roof cost in Australia?",
                                        "url": "https://www.airtasker.com/au/costs/roof-installation/new-roofing-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roof-installation/new-roofing-cost/",
                                                "anchor_text": "How much does a new roof cost in Australia?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does a chimney sweep cost?",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does a chimney sweep cost?",
                                        "url": "https://www.airtasker.com/au/costs/chimney-sweep/chimney-sweeping-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/chimney-sweep/chimney-sweeping-cost/",
                                                "anchor_text": "How much does a chimney sweep cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does roof cleaning cost?",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does roof cleaning cost?",
                                        "url": "https://www.airtasker.com/au/costs/roof-cleaning/roof-cleaner-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/roof-cleaning/roof-cleaner-cost/",
                                                "anchor_text": "How much does roof cleaning cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Solar panel cleaning cost: What it takes to stay efficient in 2025",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Solar panel cleaning cost: What it takes to stay efficient in 2025",
                                        "url": "https://www.airtasker.com/au/costs/solar-panel-cleaning/solar-panel-cleaning-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/solar-panel-cleaning/solar-panel-cleaning-cost/",
                                                "anchor_text": "Solar panel cleaning cost: What it takes to stay efficient in 2025"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How much does insulation cost?",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How much does insulation cost?",
                                        "url": "https://www.airtasker.com/au/costs/insulation/insulation-cost/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/costs/insulation/insulation-cost/",
                                                "anchor_text": "How much does insulation cost?"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How to fix a leaking roof",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to fix a leaking roof",
                                        "url": "https://www.airtasker.com/au/guides/roof-leak-repair/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/guides/roof-leak-repair/",
                                                "anchor_text": "How to fix a leaking roof"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How to clean your gutters",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to clean your gutters",
                                        "url": "https://www.airtasker.com/au/guides/how-to-clean-gutters/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/guides/how-to-clean-gutters/",
                                                "anchor_text": "How to clean your gutters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How to fix your roof tiles",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "How to fix your roof tiles",
                                        "url": "https://www.airtasker.com/au/guides/how-to-fix-roof-tiles/",
                                        "urls": [
                                            {
                                                "url": "https://www.airtasker.com/au/guides/how-to-fix-roof-tiles/",
                                                "anchor_text": "How to fix your roof tiles"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Read more",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Slate roof repair",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "13th Jan 2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Repair a single-story Slate Roof",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "13th Jan 2026",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fix or Cut Off Damaged Carport Roof Panel \u2013 Ashfield",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "27th Oct 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof leak - check gutters and patch",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "6th Sep 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Plumbing pipe removal and install up to the roof",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "10th Aug 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Window Sound Insulation",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW 2131, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "12th Jul 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof repairs",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "24th Jun 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter clean",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "2nd Jun 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Gutter cleaning",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "27th May 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Re-attach existing 5m metal gutter to back porch",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "21st Jan 2025",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Install insulation in roof space (Ashfield)",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "22nd Dec 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Clean gutters",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "18th Dec 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Repointing double story roof",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "18th Nov 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Car rooflining",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "23rd Oct 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Work and Repointing",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield, New South Wales",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "22nd Oct 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fix a tiled roof leak around a vent pipe",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "27th Sep 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Replace/reinforce timber on edge of roof",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "9th Sep 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof and gutter clean",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW 2131, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "30th Jun 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof leaking",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "23rd Jun 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Remove living possum (or rat) from house roof",
                                "main_title": "Find experienced local roofers in Ashfield NSW",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield NSW, Australia",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "25th Apr 2024",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.88,
                                "max_rating_value": 5,
                                "rating_count": 16,
                                "relative_rating": 0.976
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}