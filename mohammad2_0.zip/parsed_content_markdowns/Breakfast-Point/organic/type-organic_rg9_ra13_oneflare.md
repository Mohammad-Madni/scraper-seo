{
    "id": "01190728-1132-0216-0000-b681ad3c8c0a",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0159 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.oneflare.com.au/roofing/nsw/breakfast-point",
        "target": "www.oneflare.com.au",
        "start_url": "https://www.oneflare.com.au/roofing/nsw/breakfast-point",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Breakfast-Point\\organic\\type-organic_rg9_ra13_oneflare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:34:44 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Best roofing experts in Breakfast Point",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Post a job now to get quotes from local roofing experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Breakfast Point",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average rating of roofing experts in Breakfast Point based on 240 reviews of 27 businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oneflare /",
                                        "url": "https://www.oneflare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/",
                                                "anchor_text": "Oneflare"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Categories /",
                                        "url": "https://www.oneflare.com.au/directory",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/directory",
                                                "anchor_text": "Categories"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.oneflare.com.au/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NSW /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw",
                                                "anchor_text": "NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                                "anchor_text": "Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "24 hours Downward Chevron",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Closes at 5:00 PM Downward Chevron",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Plumbing Expert",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Homebush West, NSW (3.5km from Homebush West)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Plumbing Expert offer to as storm water\u00a0plumbing refers to any work involving\u00a0roof flashing ,gutter ,fasical board and Roof tiles and Colorbond Job or covering, any part of a drainage system that collects or disposes of storm water, or any connection of storm water pipes to rain water tanks.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Plumbing Expert",
                                        "url": "https://www.oneflare.com.au/b/roof-plumbing-expert",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roof-plumbing-expert",
                                                "anchor_text": "Roof Plumbing Expert"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Allguard Roofing And Restoration Pty Ltd",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ryde, NSW (3.4km from Ryde)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully licensed and insured, we specialize in delivering top-quality roofing solutions tailored to your needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "we are your trusted local roofing experts in Sydney, proudly serving the community for over 25 years.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are one of Sydney\u2019s most trusted providers of roofing, painting, and guttering services. With years of experience in the industry, our reputation continues to grow through consistently delivering high-quality workmanship tailored to your needs. Our team of fully licensed professionals brings proven expertise in roof repairs, replacements, restorations, ongoing maintenance, complex gutter work, exterior painting, and a range of home improvement solutions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Allguard Roofing And Restoration Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/allguard-roofing-and-restoration-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/allguard-roofing-and-restoration-pty-ltd",
                                                "anchor_text": "Allguard Roofing And Restoration Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slide 1 of 2",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "S.A Building and Carpentry",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Regents Park, NSW (9.0km from Regents Park)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Warranty period & workmanship guarantee",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Honour all commitments we make - we build all houses as if they were our own",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Follow ups on all work to ensure customers are happy at every step of the process - your satisfaction is our priority!",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hi.\nI am a builder, carpenter and I do waterproofing. I have over 18 years experience in the building industry. We have a team of Archetics and Engineers. We Design the work for DA and CC.. approvals from council or Private Certifier.\nI build Granny flats, extensions , Renovations, New bathroom, All types of carpentry work. You will happy from our work.\nPlease see some of our reviews from Word of Mouth: https://www.wordofmouth.com.au/reviews/s-a-building-and-carpentry\nMy builder's licence number is: 141779C\nRegards\nShoaib",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "S.A Building and Carpentry",
                                        "url": "https://www.oneflare.com.au/b/s-a-carpentry",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/s-a-carpentry",
                                                "anchor_text": "S.A Building and Carpentry"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slide 1 of 6",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Kangaroof",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ryde, NSW (3.6km from Ryde)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Kangaroof is a family owned and operated business. We are big enough to provide our customers with all kinds of property services, yet we are small enough to provide you with outstanding and personalised service. Our business is based upon a high standard of workmanship and customer service. We\u2019ve achieved this through honesty, exceptional customer service and strong work ethics. Unlike many other major property services companies, we do not employ a commission based sales team nor do we outsource to any telemarking companies or pay commissions to sub-contractors, which keeps us highly competitive. You will be pleased to know that you will be dealing directly with one of our business owners from start to finish.\nAnother benefit in using",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Kangaroof",
                                        "url": "https://www.oneflare.com.au/b/kangaroof-australia",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/kangaroof-australia",
                                                "anchor_text": "Kangaroof"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Frontline Guttering",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ryde, NSW (2.4km from Ryde)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Frontline Guttering is a specialist gutter cleaning company based on the lower North Shore of Sydney. We service most of the metropolitan area, both residential and Commercial. Safety and Service are the things we value most highly\nWe have been operating for 3 years now and have a very large team of experienced gutter cleaners and installers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Frontline Guttering",
                                        "url": "https://www.oneflare.com.au/b/frontline-guttering",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/frontline-guttering",
                                                "anchor_text": "Frontline Guttering"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "D2plumbing",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Hunters Hill, NSW (3.5km from Hunters Hill)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "D2plumbing are a friendly fair priced company and are fully licenced and insured.\nwe are trained in all types of plumbing.\nTo see more about us check out our website on www.d2plumbing.com.au",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "D2plumbing",
                                        "url": "https://www.oneflare.com.au/b/d2plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/d2plumbing",
                                                "anchor_text": "D2plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Flash Plumbing Services",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Concord, NSW (1.7km from Concord)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flash plumbing services specialise in New residential plumbing (free quote)\ndrain cleaning and drain maintenance and utilise our custom built vehicles fitted with the latest equipment available High Pressure water jet cleaner for all blocked drains and sewer problems\nPlumbing for kitchens and bathrooms Roof and guttering repairs and installation Gas Installation, maintenance and repairs Complete Bathroom renovations\nNew Residential Plumbing / Gas / Drainage\nC.C T.V diagnostic pipe camera Electronic underground pipe and cable locator Hot Water Systems New - Repairs\nBackflow Prevention inspections and testing\nThermostatic Mixing Valves Electronic Pipe Location and Leak Detection .",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Flash Plumbing Services",
                                        "url": "https://www.oneflare.com.au/b/flash-plumbing-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/flash-plumbing-services",
                                                "anchor_text": "Flash Plumbing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Interstate Prestige Roofing",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Olympic Park, NSW (3.5km from Sydney Olympic Park)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All types of Roof maintenance we do! \u2022 Gutter Cleaning\n\u2022 Roof Repairs\n\u2022 Drive way Sealing\n\u2022 Roof Restorations\n\u2022 Roof Replacement\n\u2022 We specialise in, terracotta, concrete and Slate roof tiles.\n\u2022 7 Years Warranty\nEvery job is provided with warranty. Rain, hail or shine we are at your doorstep!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Interstate Prestige Roofing",
                                        "url": "https://www.oneflare.com.au/b/interstate-prestige-roofing-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/interstate-prestige-roofing-roofing",
                                                "anchor_text": "Interstate Prestige Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pitched Roofing",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Five Dock, NSW (3.2km from Five Dock)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a Family Based Roofing Business servicing all over Sydney based in Five Dock NSW.We have been in the Roofing Industry for 35 yrs.We specialise in all aspects of Roofing Slate,Tiles & Metal Roofing, also Guttering & Downpipes, Leaf guard, Gutter Cleaning Re -Roofs No Job Is Too Big Or To Small.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pitched Roofing",
                                        "url": "https://www.oneflare.com.au/b/pitched-roofing-432",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/pitched-roofing-432",
                                                "anchor_text": "Pitched Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fazwear Australia",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Wareemba, NSW (2.6km from Wareemba)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All aspects of roofing. Tile. Metal. Slate. Over 20 years experience. Family owned and operated. Servicing all of Sydney. Please call us for quote today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Fazwear Australia",
                                        "url": "https://www.oneflare.com.au/b/aus-roof-restorations-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/aus-roof-restorations-pty-ltd",
                                                "anchor_text": "Fazwear Australia"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Spartan Roofing And Guttering Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Strathfield, NSW (3.7km from Strathfield)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Spartan Roofing, we take pride in providing reliable, high-quality roofing services for homes and businesses across Sydney. As a local tradie, I\u2019m committed to delivering honest workmanship, clear communication, and solutions that are tailored to each customer\u2019s needs. Whether you need roof repairs, storm-damage restoration, guttering work, or a full roof replacement, you can count on me to get the job done properly. I combine years of hands-on experience with a genuine dedication to customer satisfaction, ensuring every project is completed safely, efficiently, and to the highest standard.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Spartan Roofing And Guttering Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/spartan-roofing-and-guttering-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/spartan-roofing-and-guttering-pty-ltd",
                                                "anchor_text": "Spartan Roofing And Guttering Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Care Roof Services",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield, NSW (5.3km from Ashfield)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All Care Roofing specialise in Roof Restoration and all roof maintenance work. Servicing all areas of Sydney we strive to provide top quality roof services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Care Roof Services",
                                        "url": "https://www.oneflare.com.au/b/all-care-roof-services-508",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-care-roof-services-508",
                                                "anchor_text": "All Care Roof Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Plumbing Expert",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood, NSW (4.1km from Burwood)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are Professional Roofing Company Based on Whole around the Sydney.We are mutually trade ,hardworking ,fit,smart and young who pride to take care in my work and delivering a professional Australia standard result . I run a fully insured and licensed . We Offer Gutter Cleaning Gutter Guard Installation\nGutter Installation High Pressure Wash Roof and Drive way Rebedding and Pointing Installation Metal roof On and Off Roof Repair Fasical Board Replace and Paint Gyprock Installation\nRoof Restoration We will look Forward to work with You ..\nYours Regard Roof Plumbing Expert Group\nwww.roofplumbingexpert.com.au [email\u00a0protected] 0416224505",
                                        "url": "https://www.oneflare.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Plumbing Expert",
                                        "url": "https://www.oneflare.com.au/b/roof-plumbing-expert-50",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roof-plumbing-expert-50",
                                                "anchor_text": "Roof Plumbing Expert"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Dekfast Metal Roofing",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Breakfast Point, NSW 0",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Click on View website link located above to see our website\nYour roof is one of the first thing people see. In addition, it plays a critical role in ensuring your safety! That\u2019s why it\u2019s important to leave your metal roof repairs, renovations and restorations in the hands of Sydney\u2019s trusted roof experts. The difference is obvious when you use licensed, skilled professionals to carry out your roofing needs.\nOur clients come from far and wide because they know they will receive unbeatable service every single time. That\u2019s a result of our unwavering commitment to consistently delivering a premium service to our clients, coupled with the best value for their money. We pride ourselves on the waves of happy customers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Dekfast Metal Roofing",
                                        "url": "https://www.oneflare.com.au/b/dekfast-metal-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/dekfast-metal-roofing",
                                                "anchor_text": "Dekfast Metal Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Roofing Services",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Croydon, NSW (4.2km from Croydon)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All Roofing Services has provided the Innerwest Sydney area with experienced, professional roof installation, repair maintenance advice and assessment, restoration and replacement for over 10 years. ARS specialise in Metal and Colorbond roof installation and replacement for residences and small businesses. We have expanded across Sydney with our Roof Replacements.\nAll Roofing Services also provide all aspects of services for roof plumbing and gutter installation, repair assessment and replacement and asbestos removal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Roofing Services",
                                        "url": "https://www.oneflare.com.au/b/all-roofing-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-roofing-services",
                                                "anchor_text": "All Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Arouianroofing Verified Business",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Rydalmere, NSW (7.0km from Rydalmere)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "I pride myself with good customer service and excellent work in all aspects of roofing\u2019s from re roofs, new roofs and roof maintenance to restorations, gutters and downpipes even gutter blow outs. I specialise in metal roofing with over a decade of experience in the field. I have a team ready for any kind of work whether its big or small.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Arouianroofing Verified Business",
                                        "url": "https://www.oneflare.com.au/b/arouianroofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/arouianroofing",
                                                "anchor_text": "Arouianroofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Deen Roofing Verified Business",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Auburn, NSW (6.7km from Auburn)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Deen Roofing focuses on the quality of work and our customer's satisfaction, we strive to provide the best experience possible for our customers, from the quality of work achieved to the quality of service provided to our customers. We offer a free no obligation quote. We possess over 10 years experience in the Roofing business and we endeavor to provide quality results to our customers for their roofing needs in every possible means.\nNo job is too big or too small and travelling is not an issue for us as Customer's satisfaction is our high priority.\nOur services include the following:\n-Gutter , downpipes , fascia installation & repair -Roof leak repair & general roof repair\n-Roof Restoration\n-Metal Roofing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Deen Roofing Verified Business",
                                        "url": "https://www.oneflare.com.au/b/deen-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/deen-roofing",
                                                "anchor_text": "Deen Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Top Roof Maintenance",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Parramatta, NSW (9.8km from Parramatta)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hi , I am peter , roofer and carpenter by trade, have great experience in this field and running this business last 5 years .\nI am professional in :\n1. Gutters cleaning 2. Gutters installation 3 . Cement pointing on roof 4. Roof washing 5. Installation of gutter guard 6 . Flashing on roof .\n7. Changing of tiles I have big Ute \u201c Ready to complete the jobs \u201c\nThanks",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Top Roof Maintenance",
                                        "url": "https://www.oneflare.com.au/b/top-roof-maintenance",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/top-roof-maintenance",
                                                "anchor_text": "Top Roof Maintenance"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get the right price for your job",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Oneflare Cost Guide Centre is your one-stop shop to help you set your budget; from smaller tasks to larger projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Top Breakfast Point roofing experts near you",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Browse top Roofing Expert experts with top ratings and reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best roofing experts in Breakfast Point",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "View more roofing experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Truss costs",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Truss costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Roof Truss costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $9,000 - $15,000",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Average price $9,000 - $15,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof costs",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roof costs",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Colorbond Roof costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $15,000 - $25,000",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Average price $15,000 - $25,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling costs",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Roof Tiling costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $35 - $140 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Average price $35 - $140 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing costs",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing costs",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Roofing costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $45 - $90 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Average price $45 - $90 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse roofing experts by suburb",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular searches on Oneflare",
                                "main_title": "Best roofing experts in Breakfast Point",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.8,
                                "max_rating_value": 5,
                                "rating_count": 240,
                                "relative_rating": 0.96
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}