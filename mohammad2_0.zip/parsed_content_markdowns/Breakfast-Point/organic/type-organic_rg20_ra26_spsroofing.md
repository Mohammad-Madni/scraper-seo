{
    "id": "01190728-1132-0216-0000-a3bf51e3b44c",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0427 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://spsroofing.com.au/areas/",
        "target": "spsroofing.com.au",
        "start_url": "https://spsroofing.com.au/areas/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Breakfast-Point\\organic\\type-organic_rg20_ra26_spsroofing.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:31:29 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "Property Check Channel",
                                    "url": "https://www.youtube.com/channel/UCRsC8oPEHOARWLpWoqQ8ItQ",
                                    "urls": [
                                        {
                                            "url": "https://www.youtube.com/channel/UCRsC8oPEHOARWLpWoqQ8ItQ",
                                            "anchor_text": "Property Check  Channel"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become A Member",
                                    "url": "https://spsroofing.com.au/sign-up/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/sign-up/",
                                            "anchor_text": "Become A Member"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacements",
                                    "url": "https://spsroofing.com.au/services/roof-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-replacements/",
                                            "anchor_text": "Roof Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://spsroofing.com.au/services/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restorations",
                                    "url": "https://spsroofing.com.au/services/roof-restorations/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-restorations/",
                                            "anchor_text": "Roof Restorations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://spsroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Services",
                                    "url": "https://spsroofing.com.au/services/gutter-services/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-services/",
                                            "anchor_text": "Gutter Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become a member",
                                    "url": "https://spsroofing.com.au/sign-up/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/sign-up/",
                                            "anchor_text": "Become a member"
                                        }
                                    ]
                                },
                                {
                                    "text": "Contact Us",
                                    "url": "https://spsroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/contact-us/",
                                            "anchor_text": "Contact Us"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booking Now",
                                    "url": "https://spsroofing.com.au/booking/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/booking/",
                                            "anchor_text": "Booking Now"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": {
                            "primary_content": [
                                {
                                    "text": "We're a Multi Award Winning Business",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Address Sydney NSW 2000 Tel 02 9067 9574 Operating Hours 24 hours / 7 days a week",
                                    "url": null,
                                    "urls": null
                                },
                                {
                                    "text": "Copyright 2026 | SPS Roofing | All Rights Reserved | SPS Roofing License No. 394055C",
                                    "url": null,
                                    "urls": null
                                }
                            ],
                            "secondary_content": [
                                {
                                    "text": "Gutter Services",
                                    "url": "https://spsroofing.com.au/services/gutter-services/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-services/",
                                            "anchor_text": "Gutter Services"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs Inner West",
                                    "url": "https://spsroofing.com.au/services/roof-repairs-inner-west/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-repairs-inner-west/",
                                            "anchor_text": "Roof Repairs Inner West"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-repairs/",
                                            "anchor_text": "Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Emergency Roof Repairs",
                                    "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/emergency-roof-repairs/",
                                            "anchor_text": "Emergency Roof Repairs"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Leak Detection",
                                    "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-leak-detection/",
                                            "anchor_text": "Roof Leak Detection"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Replacements",
                                    "url": "https://spsroofing.com.au/services/roof-replacements/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-replacements/",
                                            "anchor_text": "Roof Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Painting",
                                    "url": "https://spsroofing.com.au/services/roof-painting/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-painting/",
                                            "anchor_text": "Roof Painting"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Restorations",
                                    "url": "https://spsroofing.com.au/services/roof-restorations/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-restorations/",
                                            "anchor_text": "Roof Restorations"
                                        }
                                    ]
                                },
                                {
                                    "text": "Metal Roofing",
                                    "url": "https://spsroofing.com.au/services/metal-roofing/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/metal-roofing/",
                                            "anchor_text": "Metal Roofing"
                                        }
                                    ]
                                },
                                {
                                    "text": "Box Gutter Replacement",
                                    "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/box-gutter-replacement/",
                                            "anchor_text": "Box Gutter Replacement"
                                        }
                                    ]
                                },
                                {
                                    "text": "Gutter Cleaning",
                                    "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-cleaning/",
                                            "anchor_text": "Gutter Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Leaf Gutter Guard",
                                    "url": "https://spsroofing.com.au/services/leaf-guard/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/leaf-guard/",
                                            "anchor_text": "Leaf Gutter Guard"
                                        }
                                    ]
                                },
                                {
                                    "text": "Downpipe Repairs and Replacements",
                                    "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/gutter-downpipe-replacement/",
                                            "anchor_text": "Downpipe Repairs and Replacements"
                                        }
                                    ]
                                },
                                {
                                    "text": "Roof Cleaning",
                                    "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/services/roof-cleaning/",
                                            "anchor_text": "Roof Cleaning"
                                        }
                                    ]
                                },
                                {
                                    "text": "Booking an Urgent Repair",
                                    "url": "https://spsroofing.com.au/booking/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/booking/",
                                            "anchor_text": "Booking an Urgent Repair"
                                        }
                                    ]
                                },
                                {
                                    "text": "Speak to a Strata Specialist",
                                    "url": "https://spsroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/contact-us/",
                                            "anchor_text": "Speak to a Strata Specialist"
                                        }
                                    ]
                                },
                                {
                                    "text": "Become a lifetime Member Now",
                                    "url": "https://spsroofing.com.au/membership/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/membership/",
                                            "anchor_text": "Become a lifetime Member Now"
                                        }
                                    ]
                                },
                                {
                                    "text": "Work With Us",
                                    "url": "https://spsroofing.com.au/contact-us/",
                                    "urls": [
                                        {
                                            "url": "https://spsroofing.com.au/contact-us/",
                                            "anchor_text": "Work With Us"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "main_topic": [
                            {
                                "h_title": "0% Interest Payment Plan Get Your New Roof Financed",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We aim to help you solve your home improvements & repair issues without disturbing your household cashflow",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Complete 0% Interest Plans",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "No catches or gimmicks. Have an option to spend now, pay later!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Suburbs We Service",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Acacia Gardens",
                                        "url": "https://spsroofing.com.au/roof-repairs-acacia-gardens/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-acacia-gardens/",
                                                "anchor_text": "Acacia Gardens"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Agnes Banks",
                                        "url": "https://spsroofing.com.au/roof-repairs-agnes-banks/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-agnes-banks/",
                                                "anchor_text": "Agnes Banks"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Alfords Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-alfords-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-alfords-point/",
                                                "anchor_text": "Alfords Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Allambie Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-allambie-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-allambie-heights/",
                                                "anchor_text": "Allambie Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Allambie Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-allambie-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-allambie-heights/",
                                                "anchor_text": "Allambie Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Arndell Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-arndell-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-arndell-park/",
                                                "anchor_text": "Arndell Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Badgerys Creek",
                                        "url": "https://spsroofing.com.au/roof-repairs-badgerys-creek/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-badgerys-creek/",
                                                "anchor_text": "Badgerys Creek"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Balgowlah Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-balgowlah-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-balgowlah-heights/",
                                                "anchor_text": "Balgowlah Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Balmain East",
                                        "url": "https://spsroofing.com.au/roof-repairs-balmain-east/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-balmain-east/",
                                                "anchor_text": "Balmain East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Barden Ridge",
                                        "url": "https://spsroofing.com.au/roof-repairs-barden-ridge/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-barden-ridge/",
                                                "anchor_text": "Barden Ridge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bardwell Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-bardwell-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bardwell-park/",
                                                "anchor_text": "Bardwell Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bardwell Valley",
                                        "url": "https://spsroofing.com.au/roof-repairs-bardwell-valley/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bardwell-valley/",
                                                "anchor_text": "Bardwell Valley"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bass Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-bass-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bass-hill/",
                                                "anchor_text": "Bass Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Baulkham Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-baulkham-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-baulkham-hills/",
                                                "anchor_text": "Baulkham Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Beacon Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-beacon-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-beacon-hill/",
                                                "anchor_text": "Beacon Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Beaumont Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-beaumont-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-beaumont-hills/",
                                                "anchor_text": "Beaumont Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bella Vista",
                                        "url": "https://spsroofing.com.au/roof-repairs-bella-vista/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bella-vista/",
                                                "anchor_text": "Bella Vista"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bellevue Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-bellevue-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bellevue-hill/",
                                                "anchor_text": "Bellevue Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berkshire Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-berkshire-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-berkshire-park/",
                                                "anchor_text": "Berkshire Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berowra Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-berowra-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-berowra-heights/",
                                                "anchor_text": "Berowra Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Berowra Waters",
                                        "url": "https://spsroofing.com.au/roof-repairs-berowra-waters/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-berowra-waters/",
                                                "anchor_text": "Berowra Waters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Beverley Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-beverley-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-beverley-park/",
                                                "anchor_text": "Beverley Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Beverly Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-beverly-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-beverly-hills/",
                                                "anchor_text": "Beverly Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bexley North",
                                        "url": "https://spsroofing.com.au/roof-repairs-bexley-north/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bexley-north/",
                                                "anchor_text": "Bexley North"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bickley Vale",
                                        "url": "https://spsroofing.com.au/roof-repairs-bickley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bickley-vale/",
                                                "anchor_text": "Bickley Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bilgola Plateau",
                                        "url": "https://spsroofing.com.au/roof-repairs-bilgola-plateau/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bilgola-plateau/",
                                                "anchor_text": "Bilgola Plateau"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Blair Athol",
                                        "url": "https://spsroofing.com.au/roof-repairs-blair-athol/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-blair-athol/",
                                                "anchor_text": "Blair Athol"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bondi Beach",
                                        "url": "https://spsroofing.com.au/roof-repairs-bondi-beach/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bondi-beach/",
                                                "anchor_text": "Bondi Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bondi Junction",
                                        "url": "https://spsroofing.com.au/roof-repairs-bondi-junction/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bondi-junction/",
                                                "anchor_text": "Bondi Junction"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bondi North",
                                        "url": "https://spsroofing.com.au/roof-repairs-bondi-north/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bondi-north/",
                                                "anchor_text": "Bondi North"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bonnet Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-bonnet-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bonnet-bay/",
                                                "anchor_text": "Bonnet Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bonnyrigg Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-bonnyrigg-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bonnyrigg-heights/",
                                                "anchor_text": "Bonnyrigg Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bossley Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-bossley-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bossley-park/",
                                                "anchor_text": "Bossley Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Bow Bowing",
                                        "url": "https://spsroofing.com.au/roof-repairs-bow-bowing/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-bow-bowing/",
                                                "anchor_text": "Bow Bowing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Box Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-box-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-box-hill/",
                                                "anchor_text": "Box Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Breakfast Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-breakfast-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-breakfast-point/",
                                                "anchor_text": "Breakfast Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Brighton Le Sands",
                                        "url": "https://spsroofing.com.au/roof-repairs-brighton-le-sands/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-brighton-le-sands/",
                                                "anchor_text": "Brighton Le Sands"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Burwood Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-burwood-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-burwood-heights/",
                                                "anchor_text": "Burwood Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cabramatta West",
                                        "url": "https://spsroofing.com.au/roof-repairs-cabramatta-west/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-cabramatta-west/",
                                                "anchor_text": "Cabramatta West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cambridge Gardens",
                                        "url": "https://spsroofing.com.au/roof-repairs-cambridge-gardens/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-cambridge-gardens/",
                                                "anchor_text": "Cambridge Gardens"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cambridge Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-cambridge-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-cambridge-park/",
                                                "anchor_text": "Cambridge Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Camden South",
                                        "url": "https://spsroofing.com.au/roof-repairs-camden-south/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-camden-south/",
                                                "anchor_text": "Camden South"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canada Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-canada-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-canada-bay/",
                                                "anchor_text": "Canada Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canley Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-canley-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-canley-heights/",
                                                "anchor_text": "Canley Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Canley Vale",
                                        "url": "https://spsroofing.com.au/roof-repairs-canley-vale/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-canley-vale/",
                                                "anchor_text": "Canley Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Careel Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-careel-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-careel-bay/",
                                                "anchor_text": "Careel Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Caringbah South",
                                        "url": "https://spsroofing.com.au/roof-repairs-caringbah-south/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-caringbah-south/",
                                                "anchor_text": "Caringbah South"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Carnes Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-carnes-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-carnes-hill/",
                                                "anchor_text": "Carnes Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Carss Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-carss-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-carss-park/",
                                                "anchor_text": "Carss Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Castle Cove",
                                        "url": "https://spsroofing.com.au/roof-repairs-castle-cove/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-castle-cove/",
                                                "anchor_text": "Castle Cove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Castle Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-castle-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-castle-hill/",
                                                "anchor_text": "Castle Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cecil Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-cecil-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-cecil-park/",
                                                "anchor_text": "Cecil Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Centennial Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-centennial-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-centennial-park/",
                                                "anchor_text": "Centennial Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Centennial Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-centennial-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-centennial-park/",
                                                "anchor_text": "Centennial Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Central Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-central-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-central-park/",
                                                "anchor_text": "Central Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Chatswood West",
                                        "url": "https://spsroofing.com.au/roof-repairs-chatswood-west/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-chatswood-west/",
                                                "anchor_text": "Chatswood West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Chester Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-chester-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-chester-hill/",
                                                "anchor_text": "Chester Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Chipping Norton",
                                        "url": "https://spsroofing.com.au/roof-repairs-chipping-norton/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-chipping-norton/",
                                                "anchor_text": "Chipping Norton"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Church Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-church-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-church-point/",
                                                "anchor_text": "Church Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Circular Quay",
                                        "url": "https://spsroofing.com.au/roof-repairs-circular-quay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-circular-quay/",
                                                "anchor_text": "Circular Quay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Claremont Meadows",
                                        "url": "https://spsroofing.com.au/roof-repairs-claremont-meadows/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-claremont-meadows/",
                                                "anchor_text": "Claremont Meadows"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Clemton Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-clemton-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-clemton-park/",
                                                "anchor_text": "Clemton Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Coasters Retreat",
                                        "url": "https://spsroofing.com.au/roof-repairs-coasters-retreat/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-coasters-retreat/",
                                                "anchor_text": "Coasters Retreat"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cockatoo Island",
                                        "url": "https://spsroofing.com.au/roof-repairs-cockatoo-island/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-cockatoo-island/",
                                                "anchor_text": "Cockatoo Island"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Collaroy Plateau",
                                        "url": "https://spsroofing.com.au/roof-repairs-collaroy-plateau/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-collaroy-plateau/",
                                                "anchor_text": "Collaroy Plateau"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Concord West",
                                        "url": "https://spsroofing.com.au/roof-repairs-concord-west/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-concord-west/",
                                                "anchor_text": "Concord West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Condell Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-condell-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-condell-park/",
                                                "anchor_text": "Condell Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Connells Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-connells-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-connells-point/",
                                                "anchor_text": "Connells Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Constitution Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-constitution-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-constitution-hill/",
                                                "anchor_text": "Constitution Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cottage Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-cottage-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-cottage-point/",
                                                "anchor_text": "Cottage Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cottage Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-cottage-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-cottage-point/",
                                                "anchor_text": "Cottage Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Cremorne Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-cremorne-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-cremorne-point/",
                                                "anchor_text": "Cremorne Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Crows Nest",
                                        "url": "https://spsroofing.com.au/roof-repairs-crows-nest/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-crows-nest/",
                                                "anchor_text": "Crows Nest"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-croydon-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-croydon-park/",
                                                "anchor_text": "Croydon Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Croydon Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-croydon-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-croydon-park/",
                                                "anchor_text": "Croydon Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Curl Curl",
                                        "url": "https://spsroofing.com.au/roof-repairs-curl-curl/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-curl-curl/",
                                                "anchor_text": "Curl Curl"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Currans Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-currans-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-currans-hill/",
                                                "anchor_text": "Currans Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Darling Harbour",
                                        "url": "https://spsroofing.com.au/roof-repairs-darling-harbour/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-darling-harbour/",
                                                "anchor_text": "Darling Harbour"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Darling Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-darling-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-darling-point/",
                                                "anchor_text": "Darling Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dawes Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-dawes-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-dawes-point/",
                                                "anchor_text": "Dawes Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dean Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-dean-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-dean-park/",
                                                "anchor_text": "Dean Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dee Why",
                                        "url": "https://spsroofing.com.au/roof-repairs-dee-why/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-dee-why/",
                                                "anchor_text": "Dee Why"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Denham Court",
                                        "url": "https://spsroofing.com.au/roof-repairs-denham-court/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-denham-court/",
                                                "anchor_text": "Denham Court"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Denham Court",
                                        "url": "https://spsroofing.com.au/roof-repairs-denham-court/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-denham-court/",
                                                "anchor_text": "Denham Court"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dolans Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-dolans-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-dolans-bay/",
                                                "anchor_text": "Dolans Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dolls Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-dolls-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-dolls-point/",
                                                "anchor_text": "Dolls Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Double Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-double-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-double-bay/",
                                                "anchor_text": "Double Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dover Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-dover-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-dover-heights/",
                                                "anchor_text": "Dover Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Duffys Forest",
                                        "url": "https://spsroofing.com.au/roof-repairs-duffys-forest/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-duffys-forest/",
                                                "anchor_text": "Duffys Forest"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Duffys Forest",
                                        "url": "https://spsroofing.com.au/roof-repairs-duffys-forest/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-duffys-forest/",
                                                "anchor_text": "Duffys Forest"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dulwich Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-dulwich-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-dulwich-hill/",
                                                "anchor_text": "Dulwich Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Dundas Valley",
                                        "url": "https://spsroofing.com.au/roof-repairs-dundas-valley/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-dundas-valley/",
                                                "anchor_text": "Dundas Valley"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eagle Vale",
                                        "url": "https://spsroofing.com.au/roof-repairs-eagle-vale/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-eagle-vale/",
                                                "anchor_text": "Eagle Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "East Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-east-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-east-hills/",
                                                "anchor_text": "East Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "East Killara",
                                        "url": "https://spsroofing.com.au/roof-repairs-east-killara/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-east-killara/",
                                                "anchor_text": "East Killara"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "East Lindfield",
                                        "url": "https://spsroofing.com.au/roof-repairs-east-lindfield/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-east-lindfield/",
                                                "anchor_text": "East Lindfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "East Ryde",
                                        "url": "https://spsroofing.com.au/roof-repairs-east-ryde/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-east-ryde/",
                                                "anchor_text": "East Ryde"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "East Sydney",
                                        "url": "https://spsroofing.com.au/roof-repairs-east-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-east-sydney/",
                                                "anchor_text": "East Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "East Willoughby",
                                        "url": "https://spsroofing.com.au/roof-repairs-east-willoughby/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-east-willoughby/",
                                                "anchor_text": "East Willoughby"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eastern Creek",
                                        "url": "https://spsroofing.com.au/roof-repairs-eastern-creek/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-eastern-creek/",
                                                "anchor_text": "Eastern Creek"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Edensor Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-edensor-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-edensor-park/",
                                                "anchor_text": "Edensor Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Edmondson Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-edmondson-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-edmondson-park/",
                                                "anchor_text": "Edmondson Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Elanora Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-elanora-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-elanora-heights/",
                                                "anchor_text": "Elanora Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Elizabeth Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-elizabeth-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-elizabeth-bay/",
                                                "anchor_text": "Elizabeth Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Ellis Lane",
                                        "url": "https://spsroofing.com.au/roof-repairs-ellis-lane/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-ellis-lane/",
                                                "anchor_text": "Ellis Lane"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Elvina Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-elvina-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-elvina-bay/",
                                                "anchor_text": "Elvina Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emu Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-emu-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-emu-heights/",
                                                "anchor_text": "Emu Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Emu Plains",
                                        "url": "https://spsroofing.com.au/roof-repairs-emu-plains/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-emu-plains/",
                                                "anchor_text": "Emu Plains"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Englorie Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-englorie-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-englorie-park/",
                                                "anchor_text": "Englorie Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Erskine Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-erskine-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-erskine-park/",
                                                "anchor_text": "Erskine Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Eschol Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-eschol-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-eschol-park/",
                                                "anchor_text": "Eschol Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Fairfield East",
                                        "url": "https://spsroofing.com.au/roof-repairs-fairfield-east/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-fairfield-east/",
                                                "anchor_text": "Fairfield East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Fairfield Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-fairfield-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-fairfield-heights/",
                                                "anchor_text": "Fairfield Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Five Dock",
                                        "url": "https://spsroofing.com.au/roof-repairs-five-dock/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-five-dock/",
                                                "anchor_text": "Five Dock"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Forest Lodge",
                                        "url": "https://spsroofing.com.au/roof-repairs-forest-lodge/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-forest-lodge/",
                                                "anchor_text": "Forest Lodge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Frenchs Forest",
                                        "url": "https://spsroofing.com.au/roof-repairs-frenchs-forest/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-frenchs-forest/",
                                                "anchor_text": "Frenchs Forest"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Frenchs Forest",
                                        "url": "https://spsroofing.com.au/roof-repairs-frenchs-forest/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-frenchs-forest/",
                                                "anchor_text": "Frenchs Forest"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Garden Island",
                                        "url": "https://spsroofing.com.au/roof-repairs-garden-island/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-garden-island/",
                                                "anchor_text": "Garden Island"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Georges Hall",
                                        "url": "https://spsroofing.com.au/roof-repairs-georges-hall/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-georges-hall/",
                                                "anchor_text": "Georges Hall"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Glen Alpine",
                                        "url": "https://spsroofing.com.au/roof-repairs-glen-alpine/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-glen-alpine/",
                                                "anchor_text": "Glen Alpine"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Glenmore Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-glenmore-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-glenmore-park/",
                                                "anchor_text": "Glenmore Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Goat Island",
                                        "url": "https://spsroofing.com.au/roof-repairs-goat-island/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-goat-island/",
                                                "anchor_text": "Goat Island"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Grays Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-grays-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-grays-point/",
                                                "anchor_text": "Grays Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Square",
                                        "url": "https://spsroofing.com.au/roof-repairs-green-square/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-green-square/",
                                                "anchor_text": "Green Square"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Green Valley",
                                        "url": "https://spsroofing.com.au/roof-repairs-green-valley/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-green-valley/",
                                                "anchor_text": "Green Valley"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Greenfield Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-greenfield-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-greenfield-park/",
                                                "anchor_text": "Greenfield Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Greenhills Beach",
                                        "url": "https://spsroofing.com.au/roof-repairs-greenhills-beach/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-greenhills-beach/",
                                                "anchor_text": "Greenhills Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gregory Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-gregory-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-gregory-hills/",
                                                "anchor_text": "Gregory Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Guildford East",
                                        "url": "https://spsroofing.com.au/roof-repairs-guildford-east/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-guildford-east/",
                                                "anchor_text": "Guildford East"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Guildford North",
                                        "url": "https://spsroofing.com.au/roof-repairs-guildford-north/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-guildford-north/",
                                                "anchor_text": "Guildford North"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Guildford West",
                                        "url": "https://spsroofing.com.au/roof-repairs-guildford-west/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-guildford-west/",
                                                "anchor_text": "Guildford West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Gymea Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-gymea-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-gymea-bay/",
                                                "anchor_text": "Gymea Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Harrington Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-harrington-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-harrington-park/",
                                                "anchor_text": "Harrington Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Harris Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-harris-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-harris-park/",
                                                "anchor_text": "Harris Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hassall Grove",
                                        "url": "https://spsroofing.com.au/roof-repairs-hassall-grove/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-hassall-grove/",
                                                "anchor_text": "Hassall Grove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Horningsea Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-horningsea-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-horningsea-park/",
                                                "anchor_text": "Horningsea Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Horsley Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-horsley-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-horsley-park/",
                                                "anchor_text": "Horsley Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hoxton Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-hoxton-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-hoxton-park/",
                                                "anchor_text": "Hoxton Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hunters Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-hunters-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-hunters-hill/",
                                                "anchor_text": "Hunters Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hurlstone Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-hurlstone-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-hurlstone-park/",
                                                "anchor_text": "Hurlstone Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Hurstville Grove",
                                        "url": "https://spsroofing.com.au/roof-repairs-hurstville-grove/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-hurstville-grove/",
                                                "anchor_text": "Hurstville Grove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Jordan Springs",
                                        "url": "https://spsroofing.com.au/roof-repairs-jordan-springs/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-jordan-springs/",
                                                "anchor_text": "Jordan Springs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kangaroo Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-kangaroo-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-kangaroo-point/",
                                                "anchor_text": "Kangaroo Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kellyville Ridge",
                                        "url": "https://spsroofing.com.au/roof-repairs-kellyville-ridge/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-kellyville-ridge/",
                                                "anchor_text": "Kellyville Ridge"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kemps Creek",
                                        "url": "https://spsroofing.com.au/roof-repairs-kemps-creek/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-kemps-creek/",
                                                "anchor_text": "Kemps Creek"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Killarney Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-killarney-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-killarney-heights/",
                                                "anchor_text": "Killarney Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Killarney Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-killarney-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-killarney-heights/",
                                                "anchor_text": "Killarney Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kings Cross",
                                        "url": "https://spsroofing.com.au/roof-repairs-kings-cross/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-kings-cross/",
                                                "anchor_text": "Kings Cross"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kings Langley",
                                        "url": "https://spsroofing.com.au/roof-repairs-kings-langley/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-kings-langley/",
                                                "anchor_text": "Kings Langley"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kings Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-kings-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-kings-park/",
                                                "anchor_text": "Kings Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kingswood Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-kingswood-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-kingswood-park/",
                                                "anchor_text": "Kingswood Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kogarah Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-kogarah-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-kogarah-bay/",
                                                "anchor_text": "Kogarah Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Kyle Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-kyle-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-kyle-bay/",
                                                "anchor_text": "Kyle Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "La Perouse",
                                        "url": "https://spsroofing.com.au/roof-repairs-la-perouse/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-la-perouse/",
                                                "anchor_text": "La Perouse"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "La Perouse",
                                        "url": "https://spsroofing.com.au/roof-repairs-la-perouse/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-la-perouse/",
                                                "anchor_text": "La Perouse"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lalor Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-lalor-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-lalor-park/",
                                                "anchor_text": "Lalor Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove North",
                                        "url": "https://spsroofing.com.au/roof-repairs-lane-cove-north/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-lane-cove-north/",
                                                "anchor_text": "Lane Cove North"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lane Cove West",
                                        "url": "https://spsroofing.com.au/roof-repairs-lane-cove-west/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-lane-cove-west/",
                                                "anchor_text": "Lane Cove West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lavender Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-lavender-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-lavender-bay/",
                                                "anchor_text": "Lavender Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Leets Vale",
                                        "url": "https://spsroofing.com.au/roof-repairs-leets-vale/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-leets-vale/",
                                                "anchor_text": "Leets Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lethbridge Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-lethbridge-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-lethbridge-park/",
                                                "anchor_text": "Lethbridge Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Liberty Grove",
                                        "url": "https://spsroofing.com.au/roof-repairs-liberty-grove/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-liberty-grove/",
                                                "anchor_text": "Liberty Grove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lilli Pilli",
                                        "url": "https://spsroofing.com.au/roof-repairs-lilli-pilli/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-lilli-pilli/",
                                                "anchor_text": "Lilli Pilli"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Little Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-little-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-little-bay/",
                                                "anchor_text": "Little Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Little Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-little-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-little-bay/",
                                                "anchor_text": "Little Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Long Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-long-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-long-point/",
                                                "anchor_text": "Long Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lovett Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-lovett-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-lovett-bay/",
                                                "anchor_text": "Lovett Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lower Portland",
                                        "url": "https://spsroofing.com.au/roof-repairs-lower-portland/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-lower-portland/",
                                                "anchor_text": "Lower Portland"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Lucas Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-lucas-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-lucas-heights/",
                                                "anchor_text": "Lucas Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mackerel Beach",
                                        "url": "https://spsroofing.com.au/roof-repairs-mackerel-beach/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-mackerel-beach/",
                                                "anchor_text": "Mackerel Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Macquarie Fields",
                                        "url": "https://spsroofing.com.au/roof-repairs-macquarie-fields/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-macquarie-fields/",
                                                "anchor_text": "Macquarie Fields"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Macquarie Links",
                                        "url": "https://spsroofing.com.au/roof-repairs-macquarie-links/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-macquarie-links/",
                                                "anchor_text": "Macquarie Links"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Macquarie Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-macquarie-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-macquarie-park/",
                                                "anchor_text": "Macquarie Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Manly Vale",
                                        "url": "https://spsroofing.com.au/roof-repairs-manly-vale/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-manly-vale/",
                                                "anchor_text": "Manly Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Marsden Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-marsden-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-marsden-park/",
                                                "anchor_text": "Marsden Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mays Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-mays-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-mays-hill/",
                                                "anchor_text": "Mays Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "McMahons Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-mcmahons-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-mcmahons-point/",
                                                "anchor_text": "McMahons Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Menangle Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-menangle-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-menangle-park/",
                                                "anchor_text": "Menangle Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Merrylands West",
                                        "url": "https://spsroofing.com.au/roof-repairs-merrylands-west/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-merrylands-west/",
                                                "anchor_text": "Merrylands West"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Middle Cove",
                                        "url": "https://spsroofing.com.au/roof-repairs-middle-cove/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-middle-cove/",
                                                "anchor_text": "Middle Cove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Middle Dural",
                                        "url": "https://spsroofing.com.au/roof-repairs-middle-dural/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-middle-dural/",
                                                "anchor_text": "Middle Dural"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Middleton Grange",
                                        "url": "https://spsroofing.com.au/roof-repairs-middleton-grange/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-middleton-grange/",
                                                "anchor_text": "Middleton Grange"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Millers Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-millers-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-millers-point/",
                                                "anchor_text": "Millers Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Milsons Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-milsons-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-milsons-point/",
                                                "anchor_text": "Milsons Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Minto Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-minto-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-minto-heights/",
                                                "anchor_text": "Minto Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mona Vale",
                                        "url": "https://spsroofing.com.au/roof-repairs-mona-vale/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-mona-vale/",
                                                "anchor_text": "Mona Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Moore Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-moore-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-moore-park/",
                                                "anchor_text": "Moore Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Morning Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-morning-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-morning-bay/",
                                                "anchor_text": "Morning Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Annan",
                                        "url": "https://spsroofing.com.au/roof-repairs-mount-annan/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-mount-annan/",
                                                "anchor_text": "Mount Annan"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Druitt",
                                        "url": "https://spsroofing.com.au/roof-repairs-mount-druitt/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-mount-druitt/",
                                                "anchor_text": "Mount Druitt"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Kuring gai",
                                        "url": "https://spsroofing.com.au/roof-repairs-mount-kuring-gai/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-mount-kuring-gai/",
                                                "anchor_text": "Mount Kuring gai"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Lewis",
                                        "url": "https://spsroofing.com.au/roof-repairs-mount-lewis/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-mount-lewis/",
                                                "anchor_text": "Mount Lewis"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Pritchard",
                                        "url": "https://spsroofing.com.au/roof-repairs-mount-pritchard/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-mount-pritchard/",
                                                "anchor_text": "Mount Pritchard"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Mount Vernon",
                                        "url": "https://spsroofing.com.au/roof-repairs-mount-vernon/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-mount-vernon/",
                                                "anchor_text": "Mount Vernon"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Narellan Vale",
                                        "url": "https://spsroofing.com.au/roof-repairs-narellan-vale/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-narellan-vale/",
                                                "anchor_text": "Narellan Vale"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Narrabeen North",
                                        "url": "https://spsroofing.com.au/roof-repairs-narrabeen-north/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-narrabeen-north/",
                                                "anchor_text": "Narrabeen North"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Neutral Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-neutral-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-neutral-bay/",
                                                "anchor_text": "Neutral Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Balgowlah",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-balgowlah/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-balgowlah/",
                                                "anchor_text": "North Balgowlah"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Curl Curl",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-curl-curl/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-curl-curl/",
                                                "anchor_text": "North Curl Curl"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Epping",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-epping/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-epping/",
                                                "anchor_text": "North Epping"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Manly",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-manly/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-manly/",
                                                "anchor_text": "North Manly"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Parramatta",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-parramatta/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-parramatta/",
                                                "anchor_text": "North Parramatta"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Rocks",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-rocks/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-rocks/",
                                                "anchor_text": "North Rocks"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Ryde",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-ryde/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-ryde/",
                                                "anchor_text": "North Ryde"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North St Marys",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-st-marys/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-st-marys/",
                                                "anchor_text": "North St Marys"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Strathfield",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-strathfield/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-strathfield/",
                                                "anchor_text": "North Strathfield"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Sydney",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-sydney/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-sydney/",
                                                "anchor_text": "North Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Turramurra",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-turramurra/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-turramurra/",
                                                "anchor_text": "North Turramurra"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Wahroonga",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-wahroonga/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-wahroonga/",
                                                "anchor_text": "North Wahroonga"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "North Willoughby",
                                        "url": "https://spsroofing.com.au/roof-repairs-north-willoughby/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-north-willoughby/",
                                                "anchor_text": "North Willoughby"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Old Guildford",
                                        "url": "https://spsroofing.com.au/roof-repairs-old-guildford/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-old-guildford/",
                                                "anchor_text": "Old Guildford"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Old Toongabbie",
                                        "url": "https://spsroofing.com.au/roof-repairs-old-toongabbie/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-old-toongabbie/",
                                                "anchor_text": "Old Toongabbie"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "One Tree Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-one-tree-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-one-tree-point/",
                                                "anchor_text": "One Tree Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Oran Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-oran-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-oran-park/",
                                                "anchor_text": "Oran Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Orchard Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-orchard-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-orchard-hills/",
                                                "anchor_text": "Orchard Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Oxford Falls",
                                        "url": "https://spsroofing.com.au/roof-repairs-oxford-falls/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-oxford-falls/",
                                                "anchor_text": "Oxford Falls"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Oxley Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-oxley-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-oxley-park/",
                                                "anchor_text": "Oxley Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Oyster Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-oyster-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-oyster-bay/",
                                                "anchor_text": "Oyster Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Padstow Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-padstow-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-padstow-heights/",
                                                "anchor_text": "Padstow Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Palm Beach",
                                        "url": "https://spsroofing.com.au/roof-repairs-palm-beach/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-palm-beach/",
                                                "anchor_text": "Palm Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Peakhurst Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-peakhurst-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-peakhurst-heights/",
                                                "anchor_text": "Peakhurst Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pendle Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-pendle-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-pendle-hill/",
                                                "anchor_text": "Pendle Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pennant Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-pennant-hills/",
                                                "anchor_text": "Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Phillip Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-phillip-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-phillip-bay/",
                                                "anchor_text": "Phillip Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Phillip Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-phillip-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-phillip-bay/",
                                                "anchor_text": "Phillip Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Picnic Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-picnic-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-picnic-point/",
                                                "anchor_text": "Picnic Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Pleasure Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-pleasure-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-pleasure-point/",
                                                "anchor_text": "Pleasure Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Point Piper",
                                        "url": "https://spsroofing.com.au/roof-repairs-point-piper/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-point-piper/",
                                                "anchor_text": "Point Piper"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Port Botany",
                                        "url": "https://spsroofing.com.au/roof-repairs-port-botany/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-port-botany/",
                                                "anchor_text": "Port Botany"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Port Botany",
                                        "url": "https://spsroofing.com.au/roof-repairs-port-botany/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-port-botany/",
                                                "anchor_text": "Port Botany"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Port Hacking",
                                        "url": "https://spsroofing.com.au/roof-repairs-port-hacking/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-port-hacking/",
                                                "anchor_text": "Port Hacking"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Potts Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-potts-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-potts-hill/",
                                                "anchor_text": "Potts Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Potts Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-potts-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-potts-point/",
                                                "anchor_text": "Potts Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Quakers Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-quakers-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-quakers-hill/",
                                                "anchor_text": "Quakers Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Queens Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-queens-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-queens-park/",
                                                "anchor_text": "Queens Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Railway Square",
                                        "url": "https://spsroofing.com.au/roof-repairs-railway-square/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-railway-square/",
                                                "anchor_text": "Railway Square"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Ramsgate Beach",
                                        "url": "https://spsroofing.com.au/roof-repairs-ramsgate-beach/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-ramsgate-beach/",
                                                "anchor_text": "Ramsgate Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Regents Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-regents-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-regents-park/",
                                                "anchor_text": "Regents Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Revesby Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-revesby-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-revesby-heights/",
                                                "anchor_text": "Revesby Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rodd Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-rodd-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-rodd-point/",
                                                "anchor_text": "Rodd Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rooty Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-rooty-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-rooty-hill/",
                                                "anchor_text": "Rooty Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Ropes Crossing",
                                        "url": "https://spsroofing.com.au/roof-repairs-ropes-crossing/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-ropes-crossing/",
                                                "anchor_text": "Ropes Crossing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rose Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-rose-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-rose-bay/",
                                                "anchor_text": "Rose Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roseville Chase",
                                        "url": "https://spsroofing.com.au/roof-repairs-roseville-chase/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-roseville-chase/",
                                                "anchor_text": "Roseville Chase"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rouse Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-rouse-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-rouse-hill/",
                                                "anchor_text": "Rouse Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Rushcutters Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-rushcutters-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-rushcutters-bay/",
                                                "anchor_text": "Rushcutters Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Russell Lea",
                                        "url": "https://spsroofing.com.au/roof-repairs-russell-lea/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-russell-lea/",
                                                "anchor_text": "Russell Lea"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sackville North",
                                        "url": "https://spsroofing.com.au/roof-repairs-sackville-north/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-sackville-north/",
                                                "anchor_text": "Sackville North"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sandy Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-sandy-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-sandy-point/",
                                                "anchor_text": "Sandy Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sans Souci",
                                        "url": "https://spsroofing.com.au/roof-repairs-sans-souci/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-sans-souci/",
                                                "anchor_text": "Sans Souci"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Scotland Island",
                                        "url": "https://spsroofing.com.au/roof-repairs-scotland-island/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-scotland-island/",
                                                "anchor_text": "Scotland Island"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Seven Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-seven-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-seven-hills/",
                                                "anchor_text": "Seven Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Shanes Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-shanes-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-shanes-park/",
                                                "anchor_text": "Shanes Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "South Coogee",
                                        "url": "https://spsroofing.com.au/roof-repairs-south-coogee/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-south-coogee/",
                                                "anchor_text": "South Coogee"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "South Hurstville",
                                        "url": "https://spsroofing.com.au/roof-repairs-south-hurstville/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-south-hurstville/",
                                                "anchor_text": "South Hurstville"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "South Maroota",
                                        "url": "https://spsroofing.com.au/roof-repairs-south-maroota/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-south-maroota/",
                                                "anchor_text": "South Maroota"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "South Penrith",
                                        "url": "https://spsroofing.com.au/roof-repairs-south-penrith/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-south-penrith/",
                                                "anchor_text": "South Penrith"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "South Turramurra",
                                        "url": "https://spsroofing.com.au/roof-repairs-south-turramurra/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-south-turramurra/",
                                                "anchor_text": "South Turramurra"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "South Wentworthville",
                                        "url": "https://spsroofing.com.au/roof-repairs-south-wentworthville/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-south-wentworthville/",
                                                "anchor_text": "South Wentworthville"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Spring Farm",
                                        "url": "https://spsroofing.com.au/roof-repairs-spring-farm/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-spring-farm/",
                                                "anchor_text": "Spring Farm"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Andrews",
                                        "url": "https://spsroofing.com.au/roof-repairs-st-andrews/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-st-andrews/",
                                                "anchor_text": "St Andrews"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Clair",
                                        "url": "https://spsroofing.com.au/roof-repairs-st-clair/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-st-clair/",
                                                "anchor_text": "St Clair"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Helens Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-st-helens-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-st-helens-park/",
                                                "anchor_text": "St Helens Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Ives",
                                        "url": "https://spsroofing.com.au/roof-repairs-st-ives/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-st-ives/",
                                                "anchor_text": "St Ives"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Ives Chase",
                                        "url": "https://spsroofing.com.au/roof-repairs-st-ives-chase/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-st-ives-chase/",
                                                "anchor_text": "St Ives Chase"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Johns Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-st-johns-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-st-johns-park/",
                                                "anchor_text": "St Johns Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Marys",
                                        "url": "https://spsroofing.com.au/roof-repairs-st-marys/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-st-marys/",
                                                "anchor_text": "St Marys"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "St Peters",
                                        "url": "https://spsroofing.com.au/roof-repairs-st-peters/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-st-peters/",
                                                "anchor_text": "St Peters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Stanhope Gardens",
                                        "url": "https://spsroofing.com.au/roof-repairs-stanhope-gardens/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-stanhope-gardens/",
                                                "anchor_text": "Stanhope Gardens"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strathfield South",
                                        "url": "https://spsroofing.com.au/roof-repairs-strathfield-south/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-strathfield-south/",
                                                "anchor_text": "Strathfield South"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Strawberry Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-strawberry-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-strawberry-hills/",
                                                "anchor_text": "Strawberry Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Summer Hill",
                                        "url": "https://spsroofing.com.au/roof-repairs-summer-hill/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-summer-hill/",
                                                "anchor_text": "Summer Hill"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Surry Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-surry-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-surry-hills/",
                                                "anchor_text": "Surry Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sylvania Waters",
                                        "url": "https://spsroofing.com.au/roof-repairs-sylvania-waters/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-sylvania-waters/",
                                                "anchor_text": "Sylvania Waters"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Taren Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-taren-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-taren-point/",
                                                "anchor_text": "Taren Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Tennyson Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-tennyson-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-tennyson-point/",
                                                "anchor_text": "Tennyson Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terrey Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-terrey-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-terrey-hills/",
                                                "anchor_text": "Terrey Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Terrey Hills. Annangrove",
                                        "url": "https://spsroofing.com.au/roof-repairs-terrey-hills-annangrove/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-terrey-hills-annangrove/",
                                                "anchor_text": "Terrey Hills. Annangrove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Domain",
                                        "url": "https://spsroofing.com.au/roof-repairs-the-domain/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-the-domain/",
                                                "anchor_text": "The Domain"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Ponds",
                                        "url": "https://spsroofing.com.au/roof-repairs-the-ponds/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-the-ponds/",
                                                "anchor_text": "The Ponds"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "The Rocks",
                                        "url": "https://spsroofing.com.au/roof-repairs-the-rocks/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-the-rocks/",
                                                "anchor_text": "The Rocks"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Voyager Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-voyager-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-voyager-point/",
                                                "anchor_text": "Voyager Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Warwick Farm",
                                        "url": "https://spsroofing.com.au/roof-repairs-warwick-farm/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-warwick-farm/",
                                                "anchor_text": "Warwick Farm"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Watsons Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-watsons-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-watsons-bay/",
                                                "anchor_text": "Watsons Bay"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wattle Grove",
                                        "url": "https://spsroofing.com.au/roof-repairs-wattle-grove/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-wattle-grove/",
                                                "anchor_text": "Wattle Grove"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wentworth Point",
                                        "url": "https://spsroofing.com.au/roof-repairs-wentworth-point/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-wentworth-point/",
                                                "anchor_text": "Wentworth Point"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Werrington Downs",
                                        "url": "https://spsroofing.com.au/roof-repairs-werrington-downs/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-werrington-downs/",
                                                "anchor_text": "Werrington Downs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "West Hoxton",
                                        "url": "https://spsroofing.com.au/roof-repairs-west-hoxton/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-west-hoxton/",
                                                "anchor_text": "West Hoxton"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "West Pennant Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-west-pennant-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-west-pennant-hills/",
                                                "anchor_text": "West Pennant Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "West Pymble",
                                        "url": "https://spsroofing.com.au/roof-repairs-west-pymble/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-west-pymble/",
                                                "anchor_text": "West Pymble"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "West Ryde",
                                        "url": "https://spsroofing.com.au/roof-repairs-west-ryde/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-west-ryde/",
                                                "anchor_text": "West Ryde"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wetherill Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-wetherill-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-wetherill-park/",
                                                "anchor_text": "Wetherill Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Whale Beach",
                                        "url": "https://spsroofing.com.au/roof-repairs-whale-beach/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-whale-beach/",
                                                "anchor_text": "Whale Beach"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wheeler Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-wheeler-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-wheeler-heights/",
                                                "anchor_text": "Wheeler Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wiley Park",
                                        "url": "https://spsroofing.com.au/roof-repairs-wiley-park/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-wiley-park/",
                                                "anchor_text": "Wiley Park"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Winston Hills",
                                        "url": "https://spsroofing.com.au/roof-repairs-winston-hills/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-winston-hills/",
                                                "anchor_text": "Winston Hills"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wisemans Ferry",
                                        "url": "https://spsroofing.com.au/roof-repairs-wisemans-ferry/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-wisemans-ferry/",
                                                "anchor_text": "Wisemans Ferry"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Wolli Creek",
                                        "url": "https://spsroofing.com.au/roof-repairs-wolli-creek/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-wolli-creek/",
                                                "anchor_text": "Wolli Creek"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Woronora Heights",
                                        "url": "https://spsroofing.com.au/roof-repairs-woronora-heights/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-woronora-heights/",
                                                "anchor_text": "Woronora Heights"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Yowie Bay",
                                        "url": "https://spsroofing.com.au/roof-repairs-yowie-bay/",
                                        "urls": [
                                            {
                                                "url": "https://spsroofing.com.au/roof-repairs-yowie-bay/",
                                                "anchor_text": "Yowie Bay"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Same Day Service Guaranteed!",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Lifetime Workmanship Guarantee",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Emergency Roofing Repairs",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Proudly Servicing All Of Sydney!",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Process",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "1. Inspection",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "2. Meet Project Manager",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "3. Job Commences",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 5,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Enquire with the team for an Inspection or Quotes",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Send Enquiry",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Same Day Service Guaranteed!",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Lifetime Workmanship Guarantee",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "24/7 EMERGENCY Available",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Same Day Service Guaranteed!",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Lifetime Workmanship Guarantee",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "24/7 EMERGENCY Available",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "5-7 Minute Approval Time",
                                "main_title": "Suburbs We Service",
                                "author": null,
                                "language": "en",
                                "level": 6,
                                "primary_content": [
                                    {
                                        "text": "Apply & have an outcome in minutes!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "+02 9067 9574",
                                "02 9067 9574"
                            ],
                            "emails": [
                                "info@spsroofing.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}