{
    "id": "01190728-1132-0216-0000-a9359a288f42",
    "status_code": 40602,
    "status_message": "Task In Queue.",
    "time": "0.0027 sec.",
    "cost": 0,
    "result_count": 0,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://auscityroofing.com.au/roof-repairs-breakfast-point/",
        "target": "auscityroofing.com.au",
        "start_url": "https://auscityroofing.com.au/roof-repairs-breakfast-point/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Breakfast-Point\\organic\\type-organic_rg6_ra10_auscityroofing.md"
    },
    "result": null
}