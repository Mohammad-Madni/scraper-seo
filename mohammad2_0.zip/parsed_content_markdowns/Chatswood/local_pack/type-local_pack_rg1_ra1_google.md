# Type: local_pack | Rank: 1 | RG: 1
### Raw Row Data:
{
    "rank_group": "1",
    "rank_absolute": "1",
    "service": "roofer",
    "suburb": "Chatswood",
    "title": "Roofer Near Me - Roof Repair Sydney",
    "domain": "www.google.com",
    "url": "https://www.google.com/viewer/place?sca_esv=ed956a20e7b48028&hl=en&gl=AU&output=search&mid=/g/11b77fgvh5&pip=CgZyb29mZXIQAg%3D%3D",
    "description": "Open \u00b7 Chatswood NSW",
    "type": "local_pack"
}