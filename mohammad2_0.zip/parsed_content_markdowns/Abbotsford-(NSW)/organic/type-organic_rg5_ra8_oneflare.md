{
    "id": "01190727-1132-0216-0000-68e60f3bdb04",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0130 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://www.oneflare.com.au/roofing/nsw/abbotsford",
        "target": "www.oneflare.com.au",
        "start_url": "https://www.oneflare.com.au/roofing/nsw/abbotsford",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Abbotsford-(NSW)\\organic\\type-organic_rg5_ra8_oneflare.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:46 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": null,
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Best roofing experts in Abbotsford",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "Post a job now to get quotes from local roofing experts",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Average rating of roofing experts in Abbotsford based on 210 reviews of 25 businesses.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Oneflare /",
                                        "url": "https://www.oneflare.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/",
                                                "anchor_text": "Oneflare"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Categories /",
                                        "url": "https://www.oneflare.com.au/directory",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/directory",
                                                "anchor_text": "Categories"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Roofing /",
                                        "url": "https://www.oneflare.com.au/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing",
                                                "anchor_text": "Roofing"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "NSW /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw",
                                                "anchor_text": "NSW"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Sydney /",
                                        "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/roofing/nsw/sydney",
                                                "anchor_text": "Sydney"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "24 hours Downward Chevron",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Mount Roofing Services Pty Ltd",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Padstow, NSW (14.8km from Padstow)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Mount Roofing Services, we specialise in providing top-notch metal roofing solutions with a commitment to exceptional service. Whether it\u2019s new installations, expert repairs, or maintenance, we\u2019ve got all your roofing needs covered. Stay tuned for the latest industry trends, roofing tips, exciting projects, and innovative solutions designed to last.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Mount Roofing Services Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/mount-roofing-services-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/mount-roofing-services-pty-ltd",
                                                "anchor_text": "Mount Roofing Services Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Plumbing Expert",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Homebush West, NSW (4.6km from Homebush West)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Plumbing Expert offer to as storm water\u00a0plumbing refers to any work involving\u00a0roof flashing ,gutter ,fasical board and Roof tiles and Colorbond Job or covering, any part of a drainage system that collects or disposes of storm water, or any connection of storm water pipes to rain water tanks.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Plumbing Expert",
                                        "url": "https://www.oneflare.com.au/b/roof-plumbing-expert",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roof-plumbing-expert",
                                                "anchor_text": "Roof Plumbing Expert"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Fazwear Australia",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Wareemba, NSW (0.8km from Wareemba)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All aspects of roofing. Tile. Metal. Slate. Over 20 years experience. Family owned and operated. Servicing all of Sydney. Please call us for quote today.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Fazwear Australia",
                                        "url": "https://www.oneflare.com.au/b/aus-roof-restorations-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/aus-roof-restorations-pty-ltd",
                                                "anchor_text": "Fazwear Australia"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "D2plumbing",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Hunters Hill, NSW (2.7km from Hunters Hill)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "D2plumbing are a friendly fair priced company and are fully licenced and insured.\nwe are trained in all types of plumbing.\nTo see more about us check out our website on www.d2plumbing.com.au",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "D2plumbing",
                                        "url": "https://www.oneflare.com.au/b/d2plumbing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/d2plumbing",
                                                "anchor_text": "D2plumbing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Pitched Roofing",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Five Dock, NSW (1.9km from Five Dock)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are a Family Based Roofing Business servicing all over Sydney based in Five Dock NSW.We have been in the Roofing Industry for 35 yrs.We specialise in all aspects of Roofing Slate,Tiles & Metal Roofing, also Guttering & Downpipes, Leaf guard, Gutter Cleaning Re -Roofs No Job Is Too Big Or To Small.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Pitched Roofing",
                                        "url": "https://www.oneflare.com.au/b/pitched-roofing-432",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/pitched-roofing-432",
                                                "anchor_text": "Pitched Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Care Roof Services",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ashfield, NSW (4.2km from Ashfield)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All Care Roofing specialise in Roof Restoration and all roof maintenance work. Servicing all areas of Sydney we strive to provide top quality roof services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Care Roof Services",
                                        "url": "https://www.oneflare.com.au/b/all-care-roof-services-508",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-care-roof-services-508",
                                                "anchor_text": "All Care Roof Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Flash Plumbing Services",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Concord, NSW (2.4km from Concord)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Flash plumbing services specialise in New residential plumbing (free quote)\ndrain cleaning and drain maintenance and utilise our custom built vehicles fitted with the latest equipment available High Pressure water jet cleaner for all blocked drains and sewer problems\nPlumbing for kitchens and bathrooms Roof and guttering repairs and installation Gas Installation, maintenance and repairs Complete Bathroom renovations\nNew Residential Plumbing / Gas / Drainage\nC.C T.V diagnostic pipe camera Electronic underground pipe and cable locator Hot Water Systems New - Repairs\nBackflow Prevention inspections and testing\nThermostatic Mixing Valves Electronic Pipe Location and Leak Detection .",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Flash Plumbing Services",
                                        "url": "https://www.oneflare.com.au/b/flash-plumbing-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/flash-plumbing-services",
                                                "anchor_text": "Flash Plumbing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Plumbing Expert",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Burwood, NSW (3.9km from Burwood)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are Professional Roofing Company Based on Whole around the Sydney.We are mutually trade ,hardworking ,fit,smart and young who pride to take care in my work and delivering a professional Australia standard result . I run a fully insured and licensed . We Offer Gutter Cleaning Gutter Guard Installation\nGutter Installation High Pressure Wash Roof and Drive way Rebedding and Pointing Installation Metal roof On and Off Roof Repair Fasical Board Replace and Paint Gyprock Installation\nRoof Restoration We will look Forward to work with You ..\nYours Regard Roof Plumbing Expert Group\nwww.roofplumbingexpert.com.au [email\u00a0protected] 0416224505",
                                        "url": "https://www.oneflare.com.au/cdn-cgi/l/email-protection",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/cdn-cgi/l/email-protection",
                                                "anchor_text": "[email\u00a0protected]"
                                            }
                                        ]
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Roof Plumbing Expert",
                                        "url": "https://www.oneflare.com.au/b/roof-plumbing-expert-50",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/roof-plumbing-expert-50",
                                                "anchor_text": "Roof Plumbing Expert"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Red House Roofing",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Rozelle, NSW (4.4km from Rozelle)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Red House Roofing are skilled, professional and extremely reliable providing the very best roofing services. Protect and Enhance your home and investment with Red House Roofing AWARD WINNING WORK - Rob Everett is a former winner of the Sydney Morning Herald tradesman of the year competition. At Red House Roofing we offer a complete roofing service from small repairs to major heritage re-roofing work. Backed by a team of experienced tradesmen our director is an award winning second generation roofer with over 25 years roofing experience. Red House Roofing is a Sydney based roofing company who has expertise in all types of roofing requirements. Some of the services we offer are repairs and leaks, re-roofing, slate roofing, metal roofing, copper",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Red House Roofing",
                                        "url": "https://www.oneflare.com.au/b/red-house-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/red-house-roofing",
                                                "anchor_text": "Red House Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Bryce's Roof Restoration",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Haberfield, NSW (3.2km from Haberfield)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All areas of roof restoration and maintenance. Fully licenced sole trader and can offer much cheaper prices as I do not have all the overheads of a big business.\nServicing all of Sydney, free quotes and work guaranteed 7 years.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Bryce's Roof Restoration",
                                        "url": "https://www.oneflare.com.au/b/bryce-s-roof-restoration",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/bryce-s-roof-restoration",
                                                "anchor_text": "Bryce's Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Frontline Guttering",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ryde, NSW (3.9km from Ryde)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Frontline Guttering is a specialist gutter cleaning company based on the lower North Shore of Sydney. We service most of the metropolitan area, both residential and Commercial. Safety and Service are the things we value most highly\nWe have been operating for 3 years now and have a very large team of experienced gutter cleaners and installers",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Frontline Guttering",
                                        "url": "https://www.oneflare.com.au/b/frontline-guttering",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/frontline-guttering",
                                                "anchor_text": "Frontline Guttering"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Allguard Roofing And Restoration Pty Ltd",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ryde, NSW (4.8km from Ryde)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully licensed and insured, we specialize in delivering top-quality roofing solutions tailored to your needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "we are your trusted local roofing experts in Sydney, proudly serving the community for over 25 years.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We are one of Sydney\u2019s most trusted providers of roofing, painting, and guttering services. With years of experience in the industry, our reputation continues to grow through consistently delivering high-quality workmanship tailored to your needs. Our team of fully licensed professionals brings proven expertise in roof repairs, replacements, restorations, ongoing maintenance, complex gutter work, exterior painting, and a range of home improvement solutions.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Allguard Roofing And Restoration Pty Ltd",
                                        "url": "https://www.oneflare.com.au/b/allguard-roofing-and-restoration-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/allguard-roofing-and-restoration-pty-ltd",
                                                "anchor_text": "Allguard Roofing And Restoration Pty Ltd"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Slide 1 of 2",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Kangaroof",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Ryde, NSW (4.7km from Ryde)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Kangaroof is a family owned and operated business. We are big enough to provide our customers with all kinds of property services, yet we are small enough to provide you with outstanding and personalised service. Our business is based upon a high standard of workmanship and customer service. We\u2019ve achieved this through honesty, exceptional customer service and strong work ethics. Unlike many other major property services companies, we do not employ a commission based sales team nor do we outsource to any telemarking companies or pay commissions to sub-contractors, which keeps us highly competitive. You will be pleased to know that you will be dealing directly with one of our business owners from start to finish.\nAnother benefit in using",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Kangaroof",
                                        "url": "https://www.oneflare.com.au/b/kangaroof-australia",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/kangaroof-australia",
                                                "anchor_text": "Kangaroof"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "All Roofing Services",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Croydon, NSW (3.6km from Croydon)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All Roofing Services has provided the Innerwest Sydney area with experienced, professional roof installation, repair maintenance advice and assessment, restoration and replacement for over 10 years. ARS specialise in Metal and Colorbond roof installation and replacement for residences and small businesses. We have expanded across Sydney with our Roof Replacements.\nAll Roofing Services also provide all aspects of services for roof plumbing and gutter installation, repair assessment and replacement and asbestos removal.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "All Roofing Services",
                                        "url": "https://www.oneflare.com.au/b/all-roofing-services",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/all-roofing-services",
                                                "anchor_text": "All Roofing Services"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Interstate Prestige Roofing",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Sydney Olympic Park, NSW (5.2km from Sydney Olympic Park)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "All types of Roof maintenance we do! \u2022 Gutter Cleaning\n\u2022 Roof Repairs\n\u2022 Drive way Sealing\n\u2022 Roof Restorations\n\u2022 Roof Replacement\n\u2022 We specialise in, terracotta, concrete and Slate roof tiles.\n\u2022 7 Years Warranty\nEvery job is provided with warranty. Rain, hail or shine we are at your doorstep!",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Interstate Prestige Roofing",
                                        "url": "https://www.oneflare.com.au/b/interstate-prestige-roofing-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/interstate-prestige-roofing-roofing",
                                                "anchor_text": "Interstate Prestige Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Spartan Roofing And Guttering Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Strathfield, NSW (4.0km from Strathfield)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Spartan Roofing, we take pride in providing reliable, high-quality roofing services for homes and businesses across Sydney. As a local tradie, I\u2019m committed to delivering honest workmanship, clear communication, and solutions that are tailored to each customer\u2019s needs. Whether you need roof repairs, storm-damage restoration, guttering work, or a full roof replacement, you can count on me to get the job done properly. I combine years of hands-on experience with a genuine dedication to customer satisfaction, ensuring every project is completed safely, efficiently, and to the highest standard.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Spartan Roofing And Guttering Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/spartan-roofing-and-guttering-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/spartan-roofing-and-guttering-pty-ltd",
                                                "anchor_text": "Spartan Roofing And Guttering Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Harbour City Remedial Pty Ltd Verified Business",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Balmain East, NSW (6.0km from Balmain East)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "At Harbour City Remedial / Baker Roofing we care about our customers and our workmanship. Like no other, we offer a quality guarantee with all our work. We have in house quality managers that inspect each project once complete to ensure the job is done right. We do all types of roofing works to the highest standard including but not limited to: - Tile Re-Roofs. - Metal Re-Roofs.\n- Tile & Metal Maintenance Works.\n- Guttering & Downpipe works.\n- New Metal & Tile works. - Tile Re-Bedding & Pointing. - Asbestos Removal. - Leaf Mesh. & Much much more. Please get in contact with us today if there's anything you require.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Harbour City Remedial Pty Ltd Verified Business",
                                        "url": "https://www.oneflare.com.au/b/harbour-city-remedial-pty-ltd",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/harbour-city-remedial-pty-ltd",
                                                "anchor_text": "Harbour City Remedial Pty Ltd"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Integral Slate Roofing",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "Leichhardt, NSW (4.2km from Leichhardt)",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With nearly 20 years experience with all roofing materials from concrete & terracotta tiles slate, tin copper or zinc work, guttering & lead work. Carrying out new work or repairs. Specialists in the traditional craft of natural product slate Integral Slate Roofing works with sensitive heritage listed building giving the building the respect it requires AND works along side designers & architects on new builds to achieve any required look solving complicated details Works also carried out with \u2022 Velux window installation \u2022Renew roof valleys in colour bond zinc or copper \u2022Repointing ridge tiles in Flexipoint coloured to match your roof \u2022Whirly bird installation for roof ventilation \u2022Leek detection to fix historical or new leeks due to storm damage \u2022Re-roofs",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Integral Slate Roofing",
                                        "url": "https://www.oneflare.com.au/b/integral-slate-roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/b/integral-slate-roofing",
                                                "anchor_text": "Integral Slate Roofing"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Get the right price for your job",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "The Oneflare Cost Guide Centre is your one-stop shop to help you set your budget; from smaller tasks to larger projects.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Top Abbotsford roofing experts near you",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Browse top Roofing Expert experts with top ratings and reviews",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best roofing experts in Abbotsford",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "View more roofing experts",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Truss costs",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Truss costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Roof Truss costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $9,000 - $15,000",
                                        "url": "https://www.oneflare.com.au/costs/roof-truss",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-truss",
                                                "anchor_text": "Average price $9,000 - $15,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Colorbond Roof costs",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Colorbond Roof costs",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Colorbond Roof costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $15,000 - $25,000",
                                        "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/colorbond-roof",
                                                "anchor_text": "Average price $15,000 - $25,000"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Tiling costs",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Tiling costs",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Roof Tiling costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $35 - $140 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roof-tiling",
                                                "anchor_text": "Average price $35 - $140 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roofing costs",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roofing costs",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Roofing costs"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "Average price $45 - $90 per hour",
                                        "url": "https://www.oneflare.com.au/costs/roofing",
                                        "urls": [
                                            {
                                                "url": "https://www.oneflare.com.au/costs/roofing",
                                                "anchor_text": "Average price $45 - $90 per hour"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Browse roofing experts by suburb",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Popular searches on Oneflare",
                                "main_title": "Best roofing experts in Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "ratings": [
                            {
                                "name": null,
                                "rating_value": 4.8,
                                "max_rating_value": 5,
                                "rating_count": 210,
                                "relative_rating": 0.96
                            }
                        ],
                        "offers": null,
                        "comments": null,
                        "contacts": null
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}