{
    "id": "01190727-1132-0216-0000-53ad0473c4e7",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0196 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://m.yelp.com/biz/john-glen-plastering-abbotsford",
        "target": "m.yelp.com",
        "start_url": "https://m.yelp.com/biz/john-glen-plastering-abbotsford",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Abbotsford-(NSW)\\organic\\type-organic_rg16_ra21_m.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 0
            },
            "items_count": 0,
            "items": null
        }
    ]
}