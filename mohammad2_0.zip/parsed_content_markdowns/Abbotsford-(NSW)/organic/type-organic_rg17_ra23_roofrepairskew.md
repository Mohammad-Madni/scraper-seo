{
    "id": "01190727-1132-0216-0000-69ef5e13e325",
    "status_code": 20000,
    "status_message": "Ok.",
    "time": "0.0275 sec.",
    "cost": 0,
    "result_count": 1,
    "path": [
        "v3",
        "on_page",
        "content_parsing"
    ],
    "data": {
        "api": "on_page",
        "function": "content_parsing",
        "url": "https://roofrepairskew.com.au/roof-repairs-abbotsford/",
        "target": "roofrepairskew.com.au",
        "start_url": "https://roofrepairskew.com.au/roof-repairs-abbotsford/",
        "enable_content_parsing": true,
        "max_crawl_pages": 1,
        "tag": "Abbotsford-(NSW)\\organic\\type-organic_rg17_ra23_roofrepairskew.md"
    },
    "result": [
        {
            "crawl_progress": "finished",
            "crawl_status": {
                "max_crawl_pages": 1,
                "pages_in_queue": 0,
                "pages_crawled": 1
            },
            "items_count": 1,
            "items": [
                {
                    "type": "content_parsing_element",
                    "fetch_time": "2026-01-19 03:27:50 +00:00",
                    "status_code": 200,
                    "page_content": {
                        "header": {
                            "primary_content": null,
                            "secondary_content": [
                                {
                                    "text": "ROOF REPAIRS",
                                    "url": "https://roofrepairskew.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-repairs/",
                                            "anchor_text": "ROOF REPAIRS"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF RESTORATIONS",
                                    "url": "https://roofrepairskew.com.au/roof-restoration-kew/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-restoration-kew/",
                                            "anchor_text": "ROOF RESTORATIONS"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF REPLACEMENT",
                                    "url": "https://roofrepairskew.com.au/roof-replacement-kew/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-replacement-kew/",
                                            "anchor_text": "ROOF REPLACEMENT"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF GUTTER & DOWNPIPE",
                                    "url": "https://roofrepairskew.com.au/roof-gutter-down-pipe/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-gutter-down-pipe/",
                                            "anchor_text": "ROOF GUTTER & DOWNPIPE"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF METAL/COLORBOND ROOF",
                                    "url": "https://roofrepairskew.com.au/roof-metal-colorbond-roof-kew/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-metal-colorbond-roof-kew/",
                                            "anchor_text": "ROOF METAL/COLORBOND ROOF"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF PLUMBER",
                                    "url": "https://roofrepairskew.com.au/roof-plumber-kew/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-plumber-kew/",
                                            "anchor_text": "ROOF PLUMBER"
                                        }
                                    ]
                                },
                                {
                                    "text": "KEW EAST",
                                    "url": "https://roofrepairskew.com.au/roof-repairs-kew-east/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-repairs-kew-east/",
                                            "anchor_text": "KEW EAST"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF REPAIRS",
                                    "url": "https://roofrepairskew.com.au/roof-repairs/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-repairs/",
                                            "anchor_text": "ROOF REPAIRS"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF RESTORATIONS",
                                    "url": "https://roofrepairskew.com.au/roof-restoration-kew/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-restoration-kew/",
                                            "anchor_text": "ROOF RESTORATIONS"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF REPLACEMENT",
                                    "url": "https://roofrepairskew.com.au/roof-replacement-kew/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-replacement-kew/",
                                            "anchor_text": "ROOF REPLACEMENT"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF GUTTER & DOWNPIPE",
                                    "url": "https://roofrepairskew.com.au/roof-gutter-down-pipe/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-gutter-down-pipe/",
                                            "anchor_text": "ROOF GUTTER & DOWNPIPE"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF METAL/COLORBOND ROOF",
                                    "url": "https://roofrepairskew.com.au/roof-metal-colorbond-roof-kew/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-metal-colorbond-roof-kew/",
                                            "anchor_text": "ROOF METAL/COLORBOND ROOF"
                                        }
                                    ]
                                },
                                {
                                    "text": "ROOF PLUMBER",
                                    "url": "https://roofrepairskew.com.au/roof-plumber-kew/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-plumber-kew/",
                                            "anchor_text": "ROOF PLUMBER"
                                        }
                                    ]
                                },
                                {
                                    "text": "KEW EAST",
                                    "url": "https://roofrepairskew.com.au/roof-repairs-kew-east/",
                                    "urls": [
                                        {
                                            "url": "https://roofrepairskew.com.au/roof-repairs-kew-east/",
                                            "anchor_text": "KEW EAST"
                                        }
                                    ]
                                }
                            ],
                            "table_content": null
                        },
                        "footer": null,
                        "main_topic": [
                            {
                                "h_title": "Our Expertise",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "20+ years roofing expertise in Abbotsford",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Quality roof maintenance and inspections",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "24/7 emergency roof repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter systems and downpipe installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof replacement when repair isn't viable",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof flashing and rainwater harvesting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Guaranteed work with follow-up",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Compliant with Victorian regulations",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Specialised solutions for Melbourne's climate",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fully licensed and insured",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Transparent pricing",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "How We Can Help You",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Our extensive network of certified professionals ensures that you receive reliable and safe service tailored to your specific needs. Whether it\u2019s a minor repair or a complete roof replacement, our contractors are equipped to handle projects of all sizes with precision and care.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our services encompass a wide range of roofing solutions, including metal roofing installation, gutter and downpipe services, and roof painting.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We also specialize in terracotta roof restoration and the installation of leaf guards and roof ventilators, ensuring your home is protected and energy-efficient.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With over 15 years of experience in the industry, TMR Roof Repairs Kew has built a reputation for excellence and customer satisfaction. We understand the importance of a well-maintained roof and are committed to delivering results that exceed your expectations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our 24/7 availability means we\u2019re always ready to address your roofing concerns promptly and efficiently.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "TMR Roof Repairs Kew, we pride ourselves on connecting you with top-tier roofing contractors who are committed to delivering exceptional roof repair and restoration services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "What Our Customers Are Saying...",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "\"TMR Roof Repairs Kew exceeded our expectations in Abbotsford. The quality of work was top-notch!\"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"Professional and efficient service from TMR. Our roof is now leak-free!\"",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "\"TMR Roof Repairs did a fantastic job. Highly recommend their services!\"",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Our Services In Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Full Roof Replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal Roof Repair",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "TMR Roof Plumbing specializes in comprehensive roofing solutions tailored to meet the diverse needs of our clients in Abbotsford Vic. Our expert team is adept at managing various services, including gutter systems, roof plumbing repairs, and roof ventilation, ensuring your home remains protected throughout the year. We pride ourselves on providing customized solutions for unique roofing challenges while maintaining compliance with regulatory standards.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leak Repair",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Shingle Replacement",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Structural Repairs",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Painting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaf Guard Installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Ventilator/Whirlybird Installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Terracotta Roof Restoration",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Recoating",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Roof Painting",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal Roofing Installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Colorbond Roof Installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Downpipe Installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gutter Cleaning",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaf Guard Installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Metal Roofing Installation",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Colorbond Roof Installation",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": [
                                    {
                                        "header": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Main Service",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Sub-Services",
                                                        "urls": null,
                                                        "is_header": true
                                                    }
                                                ]
                                            }
                                        ],
                                        "body": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Roof Repairs",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Leak Repair\nShingle Replacement\nStructural Repairs\nRoof Painting\nLeaf Guard Installation\nRoof Ventilator/Whirlybird Installation",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Roof Restoration",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Terracotta Roof Restoration\nRoof Cleaning\nRoof Recoating\nRoof Painting",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Roof Replacement",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Full Roof Replacement\nMetal Roofing Installation\nColorbond Roof Installation",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Roof Gutter & Downpipe",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Gutter Installation\nDownpipe Installation\nGutter Cleaning\nLeaf Guard Installation",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Roof Metal/Colorbond Roof",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Metal Roofing Installation\nColorbond Roof Installation\nMetal Roof Repair",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            }
                                        ],
                                        "footer": null
                                    }
                                ]
                            },
                            {
                                "h_title": "Our Range of Services",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Every roofing project is unique, and at TMR Roof Plumbing, we\u2019re ready for any challenge. Our skilled contractors have the expertise to handle everything from large industrial jobs to residential tasks, always with the same level of dedication. We\u2019re committed to doing our best and going the extra mile\u2014that\u2019s our promise to you",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "History of Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "Abbotsford, located in Melbourne, Victoria, was originally occupied by the Wurundjeri people, known as Carran-caramel in their language, and was first subdivided in 1838.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The suburb was named after Abbotsford House, built by John Orr, and experienced significant growth with land auctions in the 1850s, attracting residents and businesses.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The Abbotsford Convent, founded in 1863 by the Sisters of the Good Shepherd, served as a major charitable institution, accommodating thousands of women and children for over a century.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The area underwent gentrification in the 1980s, transforming it into a residential and industrial suburb, with a growing cultural and artistic community centred around the Convent.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Today, Abbotsford is known for its diverse community, historical significance, and the vibrant Abbotsford Convent arts precinct.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best Roof Repair in Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We\u2019re the trusted choice for roof repairs in Abbotsford, and for good reason. Our team of experienced and licensed professionals has expertise in all types of roofing, from tiles to Colorbond, and we only use high-quality materials to guarantee lasting results.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Whether you need emergency roof repairs or routine roof maintenance, we\u2019re here to deliver prompt and reliable service, every time.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best Roof Repair in Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "TMR Roof Repairs Kew comprises experienced and licensed professionals who\u2019ve been servicing Melbourne and surrounding suburbs for over 20 years.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "With extensive experience in the industry, our team at TMR Roof Repairs Kew has developed a thorough understanding of various roofing types, including tiles, Colorbond, and more.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We believe that the right materials make all the difference in achieving exceptional results. That\u2019s why we invest in premium materials that meet the highest standards of quality and performance.\u00a0We use materials that are resistant to weathering, corrosion, and damage, assuring your roof remains secure and intact for years to come.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team of experts combines innovative materials with proven methods to deliver exceptional results. We use the latest technology to detect and fix even the smallest issues, preventing them from becoming major problems.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Leaks in the middle of the night, storm damage, or sudden structural issues \u2013 roof emergencies can happen anytime. At TMR Roof Repairs Kew, we provide 24/7 prompt and reliable service to address these unexpected situations and prevent further damage to your property.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our fully licensed and insured team is trained to respond quickly and effectively, ensuring your safety and minimizing disruptions to your daily life.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "TMR Roof Repairs Kew is committed to providing affordable solutions that fit your budget. We believe in transparent pricing, so you\u2019ll never be surprised by hidden costs or fees.\u00a0We work closely with you to develop a budget plan that meets your needs and guarantees your roof receives the necessary repairs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our team takes the time to listen to your concerns, answer your questions, and provide personalized solutions that meet your needs. Our customers rave about our attention to detail, professionalism, and commitment to quality.\u00a0We\u2019re proud to have built a loyal customer base, with many referring their friends and family to us.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Free Consultation and Inspection",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We'll schedule a convenient on-site inspection to assess your roof for damage, leaks, and potential issues.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Followed by Detailed Quotation",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We provide a detailed, itemized quote outlining all work, materials, labor, and timelines in clear, understandable sections.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Scheduled Repair Work",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We'll schedule the work to minimize disruption to your routine while ensuring your roof gets the necessary attention.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Quality Check and Clean-Up",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We perform rigorous quality checks after each roof repair, ensuring all materials and workmanship meet our high standards.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Follow-up and Warranty Information",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": [
                                    {
                                        "text": "We stand behind our work with a guarantee, and we're dedicated to guaranteeing that you're completely satisfied with the results.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Contact Us",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We\u2019re available 24/7 to address your roofing needs, whether it\u2019s a simple roof leak repair or a complete roof restoration. Our network of professional roofing contractors is just a phone call or email away, ready to provide expert advice and affordable roof repair solutions.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Don\u2019t let roofing issues compromise your home\u2019s integrity; reach out to TMR Roof Repairs Kew today for reliable, high-quality roofing services that protect your investment and provide peace of mind.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "You can call us or send an email to tmr@roofrepairskew.com.au. We pride ourselves on prompt responses and efficient service, ensuring your residential roof repair concerns are addressed quickly.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Our experienced staff will guide you through the process, from initial consultation to project completion.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Frequently Asked Questions About Roof Repairs Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": [
                                    {
                                        "text": "We offer roof repairs, roof restoration, roof replacement, metal roofing installation, gutter and downpipe services, roof painting, terracotta roof restoration, leaf guard installation, roof ventilator/whirlybird installation, and commercial roofing services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "The cost of roof repairs varies widely based on the damage and the specific roofing materials used. A professional inspection will provide a more accurate estimate.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Look for signs such as water stains on ceilings, missing shingles, or increased energy bills.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Most minor repairs can be completed within a day, while more extensive work may take several days.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We have been operating for over 15 years, providing reliable and high-quality roofing services.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we offer a range of commercial roofing services tailored to meet business needs.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We work with various roofing materials, including metal and terracotta, and offer Colorbond roof installations.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we provide comprehensive gutter and downpipe services to ensure proper water drainage and roof maintenance.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yes, we offer professional roof painting services to enhance the appearance and longevity of your roof.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            }
                        ],
                        "secondary_topic": [
                            {
                                "h_title": "Roof Repairs Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "For more urgent roof enquiries, give us a bell at 0483-982-422",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Expert Roof Repairs in Abbotsford Vic. Trust our certified roofers for quality service. Call us today at 0483-982-422 for a free consultation!",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "GET IN TOUCH!",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "More than a year since your last roof check? Protect your loved ones and prevent costly damages by getting a free roof inspection! Fill out the form below to get get a free quote & roof inspection.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Affordable Roof Repairs Abbotsford Vic",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "TMR Roof Repairs Kew is your trusted partner for all your roofing needs in Melbourne. With over 15 years of experience, we connect you with top-tier roofing contractors who provide exceptional roof repair and restoration services. Our commitment ensures that you receive reliable and safe service from certified professionals dedicated to meeting your specific requirements.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We take pride in our extensive network of skilled contractors who focus on delivering outstanding results. Our team is well-equipped to handle a variety of roofing projects, from minor repairs to complete roof overhauls. We emphasize quality and customer satisfaction, making sure your experience with us is seamless and stress-free.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Available 24/7, our friendly and approachable team is always ready to assist you with any roofing concerns. At TMR Roof Repairs Kew, we understand the importance of local expertise and tailored solutions, so you can trust us to care for your roofing needs with the utmost professionalism and attention.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Schedule Your Free Roof Inspection Today!",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 1,
                                "primary_content": [
                                    {
                                        "text": "79-83 High St, Kew VIC 3101",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": [
                                    {
                                        "text": "Submit the form and one of our friendly staff will get back to you as soon as possible! Feel free to also give us a call at",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "COMMITMENT TO QUALITY",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Fancy a Roof Service?",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "We'll give you a hand",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Disclaimer: The content on TMR Roof Repairs Kew website serves general informational purposes. While efforts are made for accuracy, we assume no liability for reliance on this information. External links are provided for convenience, and we do not endorse or control the content on those sites.",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Privacy Policy",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "About Us",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "TMR Roof Repairs Kew collaborates with roofing contractors to deliver high-quality roof repair and restoration services in Melbourne. We connect our clients with professional roofing contractors to ensure they receive reliable and safe service from certified roofers. Our network includes contractors who provide services such as roof repairs, roof restoration, roof replacement, metal roofing installation, gutter and downpipe services, roof painting, terracotta roof restoration, leaf guard installation, roof ventilator/whirlybird installation, and commercial roofing services.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Repairs",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Repairs",
                                        "url": "https://roofrepairskew.com.au/roof-repairs/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairskew.com.au/roof-repairs/",
                                                "anchor_text": "Roof Repairs"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Restoration",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Restoration",
                                        "url": "https://roofrepairskew.com.au/roof-restoration-kew/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairskew.com.au/roof-restoration-kew/",
                                                "anchor_text": "Roof Restoration"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Replacement",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Replacement",
                                        "url": "https://roofrepairskew.com.au/roof-replacement-kew/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairskew.com.au/roof-replacement-kew/",
                                                "anchor_text": "Roof Replacement"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Gutter & Down Pipe",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Gutter & Down Pipe",
                                        "url": "https://roofrepairskew.com.au/roof-gutter-down-pipe/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairskew.com.au/roof-gutter-down-pipe/",
                                                "anchor_text": "Roof Gutter & Down Pipe"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Roof Metal/Colorbond Roof",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Roof Metal/Colorbond Roof",
                                        "url": "https://roofrepairskew.com.au/roof-metal-colorbond-roof-kew/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairskew.com.au/roof-metal-colorbond-roof-kew/",
                                                "anchor_text": "Roof Metal/Colorbond Roof"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "Schedule a free roof inspection in Kew and surrounding suburbs!",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Neighborhoods In Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Central Abbotsford",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Abbotsford Convent",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yarra Bend Park",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Studley Park",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Victoria Park",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Gipps Street",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Langridge Street",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Yarra Riverfront",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Victoria Street",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Johnston Street",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Hoddle Street",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Trenerry Crescent",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "WHY CHOOSE TMR Roof Repairs Kew",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Best Roof Repair in Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Things To Do In Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": [
                                    {
                                        "header": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Attraction/Activity",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Description",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Insider Tips",
                                                        "urls": null,
                                                        "is_header": true
                                                    }
                                                ]
                                            }
                                        ],
                                        "body": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Abbotsford Convent",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "A historic arts and cultural precinct offering galleries, gardens, and cafes.",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Visit on weekends for the farmers\u2019 market and enjoy a picnic in the gardens.",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Collingwood Children\u2019s Farm",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "A working farm where visitors can interact with animals and enjoy farm life.",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Attend the monthly farmers\u2019 market for fresh produce and local crafts.",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Yarra Bend Park",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "A large park with walking trails, picnic areas, and views of the Yarra River.",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Explore the Dights Falls and bring binoculars for birdwatching opportunities.",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            }
                                        ],
                                        "footer": null
                                    }
                                ]
                            },
                            {
                                "h_title": "Our Process",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": [
                                    {
                                        "text": "When you choose TMR Roof Repairs Kew, we\u2019ll start with an initial consultation and inspection to assess your roof\u2019s unique needs, followed by a detailed quotation outlining the scope of work and costs.\u00a0From there, we\u2019ll work with you to schedule the repair work, ensuring minimal disruption to your daily routine.",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "secondary_content": null,
                                "table_content": null
                            },
                            {
                                "h_title": "Top Sites In Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": [
                                    {
                                        "header": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Tourist Site Name",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Description",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Key Highlights",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Visitor Statistics",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Unique Features",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Google Maps Link",
                                                        "urls": null,
                                                        "is_header": true
                                                    }
                                                ]
                                            }
                                        ],
                                        "body": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "BalloonMan",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Hot air balloon ride tour agency",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Free champagne breakfast, scenic views",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "4.9 (706 reviews)",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Best hot air balloon experience in Melbourne",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "BalloonMan",
                                                        "urls": [
                                                            {
                                                                "url": "https://www.google.com/maps/place/BalloonMan/data=!4m7!3m6!1s0x6ad642ff8193a065:0x43ab0de559b7b576!8m2!3d-37.810313!4d145.004964",
                                                                "anchor_text": "BalloonMan"
                                                            }
                                                        ],
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Abbotsford Convent",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Cultural center in a historical setting",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Art exhibitions, gardens, and cafes",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "4.7 (2,210 reviews)",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Historical architecture, community events",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Abbotsford Convent",
                                                        "urls": [
                                                            {
                                                                "url": "https://www.google.com/maps/place/Abbotsford+Convent/data=!4m7!3m6!1s0x6ad6430738fab4cd:0xdb76f953991f8b47!8m2!3d-37.8022293!4d145.0038689",
                                                                "anchor_text": "Abbotsford Convent"
                                                            }
                                                        ],
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Dights Falls",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Picturesque waterfalls",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Scenic views, picnic areas",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "4.6 (330 reviews)",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Natural beauty, framed by cliffs and eucalyptus trees",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Dights Falls",
                                                        "urls": [
                                                            {
                                                                "url": "https://www.google.com/maps/place/Dights+Falls/data=!4m7!3m6!1s0x6ad64308a1fc6ee9:0x7d4cf5d64e69c212!8m2!3d-37.7970165!4d145.0011326",
                                                                "anchor_text": "Dights Falls"
                                                            }
                                                        ],
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Collingwood Children\u2019s Farm",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Nonprofit farm with animals",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Interactive animal experiences, cafe",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "4.4 (2,403 reviews)",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Family-friendly, educational programs for children",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Collingwood Children\u2019s Farm",
                                                        "urls": [
                                                            {
                                                                "url": "https://www.google.com/maps/place/Collingwood+Children%27s+Farm/data=!4m7!3m6!1s0x6ad643077cc3be07:0xb95f6b8be886bcc2!8m2!3d-37.8026055!4d145.0053048",
                                                                "anchor_text": "Collingwood Children\u2019s Farm"
                                                            }
                                                        ],
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Gahan Reserve",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Public park with recreational facilities",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Off-leash dog area, basketball court",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "4.4 (160 reviews)",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Spacious green area, suitable for picnics and sports",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Gahan Reserve",
                                                        "urls": [
                                                            {
                                                                "url": "https://www.google.com/maps/place/Gahan+Reserve/data=!4m7!3m6!1s0x6ad64302b507cc89:0xf04567605318460!8m2!3d-37.8034436!4d144.9944611",
                                                                "anchor_text": "Gahan Reserve"
                                                            }
                                                        ],
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Cooks\u2019 Cottage",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Historical cottage of Captain James Cook\u2019s family",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Authentic 18th-century architecture",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "4.3 (1,924 reviews)",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Replica of a historical English cottage",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Cooks\u2019 Cottage",
                                                        "urls": [
                                                            {
                                                                "url": "https://www.google.com/maps/place/Cooks%27+Cottage/data=!4m7!3m6!1s0x6ad642c16b43fd15:0xf4b9cf4b894015ef!8m2!3d-37.8145006!4d144.9794476",
                                                                "anchor_text": "Cooks\u2019 Cottage"
                                                            }
                                                        ],
                                                        "is_header": false
                                                    }
                                                ]
                                            }
                                        ],
                                        "footer": null
                                    }
                                ]
                            },
                            {
                                "h_title": "Transportation in Abbotsford",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 2,
                                "primary_content": null,
                                "secondary_content": null,
                                "table_content": [
                                    {
                                        "header": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Station/Stop Name",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Type",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Address",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Lines/Routes Served",
                                                        "urls": null,
                                                        "is_header": true
                                                    },
                                                    {
                                                        "text": "Facilities Available",
                                                        "urls": null,
                                                        "is_header": true
                                                    }
                                                ]
                                            }
                                        ],
                                        "body": [
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Victoria Park Railway Station",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Train",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Johnston St / Lulie St",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Train Lines",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Shelter, Ticketing, Restroom",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "19-Abbotsford St Interchange/Abbotsford St",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Tram",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Abbotsford St (North Melbourne)",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Tram Lines",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Shelter, Seating",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Abbotsford St/Queensberry St",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Tram",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Abbotsford St / Queensberry St",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Tram Lines",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Shelter, Seating",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Truro St/Hoddle St",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Bus",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Truro St / Hoddle St",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Bus Routes",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Shelter",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Victoria Park Train Station",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Train",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Victoria Park",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Train Lines",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Shelter, Ticketing, Restroom",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            },
                                            {
                                                "row_cells": [
                                                    {
                                                        "text": "Haines St/Abbotsford St",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Bus",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Haines St / Abbotsford St",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Bus Routes",
                                                        "urls": null,
                                                        "is_header": false
                                                    },
                                                    {
                                                        "text": "Shelter",
                                                        "urls": null,
                                                        "is_header": false
                                                    }
                                                ]
                                            }
                                        ],
                                        "footer": null
                                    }
                                ]
                            },
                            {
                                "h_title": "Working Hours:",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 4,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Open 24 hours a day, 7 days a week",
                                        "url": null,
                                        "urls": null
                                    }
                                ],
                                "table_content": null
                            },
                            {
                                "h_title": "TMR Roof Repairs Kew",
                                "main_title": "Roof Repairs Abbotsford",
                                "author": null,
                                "language": "en",
                                "level": 3,
                                "primary_content": null,
                                "secondary_content": [
                                    {
                                        "text": "Address: 79-83 High St, Kew VIC 3101",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Phone: 0483-982-422",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Email: tmr@roofrepairskew.com.au",
                                        "url": null,
                                        "urls": null
                                    },
                                    {
                                        "text": "Website: https://roofrepairskew.com.au",
                                        "url": "https://roofrepairskew.com.au/",
                                        "urls": [
                                            {
                                                "url": "https://roofrepairskew.com.au/",
                                                "anchor_text": "https://roofrepairskew.com.au"
                                            }
                                        ]
                                    }
                                ],
                                "table_content": null
                            }
                        ],
                        "ratings": null,
                        "offers": null,
                        "comments": null,
                        "contacts": {
                            "telephones": [
                                "0483-982-422",
                                "0483982422",
                                "+61483982422"
                            ],
                            "emails": [
                                "tmr@roofrepairskew.com.au"
                            ]
                        }
                    },
                    "page_as_markdown": null
                }
            ]
        }
    ]
}